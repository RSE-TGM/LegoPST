C/**********************************************************************
C*
C*	F Source:		wad1.f
C*	Instance:		1
C*	Description:	
C*	%created_by:	cfb_int %
C*	%date_created:	Thu Oct 02 12:35:04 2003 %
C*
C**********************************************************************/
C***********************************************************
C*                                                         *
C*  modulo per la simulazione di cavita` contenenti acqua  *
C*  (nei due stati di liquido e vapore) e aria             *
C*                                                         *
C***********************************************************
C
      SUBROUTINE WAD1I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBL1,IBL2,IER,CNXYU,TOL)
C
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
      LOGICAL KREGIM
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
C
C
C---CAVITA' LIQUIDO ARIA VAPORE
C
      GO TO(100,200), IFUN
C
  100 CONTINUE
      WRITE(14,500)'G.Z.I.L.','G.Z.O.L.','L.Z.I.L.',
     $             'L.Z.O.L.','A.Z.I.L.','A.Z.O.L.',     
     $             'S.S.I.L.'     
      WRITE(14,500)'TYPE_CAV','VOL.CAV.','MISURA_Y',
     $             'X_OVER  ','X_UNDER ','ZERO_Y  ',
     $             'VOL_Y   ','GAMMA_Y ','SEZ_Y   '
      WRITE(14,500)'CV_SF   '
      RETURN
C
C---lettura e memorizzazione dati
C
  200 READ(14,501)
      READ(14,501) XNGZIL,XNGZOL,XNLZIL
      READ(14,501) XNLZOL,XNAZIL,XNAZOL
      READ(14,501) XSSIL
      READ(14,501) TYP,VCAV,FY,XOV,XUN,ZERY,VY,GY,SEZY
      READ(14,501) CV
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  501 FORMAT(3(14X,F10.0,1X))
C
C---  Come fattore di normalizzazione della massa di aria nella cavita`
C     si utilizza il valore della massa d'aria contenuta nella cavita`
C     alla pressione di 1. bar e alla temperatura di 293.15 K.
C     (precedente valore: AMA0=100.)
C
C     AMA0 = @V = P/(RT) = 1.E+05/(287.195*293.15)V = 1.1878*V
C
C---  Come fattore di normalizzazione della massa di vapore nella cavita`
C     si utilizza il valore della massa di vapore contenuta nella cavita`
C     alla pressione di 221.2 bar e alla temperatura di 647.34 K.
C
C     AMV0 = @V = 315.5*V
C
      NGZIL=XNGZIL
      NGZOL=XNGZOL
      NLZIL=XNLZIL
      NLZOL=XNLZOL
      NAZIL=XNAZIL
      NAZOL=XNAZOL
      NSSIL=XSSIL
C
      AML0=200.*VCAV
      AMA0=1.1878*VCAV
      AMV0=315.5*VCAV
C
      WAS0=1.
      WVS0=1.
      WCE0=1.
C
      DATI(ID2   ) = TYP
      DATI(ID2+1 ) = VCAV
      DATI(ID2+2 ) = FY
      DATI(ID2+3 ) = XOV/100.
      DATI(ID2+4 ) = XUN/100.
      DATI(ID2+5 ) = ZERY
      DATI(ID2+6 ) = VY
      DATI(ID2+7 ) = GY
      DATI(ID2+8 ) = SEZY
      DATI(ID2+9 ) = CV
      DATI(ID2+10) = 1.
      DATI(ID2+11) = 1.
      DATI(ID2+12) = AML0
      DATI(ID2+13) = AMA0
      DATI(ID2+14) = AMV0
      DATI(ID2+15) = WAS0
      DATI(ID2+16) = WVS0
      DATI(ID2+17) = WCE0
      DATI(ID2+18) = NGZIL
      DATI(ID2+19) = NGZOL
      DATI(ID2+20) = NLZIL
      DATI(ID2+21) = NLZOL
      DATI(ID2+22) = NAZIL
      DATI(ID2+23) = NAZOL
      DATI(ID2+24) = NSSIL
      ID2 = ID2+24
C
C---costanti di normalizzazione
C
C---- Output Variables
C
      CNXYU(IV1  ) = P0
      CNXYU(IV1+1) = H0
      CNXYU(IV1+2) = H0
      CNXYU(IV1+3) = AMA0
      CNXYU(IV1+4) = AML0
      CNXYU(IV1+5) = AMV0
      CNXYU(IV1+6) = 100.
      CNXYU(IV1+7) = P0
      CNXYU(IV1+8) = P0
      CNXYU(IV1+9) = P0
      CNXYU(IV1+10) = WAS0
      CNXYU(IV1+11) = WVS0
      CNXYU(IV1+12) = T0
      CNXYU(IV1+13) = T0
C
      IV1P13 = IV1+13
C
C---- Input Variables
C
C     CNXYU(IV1+14) = W0
C     CNXYU(IV1+15) = H0
C
      NSSIL2=2*NSSIL
C
      DO I=1,NSSIL2,2
         CNXYU(IV1P13+I) = W0
         CNXYU(IV1P13+I+1) = H0
      END DO
C
      IV1P15 = IV1P13+NSSIL2
C
      NGZIL2=2*NGZIL
C
      DO I=1,NGZIL2,2
         CNXYU(IV1P15+I) = W0
         CNXYU(IV1P15+I+1) = H0
      END DO
C
      NGZOL2=2*NGZOL
C
      DO I=1,NGZOL2,2
         CNXYU(IV1P15+NGZIL2+I) = W0
         CNXYU(IV1P15+NGZIL2+I+1) = H0
      END DO
C
      NGZIOL2=NGZIL2+NGZOL2
C
      NLZIL2=2*NLZIL
C
      DO I=1,NLZIL2,2
         CNXYU(IV1P15+NGZIOL2+I) = W0
         CNXYU(IV1P15+NGZIOL2+I+1) = H0
      END DO
C
      NLZOL2=2*NLZOL
C
      DO I=1,NLZOL2,2
         CNXYU(IV1P15+NGZIOL2+NLZIL2+I) = W0
         CNXYU(IV1P15+NGZIOL2+NLZIL2+I+1) = H0
      END DO
C
      NLZIOL2=NLZIL2+NLZOL2
C
      NAZIL2=2*NAZIL
C
      DO I=1,NAZIL2,2
         CNXYU(IV1P15+NGZIOL2+NLZIOL2+I) = W0
         CNXYU(IV1P15+NGZIOL2+NLZIOL2+I+1) = T0
      END DO
C
      NAZOL2=2*NAZOL
C
      DO I=1,NAZOL2,2
         CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIL2+I) = W0
         CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIL2+I+1) = T0
      END DO
C      
      NAZIOL2=NAZIL2+NAZOL2
C
      CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIOL2+1) = W0*H0
      CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIOL2+2) = W0*H0
      CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIOL2+3) = 1.
      CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIOL2+4) = P0
      CNXYU(IV1P15+NGZIOL2+NLZIOL2+NAZIOL2+5) = T0
C
C    maggiore tolleranza sul livello se misurato come quota del pelo
C    libero del liquido
C
      IF(FY.GT.0.) TOL(6)=1.E-03
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
      SUBROUTINE WAD1I3(IFO,IOB,DEBL)
C
      COMMON/WAD100/IBLOC,NGZIL,NGZOL,NLZIL,NLZOL,NAZIL,NAZOL,NSSIL
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'WAD1'/
C
      CALL WAD1I4(IOB,MOD)
      NSTATI = 5
      NUSCIT = 9
      NINGRE = 2*(1+NGZIL+NGZOL+NLZIL+NLZOL+NAZIL+NAZOL+NSSIL)+3
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
      WRITE(IFO,3000)
     $ 'PCAV',IOB,'US','GLOBAL PRESSURE INSIDE THE CAVITY',
     $ 'HVCA',IOB,'US','SPECIFIC ENTHALPY OF THE STEAM',
     $ 'HLCA',IOB,'US','SPECIFIC ENTHALPY OF THE LIQUID',
     $ 'MASA',IOB,'US','MASS OF AIR INSIDE THE CAVITY',
     $ 'MLCA',IOB,'US','LIQUID MASS INSIDE THE CAVITY',
     $ 'MVCA',IOB,'UA','STEAM MASS INSIDE THE CAVITY',               
     $ 'LIVC',IOB,'UA','LIQUID LEVEL INSIDE THE CAVITY',
     $ 'PFCA',IOB,'UA','PRESSURE AT THE BOTTOM OF THE CAVITY',
     $ 'PPAC',IOB,'UA','PARTIAL PRESSURE OF THE AIR IN THE CAVITY',
     $ 'PPVC',IOB,'UA','PARTIAL PRESSURE OF THE STEAM IN THE CAVITY',
     $ 'WASC',IOB,'UA','AIR FLOW RATE EXITING THROUGH VENTING VALVE',
     $ 'WVUS',IOB,'UA','STEAM FLOW RATE EXITING THROUGH VENTING VALVE',
     $ 'TLCA',IOB,'UA','LIQUID TEMPERATURE',
     $ 'TVCA',IOB,'UA','STEAM-AIR TEMPERATURE'
C
      DO J=1,NSSIL
        WRITE(IFO,3010)
     $ 'WM',J,IOB,'IN','STEAM SEPARATOR INLET LINE N.',J,
     $                 ' LIQUID-STEAM MIX FLOW RATE',
     $ 'HM',J,IOB,'IN','STEAM SEPARATOR INLET LINE N.',J,
     $                 ' LIQUID-STEAM MIX ENTHALPY'
      END DO
C
      DO J=1,NGZIL
        WRITE(IFO,3010)
     $ 'WG',J,IOB,'IN','GAS ZONE INLET LINE N.',J,
     $                 ' LIQUID-STEAM FLOW RATE',
     $ 'HG',J,IOB,'IN','GAS ZONE INLET LINE N.',J,
     $                 ' LIQUID-STEAM ENTHALPY'
      END DO 
C
      DO J=1,NGZOL
        WRITE(IFO,3010)
     $ 'WS',J,IOB,'IN','GAS ZONE OUTLET LINE N.',J,' STEAM FLOW RATE',
     $ 'HS',J,IOB,'IN','GAS ZONE OUTLET LINE N.',J,
     $                 ' REVERSE FLOW STEAM ENTHALPY'
      END DO
C
      DO J=1,NLZIL
        WRITE(IFO,3010)
     $ 'WL',J,IOB,'IN','LIQUID ZONE INLET LINE N.',J,
     $                 ' LIQUID-STEAM FLOW RATE',
     $ 'HL',J,IOB,'IN','LIQUID ZONE INLET LINE N.',J,
     $                 ' LIQUID-STEAM ENTHALPY'
      END DO
C
      DO J=1,NLZOL
        WRITE(IFO,3010)
     $ 'WW',J,IOB,'IN','LIQUID ZONE OUTLET  N.',J,' LIQUID FLOW RATE',
     $ 'HW',J,IOB,'IN','LIQUID ZONE OUTLET  N.',J,
     $                 ' REVERSE FLOW LIQUID ENTHALPY'
      END DO
C
      DO J=1,NAZIL
        WRITE(IFO,3010)
     $ 'WA',J,IOB,'IN','AIR ZONE INLET LINE N.',J,
     $                 ' AIR FLOW RATE',
     $ 'TA',J,IOB,'IN','AIR ZONE INLET LINE N.',J,
     $                 ' AIR TEMPERATURE'
      END DO
C
      DO J=1,NAZOL
        WRITE(IFO,3010)
     $ 'WU',J,IOB,'IN','AIR ZONE OUTLET  N.',J,' AIR FLOW RATE',
     $ 'TU',J,IOB,'IN','AIR ZONE OUTLET  N.',J,
     $                 ' REVERSE FLOW AIR TEMPERATURE'
      END DO
C
      WRITE(IFO,3000)
     $ 'QGZP',IOB,'IN','GAS ZONE FURTHER EXCHANGED POWER',
     $ 'QLZP',IOB,'IN','LIQUID ZONE FURTHER EXCHANGED POWER',
     $ 'ALZS',IOB,'IN','VALVE LIFT OF THE VENTING  VALVE',
     $ 'PVVS',IOB,'IN','PRESSURE DOWNSTREAM THE VENTING  VALVE',
     $ 'TAIS',IOB,'IN','TEMPERATURE OF AIR FROM THE VENTING VALVE'
C
      RETURN
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
 3000 FORMAT(2A4,'  --',A2,'-- ',A)
 3010 FORMAT(1A2,I2,1A4,'  --',A2,'-- ',A,I2,A)
      END
C
C/**********************************************************************
C/**********************************************************************
C
      SUBROUTINE WAD1I4(IOB,MOD)
      COMMON/WAD100/IBLOC,NGZIL,NGZOL,NLZIL,NLZOL,NAZIL,NAZOL,NSSIL
      CHARACTER*4 IOB, MOD, IBLOC*8
      PARAMETER(MAXLZN=30)
C
      WRITE(6,100) MAXLZN-2
  100 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF STEAM SEPARATOR INLET LINES [01 -',I3,'] ?')
  20  CONTINUE
      READ(5,*) NSSIL
      IF(NSSIL.LT.1.OR.NSSIL.GT.MAXLZN-2) THEN
      WRITE(6,112) NSSIL,MAXLZN-2
  112 FORMAT(10X,'ERROR - NUMBER OF STEAM SEPARATOR INLET LINES =',I3,/,
     $       10X,'Number of steam separator inlet lines out of range',/,
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 20
      ENDIF
C
      WRITE(6,101) MAXLZN-NSSIL-2
  101 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF GAS ZONE INLET LINES [00 -',I3,'] ?')
  10  CONTINUE
      READ(5,*) NGZIL
      IF(NGZIL.LT.0.OR.NGZIL.GT.MAXLZN-NSSIL-2) THEN
      WRITE(6,102) NGZIL,MAXLZN-NSSIL-2
  102 FORMAT(10X,'ERROR - NUMBER OF GAS ZONE INLET LINES =',I3,/,
     $       10X,'Number of gas zone inlet lines out of range',/,
     $       10X,'Please reassigne data in range [00 -',I3,']')
      GOTO 10
      ENDIF
C
      WRITE(6,103) MAXLZN-NSSIL-NGZIL-1
  103 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF GAS ZONE OUTLET LINES [01 -',I3,'] ?')
  11  CONTINUE
      READ(5,*) NGZOL
      IF(NGZOL.LE.0.OR.NGZOL.GT.MAXLZN-NSSIL-NGZIL-1) THEN
      WRITE(6,104) NGZOL,MAXLZN-NSSIL-NGZIL-1
  104 FORMAT(10X,'ERROR - NUMBER OF GAS ZONE OUTLET LINES =',I3,/
     $       10X,'Number of gas zone outlet lines out of range',/
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 11
      ENDIF
C
      WRITE(6,105) MAXLZN-NSSIL-NGZIL-NGZOL-1
  105 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF LIQUID ZONE INLET LINES [00 -',I3,'] ?')
  12  CONTINUE
      READ(5,*) NLZIL
      IF(NLZIL.LT.0.OR.NLZIL.GT.MAXLZN-NSSIL-NGZIL-NGZOL-1) THEN
      WRITE(6,106) NLZIL,MAXLZN-NSSIL-NGZIL-NGZOL-1
  106 FORMAT(10X,'ERROR - NUMBER OF LIQUID ZONE INLET LINES =',I3,/
     $       10X,'Number of liquid zone inlet lines out of range',/
     $       10X,'Please reassigne data in range [00 -',I3,']')
      GOTO 12
      ENDIF
C
      WRITE(6,107) MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL
  107 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF LIQUID ZONE OUTLET LINES [01 -',I3,'] ?')
  13  CONTINUE
      READ(5,*) NLZOL
      IF(NLZOL.LE.0.OR.NLZOL.GT.MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL) THEN
      WRITE(6,108) NLZOL,MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL
  108 FORMAT(10X,'ERROR - NUMBER OF LIQUID ZONE OUTLET LINES =',I3,/
     $       10X,'Number of liquid zone outlet lines out of range',/
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 13
      ENDIF
C
      WRITE(6,201) MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL-NLZOL-1
  201 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF AIR ZONE INLET LINES [00 -',I3,'] ?')
  14  CONTINUE
      READ(5,*) NAZIL
      IF(NAZIL.LT.0.OR.NAZIL.GT.MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL
     $                                              -NLZOL-1) THEN
      WRITE(6,202) NLZIL,MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL-NLZOL-1
  202 FORMAT(10X,'ERROR - NUMBER OF AIR ZONE INLET LINES =',I3,/
     $       10X,'Number of air zone inlet lines out of range',/
     $       10X,'Please reassigne data in range [00 -',I3,']')
      GOTO 14
      ENDIF
C
      WRITE(6,203) MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL-NLZOL-NAZIL
  203 FORMAT(10X,'WATER AIR STEAM DRUM'/
     $       10X,'NUMBER OF AIR ZONE OUTLET LINES [00 -',I3,'] ?')
  15  CONTINUE
      READ(5,*) NAZOL
      IF(NAZOL.LT.0.OR.NAZOL.GT.MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL
     $                         -NLZOL-NAZIL) THEN
      WRITE(6,204) NLZOL,MAXLZN-NSSIL-NGZIL-NGZOL-NLZIL
     $                                               -NLZOL-NAZIL
  204 FORMAT(10X,'ERROR - NUMBER OF AIR ZONE OUTLET LINES =',I3,/
     $       10X,'Number of air zone outlet lines out of range',/
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 15
      ENDIF
C--
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
      SUBROUTINE WAD1C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/NEQUAZ/NEQMOD
      COMMON/WAD1NQ/NEQ
      EXTERNAL WAD1
C
C
C---CAVITA' LIQUIDO ARIA VAPORE
C
C
C----NEQMOD = numero di equazioni algebriche in transitorio
C
C     NEQMOD=3
       NEQMOD=9
C
      IF(KREGIM) THEN
        NEQ=14
      ELSE
C       NEQ=8
         NEQ=14
      ENDIF
C
      NGZIL = DATI(IPD+18)
      NGZOL = DATI(IPD+19)
      NLZIL = DATI(IPD+20)
      NLZOL = DATI(IPD+21)
      NAZIL = DATI(IPD+22)
      NAZOL = DATI(IPD+23)
      NSSIL = DATI(IPD+24)
C
      NINGRE = 2*(1+NGZIL+NGZOL+NLZIL+NLZOL+NAZIL+NAZOL+NSSIL)+3
C
      NVARIABL=NEQ+NINGRE
C
      GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
C
  100 DO 10 I=1,NEQ
        DO 10 J=1,NVARIABL
          AJAC(I,J)=1.
   10 CONTINUE
      RETURN
C
C---calcolo residui
C
  200 CALL WAD1(IFUN,IXYU,XYU,IPD,DATI,RNI)
      RETURN
C
C---calcolo jacobiano numerico
C
  300 NSTATI = 5
      NUSCIT = 9
      EPS    = 1.E-3
      EPSLIM = 1.E-5
      CALL WAD1JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,WAD1)
      RETURN
C
      END
C
C/**********************************************************************
C/**********************************************************************
C
      SUBROUTINE WAD1JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      LOGICAL KREGIM
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/WAD1NQ/NEQ
C
      NRIG=NEQ
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
      DO 30 J=1,NCOL
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      IF(J.EQ.1.OR.J.EQ.8.OR.J.EQ.9.OR.J.EQ.10.OR.J.EQ.NCOL-1) THEN
C       VAR=EPS*XYU(IXYU+J-1)
C       IF(ABS(VAR).LT.VARP) VAR=VARP
        VAR=VARP
      ELSE 
        VAR=EPS*XYU(IXYU+J-1)
        IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
      ENDIF
C
      DO 10 K=1,NCOL
        CXYU(K)=XYU(IXYU+K-1)
        CCXYU(K)=XYU(IXYU+K-1)
        IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
        IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
   10 CONTINUE
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
      CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
      CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
      DO 20 I=1,NRIG
        AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
        IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
   20 CONTINUE
C
   30 CONTINUE
C
      IF(KREGIM.AND.XYU(IXYU+NCOL-3).LE.0.)AJAC(4,NCOL-1)=1.
C
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
      SUBROUTINE WAD1(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      DIMENSION XYU(*),DATI(*),RNI(*)
      PARAMETER(MAXLZN=30)
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/TOLEG00/TOLIN(100)
C
      COMMON /WAD1AR/ PPAC,TAIS,RA,CPA,ROA,WAUS,WAIS,ALZS,WASC,PVVS,
     $                MA,WAE(MAXLZN),TAE(MAXLZN),WAS(MAXLZN),TAS(MAXLZN)
C     COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,WMIC,HVS,HLSPPV,
C    $                HMIC,WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
      COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,HVS,HLSPPV,
     $                WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
     $                MVCA,TVS,PVTAV,HVTAV,TVCA,
     $                WG(MAXLZN),HG(MAXLZN),WS(MAXLZN),HS(MAXLZN),QGZP
      COMMON /WAD1LQ/ PCAV,HLCA,TL,SL,MLCA,VL,WEV,
     $                ROL,XL,HVSP,HLS,TAUL,PFCA,HAIC,LIV,HLSPSL,
     $                HVSPSL,PLTAV,HLTAV,TLCA,
     $                WL(MAXLZN),HL(MAXLZN),WW(MAXLZN),HW(MAXLZN),QLZP
      COMMON /WAD1MX/ WM(MAXLZN),HM(MAXLZN),WVM(MAXLZN),HVP(MAXLZN),
     $                WLM(MAXLZN),HLP(MAXLZN)
      COMMON /WAD1DT/ TYP,VCAV,FY,ZERY,VY,GY,SEZY,EMPTY,FULL,AML0,G,
     $                NFL,AMA0,AMV0,WAS0,WVS0,WCE0,NGZIL,NGZOL,NLZIL,
     $                NLZOL,NAZIL,NAZOL,NSSIL
      COMMON /WAD1ST/ IS
C
C
      REAL MA,MVCA,MLCA,LIV
C
      RA  = 287.195
      CPA = 1005.1825
      G   = 9.81
C
C---CAVITA' LIQUIDO ARIA VAPORE
C   calcolo residui
C
C---decodifica dati e variabili
C
      TYP   = DATI(IPD   )
      VCAV  = DATI(IPD+1 )
      FY    = DATI(IPD+2 )
      XOVP  = DATI(IPD+3 )
      XUNP  = DATI(IPD+4 )
      ZERY  = DATI(IPD+5 )
      VY    = DATI(IPD+6 )
      GY    = DATI(IPD+7 )
      SEZY  = DATI(IPD+8 )
      CV    = DATI(IPD+9 )
      EMPTY = DATI(IPD+10)
      FULL  = DATI(IPD+11)
      AML0  = DATI(IPD+12)
      AMA0  = DATI(IPD+13)
      AMV0  = DATI(IPD+14)
      WAS0  = DATI(IPD+15)
      WVS0  = DATI(IPD+16)
      WCE0  = DATI(IPD+17)
      NGZIL = DATI(IPD+18)
      NGZOL = DATI(IPD+19)
      NLZIL = DATI(IPD+20)
      NLZOL = DATI(IPD+21)
      NAZIL = DATI(IPD+22)
      NAZOL = DATI(IPD+23)
      NSSIL = DATI(IPD+24)
C
C----   Output variables
C
      PCAV = XYU(IXYU   )*P0
      HVCA = XYU(IXYU+1 )*H0
      HLCA = XYU(IXYU+2 )*H0
      MA   = XYU(IXYU+3 )*AMA0
      MLCA = XYU(IXYU+4 )*AML0
      MVCA = XYU(IXYU+5 )*AMV0
      LIV  = XYU(IXYU+6 )      
      PFCA = XYU(IXYU+7 )*P0
      PPAC = XYU(IXYU+8 )*P0
      PPVC = XYU(IXYU+9 )*P0
      WASC = XYU(IXYU+10)*WAS0
      WVUS = XYU(IXYU+11)*WVS0
      TLCA = XYU(IXYU+12)*T0
      TVCA = XYU(IXYU+13)*T0
C
C----   Input variables
C
C     WMIC = XYU(IXYU+14)*W0
C     HMIC = XYU(IXYU+15)*H0
C
      IXYUP13=IXYU+13
C
      NSSIL2=2*NSSIL
C
      DO I=1,NSSIL2,2
         K=INT(I/2.)+1
         WM(K) = XYU(IXYUP13+I)*W0
         HM(K) = XYU(IXYUP13+I+1)*H0
      END DO
C
      IXYUP15=IXYUP13+NSSIL2
C
      NGZIL2=2*NGZIL
C
      DO I=1,NGZIL2,2
         K=INT(I/2.)+1
         WG(K) = XYU(IXYUP15+I)*W0
         HG(K) = XYU(IXYUP15+I+1)*H0
      END DO
C
      NGZOL2=2*NGZOL
C
      DO I=1,NGZOL2,2
         K=INT(I/2.)+1
         WS(K) = XYU(IXYUP15+NGZIL2+I)*W0
         HS(K) = XYU(IXYUP15+NGZIL2+I+1)*H0
      END DO
C
      NGZIOL2=NGZIL2+NGZOL2
C
      NLZIL2=2*NLZIL
C
      DO I=1,NLZIL2,2
         K=INT(I/2.)+1
         WL(K) = XYU(IXYUP15+NGZIOL2+I)*W0
         HL(K) = XYU(IXYUP15+NGZIOL2+I+1)*H0
      END DO
C
      NLZOL2=2*NLZOL
C
      DO I=1,NLZOL2,2
         K=INT(I/2.)+1
         WW(K) = XYU(IXYUP15+NGZIOL2+NLZIL2+I)*W0
         HW(K) = XYU(IXYUP15+NGZIOL2+NLZIL2+I+1)*H0
      END DO
C
      NLZIOL2=NLZIL2+NLZOL2
C
C--OL
      NAZIL2=2*NAZIL
C
      DO I=1,NAZIL2,2
         K=INT(I/2.)+1
         WAE(K) = XYU(IXYUP15+NGZIOL2+NLZIOL2+I)*W0
         TAE(K) = XYU(IXYUP15+NGZIOL2+NLZIOL2+I+1)*T0
      END DO
C
      NAZOL2=2*NAZOL
C
      DO I=1,NAZOL2,2
         K=INT(I/2.)+1
         WAS(K) = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIL2+I)*W0
         TAS(K) = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIL2+I+1)*T0
      END DO
C
      NAZIOL2=NAZIL2+NAZOL2
C
      QGZP = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIOL2+1)*W0*H0
      QLZP = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIOL2+2)*W0*H0
      ALZS = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIOL2+3)
      PVVS = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIOL2+4)*P0
      TAIS = XYU(IXYUP15+NGZIOL2+NLZIOL2+NAZIOL2+5)*T0
C
C
      IF(PCAV.LT.1.5E5) THEN
        PPTOL=50./P0
      ELSE IF(PCAV.LT.5.E5) THEN
        PPTOL=100./P0
      ELSE
        PPTOL=1000./P0
      ENDIF
      TOLIN(1)=PPTOL
C
      IF(PPVC.LT.1.5E5) THEN
         PPTOLV=50./P0
      ELSE IF(PPVC.LT.5.E5) THEN
         PPTOLV=100./P0
      ELSE
         PPTOLV=1000./P0
      ENDIF
      TOLIN(10)=PPTOLV
C
      NFL=1
      IS=IFUN
C
C--- calcolo  delle proprieta` fisiche dei fluidi e delle grandezze che
C    compaiono nei termini noti delle equazioni:
C
C--- calcolo della temperatura dell'aria nella cavita`,
C    pari alla temperatura del vapore
C
C
C-----  Protezione per pressioni ed entalpie fuori range
C
      PVTAV=PPVC
      HVTAV=HVCA
C
      IF(PVTAV.LE.610.8) THEN
        PVTAV=610.8
C  25 ott. 2005        IF(HVTAV.LT.0.) HVTAV=0.
C  25 ott. 2005        IF(HVTAV.GT.4055.11E+03) HVTAV=4055.11E+03
      ELSE IF(PVTAV.GE.400.E+05) THEN
        PVTAV=400.E+05
C  25 ott. 2005        IF(HVTAV.LT.39.7452E+03) HVTAV=39.7452E+03
C  25 ott. 2005        IF(HVTAV.GT.3971.71E+03) HVTAV=3971.71E+03
C  25 ott. 2005      ELSE IF(HVTAV.LT.0.) THEN
C  25 ott. 2005        TTAV=275.16
C  25 ott. 2005	YTAV=1.
C  25 ott. 2005        STAV=STEV(PVTAV,TTAV,YTAV,1)
C  25 ott. 2005        HVTAV=HEV(PVTAV,STAV,1)
C        HVTAV=0.
C  25 ott. 2005      ELSE
C  25 ott. 2005        TTAV=1023.16
C  25 ott. 2005	YTAV=1.
C  25 ott. 2005        STAV=STEV(PVTAV,TTAV,YTAV,1)
C  25 ott. 2005        HMAX=HEV(PVTAV,STAV,1)
        IF(HVTAV.GT.HMAX) HVTAV=HMAX
C        IF(HVTAV.GT.3971.71E+03) HVTAV=3971.71E+03
      ENDIF
C
      PLTAV=PCAV
      HLTAV=HLCA
C
      IF(PLTAV.LE.610.8) THEN
        PLTAV=610.8
C  25 ott. 2005        IF(HLTAV.LT.0.) HLTAV=0.
C  25 ott. 2005        IF(HLTAV.GT.4055.11E+03) HLTAV=4055.11E+03
      ELSE IF(PLTAV.GE.400.E+05) THEN
        PLTAV=400.E+05
C  25 ott. 2005        IF(HLTAV.LT.39.7452E+03) HLTAV=39.7452E+03
C  25 ott. 2005        IF(HLTAV.GT.3971.71E+03) HLTAV=3971.71E+03
C  25 ott. 2005      ELSE IF(HLTAV.LT.0.) THEN
C  25 ott. 2005        TTAV=275.16
C  25 ott. 2005	YTAV=0.0001
C  25 ott. 2005        SLTAV=STEV(PLTAV,TTAV,YTAV,1)
C  25 ott. 2005        HLTAV=HEV(PLTAV,SLTAV,1)
C        HLTAV=0.
C  25 ott. 2005      ELSE
C  25 ott. 2005        TTAV=1023.16
C  25 ott. 2005	YTAV=1.
C  25 ott. 2005        SLTAV=STEV(PLTAV,TTAV,YTAV,1)
C  25 ott. 2005        HMAX=HEV(PLTAV,SLTAV,1)
C  25 ott. 2005        IF(HLTAV.GT.HMAX) HLTAV=HMAX
C        IF(HLTAV.GT.3971.71E+03) HLTAV=3971.71E+03
      ENDIF
C
      SV=SHEV(PVTAV,HVTAV,NFL)
      TV=TEV(PVTAV,SV,NFL)
C
C
C--- calcolo della portata di vapore e della portata di liquido entranti
C    per l'azione dei separatori sulla miscela immessa nella cavita`
C
      PVSTAV=PVTAV
      IF (PVSTAV.GT.221.E+05)PVSTAV=221.E+05
C
      PLSTAV=PLTAV
      IF (PLSTAV.GT.221.E+05)PLSTAV=221.E+05
C
      HLSTAV=HLCA
      IF (HLSTAV.LT.0.)HLSTAV=0.
      IF (HLSTAV.GT.2.1E6)HLSTAV=2.1E6
C
      PSATL=PHSAT(HLSTAV)
      CALL SATUR(PSATL,2,HLSPSL,HVSPSL,NFL)
      CALL SATUR(PLSTAV,2,HLS,HVSP,NFL)
      CALL SATUR(PVSTAV,2,HLSPPV,HVS,NFL)
C
C     XM=(HMIC-HLS)/(HVSP-HLS)
C     CALL WAD1SEP(TYP,XOVP,XUNP,XM,WMIC,PPVC,XOVS,XUNS)
C
C     IF (XM.GT.1.) THEN
C       HVP=HMIC
C       HLP=HLS+XUNS*(HVSP-HLS)
C     ELSE IF (XM.LT.0.) THEN
C       HVP=HLS+XOVS*(HVSP-HLS)
C       HLP=HMIC
C     ELSE
C       XVM=MAX(XM,XOVS)
C       XLM=MIN(XM,XUNS)
C       HVP=HLS+XVM*(HVSP-HLS)
C       HLP=HLS+XLM*(HVSP-HLS)
C     ENDIF
C
C     IF (WMIC.GE.0.) THEN
C       WVM=WMIC*(HMIC-HLP)/(HVP-HLP)
C       WLM=WMIC-WVM
C     ELSE
C       WVM=0.
C       HVP=HVCA
C       WLM=WMIC
C       HLP=HLCA
C     ENDIF
C
C-------------------
C
C
      DO JM=1,NSSIL
        XM=(HM(JM)-HLS)/(HVSP-HLS)
        CALL WAD1SEP(TYP,XOVP,XUNP,XM,WM(JM),PPVC,XOVS,XUNS)
C
        IF (XM.GT.1.) THEN
          HVP(JM)=HM(JM)
          HLP(JM)=HLS+XUNS*(HVSP-HLS)
        ELSE IF (XM.LT.0.) THEN
          HVP(JM)=HLS+XOVS*(HVSP-HLS)
          HLP(JM)=HM(JM)
        ELSE
          XVM=MAX(XM,XOVS)
          XLM=MIN(XM,XUNS)
          HVP(JM)=HLS+XVM*(HVSP-HLS)
          HLP(JM)=HLS+XLM*(HVSP-HLS)
        ENDIF
C
        IF (WM(JM).GE.0.) THEN
          WVM(JM)=WM(JM)*(HM(JM)-HLP(JM))/(HVP(JM)-HLP(JM))
          WLM(JM)=WM(JM)-WVM(JM)
        ELSE
          WVM(JM)=0.
          HVP(JM)=HVCA
          WLM(JM)=WM(JM)
          HLP(JM)=HLCA
        ENDIF
C
      END DO
C
C------------------
C
C--- calcolo della densita` del liquido
C
      SL=SHEV(PLTAV,HLTAV,NFL)
      ROL=ROEV(PLTAV,SL,NFL)
C
C--- calcolo del volume di liquido
C
      VL=MLCA/ROL
C
C--- calcolo del volume occupato sia dall'aria che dal vapore
C
      IF(VCAV.GT.VL)THEN
        VG=VCAV-VL
      ELSE
        WRITE(6,*)' WARNING !! - liquid mass ',MLCA
        WRITE(6,*)' WARNING !! - liquid density ',ROL
        WRITE(6,*)' WARNING !! - drum volume ',VCAV
        WRITE(6,*)' WARNING !! - liquid volume ',VL
        WRITE(6,*)' WARNING !! - gas zone volume ',VCAV-VL,'  < 0.'
        WRITE(6,*)' Calculation goes on using gas zone volume = 0.001m�'
        VG=0.001
      ENDIF
C
C--- calcolo della densita` dell'aria
C
      ROA=MA/VG
C
C--- calcolo della densita` del vapore
C
      ROV=ROEV(PVTAV,SV,NFL)
C
C
C--- calcolo della portata di condensazione nel volume del vapore
C
      CALL WAD1PAR(TYP,PPVC,PCAV,TAUV,TAUL,BETA,ALFA,HSUP,HSUR)
      XV=YEV(PVTAV,SV,NFL)
      WCP=MVCA*(XOVS-XV)/TAUV
      WC=MAX(0.,WCP)
C
C--- calcolo della portata di condensazione superficiale
C
      TL=TEV(PLTAV,SL,NFL)
      CALL SATUR(PVSTAV,7,TVS,Z,NFL)
      IF(SEZY.LE.0.) THEN
        CALL WAD1LIV(TYP,VL,Y,YTOT,AREA)
      ELSE
        AREA=SEZY
      ENDIF
C
      IF(TV.GE.TL.AND.TVS.GE.TL)THEN
        R=HVS-HLSPPV
        WCSUP=HSUP*AREA*BETA*(TVS-TL)/R
      ELSE
        R=HVSPSL-HLSPSL
        WCSUP=HSUP*AREA*BETA*(TVS-TL)/R
      ENDIF
C
C--- calcolo della portata di evaporazione nel volume del liquido
C    e dell'entalpia associata
C
      XL=YEV(PLTAV,SL,NFL)
      WEVP=MLCA*(XL-XUNS)/TAUL
      WEV=MAX(0.,WEVP)
C
C--- calcolo della portata di aria uscente o entrante nella cavita`
C
       IF(PCAV.GT.PVVS) THEN
         WAUS=ROA*CV*ALZS*SQRT((PCAV-PVVS)/ABS(ROA+ROV))
         WAIS=0.
         WPVUS=ROV*CV*ALZS*SQRT((PCAV-PVVS)/ABS(ROA+ROV))
       ELSE
         WAUS=0.
         WAIS=CV*ALZS*SQRT((PVVS-PCAV)*PVVS/(RA*TAIS))
         WPVUS=0.
       ENDIF
C
C--- calcolo della potenza termica scambiata fra liquido e vapore
C    attraverso la superficie di separazione
C
      IF(TV.GE.TL.AND.TVS.GE.TL)THEN
        QSUP=HSUR*AREA*(TV-TVS)*(1.+ALFA*BETA*(TVS-TL))
      ELSE IF(TV.GE.TL.AND.TVS.LE.TL)THEN
        QSUP=HSUR*AREA*(TV-TL)
      ELSE
        QSUP=0.
      ENDIF
C
C--- calcolo dello stazionario o del transitorio
C
      IF(KREGIM) THEN
        CALL STEAWAD1(IFUN,IPD,DATI,RNI)
      ELSE
        CALL TRANWAD1(IFUN,IPD,DATI,RNI)
      ENDIF
C
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
C
C**********************************
C*                                *
C*   Calcolo regime stazionario   *
C*                                *
C**********************************
C
      SUBROUTINE STEAWAD1(IFUN,IPD,DATI,RNI)
C
      DIMENSION DATI(*),RNI(*)
C
      LOGICAL VUOTO,PIENO
C
      PARAMETER(MAXLZN=30)
C
      REAL MA,MVCA,MLCA,LIV
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      COMMON /WAD1AR/ PPAC,TAIS,RA,CPA,ROA,WAUS,WAIS,ALZS,WASC,PVVS,
C--OL     $                MA
     $                MA,WAE(MAXLZN),TAE(MAXLZN),WAS(MAXLZN),TAS(MAXLZN)
C     COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,WMIC,HVS,HLSPPV,
C    $                HMIC,WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
      COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,HVS,HLSPPV,
     $                WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
     $                MVCA,TVS,PVTAV,HVTAV,TVCA,
     $                WG(MAXLZN),HG(MAXLZN),WS(MAXLZN),HS(MAXLZN),QGZP
      COMMON /WAD1LQ/ PCAV,HLCA,TL,SL,MLCA,VL,WEV,
     $                ROL,XL,HVSP,HLS,TAUL,PFCA,HAIC,LIV,HLSPSL,
     $                HVSPSL,PLTAV,HLTAV,TLCA,
     $                WL(MAXLZN),HL(MAXLZN),WW(MAXLZN),HW(MAXLZN),QLZP
      COMMON /WAD1MX/ WM(MAXLZN),HM(MAXLZN),WVM(MAXLZN),HVP(MAXLZN),
     $                WLM(MAXLZN),HLP(MAXLZN)
      COMMON /WAD1DT/ TYP,VCAV,FY,ZERY,VY,GY,SEZY,EMPTY,FULL,AML0,G,
     $                NFL,AMA0,AMV0,WAS0,WVS0,WCE0,NGZIL,NGZOL,NLZIL,
     $                NLZOL,NAZIL,NAZOL,NSSIL
      COMMON /WAD1ST/ IS
C
      IF(PLTAV.LE.221.E+05) THEN
        CALL SATUR(PLTAV,3,ROLS,ROVSPCAV,NFL)
      ELSE
        CALL SATUR(221.E+05,3,ROLS,ROVSPCAV,NFL)
      ENDIF
C
C--- inizializzazione variabili logiche "VUOTO" e "PIENO"
C
      VUOTO=.FALSE.
      DATI(IPD+10)=1.
      IF (MLCA.LE.AML0*1.E-04) THEN
        VUOTO=.TRUE.
        DATI(IPD+10)=0.
      ENDIF
C
      PIENO=.FALSE.
      DATI(IPD+11)=1.
C     IF (VG.LE.VCAV*1.E-02) THEN
C       IF (MLCA.GE.ROLS*VCAV) THEN
        IF (MLCA.GE.ROL*VCAV) THEN
        PIENO=.TRUE.
        DATI(IPD+11)=0.
      ENDIF
C
C--- discriminazione fra: cavita` vuota o piena
C                         cavita` in normali condizioni operative
C
C      IF (VUOTO) THEN
C        CALL WAD1STEMP(RNI)
C      ELSE IF (VUOTO.OR.PIENO)
C        CALL WAD1STFULL(RNI)
C      ELSE
C        CALL WAD1STNF(RNI)
C      ENDIF
C
       CALL WAD1STNF(RNI)
C
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
C*******************************************************
C*                                                     *
C*   Calcolo dei residui in stazionario, con cavita`   *
C*   in normali condizioni operative                   *
C*                                                     *
C*******************************************************
C
      SUBROUTINE WAD1STNF(RNI)
C
      DIMENSION RNI(*)
C
      PARAMETER(MAXLZN=30)
C
      REAL MA,MVCA,MLCA,LIV
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      COMMON /WAD1AR/ PPAC,TAIS,RA,CPA,ROA,WAUS,WAIS,ALZS,WASC,PVVS,
C--OL     $                MA
     $                MA,WAE(MAXLZN),TAE(MAXLZN),WAS(MAXLZN),TAS(MAXLZN)
C     COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,WMIC,HVS,HLSPPV,
C    $                HMIC,WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
      COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,HVS,HLSPPV,
     $                WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
     $                MVCA,TVS,PVTAV,HVTAV,TVCA,
     $                WG(MAXLZN),HG(MAXLZN),WS(MAXLZN),HS(MAXLZN),QGZP
      COMMON /WAD1LQ/ PCAV,HLCA,TL,SL,MLCA,VL,WEV,
     $                ROL,XL,HVSP,HLS,TAUL,PFCA,HAIC,LIV,HLSPSL,
     $                HVSPSL,PLTAV,HLTAV,TLCA,
     $                WL(MAXLZN),HL(MAXLZN),WW(MAXLZN),HW(MAXLZN),QLZP
      COMMON /WAD1MX/ WM(MAXLZN),HM(MAXLZN),WVM(MAXLZN),HVP(MAXLZN),
     $                WLM(MAXLZN),HLP(MAXLZN)
      COMMON /WAD1DT/ TYP,VCAV,FY,ZERY,VY,GY,SEZY,EMPTY,FULL,AML0,G,
     $                NFL,AMA0,AMV0,WAS0,WVS0,WCE0,NGZIL,NGZOL,NLZIL,
     $                NLZOL,NAZIL,NAZOL,NSSIL
      COMMON /WAD1ST/ IS
C
C--- calcolo del livello o come quota del pelo libero del liquido
C    (comprendendo le bolle di vapore incluse nella fase liquida),
C    o come quota del pelo libero che il liquido assumerebbe se si
C    escludessero le bolle di vapore dalla fase liquida
C
      CALL SATUR(PCAV,3,ROLS,ROVSPCAV,NFL)
C
      IF (FY.LE.0.) THEN
        ROY=MAX(ROL,ROLS)
        VLL=MLCA*(1-XL)/ROY
      ELSE
        VLL=VL
      ENDIF
C
      IF(VLL.GE.VCAV)VLL=0.9999*VCAV
      IF(VLL.LT.0.0001)VLL=0.0001
C
      IF (SEZY.LE.0.) THEN
        CALL WAD1LIV(TYP,VLL,Y,YTOT,AREA)
      ELSE
        Y=(VLL-VY)/(SEZY*GY)
        YTOT=Y*GY+ZERY
      ENDIF
C
C
C--- calcolo termini noti delle equazioni di conservazione dell'energia
C    del vapore e del liquido
C
      WVMT=0.
      WDHVM=0.
      WLMT=0.
      WDHLM=0.
      DO J=1,NSSIL
        WVMT=WVMT+WVM(J)
        IF(WVM(J).GT.0.) WDHVM=WDHVM+WVM(J)*(HVP(J)-HVCA)
        WLMT=WLMT+WLM(J)
        IF(WLM(J).GT.0.)WDHLM=WDHLM+WLM(J)*(HLP(J)-HLCA)
      END DO
C
      WGT=0.
      WDHG=0.
      DO J=1,NGZIL
         WGT=WGT+WG(J)
         IF(WG(J).GT.0.)WDHG=WDHG+WG(J)*(HG(J)-HVCA)
      END DO
C
      WST=0.
      WDHS=0.
      DO J=1,NGZOL
         WST=WST+WS(J)
         IF(WS(J).LT.0.)WDHS=WDHS+ABS(WS(J))*(HS(J)-HVCA)
      END DO
C
      WLT=0.
      WDHL=0.
      DO J=1,NLZIL
         WLT=WLT+WL(J)
         IF(WL(J).GT.0.)WDHL=WDHL+WL(J)*(HL(J)-HLCA)
      END DO

C
      WWT=0.
      WDHW=0.
      DO J=1,NLZOL
         WWT=WWT+WW(J)
         IF(WW(J).LT.0.)WDHW=WDHW+ABS(WW(J))*(HW(J)-HLCA)
      END DO
C
      IF(WCSUP.GE.0.)THEN
C       SHV=WDHG+WDHS+WVM*(HVP-HVCA)+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
        SHV=WDHG+WDHS+WDHVM+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
     $    WCSUP*(HVS-HVCA)-QSUP-QGZP
C    $    WCSUP*(HLSPPV-HVCA)-QSUP-QGZP
C       SHL=WDHL+WDHW+WLM*(HLP-HLCA)+WC*(HLSPPV-HLCA)+
        SHL=WDHL+WDHW+WDHLM+WC*(HLSPPV-HLCA)+
     $  WCSUP*(HVS-HLCA)-WEV*(HVSP-HLCA)+QSUP-QLZP
C    $  WCSUP*(HLSPPV-HLCA)-WEV*(HVSP-HLCA)+QSUP-QLZP
      ELSE
C       SHV=WDHG+WDHS+WVM*(HVP-HVCA)+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
        SHV=WDHG+WDHS+WDHVM+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
     $    WCSUP*(HVSPSL-HVCA)-QSUP-QGZP
C       SHL=WDHL+WDHW+WLM*(HLP-HLCA)+WC*(HLSPPV-HLCA)+
        SHL=WDHL+WDHW+WDHLM+WC*(HLSPPV-HLCA)+
     $    WCSUP*(HVSPSL-HLCA)-WEV*(HVSP-HLCA)+QSUP-QLZP
      ENDIF
C
C--OL
      WWAE=0.
      WDHAE=0.
      DO J=1,NAZIL
         WWAE=WWAE+WAE(J)
         IF(WAE(J).GT.0.)WDHAE=WDHAE+WAE(J)*CPA*(TAE(J)-TV)
      END DO
C
      WWAS=0.
      WDHAS=0.
      DO J=1,NAZOL
         WWAS=WWAS+WAS(J)
         IF(WAS(J).LT.0.)WDHAS=WDHAS+ABS(WAS(J))*CPA*(TAS(J)-TV)
      END DO
C
      SHA = WDHAE + WDHAS
C
C--OL
C
C
C---calcolo residui
C
C--residuo n.1: equazione di conservazione della massa di vapore
C               (pressione totale nella cavita`)
C
C--OL       RNI(1) = (WGT+WVM+WEV-WST-WC-WCSUP-WPVUS)/W0
C      RNI(1) = (WGT+WVM+WEV+WWAE+WAIS-WST-WC-WCSUP-WPVUS-WWAS-WAUS)/W0
       RNI(1) = (WGT+WVMT+WEV+WWAE+WAIS-WST-WC-WCSUP-WPVUS-WWAS-WAUS)/W0
C
C
C--residuo n.2: equazione di conservazione dell'energia della zona gassosa
C               (entalpia specifica del vapore)
C
C--OL       RNI(2) = (WAIS*CPA*(TAIS-TV)+SHV)/(W0*H0)
       RNI(2) = (SHA+WAIS*CPA*(TAIS-TV)+SHV)/(W0*H0)
C
C
C--residuo n.3: equazione di conservazione dell'energia del liquido
C               (entalpia specifica del liquido)
C
       RNI(3) = SHL/(W0*H0)
C
C
C--residuo n.4: equazione di conservazione della massa d'aria
C               ( Air mass into the cavity)
C--- per ALZS = 0. si suppone che non vi sia aria dentro la cavita`
C
C--OL      IF (ALZS.GT.0.) THEN
C--OLC        RNI(4) = WAIS-WAUS
C--OL        RNI(4) = (WAIS-WAUS)/AMA0
C--OL      ELSE
C--OLC        RNI(4) = (MLCA/ROL + MA/PPAC*RA*TV - VCAV)/VCAV
C--OLC        RNI(4) = -MA/AMA0
C--OL        RNI(4) = 0.
C--OL      ENDIF
C
        RNI(4) = (WWAE+WAIS-WWAS-WAUS)/AMA0
C
C
C--residuo n.5: equazione di conservazione della massa di liquido
C               (massa di liquido nella cavita`)
C
C      RNI(5) = (WLT+WLM+WC+WCSUP-WEV-WWT)/W0
       RNI(5) = (WLT+WLMT+WC+WCSUP-WEV-WWT)/W0
C
C
C--residual n.6:  Steam mass into the cavity
C
       RNI(6)=(VG*ROEV(PVTAV,SV,NFL)-MVCA)/AMV0
C
C
C--residuo n.7: livello del liquido
C
       RNI(7) = Y - LIV
C
C
C--residuo n.8: pressione sul fondo
C
       RNI(8) = (PCAV+ROL*G*YTOT-PFCA)/P0
C
C
C--residuo n.9: pressione parziale dell'aria nella cavita`
C
       RNI(9) = (ROA*RA*TV - PPAC)/P0
C
C
C--residuo n.10: Steam partial pressure
C
       RNI(10) = (PPVC+PPAC-PCAV)/P0
C
C--residuo n.11: portata di aria entrante o uscente dallo sfiato
C
C       RNI(11) = ((WAIS-WAUS) - WASC)/W0
C--OL       RNI(11) = ((WAIS-WAUS) - WASC)/WAS0
       RNI(11) = ((WAUS-WAIS) - WASC)/WAS0
C
C
C--residuo n.12: portata di vapore uscente dallo sfiato
C
       RNI(12) = (WPVUS - WVUS)/WVS0
C
C
C--residuo n.13   Surface condensation/evaporation mass flow rate
C--residuo n.13   Liquid temperature
C
C      RNI(13) = (WCSUP - WSCE)/WCE0
       RNI(13) = (TL - TLCA)/T0
C
C
C--residuo n.14   Steam/air temperature
C
       RNI(14) = (TV - TVCA)/T0
C
C
       RETURN
       END
C
C/**********************************************************************
C/**********************************************************************
C
C***************************
C*                         *
C*   Calcolo transitorio   *
C*                         *
C***************************
C
      SUBROUTINE TRANWAD1(IFUN,IPD,DATI,RNI)
C
C
      DIMENSION DATI(*),RNI(*)
C
      LOGICAL VUOTO,PIENO
C
      PARAMETER(MAXLZN=30)
C
      REAL MA,MVCA,MLCA,LIV
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      COMMON /WAD1AR/ PPAC,TAIS,RA,CPA,ROA,WAUS,WAIS,ALZS,WASC,PVVS,
C--OL     $                MA
     $                MA,WAE(MAXLZN),TAE(MAXLZN),WAS(MAXLZN),TAS(MAXLZN)
C     COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,WMIC,HVS,HLSPPV,
C    $                HMIC,WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
      COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,HVS,HLSPPV,
     $                WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
     $                MVCA,TVS,PVTAV,HVTAV,TVCA,
     $                WG(MAXLZN),HG(MAXLZN),WS(MAXLZN),HS(MAXLZN),QGZP
      COMMON /WAD1LQ/ PCAV,HLCA,TL,SL,MLCA,VL,WEV,
     $                ROL,XL,HVSP,HLS,TAUL,PFCA,HAIC,LIV,HLSPSL,
     $                HVSPSL,PLTAV,HLTAV,TLCA,
     $                WL(MAXLZN),HL(MAXLZN),WW(MAXLZN),HW(MAXLZN),QLZP
      COMMON /WAD1MX/ WM(MAXLZN),HM(MAXLZN),WVM(MAXLZN),HVP(MAXLZN),
     $                WLM(MAXLZN),HLP(MAXLZN)
      COMMON /WAD1DT/ TYP,VCAV,FY,ZERY,VY,GY,SEZY,EMPTY,FULL,AML0,G,
     $                NFL,AMA0,AMV0,WAS0,WVS0,WCE0,NGZIL,NGZOL,NLZIL,
     $                NLZOL,NAZIL,NAZOL,NSSIL
      COMMON /WARDDY/ DTVDPV,DTVDHV,DRVDPV,DRVDHV,DRLDP,DRLDHL
      COMMON /WAD1ST/ IS
      COMMON /WAD1XX/ DTVDPVS,DTVDSV
C
      IF(PLTAV.LE.221.E+05) THEN
        CALL SATUR(PLTAV,3,ROLS,ROVSPCAV,NFL)
      ELSE
        PLSATUR=221.E+05
        CALL SATUR(PLSATUR,3,ROLS,ROVSPCAV,NFL)
      ENDIF
C
C---      Inizializzazione variabili logiche "VUOTO" e "PIENO"
C
      IF (IFUN.NE.2.OR.ITERT.NE.0) THEN
        VUOTO=EMPTY.LT.0.5
        PIENO=FULL.LT.0.5
      ELSE
        VUOTO=.FALSE.
        DATI(IPD+10)=1.
        IF (MLCA.LE.AML0*1.E-04) THEN
          VUOTO=.TRUE.
          DATI(IPD+10)=0.
        ENDIF
C
        PIENO=.FALSE.
        DATI(IPD+11)=1.
C       IF (VG.LE.VCAV*1.E-02) THEN
C       IF (MLCA.GE.ROLS*VCAV) THEN
        IF (MLCA.GE.ROL*VCAV) THEN
          PIENO=.TRUE.
          DATI(IPD+11)=0.
        ENDIF
      ENDIF
C
C--- calcolo dei termini che costituiscono i coefficienti delle equazioni
C
C--- derivata della temperatura del vapore fatta rispetto alla
C    pressione parziale del vapore, ad entropia costante [dTv/dPv]s
C
      DELTAP=0.01*PVTAV
C
C------ CASAM  4 Novembre 1994 ------
C
C Protezioni per valori di Pressione, Entalpia ed Entropia fuori dal
C range consentito dalle tavole del vapore
C
      IF(PVTAV+DELTAP.GE.400.E+05)THEN
        PVI = 396.E+05
        PVA=400.E+05
        DELTAP=4.E+05
        TVA=TEV(PVA,SV,NFL)
        TVI=TEV(PVI,SV,NFL)
        DTVDPVS=(TVA-TVI)/DELTAP
        SVMIN=0.4
        SVMAX=6.66E+03
      ELSE IF(PVTAV-DELTAP.LE.610.8)THEN
        PVA = 616.9
        PVI = 610.8
        DELTAP=6.1
        TVA=TEV(PVA,SV,NFL)
        TVI=TEV(PVI,SV,NFL)
        DTVDPVS=(TVA-TVI)/DELTAP
        SVMIN=-0.2
        SVMAX=11.82E+03
      ELSE
        PVI = PVTAV - DELTAP
        PVA = PVTAV + DELTAP
        TVA=TEV(PVA,SV,NFL)
        TVI=TEV(PVI,SV,NFL)
        DTVDPVS=(TVA-TVI)/(2.*DELTAP)
      ENDIF
C
      SVMIN=0.4
      TVMAX=1023.
      TITOLO=1.
      SVMAX=STEV(PVTAV,TVMAX,TITOLO,NFL)
C
C--- derivata della temperatura del vapore fatta rispetto all'entropia,
C    a pressione parziale del vapore costante [dTv/dSv]p
C
      DELTAS=0.01*SV
C
C
      IF(SV+DELTAS.GT.SVMAX) THEN
        DELTAS=0.01*SVMAX
        TVSA=TEV(PVTAV,SVMAX,NFL)
	DELTASMAXI=SVMAX-DELTAS
        TVSI=TEV(PVTAV,DELTASMAXI,NFL)
        DTVDSV=(TVSA-TVSI)/DELTAS
      ELSE IF(SV-DELTAS.LT.SVMIN) THEN
        DELTAS=0.01*SVMIN
	DELTASMIN=SVMIN+DELTAS
        TVSA=TEV(PVTAV,DELTASMIN,NFL)
        TVSI=TEV(PVTAV,SVMIN,NFL)
        DTVDSV=(TVSA-TVSI)/DELTAS
      ELSE
        DELTASPIU=SV+DELTAS
        DELTASMENO=SV-DELTAS
        TVSA=TEV(PVTAV,DELTASPIU,NFL)
        TVSI=TEV(PVTAV,DELTASMENO,NFL)
        DTVDSV=(TVSA-TVSI)/(2.*DELTAS)
      ENDIF
C
C------ CASAM  4 Novembre 1994 ------ FINE
C
C--- derivata della temperatura del vapore fatta rispetto alla
C    pressione parziale del vapore, ad entalpia costante [dTv/dPv]h
C
      DTVDPV=DTVDPVS-1./(ROV*TV)*DTVDSV
C
C--- derivata della temperatura del vapore fatta rispetto all'entalpia,
C    a pressione parziale del vapore costante [dTv/dHv]p
C
      DTVDHV=DTVDSV/TV
C
C--- derivata della densit. del vapore fatta rispetto alla pressione,
C    ad entalpia costante [d@v/dPv]h
C
C      DRVDPV=1./A2EV(PPVC,SV,NFL)-1./(ROV*TV)*BEV(PPVC,SV,NFL)
      DRVDPV=1./A2EV(PVTAV,SV,NFL)-1./(ROV*TV)*BEV(PVTAV,SV,NFL)
C
C--- derivata della densita` del vapore fatta rispetto all'entalpia,
C    a pressione parziale del vapore costante [d@v/dHv]p
C
C      DRVDHV=BEV(PPVC,SV,NFL)/TV
      DRVDHV=BEV(PVTAV,SV,NFL)/TV
C
C--- derivata della densita` del liquido fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h
C
C      DRLDP=1./A2EV(PCAV,SL,NFL)-1./(ROL*TL)*BEV(PCAV,SL,NFL)
      DRLDP=1./A2EV(PLTAV,SL,NFL)-1./(ROL*TL)*BEV(PLTAV,SL,NFL)
C
C--- derivata della densita` del liquido fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p
C
C      DRLDHL=BEV(PCAV,SL,NFL)/TL
      DRLDHL=BEV(PLTAV,SL,NFL)/TL
C
C--- discriminazione fra: cavita` vuota o piena
C                         cavita` in normali condizioni operative
C
      IF (VUOTO) THEN
        WRITE(6,*)' ERROR: EMPTY CAVITY!'
        STOP
C        CALL WAD1TREMP(RNI)
      ELSE IF (PIENO) THEN
        WRITE(6,*)' ERROR: FULL CAVITY!'
        STOP
C        CALL WAD1TRFULL(RNI)
      ELSE
        CALL WAD1TRNF(RNI)
      ENDIF
C
      RETURN
      END
C
C/**********************************************************************
C/**********************************************************************
C
C*******************************************************************
C*                                                                 *
C*    Calcolo dei residui in transitorio, con cavita` in normali   *
C*    condizioni operative                                         *
C*                                                                 *
C*******************************************************************
C
      SUBROUTINE WAD1TRNF(RNI)
C
      DIMENSION RNI(*)
C
      PARAMETER(MAXLZN=30)
C
      REAL MA,MVCA,MLCA,LIV
      REAL N1,N2,N3,N4
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
C
      COMMON /WAD1AR/ PPAC,TAIS,RA,CPA,ROA,WAUS,WAIS,ALZS,WASC,PVVS,
C--OL     $                MA
     $                MA,WAE(MAXLZN),TAE(MAXLZN),WAS(MAXLZN),TAS(MAXLZN)
C     COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,WMIC,HVS,HLSPPV,
C    $                HMIC,WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
      COMMON /WAD1VP/ PPVC,HVCA,TV,SV,ROV,HVS,HLSPPV,
     $                WC,WCSUP,WSCE,WPVUS,WVUS,QSUP,VG,TAUV,
     $                MVCA,TVS,PVTAV,HVTAV,TVCA,
     $                WG(MAXLZN),HG(MAXLZN),WS(MAXLZN),HS(MAXLZN),QGZP
      COMMON /WAD1LQ/ PCAV,HLCA,TL,SL,MLCA,VL,WEV,
     $                ROL,XL,HVSP,HLS,TAUL,PFCA,HAIC,LIV,HLSPSL,
     $                HVSPSL,PLTAV,HLTAV,TLCA,
     $                WL(MAXLZN),HL(MAXLZN),WW(MAXLZN),HW(MAXLZN),QLZP
      COMMON /WAD1MX/ WM(MAXLZN),HM(MAXLZN),WVM(MAXLZN),HVP(MAXLZN),
     $                WLM(MAXLZN),HLP(MAXLZN)
      COMMON /WAD1DT/ TYP,VCAV,FY,ZERY,VY,GY,SEZY,EMPTY,FULL,AML0,G,
     $                NFL,AMA0,AMV0,WAS0,WVS0,WCE0,NGZIL,NGZOL,NLZIL,
     $                NLZOL,NAZIL,NAZOL,NSSIL
      COMMON /WARDDY/ DTVDPV,DTVDHV,DRVDPV,DRVDHV,DRLDP,DRLDHL
      COMMON /WAD1ST/ IS
      COMMON /WAD1XX/ DTVDPVS,DTVDSV
C
C--- Calcolo del livello o come quota del pelo libero del liquido
C    (comprendendo le bolle di vapore incluse nella fase liquida),
C    o come quota del pelo libero che il liquido assumerebbe se si
C    escludessero le bolle di vapore dalla fase liquida
C
      IF(PLTAV.LE.221.E+05) THEN
        CALL SATUR(PLTAV,3,ROLS,ROVSPCAV,NFL)
      ELSE
        CALL SATUR(221.E+05,3,ROLS,ROVSPCAV,NFL)
      ENDIF
      IF (FY.LE.0.) THEN
        ROY=MAX(ROL,ROLS)
        VLL=MLCA*(1-XL)/ROY
      ELSE
        VLL=VL
      ENDIF
C
      IF(VLL.GE.VCAV)VLL=0.9999*VCAV
      IF(VLL.LT.0.0001)VLL=0.0001
C
      IF (SEZY.LE.0.) THEN
        CALL WAD1LIV(TYP,VLL,Y,YTOT,AREA)
      ELSE
        Y=(VLL-VY)/(SEZY*GY)
        YTOT=Y*GY+ZERY
      ENDIF
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni
C
C
C
      WVMT=0.
      WDHVM=0.
      WLMT=0.
      WDHLM=0.
      DO J=1,NSSIL
        WVMT=WVMT+WVM(J)
        IF(WVM(J).GT.0.) WDHVM=WDHVM+WVM(J)*(HVP(J)-HVCA)
        WLMT=WLMT+WLM(J)
        IF(WLM(J).GT.0.)WDHLM=WDHLM+WLM(J)*(HLP(J)-HLCA)
      END DO
C
      WGT=0.
      WDHG=0.
      DO J=1,NGZIL
         WGT=WGT+WG(J)
         IF(WG(J).GT.0.)WDHG=WDHG+WG(J)*(HG(J)-HVCA)
      END DO
C
      WST=0.
      WDHS=0.
      DO J=1,NGZOL
         WST=WST+WS(J)
         IF(WS(J).LT.0.)WDHS=WDHS+ABS(WS(J))*(HS(J)-HVCA)
      END DO
C
      WLT=0.
      WDHL=0.
      DO J=1,NLZIL
         WLT=WLT+WL(J)
         IF(WL(J).GT.0.)WDHL=WDHL+WL(J)*(HL(J)-HLCA)
      END DO

C
      WWT=0.
      WDHW=0.
      DO J=1,NLZOL
         WWT=WWT+WW(J)
         IF(WW(J).LT.0.)WDHW=WDHW+ABS(WW(J))*(HW(J)-HLCA)
      END DO
C
C--OL
      WWAE=0.
      WDHAE=0.
      DO J=1,NAZIL
         WWAE=WWAE+WAE(J)
         IF(WAE(J).GT.0.)WDHAE=WDHAE+WAE(J)*CPA*(TAE(J)-TV)
      END DO
C
      WWAS=0.
      WDHAS=0.
      DO J=1,NAZOL
         WWAS=WWAS+WAS(J)
         IF(WAS(J).LT.0.)WDHAS=WDHAS+ABS(WAS(J))*CPA*(TAS(J)-TV)
      END DO
C
C--OL      SA=WAIS-WAUS
C--OL      SHA=WAIS*CPA*(TAIS-TV)
      SA=WWAE+WAIS-WWAS-WAUS
      SHA=WAIS*CPA*(TAIS-TV)+WDHAE+WDHAS
C
C     SVAP=WGT+WVM+WEV-WST-WC-WCSUP-WPVUS
      SVAP=WGT+WVMT+WEV-WST-WC-WCSUP-WPVUS
C
      IF(WCSUP.GE.0.)THEN
C       SHV=WDHG+WDHS+WVM*(HVP-HVCA)+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
        SHV=WDHG+WDHS+WDHVM+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
     $    WCSUP*(HVS-HVCA)-QSUP-QGZP
C       SHL=WDHL+WDHW+WLM*(HLP-HLCA)+WC*(HLSPPV-HLCA)+
        SHL=WDHL+WDHW+WDHLM+WC*(HLSPPV-HLCA)+
     $  WCSUP*(HVS-HLCA)-WEV*(HVSP-HLCA)+QSUP-QLZP
      ELSE
C       SHV=WDHG+WDHS+WVM*(HVP-HVCA)+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
        SHV=WDHG+WDHS+WDHVM+WEV*(HVSP-HVCA)-WC*(HLSPPV-HVCA)-
     $    WCSUP*(HVSPSL-HVCA)-QSUP-QGZP
C       SHL=WDHL+WDHW+WLM*(HLP-HLCA)+WC*(HLSPPV-HLCA)+
        SHL=WDHL+WDHW+WDHLM+WC*(HLSPPV-HLCA)+
     $    WCSUP*(HVSPSL-HLCA)-WEV*(HVSP-HLCA)+QSUP-QLZP
      ENDIF
C
C      SLIQ=WLT+WLM+WC+WCSUP-WEV-WWT
       SLIQ=WLT+WLMT+WC+WCSUP-WEV-WWT
C
C---      n.1    equazione di conservazione della massa d'aria
C
       ROL2=ROL**2.
C
       A11=ROA/ROL2*(MLCA*DRLDP+VL*DRLDHL)-MA/TV*DTVDPV
       A12=VG/(RA*TV)+MA/TV*DTVDPV
       A13=MA/TV*DTVDHV
C
       N1=SA+ROA/ROL*SLIQ-ROA/ROL2*DRLDHL*SHL
C
C---      n.2    equazione di conservazione della massa di vapore
C
       A21=VG*DRVDPV+ROV/ROL2*(MLCA*DRLDP+VL*DRLDHL)
       A22=VG*DRVDPV
       A23=VG*DRVDHV
C
       N2=SVAP+ROV/ROL*SLIQ-ROV/ROL2*DRLDHL*SHL
C
C---      n.3    equazione di conservazione dell'energia nella zona gassosa
C                              ( aria e vapore )
C
       A31=MA*CPA*DTVDPV-VG
       A32=MA*CPA*DTVDPV
       A33=MVCA+MA*CPA*DTVDHV
C
       N3=SHA+SHV
C
C---      n.4    equazione di conservazione dell'energia nella zona liquido
C
       A41=1./ROL
C
       N4=SHL/MLCA
C
C--- calcolo residui
C
CC    IF (IS.EQ.5 .AND. TEMPO.GT.7180. .AND. TEMPO.LT.7230.) THEN
CC      WRITE(6,*)
CC      WRITE(6,1100)' TEMPO ',TEMPO
CC      WRITE(6,*)
CC      WRITE(6,1100)' WASC ',WASC,' WVM ',WVM,' WEV ',WEV,
CC   $               ' WVCA ',WVCA
CC      WRITE(6,1100)' WC ',WC,' WCSUP ',WCSUP,' WPVUS ',WPVUS,
CC   $               ' WLM ',WLM,' TV ',TV,' TL ',TL
CC      WRITE(6,1100)' WAIC ',WAIC,' WAUC ',WAUC
CC      WRITE(6,1100)' HVP ',HVP,' HVCA ',HVCA,' HVSP ',HVSP,
CC   $               ' HVS ',HVS,' HVSPSL',HVSPSL,' TVS ',TVS
CC      WRITE(6,1100)' HLSPPV ',HLSPPV,' QSUP ',QSUP,
CC   $               ' HAIC ',HAIC,'HLSPSL ',HLSPSL
CC      WRITE(6,1100)' HLP ',HLP,' HLCA ',HLCA,' HMIC ',HMIC,
CC   $               ' PFCA ',PFCA
CC      WRITE(6,1100)' PCAV ',PCAV,' PPVC ',PPVC,' PPAC ',PPAC
CC      WRITE(6,*)
CC      WRITE(6,1100)' SA ',SA,' SHA ',SHA,' SV ',SVAP,' SHV ',SHV
CC      WRITE(6,*)
CC      WRITE(6,*)' SL ',SLIQ,' SHL ',SHL
CC      WRITE(6,*)
CC       WRITE(6,*)' N1 ',N1,' N2 ',N2,' N3 ',N3,' N4 ',N4
CC      WRITE(6,*)
CC    ENDIF
C1100 FORMAT (8(A6,G15.5))
C
C--- determinante del sistema di equazioni costituito dalle equazioni
C    n. 1, 2, 3
C
      DET=A21*A32*A13+A12*A23*A31-A11*A22*A33-
     $    A13*A22*A31+A23*A32*A11-A12*A21*A33
C
C--residuo n.1 (equazione di stato)   pressione totale nella cavita`
C
       DPDTAU = (N2*A32*A13-N1*A22*A33+A12*A23*N3-A13*A22*N3+A23*A32*N1-
     $           A12*N2*A33)/DET
C
       RNI(1) =DPDTAU/P0
C
      IF (IS.EQ.5)THEN
c        WRITE(6,*)' '
c        WRITE(6,*)' '
c        WRITE(6,*)' '
        WRITE(6,*)' A11 ',A11,' A12 ',A12,' A13 ',A13
        WRITE(6,*)' A21 ',A21,' A22 ',A22,' A23 ',A23
        WRITE(6,*)' A31 ',A31,' A32 ',A32,' A33 ',A33
c        WRITE(6,*)' '
c        WRITE(6,*)' '
c        WRITE(6,*)' '
        WRITE(6,*)' A21*A32*A13 ',A21*A32*A13
        WRITE(6,*)' A12*A23*A31 ',A12*A23*A31
        WRITE(6,*)' A11*A22*A33 ',A11*A22*A33
        WRITE(6,*)' A13*A22*A31 ',A13*A22*A31
        WRITE(6,*)' A23*A32*A11 ',A23*A32*A11
        WRITE(6,*)' A12*A21*A33 ',A12*A21*A33
c        WRITE(6,*)' '
        WRITE(6,*)' A12*N2*A31',A12*N2*A31
        WRITE(6,*)'-A11*A22*N3',-A11*A22*N3
        WRITE(6,*)'-A21*A32*N1',-A21*A32*N1
        WRITE(6,*)' N1*A22*A31',N1*A22*A31
        WRITE(6,*)'-A12*A21*N3',-A12*A21*N3
        WRITE(6,*)' N2*A32*A11',N2*A32*A11
c        WRITE(6,*)' '
c        WRITE(6,*)' '
c        WRITE(6,*)' '
        WRITE(6,*)' A11*N2*A33', A11*N2*A33
        WRITE(6,*)'-A21*A13*N3',-A21*A13*N3
        WRITE(6,*)' A23*A31*N1', A23*A31*N1
        WRITE(6,*)' N2*A13*A31', N2*A13*A31
        WRITE(6,*)'-A23*A11*N3',-A23*A11*N3
        WRITE(6,*)'-N1*A21*A33',-N1*A21*A33
c        WRITE(6,*)' '
c        WRITE(6,*)' '
c        WRITE(6,*)' A12*A23*N3 ',A12*A23*N3,' A13*A22*N3 ',A13*A22*N3
        WRITE(6,*)' DET ',DET,' DPDTAU ',DPDTAU
        WRITE(6,*)' DTVDPV ',DTVDPV,' DTVDHV ',DTVDHV,' TV ',TV
        WRITE(6,*)' DRLDP ',DRLDP,' DRLDHL ',DRLDHL,' TL ',TL
        WRITE(6,*)' MA ',MA,' ML ',MLCA
        WRITE(6,*)' ROA ',ROA,' ROL ',ROL,' ROV ',ROV
        WRITE(6,*)' VG ',VG,' VL ',VL
      ENDIF
C
C--residuo n.2 (equazione di stato)   entalpia specifica del vapore
C
      RNI(2) = (A12*N2*A31-A11*A22*N3-A21*A32*N1+N1*A22*A31-A12*A21*N3+
     $         N2*A32*A11)/(DET*H0)
C
C
C--residuo n.3 (equazione di stato)   entalpia specifica del liquido
C
      RNI(3) =  (SHL/MLCA+A41*DPDTAU)/H0
C
C
C--residuo n.4 (equazione di stato)   massa d'aria nella cavita`
C
        RNI(4) = SA/AMA0
C
C
C--residuo n.5 (equazione di stato)   massa di liquido nella cavita`
C
      RNI(5) = SLIQ/AML0
C
C
C--residuo n.6 (equazione algebrica)   Steam mass in the cavity
C
      RNI(6) = (VG*ROEV(PVTAV,SV,NFL)-MVCA)/AMV0
C
C--residuo n.7 (equazione algebrica)  livello del liquido
C
      RNI(7) = Y - LIV
C
C--residuo n.8 (equazione algebrica)  pressione sul fondo
C
      RNI(8) = (PCAV + ROL*G*YTOT - PFCA)/P0
C
C
C--residuo n.9     pressione parziale dell'aria nella cavita`
C
       RNI(9) = (ROA*RA*TV - PPAC)/P0
C     RNI(9) = ROA*RA*TV/P0
C
C
C--residuo n.10 (equazione algebrica)  pressione parziale del vapore
C
       RNI(10) = (PCAV-PPVC-PPAC)/P0
C     RNI(10) = (PCAV-PPVC-ROA*RA*TV)/P0
C
C--residuo n.11 (equazione algebrica) portata di aria entrante o
C                                     uscente dallo sfiato
C--OL       RNI(11) = (SA-WASC)/W0
       RNI(11) = (WAUS-WAIS-WASC)/W0
C     RNI(11) = SA/W0
C
C--residuo n.12 (equazione algebrica)  portata di vapore uscente dallo sfiato
C
       RNI(12) = (WPVUS-WVUS)/W0
C     RNI(12) = WPVUS/W0
C
C--residuo n.13     portata di condensazione o evaporazione superficiale
C--residuo n.13     Liquid temperature
C
C      RNI(13) = (WCSUP - WSCE)/W0
C      RNI(13) = WCES/W0
       RNI(13) = (TL - TLCA)/T0
C
C
C--residuo n.14    Steam/air temperature
C
       RNI(14) = (TV - TVCA)/T0
C
C
C
      IF (IS.EQ.5) THEN
C        WRITE(6,*)' rni_1 ',rni(1)
C        WRITE(6,*)' rni_2 ',rni(2)
C        WRITE(6,*)' rni_3 ',rni(3)
C        WRITE(6,*)' rni_4 ',rni(4)
C        WRITE(6,*)' rni_5 ',rni(5)
C        WRITE(6,*)' rni_6 ',rni(6)
C        WRITE(6,*)' rni_7 ',rni(7)
C        WRITE(6,*)' rni_8 ',rni(8)
C        WRITE(6,*)' rni_9 ',rni(9)
C        WRITE(6,*)' rni_10 ',rni(10)
C        WRITE(6,*)' DPDTAU ',DPDTAU
        WRITE(6,*)' A12*N2*A31', A12*N2*A31
        WRITE(6,*)'-A11*A22*N3',-A11*A22*N3
        WRITE(6,*)'-A21*A32*N1',-A21*A32*N1
        WRITE(6,*)' N1*A22*A31', N1*A22*A31
        WRITE(6,*)'-A12*A21*N3',-A12*A21*N3
        WRITE(6,*)' N2*A32*A11', N2*A32*A11
        WRITE(6,*)' DHVDT ',RNI(3)*H0
C        WRITE(6,*)' DPADT ',DPADT
      ENDIF
C
      RETURN
      END
C
C
C
C*********************************************************************
C*                                                                   *
C*    Assegnazione dei parametri per il calcolo delle portate di     *
C*    condensazione e di evaporazione,  e  della potenza termica     *
C*    scambiata fra liquido e vapore attraverso la superficie di     *
C*    separazione                                                    *
C*                                                                   *
C*********************************************************************
C
      SUBROUTINE WAD1PAR(TYP,PPVC,PCAV,TAUV,TAUL,BETA,ALFA,HSUP,HSUR)
C
C      AKW=100.E3 ! coeff. scambio condensazione superficiale
C      AKQ=100. ! coeff. scambio convezione superficiale
C      ALFA=3.3 ! peso sottoraf. nella convezione sup.
C      BETA=0.1 ! sottoraf. sup./sottoraf. bulk
C      TG=1.  ! tempo condensazione
C      TL=1.  ! tempo evaporazione
C
      HSUP=100.E3
      HSUR=100.
      ALFA=3.3
      BETA=0.1
      TAUV=1.
      TAUL=1.
C
      RETURN
      END
C
C
C
      SUBROUTINE WAD1SEP(TYP,XOVP,XUNP,XR,WR,P,XOVS,XUNS)
C
      XOVS=XOVP
      XUNS=XUNP
C
      RETURN
      END
C
C
C

      SUBROUTINE WAD1D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
      Q0 = W0*H0
C
      AMA0 = DATI(IPD+13)
      AMV0 = DATI(IPD+14)
      WAS0  = DATI(IPD+15)
      WVS0  = DATI(IPD+16)
      WCE0  = DATI(IPD+17)
C 
      ALZS = XYU(IXYU+18)
C
C-----Calcolo in stazionario
C
      NVARIABL=13+NINGRE
      DO I = 1, 13
        DO  J = 1,NVARIABL
          ITOPVA(I,J) = 1
        END DO
      END DO
C
C---si considerano solo le normali condizioni operative
C   (cavita` non piena, non vuota e non isolata)
C
C--residuo n.1     equazione di conservazione della massa di vapore
C                       (Total pressure in the cavity)
C
      SIGNEQ(1) = 'STEAM MASS CONSERVATION INSIDE THE CAVITY'
      UNITEQ(1) = 'kg/s'
      COSNOR(1) = W0
C
C
C--residuo n.2      equazione di conservazione dell'energia del vapore
C                       ( Steam enthalpy )
C
      SIGNEQ(2) = 'STEAM ENERGY CONSERVATION INSIDE THE CAVITY'
      UNITEQ(2) = 'W'
      COSNOR(2) = Q0
C
C
C--residuo n.3      equazione di conservazione dell'energia del liquido
C                       ( Liquid enthalpy )
C
      SIGNEQ(3) = 'LIQUID ENERGY CONSERVATION INSIDE THE CAVITY'
      UNITEQ(3) = 'W'
      COSNOR(3) = Q0
C
C
C---residuo n.4    equazione di conservazione della massa d'aria
C   per ALZS = 0. si suppone che non vi sia aria dentro la cavita`
C
      IF (ALZS .GT. 0.) THEN
        SIGNEQ(4) = 'AIR MASS CONSERVATION INSIDE THE CAVITY'
        UNITEQ(4) = 'kg/s'
        COSNOR(4) = AMA0
      ELSE
        SIGNEQ(4) = 'CHECK OF NO AIR MASS INSIDE THE CAVITY'
        UNITEQ(4) = 'kg'
        COSNOR(4) = AMA0
      END IF
C
C
C--residuo n.5      equazione di conservazione della massa di liquido
C                       ( Liquid mass )
C
      SIGNEQ(5) = 'LIQUID MASS CONSERVATION INSIDE THE CAVITY'
      UNITEQ(5) = 'kg/s'
      COSNOR(5) = W0
C
C
C--residuo n.6     Steam mass in the cavity
C
      SIGNEQ(6) = 'COMPUTATION OF STEAM MASS IN THE CAVITY'
      UNITEQ(6) = 'kg'
      COSNOR(6) = AMV0
C
C
C--residuo n.7      livello del liquido
C
      SIGNEQ(7) = 'LIQUID LEVEL COMPUTATION IN THE CAVITY'
      UNITEQ(7) = '%'
      COSNOR(7) = 100.
C
C
C--residuo n.8      pressione sul fondo
C
      SIGNEQ(8) = 'PRESSURE ON THE BOTTOM OF THE CAVITY COMPUT.'
      UNITEQ(8) = 'Pa'
      COSNOR(8) = P0
C
C--residuo n.9     Air partial pressure
C
      SIGNEQ(9) = 'AIR PARTIAL PRESSURE IN THE CAVITY COMPUT.'
      UNITEQ(9) = 'Pa'
      COSNOR(9) = P0
C
C
C--residuo n.10    Steam partial pressure
C
      SIGNEQ(10) = 'STEAM PARTIAL PRESSURE IN THE CAVITY COMPUT.'
      UNITEQ(10) = 'Pa'
      COSNOR(10) = P0
C
C
C--residuo n.11     portata di aria entrante o uscente dallo sfiato
C
      SIGNEQ(11) = 'FLOW RATE OF AIR FROM OR TO VENTING VALVE'
      UNITEQ(11) = 'kg/s'
      COSNOR(11) = WAS0
C
C
C--residuo n.12     portata di vapore uscente dallo sfiato
C
      SIGNEQ(12) = 'FLOW RATE OF STEAM EXITING THROUGH VENTING VALVE'
      UNITEQ(12) = 'kg/s'
      COSNOR(12) = WVS0
C
C
C
C--residuo n.13     Surface condensation/evaporation mass flow rate
C
C     SIGNEQ(13) = 'Surface condensation/evaporation mass flow rate'
C     UNITEQ(13) = 'kg/s'
C     COSNOR(13) = WCE0
C
C--residuo n.13     Liquid temperature
C
      SIGNEQ(13) = 'Liquid temperature'
      UNITEQ(13) = 'K'
      COSNOR(13) = T0
C
C--residuo n.14     Steam-air temperature
C
      SIGNEQ(13) = 'Steam-air temperature'
      UNITEQ(13) = 'K'
      COSNOR(13) = T0
C
      RETURN
      END
C
C
C
C      SUBROUTINE WAD1LIV(VCAV,RCAV,HLCAV,Y,YTOT,SEZ)
CC
CC CALCOLA IL LIVELLO  IN UN CILINDRO ORIZZONTALE
CC
CC          Y  livello diviso 100
CC          YTOT livello in metri
CC          SEZ  superficie del pelo libero
CC NOTI:
CC     VCAV  volume occupato
CC     RCAV  raggio del cilindro
CC     HLCAV lunghezza del cilindro
CC
CC ESECUZIONE
CC
C      Y0=Y
C      VMAX=RCAV*RCAV*3.141592*HLCAV
C      IF(VCAV.LT.VMAX)GO TO 99
C      YTOT=2*RCAV
C      Y=YTOT/100.
C      SEZ=0.
C      RETURN
C   99 IF(VCAV.GT.1.E-3)GO TO 98
C      YTOT=0.
C      Y=0.
C      SEZ=0.
C      RETURN
CC
CC     CALCOLO IETERATIVO SECONDO NEWTON-RAPHSON
CC
C   98 IT=0
C      Y=RCAV
C    1 IT=IT+1
CC
CC ALFA: ANGOLO AL CENTRO DEL SEGMENTO CIRCOLARE
CC
C      ALFA=ACOS((RCAV-Y)/RCAV)
C      AST=RCAV**2.*ALFA-RCAV*(RCAV-Y)*SIN(ALFA)
CC
CC   RESIDUO
CC
C      RES=VCAV-HLCAV*AST
CC
C      IF(ABS(RES).LT.1.E-4)GO TO 10
C      IF(IT.GT.100)GO TO 20
CC
CC     JACOBIANO
CC
C      DALFA=1./(RCAV*SQRT(1.-((RCAV-Y)/RCAV)**2.))
C      DASOT=RCAV**2.*DALFA+RCAV*SIN(ALFA)+COS(ALFA)*RCAV*
C     $ DALFA*(Y-RCAV)
C      DVDY=DASOT*HLCAV
CC
CC   ITERAZIONE
CC
C      DY=RES/DVDY
C      Y=Y+DY
C      GO TO 1
CC
CC   SOLUZIONE
CC
C   10 CONTINUE
C      YTOT=Y
C      SEZ=HLCAV*2*SQRT(2*RCAV*Y-Y*Y)
C      Y=Y/100.
C      RETURN
C   20 WRITE(6,1000)RES
C 1000 FORMAT(//10X,'SUBROUTINE WAD1LCO'/
C     $  10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
C      GO TO 10
C      END
C
C
C~FORAUS_WAD1~C
C
C FORTRAN AUSILIARIO DEL MODULO CAVITA` LIQUIDO-VAPORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE WAD1LIV(TYP,VLIV,Y,YTOT,AREA)
C
C  La subroutine CNDLIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  WAD1  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  WAD1LIV(TYP,VLIV,Y,YTOT,AREA)
C     RETURN
C     END
C
C~FORAUS_WAD1~C
