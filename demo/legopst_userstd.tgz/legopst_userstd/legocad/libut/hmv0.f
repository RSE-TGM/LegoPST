C**********************************************************************
C modulo HMV0.f
C tipo 
C release 5.3
C data 13/10/2007
C reserver @(#)HMV0.f	5.3
C**********************************************************************
C
C**********************************************************************
C
C   Heavy Metal Valve rel. 0
C
C   ref. I. E. Idelchik - Handbook of hydraulic resistance - 
C   Hemisphere Publishing Corporation - 1986
C    
C
C   Vincenzo Casamassima
C   SSG - Generation Systems Departement
C   CESI Ricerca
C   via Rubattino, 54
C   20134 Milan
C   Italy
C**********************************************************************
C
      SUBROUTINE HMV0I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMV000/IBLOC
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 NOMAPP
      CHARACTER*4 MOD
      DATA MOD/'HMV0'/
C
C
C
      CALL HMV0I4(IOB,MOD)
C
C
C
      NSTATI=0
      NUSCIT=3
      NINGRE=5
C
      WRITE(NOMAPP,'(A1)')IBLOC
      WP=0.
      IF(NOMAPP(1:1).EQ.'+')WP=1.
      IF(NOMAPP(1:1).EQ.'-')WP=2.
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
      IF (WP.EQ.0.) THEN
        WRITE(IFO,3000)IOB
3000    FORMAT('WTUB',A4,2X,'--UA-- FLUID MASS FLOW RATE ')
        WRITE(IFO,3001)IOB
3001    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3002)IOB
3002    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT METER INLET -W<0')
        WRITE(IFO,3003)IOB
3003    FORMAT('PITU',A4,2X,'--IN-- UPSTREAM PRESSURE ')
        WRITE(IFO,3004)IOB
3004    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3005)IOB
3005    FORMAT('PUTU',A4,2X,'--IN-- DOWNSTREAM PRESSURE')
        WRITE(IFO,3006)IOB
3006    FORMAT('HUTI',A4,2X,'--IN-- FLUID ENTHALPY AT METER OUTLET-W<0')
        WRITE(IFO,3007)IOB
3007    FORMAT('ACTU',A4,2X,'--IN-- ACTUATOR POSITION - 0 CLOSE - 1',
     $                              ' FULLY OPEN')
      END IF
C
      IF (WP.EQ.1.) THEN
        WRITE(IFO,3008)IOB
3008    FORMAT('PITU',A4,2X,'--UA-- PIPE INLET PRESSURE ')
        WRITE(IFO,3009)IOB
3009    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3010)IOB
3010    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3011)IOB
3011    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
      WRITE(IFO,3012)IOB
3012    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3013)IOB
3013    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3014)IOB
3014    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3015)IOB
3015    FORMAT('AKTB',A4,2X,'--IN-- ACTUATOR POSITION - 0 CLOSE - 1',
     $                              ' FULLY OPEN')
      END IF
C
      IF (WP.EQ.2.) THEN
        WRITE(IFO,3016)IOB
3016    FORMAT('PUTU',A4,2X,'--UA-- PIPE OUTLET PRESSURE ')
        WRITE(IFO,3017)IOB
3017    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3018)IOB
3018    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3019)IOB
3019    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3020)IOB
3020    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3021)IOB
3021    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
         WRITE(IFO,3022)IOB
3022    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3023)IOB
3023    FORMAT('AKTB',A4,2X,'--IN-- ACTUATOR POSITION - 0 CLOSE - 1',
     $                              ' FULLY OPEN')
      END IF
C
      RETURN
      END
      SUBROUTINE HMV0I4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMV000/IBLOC
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MODU
      CHARACTER*1 ICA,IMEN,IPIU
      CHARACTER*1 IBL
      CHARACTER*4 MOD
      DATA IBL/' '/
      DATA IPIU/'+'/
      DATA IMEN/'-'/
C
    2 WRITE(6,2999)
 2999 FORMAT(//10X,'GIVE A CHARACTER'
     $ /5X,' - FLOW RATE AS OUTPUT =========> BLANK'
     $ /5X,' - INLET PRESSURE AS OUTPUT ====>   +'
     $ /5X,' - OUTLET PRESSURE AS OUTPUT ===>   -')
      READ(5,3001)ICA
      IF(ICA.EQ.IPIU)GO TO 1
      IF(ICA.EQ.IMEN)GO TO 1
      IF(ICA.EQ.IBL)GO TO 1
      GO TO 2
 3001 FORMAT(A)
    1 CONTINUE
C
      WRITE(MODU,'(A1,A3)')ICA,MOD
      IF(ICA.EQ.IBL)MODU=MOD
      WRITE(IBLOC,'(2A4)')MODU,IOB
C
      RETURN
      END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMV0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,NOM1,NOM2,
     $ IER,CNXYU,TOL)
C
C-------------------------------------------------------------------------
C
C     FLUID = Fluid through the flow meter (Lead, LBE, Sodium ....)
C     PID   = Main pipe internal diameter
C     OD    = Orifice Diameter
C     DC    = Dimensionless discharge coefficient Cd
C
C--------------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*8 PID,VD,DC,DFLUID,Fluid,VALVT,VL
      CHARACTER*6 RTN,RTD,RTL,RTP,RTDZ,HLC,FluidT,ROUGH                                
      CHARACTER*4 NOMAPP
      CHARACTER*10 FluidType
      INTEGER VAR,FluidIndex,ValveType
      LOGICAL JPB,JPB1,JLEAD,JLBE,JLBE1,JNA,JNA1,JSODIUM
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
      COMMON / NORM / P0,H0,T0,Q0,R0,AL0,V0,DP0
      DATA DFLUID/'Fluid'/
      DATA VALVT/'VALVType'/,PID/'Pipe Dia'/,VD/'Valve D.'/
      DATA VL/'Valve L.'/,DC/'Cd      '/
      DATA FluidT/'Fluid '/
C
      GO TO (1,10),IFUN
C
C      SCRITTURA DEI SIMBOLI SUL FILE 14
C
   1  CONTINUE                                                    
      WRITE(14,3800)
 3800 FORMAT ('*   Heavy Metal Selection : Lead, LBE, Sodium')
      WRITE(14,'(4X,A6,A4,10X,A1)')FluidT,'   =','*'
      WRITE(14,3900)
 3900 FORMAT ('*   -')
      WRITE(14,4000)
 4000 FORMAT ('*   Valve Model Selection :')
      WRITE(14,4001)                                                 
 4001 FORMAT ('*   0 --> Conical seal gate in straight pipe - Flanged' )
      WRITE(14,4002)
 4002 FORMAT ('*   1 --> -- to be defined --')
      WRITE(14,4003)
 4003 FORMAT ('*   2 --> -- to be defined --')
      WRITE(14,4004)
 4004 FORMAT (4X,'ValveMdSl=',10X,'*')
      WRITE(14,4005)
 4005 FORMAT ('*   -')
      WRITE(14,4006)
 4006 FORMAT ('*     0 - Conical seal gate in straight pipe - Flanged' )
      WRITE(14,4007)
 4007 FORMAT ('*   Pipe data')
      WRITE(14,4008)
 4008 FORMAT ('*      Pipe dia - [m] Pipe diameter ')
      WRITE(14,1100) 'Pipe dia ='
 1100 FORMAT(3(4X,A10,10X,'*'),5X)     
      WRITE(14,4009)
 4009 FORMAT ('*   Valve data')
      WRITE(14,4010)
 4010 FORMAT ('*         Vpd - [m] Valve passage diameter ')
      WRITE(14,4011)
 4011 FORMAT ('*         Vpl - [m] Valve passage lenght ')
      WRITE(14,4012)
 4012 FORMAT ('*         Vpr - [m] Valve passage roughness ')
      WRITE(14,4013)
 4013 FORMAT ('*         Cd  - [....] Valve discharge coefficient ')
      WRITE(14,1100)'Vpd  [m] =','Vpl  [m] =','Vpr  [m] =','Cd [...] ='
      WRITE(14,4014)
 4014 FORMAT ('*   Flange data')
      WRITE(14,4015)
 4015 FORMAT ('*         Fpd - [m] Flange passage diameter ')
      WRITE(14,4016)
 4016 FORMAT ('*         Fpl - [m] Flange passage lenght ')
      WRITE(14,4017)
 4017 FORMAT ('*         Fpr - [m] Flange passage roughness ')
      WRITE(14,1100)'Fpd  [m] =','Fpl  [m] =','Fpr  [m] ='
      WRITE(14,4018)
 4018 FORMAT ('*   Gasket data')
      WRITE(14,4019)
 4019 FORMAT ('*          Gt - [m] gasket thickness ')
      WRITE(14,4020)
 4020 FORMAT ('*          Gd - [m] gasket diameter')
      WRITE(14,4021)
 4021 FORMAT ('*          Gr - [m] gasket roughness')
      WRITE(14,1100)'Gt   [m] =','Gd   [m] =','Gr   [m] ='
C
      RETURN
C
C      LETTURA  DEI DATI DAL FILE 14
C
   10 CONTINUE                                                                      
C
C -----   inizio modifica istruzione di DECODE   -----
C
      WRITE(NOMAPP,'(A1)')NOM1
      IWP=0
      IF(NOMAPP(1:1).EQ.'+')IWP=1
      IF(NOMAPP(1:1).EQ.'-')IWP=2
C
C -----    fine modifica istruzione di DECODE    -----
C
      IF(IWP.EQ.0)WRITE(6,502)'*** FLOW RATE AS OUTPUT ***'
      IF(IWP.EQ.1)WRITE(6,502)'*** INLET PRESSURE AS OUTPUT ***'
      IF(IWP.EQ.2)WRITE(6,502)'*** OUTLET PRESSURE AS OUTPUT ***'
  502 FORMAT(14X,A,//)
C
      READ(14,1070)
      READ(14,1070)
      READ(14,'(14X,A10)') FluidType                                                     
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070) ValveType                                                     
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070) PipeD                                                     
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070) Vpd,Vpl,Vpr,Cd                                                     
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070) Fpd,Fpl,Fpr                                                   
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070)
      READ(14,1070) Gt,Gd,Gr                                                     
C
 1070 FORMAT(3(14X,F10.0,1X),5X)
 1071 FORMAT(14X,A8,3X,2(14X,F10.0,1X),5X)
C
C
      Select Case  (ValveType)
        Case (0)
          write(6,'(21x,1A)')
     $    'Valve model : Conical seal gate in straight pipe - Flanged'                                      
        Case Default
          write(6,*)'WARNING!!! Valve model is not assigned'                                        
          write(6,*)'WARNING!!! default case - ',
     $    'Valve model : Conical seal gate in straight pipe - Flanged'                                          
      End Select
C
C---- Fluid index assignement
C
C--- SELECT CASE on CHARACTER type not supported by GNU FORTRAN ----
C
C      Select Case  (FluidType)
C        Case ("PB","Pb","pB","pb")
C          FluidIndex=1
C          write(6,'(27x,2A)')'Fluid : ',FluidType                                          
CC          write(6,'(27x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Lead','lead')
C          FluidIndex=1
C          write(6,'(27x,2A)')'Fluid : ',FluidType                                          
CC          write(6,'(27x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('LBE','Lbe','lbe')
C          FluidIndex=2
C          write(6,'(27x,2A)')'Fluid : ',FluidType                                          
CC          write(6,'(27x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Sodium','sodium','NA','Na','nA','na')
C          FluidIndex=3.
C          write(6,'(27x,2A,I1)')'Fluid : ',FluidType                                          
CC          write(6,'(27x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case Default
C          FluidIndex=1
C          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
C          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
C          write(6,*)'WARNING!!! default case - Fluid Index   ='
C     $              ,FluidIndex                                             
C      End Select
C
       JPB=(FluidType.EQ.'PB'.OR.FluidType.EQ.'Pb')
       JPB1=(FluidType.EQ.'pB'.OR.FluidType.EQ.'pb')
       JLEAD=(FluidType.EQ.'Lead'.OR.FluidType.EQ.'lead')
       JLBE=(FluidType.EQ.'LBE'.OR.FluidType.EQ.'Lbe')
       JLBE1=(FluidType.EQ.'lbe')
       JSODIUM=(FluidType.EQ.'Sodium'.OR.FluidType.EQ.'sodium')
       JNA=(FluidType.EQ.'NA'.OR.FluidType.EQ.'Na')
       JNA1=(FluidType.EQ.'nA'.OR.FluidType.EQ.'na')
C
       IF (JPB.OR.JPB1.OR.JLEAD) THEN
          FluidIndex=1
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JLBE.OR.JLBE1) THEN
          FluidIndex=2
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JNA.OR.JNA1.OR.JSODIUM) THEN
          FluidIndex=3.
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE
          FluidIndex=1
          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
          write(6,*)'WARNING!!! default case - Fluid Index   ='
     $              ,FluidIndex                                             
       END IF                                             
CC                                           
C
C--- ---------------------------------------------------------------- ----
C
C
C------ General data calculation
C
C
C
C   CALCOLO DEL COEFFICIENTE DI PERDITA DI CARICO
C
C
C	RK0=0.
C
C	IF(WL.GT.0.) THEN
C	  IFL=1
C          TLEAD=T_H_LEAD(H)
C          RO=RO_T_LEAD(TLEAD)
C 	  RK0=2.*(PM-PV)*RO/(WL*WL)
C	  GO TO 15
C	ENDIF
C	   RK0= CS
C 15   CONTINUE
C
C      DECODE(1,2222,NOM1)IWP
C 2222 FORMAT(A1,3X)
C       MEMORIZZAZIONE DATI
C
C      RKK=RK0
C      WRITE(6,3023)RKK
 3023 FORMAT(//10X,'HEAD LOSS COEFFICIENT = ',E12.5/)
C
      DATI(ID1)=FluidIndex
      DATI(ID1+1)=IWP
      DATI(ID1+2)=ValveType
      DATI(ID1+3)=PipeD
      DATI(ID1+4)=Vpd
      DATI(ID1+5)=Vpl
      DATI(ID1+6)=Vpr
      DATI(ID1+7)=Cd
      DATI(ID1+8)=Fpd
      DATI(ID1+9)=Fpl
      DATI(ID1+10)=Fpr
      DATI(ID1+11)=Gt
      DATI(ID1+12)=Gd
      DATI(ID1+13)=Gr
      ID2=ID2+13
C
C   COSTANTI DI NORMALIZZAZIONE
C
      CNXYU(IV1)=Q0
      CNXYU(IV1+1)=H0
      CNXYU(IV1+2)=H0
      CNXYU(IV1+3)=P0
      CNXYU(IV1+4)=H0
      CNXYU(IV1+5)=P0
      CNXYU(IV1+6)=H0
      CNXYU(IV1+7)=1.
C
      IF (IWP.EQ.1) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+3)=Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+5)=Q0
      END IF
C
C   TOLLERANZA PER LA SOLUZIONE DELL'EQUAZIONE
C    viene posta 1000 pascal / P0
C     se viene data la differenza di pressione nominale
C     viene posta 1/100 di quest'ultima.
C
C      TOL(1)=1000./P0
C$$$
C      IF(WL.GT.0.) TOL(1)=(PM-PV)/100./P0
C$$$
C
      WRITE(6,*)                           
      WRITE(6,'(21x,1A,I2)')   'Fluid Index :',FluidIndex                                
      WRITE(6,'(20x,1A,I2)')   'Valve Index  :',ValveType                                      
      WRITE(6,'(19x,1A,F8.5)')'Pipe Diameter :',PipeD                                    
      WRITE(6,'(10x,1A,F8.5)')'Valve Passage Diameter :',Vpd                                       
      WRITE(6,'(12x,1A,F8.5)')'Valve Passage Lenght :',Vpl                                       
      WRITE(6,'(9x,1A,E8.3)')'Valve Passage Roughness :  ',Vpr                                       
      WRITE(6,'(5x,1A,F8.5)')'Valve Discharge coefficient :',Cd                                       
      WRITE(6,'(9x,1A,F8.5)')'Flange Passage Diameter :',Fpd                                     
      WRITE(6,'(11x,1A,F8.5)')'Flange Passage Lenght :',Fpl                                     
      WRITE(6,'(8x,1A,E8.3)')'Flange Passage Roughness :  ',Fpr                                     
      WRITE(6,'(16x,1A,F8.5)')'Gasket Thichness :',Gt                                     
      WRITE(6,'(17x,1A,F8.5)')'Gasket Diameter :',Gd                                     
      WRITE(6,'(16x,1A,E8.3)')'Gasket Roughness :  ',Gr                                     
      WRITE(6,*)                           
      WRITE(6,*)                           
C
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMV0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RN,NOM1,NOM2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      INTEGER ValveType
      INTEGER FluidIndex
      REAL MU
      REAL L0SUD0,K1
      LOGICAL KREGIM
C
      PARAMETER (NFGSUFS=4,NL0SUD0=8,NK1=NFGSUFS*NL0SUD0)
      PARAMETER (NCDELTA2=11,NCDUMMY=2,NV1A1=NCDUMMY*NCDELTA2)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION TABFGSUFS(NFGSUFS),TABL0SUD0(NL0SUD0),TABNK1(NK1)
      DIMENSION TABDUMMY(NCDUMMY),TABDELTA2(NCDELTA2),TAB1A1(NV1A1)
C
      COMMON/NORM/P0,H0,T0,Q0,R0,AL0,V0,DP0
      COMMON/TOLEG00/TOLIN(100)
      COMMON/PARPAR/NUL(6),KSTP,ITERT
      COMMON/REGIME/KREGIM                                  
C
      DATA SccsID/'@(#)HMV0.f	5.3\t 5.3\t 10/3/96'/          
      DATA PIGRECO/3.141592653/          
C
C
      DATA TABFGSUFS/1.6,2.3,3.2,4./
      DATA TABL0SUD0/0.0,0.5,0.6,0.7,0.8,1.,1.4,2./
      DATA TABNK1/1.0,  1.02, 1.01, 1.0,  1.0 , 1.0,  1.0,  1.0,
     $            1.0,  1.06, 1.03, 1.02, 1.01, 1.0,  1.0,  1.0, 
     $            1.0,  1.16, 1.10, 1.06, 1.04, 1.01, 1.0,  1.0,
     $            1.0,  1.20, 1.15, 1.10, 1.08, 1.04, 1.03, 1.0/
C
      DATA TABDUMMY/0.,1./
      DATA TABDELTA2 /0.,10.,20.,30.,40.,50.,60.,70.,80.,85.,90./
      DATA TAB1A1/0.05,0.51,2.75,7.7,17.5,48.5,150.,810.,2500.,6000.,
     $                                                       216910.,
     $            0.05,0.51,2.75,7.7,17.5,48.5,150.,810.,2500.,6000.,
     $                                                       216910./
      DATA DUMMY /0.5/
C
C
      IFL=1
      GO TO (1,10,10),IFUN
C
C   DEFINIZIONE DELLA TOPOLOGIA
C
  1   CONTINUE
C
      DO J=1,3
        DO I=1,8
          AJAC(J,I)=1.
        END DO
      END DO
C
      RETURN
C 
C   DECODIFICA DEI DATI
C
   10 CONTINUE
C
      FluidIndex=DATI(IPD)
      IWP=DATI(IPD+1)
      ValveType=DATI(IPD+2)
      PipeD=DATI(IPD+3)
      Vpd=DATI(IPD+4)
      Vpl=DATI(IPD+5)
      Vpr=DATI(IPD+6)
      Cd=DATI(IPD+7)
      Fpd=DATI(IPD+8)
      Fpl=DATI(IPD+9)
      Fpr=DATI(IPD+10)
      Gt=DATI(IPD+11)
      Gd=DATI(IPD+12)
      Gr=DATI(IPD+13)
C
C   DECODIFICA DELLE VARIABILI
C
      W=XYU(IXYU)*Q0
      HUTU=XYU(IXYU+1)*H0
      HITI=XYU(IXYU+2)*H0
      PM=XYU(IXYU+3)*P0
      HITU=XYU(IXYU+4)*H0
      PV=XYU(IXYU+5)*P0
      HUTI=XYU(IXYU+6)*H0
      ACTU=XYU(IXYU+7)
C
      IF (IWP.EQ.1) THEN
        PM=XYU(IXYU)*P0
        W=XYU(IXYU+3)*Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        PV=XYU(IXYU)*P0
        W=XYU(IXYU+5)*Q0
      END IF
CC
      DP = PM-PV
      PMED=(0.5*PM+0.5*PV)
      IF (PM.GE.PV) THEN
        CALL HMV0_FLUID_PROP(FluidIndex,HITU,RO,MU)
C      write(6,*)'TFLUIDI=',TFLUIDI,' MU=',MU                                              
      ELSE
        CALL HMV0_FLUID_PROP(FluidIndex,HUTI,RO,MU)
C      write(6,*)'TFLUIDO=',TFLUIDO,' MU=',MU                                              
       END IF
C
C      PipeD=0.0529
C      Orifd=0.03246
C
C      TOLIN(1)=50./P0
C      TOLIN(1)=0.001/Q0
C
C
      Select Case  (ValveType)
        Case (0)
CX          write(6,*)'case 0'
C
C         Flanged joint with gasket right and left contribution
C
C           TD   = Tube diameter
C           FS   = main stream flow section
C           GT   = Gasket thickness
C           GD   = Gasket diameter
C           FG   = Gasket flow section
C           CSIE = Expansion coefficient
C           CSIC = Contraction coefficient
C           CL   = Linear loss coefficient
C             
C----  Expansion contribution --------------------------------------
C
           FSP=PIGRECO*PipeD*PipeD/4.
           FG=PIGRECO*Gd*Gd/4.
           CSIE=(1-FSP/FG)**2.
C
C----  Contraction contribution --------------------------------------
C
           FSF=PIGRECO*Fpd*Fpd/4.
           CSIC=0.5*(1-FSF/FG)**(3./4.)
C
C----  Gasket friction contribution --------------------------------------
C
           GASPEED=ABS(W)/FG
           CALL HMV0_MOODY_FF(Gr,Gd,GASPEED,MU,GF)
           CL=Gt/Gd*GF
C
C----  Gaskets global contribution --------------------------------------
C
           FGSUFS=FG/FSP
           L0SUD0=Gt/Gd
           CALL LINTAB(TABFGSUFS,NFGSUFS,TABL0SUD0,NL0SUD0,TABNK1,
     $                L0SUD0,FGSUFS,K1,Z1,Z2)
           CSILOC=2.*K1*(CSIE+CSIC+CL)
C          write(6,*)'CSI locale ','FS=',FS,' FG=',FG,' CSIE=',CSIE                                              
C          write(6,*)'CSI locale ','CSIC=',CSIC,' GASPEED=',GASPEED                                              
CX          write(6,*)'CSI locale ','FGSUFS=',FGSUFS,' L0SUD0=',L0SUD0                                             
CX          write(6,*)'CSI locale ','GF=',GF,' CL=',CL,' K1=',K1                                              
C          write(6,*)'CSI locale ','Z1=',Z1,' Z2=',Z2                                           
C          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C
C
C----  Flange friction contribution --------------------------------------
C
           FLSPEED=ABS(W)/FSF
           CALL HMV0_MOODY_FF(Fpr,Fpd,FLSPEED,MU,FLF)
           FLC=Fpl/Fpd*FLF
C
C----  Flanges friction global contribution --------------------------------------
C
           FLC=2.*FLC
C
C----  Flange -> Valve Contraction contribution --------------------------------------
C
           VFS=PIGRECO*Vpd*Vpd/4.
           VCSIC=0.5*(1-VFS/FSF)**(3./4.)
C             
C----  Valve -> Flange   Expansion contribution --------------------------------------
C
           VCSIE=(1-VFS/FSF)**2.
C
C----  Valve friction contribution --------------------------------------
C
           VSPEED=ABS(W)/VFS
           CALL HMV0_MOODY_FF(Vpr,Vpd,VSPEED,MU,VLF)
           VLC=Vpl/Vpd*VLF
C
C----  Valve global transition contribution
C
           VFGSUFS=FSF/VFS
           VL0SUD0=Vpl/Vpd
           CALL LINTAB(TABFGSUFS,NFGSUFS,TABL0SUD0,NL0SUD0,TABNK1,
     $                VL0SUD0,VFGSUFS,VK1,Z1,Z2)
           VCSILOC=VK1*(VCSIC+VCSIE+VLC)
C
C----  Valve global resitance
C
          DELTA=90.*(1.-ACTU)
C
          CALL LINTAB(TABDUMMY,NCDUMMY,TABDELTA2,NCDELTA2,TAB1A1
     $                ,DELTA,DUMMY,CSI,Z1,Z2)
C
          CSIOV=CSI+VCSILOC+CSILOC+FLC
C
        Case Default
      End Select
C
C
CX      Write(6,*)'CSI=',CSI,'VCSILOC=',VCSILOC,'CSILOC=',CSILOC
CX      Write(6,*)'VLC=',VLC,'CL=',CL,'K1=',K1,'VK1=',VK1,'FLC=',FLC
CX      Write(6,*)'CSIOV=',CSIOV,'DELTA=',DELTA
C
C   CALCOLO DEL RESIDUO
C
      RK0=CSIOV/(VFS*VFS)
CX      Write(6,*)'RK0=',RK0
      IF(IFUN.EQ.3) GO TO 40
C      RN(1) = (DP-ACTU*RK0/RO/2.*W*ABS(W))/P0
      RN(1) = (ACTU*ACTU*DP-RK0/RO/2.*W*ABS(W))/P0
      RN(2) = (HITU-HUTU)/H0
      RN(3) = (HUTI-HITI)/H0
C
      IF (KREGIM.AND.IFUN.EQ.2.AND.ITERT.EQ.0) THEN
        WRITE(6,*)
        WRITE(6,*)
        WRITE(6,*)
        WRITE(6,'(1A18,2A4,1A10)')'  --------  Block ',NOM1,NOM2
     $                           ,'  --------'
        WRITE(6,*)
        WRITE(6,*)' (Valve + Flanges)  Global pressure drop coefficient'
     $            ,' K :',CSIOV
        WRITE(6,*)
	GLOBF=2.*CL+FLC+VLC
	GLOBCSI=CSI+VCSILOC+CSILOC
	FSPEED=VSPEED/RO
C	FSPEED=FLSPEED/RO
C        write(16,*)'FLSPEED ',FLSPEED,'VSPEED ',VSPEED 
	RE=VSPEED*Vpd/MU
        WRITE(34,1005)NOM1,NOM2,GLOBF,GLOBCSI,CSIOV,FSPEED,RE                                                      
1005  FORMAT('Block ',2A4,5x,'f(L/D)',F12.6,5x,'Form loss coefficient K'
     $       ,F12.6,5x,'f(L/D)+K',F12.6,5x,'Average speed [m/s]',F12.6
     $       ,5x,'Average Reynolds number RE  ',F15.6 )
C      
      END IF
C
      RETURN
C
C     CALCOLO DELLO JACOBIANO
C
   40 IWPP=IWP+1
      GO TO (42,46,48),IWPP
C
C________ USCITA IN PORTATA
C
C   42 AJAC(1,1) = ACTU*RK0/RO*ABS(W)*Q0/P0
   42 AJAC(1,1) = RK0/RO*ABS(W)*Q0/P0
C      AJAC(1,4) = -1.
C      AJAC(1,6) = 1.
C      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
      AJAC(1,4) = -1.*ACTU*ACTU
      AJAC(1,6) = 1.*ACTU*ACTU
      AJAC(1,8) = 2.*ACTU*DP/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
        GO TO 50
C
C________ USCITA IN PRESSIONE A MONTE
C
  46  AJAC(1,1) = -1.
C      AJAC(1,4) = ACTU*RK0/RO*(ABS(W)+.1)/P0
      AJAC(1,4) = ACTU*RK0/RO*ABS(W)/P0
      AJAC(1,6) = 1.
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
       GO TO 50
C
C________ USCITA IN PRESSIONE A VALLE
C
 48   AJAC(1,1) = 1.
      AJAC(1,4) = -1.
C      AJAC(1,6) = ACTU*RK0/RO*(ABS(W)+.1)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(1,6) = ACTU*RK0/RO*ABS(W)/P0
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
  50   RETURN
      END
CC
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMV0_FLUID_PROP(FluidIndex,H,RO,MU)
C
      INTEGER FluidIndex
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE
C
      Select Case  (FluidIndex)
          Case (1)
C           Case ('Lead')
            T=T_H_LEAD(H)
            RO=RO_T_LEAD(T)
            MU=MU_T_LEAD(T)
CX       write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
          Case (2)
C           Case ('LBE')
            T=T_H_LBE(H)
            RO=RO_T_LBE(T)
            MU=MU_T_LBE(T)
CX       write(6,*)'Case LBE ','T=',T,' MU=',MU                                              
C          Case (3)
C           Case ('Sodium')
          Case Default
C           Case ('Lead')
            T=T_H_LEAD(H)
            RO=RO_T_LEAD(T)
            MU=MU_T_LEAD(T)
CX       write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
      SUBROUTINE HMV0_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C                       Moody friction factor 
C
C  Parametri in ingresso:  ROUGHNESS, DIA,GSPEED,MU 
C  Parametri in uscita:    FRICF
C
C
C  ROUGHNESS [m] - Roughness
C  DIA       [m] - Equivalent Hydraulic Diameter
C  GSPEED    
C  MU        
C  FRICF
C
C-------------------------------------------------------------------------
C
      REAL MU
C
      COMMON/TEE0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
C
      RE=GSPEED*DIA/MU
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
	FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
	  FRICF=64./RE
	ELSE
	  IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
	  IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25                                                
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
	  DO WHILE (I.LE.100)
            IT=IT+1
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
	    END IF
	    
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
          END DO
C
C   SOLUZIONE
C
          WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP0_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBLOC1X,IBLOC2X
        END IF
      END IF
      RETURN                                                            
      END
C
C
CC
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMV0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
