C modulo dsr0.f
C tipo
C release 0.0
C data 7/giugno/2005
C Sulcis project libut reserver @(#)dsr0.f	0.0
C**********************************************************************
C
C
C 
C
C**********************************************************************
C
      SUBROUTINE DSR0I3(IFO,IOB,DEBL)
      COMMON/DSR000/IBLOC,NE,NUS
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'DSR0'/
C
C
      CALL DSR0I4(IOB,MOD)
C
      NZDSH=6
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      WRITE(IFO,3000)IOB
 3000 FORMAT('PWSS',A4,2X,'--US-- SHELL SIDE WATER PRESSURE')
C
      WRITE(IFO,3001)(I,IOB,I,I=1,NZDSH)
 3001 FORMAT('HSD',I1,A4,2X
     $      ,'--US-- STEAM ENTHALPY DESUPERHEATING ZONE ',I1)
C
      WRITE(IFO,3003)IOB
 3003 FORMAT('HVRS',A4,2X,'--US-- STEAM AVERAGE ENTHALPY')
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('TAMS',A4,2X,'--US-- SHELL METAL AVERAGE TEMPERATURE')
C
      WRITE(IFO,3005)(I,IOB,I,I=1,NZDSH)
 3005 FORMAT('TM',I2,A4,2X,'--US-- TUBES WALL TEMPERAT. ZONE ',I2)
C
      WRITE(IFO,3006) (I,IOB,I,I=1,NZDSH)
 3006 FORMAT('HF',I2,A4,2X,'--US-- TUBES SIDE WATER ENTHALPY ZONE ',I2)
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WFDW',A4,2X,'--UA-- FEEDWATER MASS FLOW RATE')
C
      DO J=1,NE
        WRITE(IFO,3020)J,IOB,J
        WRITE(IFO,3021)J,IOB,J
      ENDDO 
 3020 FORMAT('WS',I2,A4,2X,'--IN-- STEAM MASS FLOW RATE INLET  N.',I2)
 3021 FORMAT('HS',I2,A4,2X,'--IN-- STEAM ENTHALPY INLET BRANCH N.',I2)
C
      DO J=1,NUS
        WRITE(IFO,3022)J,IOB,J
        WRITE(IFO,3023)J,IOB,J
      ENDDO
 3022 FORMAT('WSO',I1,A4,2X,'--IN-- STEAM FLOW RATE OUTLET  N ',I1)
 3023 FORMAT('HSO',I1,A4,2X,'--IN-- STEAM ENTHALPY OUTLET N',I1,'(W<0)')
C
      WRITE(IFO,3024)IOB
 3024 FORMAT('PFIN',A4,2X,'--IN-- FEEDWATER INLET PRESSURE')
C
      WRITE(IFO,3025)IOB
 3025 FORMAT('HFIN',A4,2X,'--IN-- FEEDWATER INLET ENTHALPY')
C
      WRITE(IFO,3026)IOB
 3026 FORMAT('PFOU',A4,2X,'--IN-- FEEDWATER OUTLET PRESSURE')
C
      WRITE(IFO,3027)IOB
 3027 FORMAT('HFOU',A4,2X
     $      ,'--IN-- REVERSE FLOW FEEDWATER OUTLET ENTHALPY W<0')
C
      WRITE(IFO,3028)IOB
 3028 FORMAT('FTFF',A4,2X,'--IN-- FEEDWATER TUBES FRICTION FACTOR')
C
      WRITE(IFO,3029)IOB
 3029 FORMAT('ADSH',A4,2X
     $      ,'--IN-- DESUPERHEATING HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3030)IOB
 3030 FORMAT('GSIF',A4,2X
     $      ,'--IN-- SHELL-INNER FLUID HEAT TRANSFER COEFFICIENT')
C
      WRITE(IFO,3031)IOB
 3031 FORMAT('TEST',A4,2X,'--IN-- EXTERNAL ENVIRONMENT TEMPERATURE')
C
      WRITE(IFO,3032)IOB
 3032 FORMAT('GEST',A4,2X,'--IN-- EXTERNAL HEAT TRANSFER COEFFICIENT')
C
C
      RETURN
      END
C***********************************************************************
      SUBROUTINE DSR0I4(IOB,MOD)
      PARAMETER (MAXIO=5,MAXCI=15)
      COMMON/DSR000/IBLOC,NE,NUS
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
C
      WRITE(6,101) MAXIO
  101 FORMAT(10X,'***** High Pressure desuperheater model *****',//,
     $       10X,'Inlet Branches Number [01 -',I3,'] ?')
    9 CONTINUE
      READ(5,*) NE
      IF(NE.LE.0.OR.NE.GT.MAXIO) THEN
         WRITE(6,102) NE,MAXIO
         GOTO 9
      ENDIF
  102 FORMAT(/10X,'%% ERROR %% -> assigned inlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')
C
C
      WRITE(6,105) MAXIO
  105 FORMAT(10X,'Steam Outlet Branches Number [01 -',I3,'] ?')
   15 CONTINUE
      READ(5,*) NUS
      IF(NUS.LT.1.OR.NUS.GT.MAXIO) THEN
         WRITE(6,106) NUS,MAXIO
         GOTO 15
      ENDIF
  106 FORMAT(10X,'%% ERROR %% -> assigned outlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C***********************************************************************
        SUBROUTINE DSR0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
        DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
        PARAMETER (PI=3.14159)
        PARAMETER (MAXIO=5,MAXCI=15)
        PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
        COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
C
C   High pressure desuperheater model
C
        GO TO(100,200),IFUN
C
  100   WRITE(14,500)    'I.S.B.N.'
     1                  ,'O.S.B.N.'
     1                  ,'SH.O.D. '
     1                  ,'SH.THICK'
     1                  ,'SH.LENGH'
     1                  ,'SH.M.RO.'
     1                  ,'SH.CP.  '
     1                  ,'SH.COND.'
     1                  ,'D.C.I.  '
     1                  ,'TUB.NUMB'
     1                  ,'TUB.O.D.'
     1                  ,'TUB.THIC'
     1                  ,'TUB.LENG'
     1                  ,'TU.M.RO.'
     1                  ,'TUB. CP.'
     1                  ,'TUB. K. '
     1                  ,'DSH.SURF'
     1                  ,'U.SH.T.C'
     1                  ,'U.TH.T.C'
     1                  ,'H.T.A.'
        RETURN
C
C
C
C-----------'I.S.B.N.' - Inlet Steam Branch Number
C-----------'O.S.B.N.' - Outlet Steam Branch Number
C-----------'SH.O.D. ' - SHell Outside Diameter
C-----------'SH.THICK' - SHell THICKness
C-----------'SH.LENGH' - SHell LENGHT
C-----------'SH.M.RO.' - SHell Metal density
C-----------'SH.CP.  ' - SHell metal specific heat
C-----------'SH.COND.' - SHell metal CONDuctivity
C-----------'D.C.I.  ' - Diametro Cassa Interna
C-----------'TUB.NUMB' - TUBes NUMBer
C-----------'TUB.O.D.' - TUBes Outside Diameter
C-----------'TUB.THIC' - TUBes THICkness
C-----------'TUB.LENG' - TUBes LENGht
C-----------'TU.M.RO.' - TUbes Metal density
C-----------'TUB. CP.' - TUBes Metal specific heat
C-----------'TUB. K. ' - TUBes metal conductivity
C-----------'DSH.SURF' - DeSuperHeating SURFace
C-----------'U.SH.T.C' - User Shell Heat Transfer Coefficient
C-----------'U.TH.T.C' - User Tubes Heat Transfer Coefficient
C-----------'H.T.A.  ' - Heat Transfer Arrangement 0 = counterflow; 1 = parallel

C
C---lettura e memorizzazione dati
C
  200   READ(14,502)
        READ(14,502)     FNE
     1                  ,FNUS
     1                  ,SHOD
     1                  ,SHTHICK
     1                  ,SHLENGH
     1                  ,SHRO
     1                  ,SHCP
     1                  ,SHCOND
     1                  ,DCI
     1                  ,FNTUB
     1                  ,TUBOD
     1                  ,TTHICK
     1                  ,TUBLENGH
     1                  ,TUBRO
     1                  ,TUBCP
     1                  ,TUBK
     1                  ,DSHSUP
     1                  ,USHTC
     1                  ,UTHTC
     1                  ,HTA
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  502 FORMAT(3(14X,F10.2,1X))
C
C______________________________________________
C
      NE=FNE
      NUS=FNUS
      NZDSH=6
      FNZON=FLOAT(NZDSH)
      NTUB=FNTUB
C
C--- Shell outside surface ---
C
      SHOS=PI*SHOD*SHLENGH
C
C--- Shell inside diameter ---
C
      SHID=SHOD-2.*SHTHICK
C
C--- Shell inside surface ---
C
      SHIS=PI*SHID*SHLENGH
C
C--- Volume beetwen shell and internal tank ---
C
      SHIV=PI*(SHID**2.-DCI**2.)*SHLENGH/4.
C
C--- Tank inner volume without tubes' volume ---
C
      TIVWT=PI*DCI**2.*SHLENGH/4.-FNTUB*PI*(TUBOD**2)*TUBLENGH/4.
C
C
      IF (TIVWT.LE.0) THEN
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^    ERROR!!  ERROR!  ERROR!  ERROR!  ERROR!!    ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^  Tubes volume can''t be bigger then enclosure  ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)' '
        STOP
      ENDIF
C
C--- Internal tank flow cross-sectional area ---
C
C     FCSA=PI*(DCI**2.)/4.-FNTUB*PI*(TUBOD**2.)/4.
      FCSA=0.5*(PI*(DCI**2.)/4.-2.*FNTUB*PI*(TUBOD**2.)/4.)
C
C--- Internal tank equivalent diameter ---
C
C     EQD=4.*FCSA/(PI*DCI+FNTUB*PI*TUBOD)
      EQD=4.*FCSA/(FNTUB*PI*TUBOD)
C
C--- Shell metal mass ---
C
      SHMASS=SHRO*PI*(SHOD**2.-SHID**2.)/4.*SHLENGH
C
C--- Shell thermal capacity ---
C
      SHTC=SHCP*SHMASS
C
C--- Internal tank heat exchange surface per zone ---
C
      SSCIZ=PI*DCI*SHLENGH/FNZON
C
C--- Tubes' heat exchange surface per zone ---
C
      IF (DSHSUP.EQ.0.) THEN
         DSHSUP=FNTUB*PI*TUBOD*TUBLENGH
         TUBZSURF=FNTUB*PI*TUBOD*TUBLENGH/FNZON
      ELSE
         TUBZSURF=DSHSUP/FNZON
C
C--- Average tubes' outside diameter ----
C
         TUBOD=DSHSUP/(PI*FNTUB*TUBLENGH)
      ENDIF
C
C
C--- Feedwater tubes flow cross-sectional area ---
C
      FTCSA=FNTUB*PI*((TUBOD-2.*TTHICK)**2.)/4.
C
C--- Feedwater tubes equivalent diameter ---
C
      FTEQD=4.*FTCSA/(FNTUB*PI*(TUBOD-2.*TTHICK))
C
C
      WRITE(6,11)
   11 FORMAT(/10X,24H----  Shell's Data  ----)
      WRITE(6,12)SHOD,SHTHICK,SHLENGH,SHID
   12 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Shell lenght',13X,'Inside diameter',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],23X,3H[m]//,10X,
     $       4(G15.6,10X))
      WRITE(6,13)SHOS,SHIS,(TIVWT+SHIV),SHMASS
   13 FORMAT(///10X,'Outside surface',10X,'Inside surface',
     $       11X,'Inside volume',12X,'Metal mass',/16X,
     $       4H[m2],19X,4H[m2],22X,4H[m3],20X,4H[kg]//,10X,
     $       4(G15.6,10X))
      WRITE(6,14)FCSA,EQD
   14 FORMAT(///10X,'Flow cross-sectional area',
     $       10X,'Equivalent diameter',/,20X,
     $       4H[m2],30X,3H[m]//,10X,
     $       2(G15.6,20X))
      WRITE(6,1)
    1 FORMAT(/////10X,23H----  Tubes' Data  ----)
      WRITE(6,*) ' '
      WRITE(6,2)TUBOD,TTHICK,TUBLENGH,NTUB
    2 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Tubes lenght',13X,'Tubes number',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],21X,3H[-],//,10X,
     $       3(G15.6,10X),1I5)
      WRITE(6,*) ' '
      WRITE(6,3)TUBZSURF*NZDSH,TUBZSURF,NZDSH
    3 FORMAT(/10X,'Heat Exchange Surface',9X,
     $       'Heat Exchange Surface per Zone',
     $       11X,'Zone number',/19X,
     $       4H[m2],30X,4H[m2],28X,3H[-],//,12X,
     $       2(G15.6,20X),1I5)
C
C
      DATI(ID2  ) = NE
      DATI(ID2+1) = NUS
      DATI(ID2+2) = SHOS
      DATI(ID2+3) = SHIS
      DATI(ID2+4) = TIVWT
      DATI(ID2+5) = FCSA
      DATI(ID2+6) = EQD
      DATI(ID2+7) = SHTC
      DATI(ID2+8) = NZDSH
      DATI(ID2+9) = NTUB
      DATI(ID2+10)= TUBOD
      DATI(ID2+11)= TUBLENGH
      DATI(ID2+12)= DSHSUP
      DATI(ID2+13)= USHTC
      DATI(ID2+14)= SHID
      DATI(ID2+15)= SHLENGH
      DATI(ID2+16)= SHIV
      DATI(ID2+17)= SSCIZ
      DATI(ID2+18)= FTCSA
      DATI(ID2+19)= FTEQD
      DATI(ID2+20)= TTHICK
      DATI(ID2+21)= TUBRO
      DATI(ID2+22)= TUBCP
      DATI(ID2+23)= TUBK
      DATI(ID2+24)= HTA
      DATI(ID2+25)= UTHTC
C
C
      ID2 = ID2+25+1
C
C---costanti di normalizzazione
C
      CNXYU(IV1  ) = P0
C
      DO I=1,NZDSH
        CNXYU(IV1+I) = H0
      END DO
C
      CNXYU(IV1+NZDSH+1) = H0
C
      CNXYU(IV1+NZDSH+2) = T0
C
      DO I=1,NZDSH
        CNXYU(IV1+NZDSH+2+I) = T0
      END DO
C
      DO I=1,NZDSH
	CNXYU(IV1+2*NZDSH+2+I)=H0
      END DO
C
      CNXYU(IV1+3*NZDSH+3) = W0
C
      NT=NE+NUS
C
      I0=IV1+3*NZDSH+3
C
      DO J = 1,NT
	JW=2*J-1
	JH=JW+1
	CNXYU(I0+JW) = W0
	CNXYU(I0+JH) = H0
      END DO
C
      CNXYU(I0+2*NT+1)=P0
      CNXYU(I0+2*NT+2)=H0
      CNXYU(I0+2*NT+3)=P0
      CNXYU(I0+2*NT+4)=H0
C
C     CNXYU(I0+2*NT+5) = 0.01
      CNXYU(I0+2*NT+5) = 10000.
      CNXYU(I0+2*NT+6) = 1.
C
      CNXYU(I0+2*NT+7) = GAM0
      CNXYU(I0+2*NT+8) = T0
      CNXYU(I0+2*NT+9) = GAM0
C
      RETURN
      END
C************************************************************************
C
      SUBROUTINE DSR0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/REGIME/KRE10GIM
C
      COMMON/DSR0BLOC/IBL1X,IBL2X
C
      EXTERNAL DSR0
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
      CHARACTER*100 SccsID
      DATA SccsID/'@(#)hess.f	1.1\t 1.1\t 12/19/97 Puerpro libut'/
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      IBL1X=IBL1
      IBL2X=IBL2
C
C   High pressure desuperheater model
C
C   CALCOLO RESIDUI
C
C
      NE  =DATI(IPD)
      NUS =DATI(IPD+1)
      NZDSH=DATI(IPD+8)
      NSTATI=3+3*NZDSH
      NUSCALG=1
      NUSCTOT=NSTATI+NUSCALG
      NINGRE=2*(NE+NUS)+9
      NVAR=NUSCTOT+NINGRE
C
        GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100   DO I=1,NUSCTOT
          DO J =1,NVAR
            AJAC(I,J) = 1.
          END DO
        END DO
        RETURN
C
C---calcolo residui
C
  200   CONTINUE
        CALL DSR0(IFUN,IXYU,XYU,IPD,DATI,RNI)
        RETURN
C
C---calcolo jacobiano 
C
 300    CONTINUE
C
      EPS   =1.E-4
      EPSLIM=1.E-6
C     CALL DSR0JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
C    $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,DSR0)
      CALL NAJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,DSR0)
C
       RETURN                
      END
C
C
      SUBROUTINE DSR0JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(100),CXYU(100),CCRN(100),CCXYU(100),VAR(100)
      EXTERNAL RESIDUI
C
      PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE

C
C--- se la variabile e` una pressione
C    non viene limitato il suo incremento
C
C
      NE   =DATI(IPD)
      NUS  =DATI(IPD+1)
      NZDSH=DATI(IPD+8)
      ILS=3*NZDSH+4
      I1LS=ILS+2*(NE+NUS)
C
      PR=XYU(IXYU)*P0
C
      VAR(1)=10./P0
C
      DO J=1,NZDSH
        VAR(1+J)=100./H0
      END DO
C
      VAR(NZDSH+2)=100./H0
C
      VAR(NZDSH+3)=1./T0
C
      DO J=1,NZDSH
        VAR(NZDSH+3+J)=1./T0
      END DO
C
      DO I=1,NZDSH
        VAR(2*NZDSH+3+I)=100./H0
      END DO
C
      VAR(3*NZDSH+4)=0.1/W0
C
      DO I1=ILS+1,I1LS,2
        VAR(I1)=0.1/W0
        VAR(I1+1)=50./H0
      END DO
C
      VAR(I1LS+1)=10./P0
      VAR(I1LS+2)=100./H0
      VAR(I1LS+3)=10./P0
      VAR(I1LS+4)=100./H0
C
      VAR(I1LS+5)=0.0001
      VAR(I1LS+6)=0.01

      VAR(I1LS+7)=10./1000.
      VAR(I1LS+8)=1./T0
      VAR(I1LS+9)=10./1000.
C
      DO 30 J=1,NCOL
        DO 10 K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR(J)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR(J)
   10   CONTINUE
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
C
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
C
        DO 20 I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR(J))
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
   20   CONTINUE
C
   30 CONTINUE
C
      RETURN
      END
C
C
C*********************************************************************
      SUBROUTINE DSR0(IFUN,IXYU,XYU,IPD,DATI,RNI)
      DIMENSION XYU(*),DATI(*),RNI(*)
C
C   Simplified Heat Exchanger Shell side model
C
      PARAMETER (MAXIO=5,MAXCI=15)
C     PARAMETER (GAM0=1000.)
      PARAMETER (ALMIN=0.5)
C
      PARAMETER (ALFA=3.3)
      PARAMETER (BETA=0.1)
      PARAMETER (HSUP=100.E3)
C
      DIMENSION WS(MAXIO),WSO(MAXIO)
      DIMENSION HS(MAXIO),HSO(MAXIO),HVTAV(MAXCI)
      DIMENSION TM(MAXCI),TFW(MAXCI)
      DIMENSION HSD(MAXCI),TVZ(MAXCI),HF(MAXCI)
      DIMENSION XVZ(MAXCI)
      DIMENSION QDSH(MAXCI)
      DIMENSION DITBOE(MAXCI),HADAL(MAXCI)
      DIMENSION QFDW(MAXCI),QKSC(MAXCI)
      DIMENSION SHDSH(MAXCI),SHFDW(MAXCI)
      DIMENSION ROFW(MAXCI)
      DIMENSION QSHIS(MAXCI)
      DIMENSION DRODH(MAXCI),DRODP(MAXCI)
C
      REAL MVZ(MAXCI),MVZT,MLFW(MAXCI)
      REAL MFWTOT
C
      LOGICAL KREGIM,COUNTERFLOW
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
C
      COMMON/REGIME/KREGIM
C
      COMMON/DSR0VAR0/MVZT,MVZ,MLFW,ROMFW
      COMMON/DSR0VAR1/PFIN,HFIN,PFOU,FTFF,WFDW
      COMMON/DSR0VAR2/SHDSH,SHFDW,SHV,SMV
      COMMON/DSR0VAR3/TBMDSHZ
      COMMON/DSR0VAR4/QDSH,QFDW,QSHE,QSHIST
      COMMON/DSR0DER0/DRODHVRS,DRODPVRS
C
C
      GAM0=1000.
C
C---decodifica dati
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      SHOS    = DATI(IPD+2)
      SHIS    = DATI(IPD+3)
      TIVWT   = DATI(IPD+4)
      FCSA    = DATI(IPD+5)
      EQD     = DATI(IPD+6)
      SHTC    = DATI(IPD+7)
      NZDSH   = DATI(IPD+8)
      NTUB    = DATI(IPD+9)
      TUBOD   = DATI(IPD+10)
      TUBLENGH= DATI(IPD+11)
      DSHSUP  = DATI(IPD+12)
      USHTC   = DATI(IPD+13)
      SHID    = DATI(IPD+14)
      SHLENGH = DATI(IPD+15)
      SHIV    = DATI(IPD+16)
      SSCIZ   = DATI(IPD+17)
      FTCSA   = DATI(IPD+18)
      FTEQD   = DATI(IPD+19)
      TTHICK  = DATI(IPD+20)
      TUBRO   = DATI(IPD+21)
      TUBCP   = DATI(IPD+22)
      TUBK    = DATI(IPD+23)
      HTA     = DATI(IPD+24)
      UTHTC   = DATI(IPD+25)
C
      FNZON=FLOAT(NZDSH)
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C
C----- Superfici di scambio per cella nelle divere zone
C
      DSHSUPZ=DSHSUP/FLOAT(NZDSH)
C
C----- Massa di metallo complessiva del fascio tubiero
C
      TUBID=TUBOD-2.*TTHICK
      TUBMASS=TUBRO*FLOAT(NTUB)*TUBLENGH*3.1415*(TUBOD**2.-TUBID**2.)/4.
C
C----- Superficie esterna complessiva del fascio tubiero
C
      TUBSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBOD
C
C----- Massa di metallo per cella nelle divere zone del fascio tubiero
C      proporzionale al rapporto fra superficie di scambio della zona
C      e superficie esterna complesiva
C
      TBMDSHZ=DSHSUPZ/TUBSURF*TUBMASS
C     write(6,*)' TBMDSHZ = ',TBMDSHZ,' DSHSUPZ = ',DSHSUPZ
C     write(6,*)' TUBSURF = ',TUBSURF,' TUBMASS = ',TUBMASS
C
C
C----- Superficie interna complessiva del fascio tubiero
C
      TUBINSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID
C
C
C----- Superfici di scambio interno (lato acqua alimento) per cella nelle
C----- divere zone del fascio tubiero
C
      TBSDSHZ=DSHSUPZ/TUBSURF*TUBINSURF
C
C
C----- Volume interno complessivo del fascio tubiero
C
      TUBINVOL=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID**2./4.
C
C
C----- Volume interno (lato acqua alimento) nelle divere zone del fascio tubiero
C
      TBVDSHZ=DSHSUPZ/TUBSURF*TUBINVOL
C
C----- Volume lato shell nelle divere zone
C
      SHVDSHZ=DSHSUPZ/TUBSURF*TIVWT
C
C
C---decodifica variabili
C
      PWSS = XYU(IXYU  )*P0
C
      DO I=1,NZDSH
        HSD(I) = XYU(IXYU+I)*H0
      END DO
C
      HVRS = XYU(IXYU+NZDSH+1)*H0
C
      TAMS = XYU(IXYU+NZDSH+2)*T0
C
      DO I=1,NZDSH
        TM(I) = XYU(IXYU+NZDSH+2+I)*T0
      END DO
C
      DO I=1,NZDSH
        HF(I)=XYU(IXYU+2*NZDSH+2+I)*H0
      ENDDO
C
      WFDW = XYU(IXYU+3*NZDSH+3)*W0
C
      I0=IXYU+3*NZDSH+3
C
      DO J = 1,NE
        JW=2*J-1
        JH=JW+1
        WS(J) = XYU(I0+JW)*W0
        HS(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NE
C
      DO J = 1,NUS
        JW=2*J-1
        JH=JW+1
        WSO(J) = XYU(I0+JW)*W0
        HSO(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NUS
C
C
      PFIN=XYU(I0+1)*P0
      HFIN=XYU(I0+2)*H0
      PFOU=XYU(I0+3)*P0
      HFOU=XYU(I0+4)*H0
C
C     FTFF=XYU(I0+5)*0.01
      FTFF=XYU(I0+5)*10000.
      ADSH=XYU(I0+6)
C
      GSIF = XYU(I0+7)*GAM0
      TEST = XYU(I0+8)*T0
      GEST = XYU(I0+9)*GAM0
C
      IF(PWSS.LT.2.5E5) THEN
        PPTOL=10./P0
      ELSE IF(PWSS.LT.10.E5) THEN
        PPTOL=50./P0
      ELSE
        PPTOL=100./P0
      ENDIF
C
      TOLIN(1)=PPTOL
C
C---- Portate di fluido in igresso
C
      SWS=0.
      SWSDHS=0.
      SWSINV=0.
C
      DO J= 1,NE
        IF(WS(J).GT.0.) THEN
          SWS=SWS+WS(J)
          SWSDHS=SWSDHS+WS(J)*HS(J)
        ELSE
          SWSINV=SWSINV-WS(J)
        ENDIF
      END DO
C
C
C---- Portate di vapore in uscita (ultima zona di scambio)
C
      SWSOINV=0.
      SWSODHSOINV=0.
      SWSO=0.
C
      DO J= 1,NUS
        IF(WSO(J).LT.0.) THEN
          SWSOINV=SWSOINV-WSO(J)
          SWSODHSOINV=SWSODHSOINV-WSO(J)*HSO(J)
        ELSE
          SWSO=SWSO+WSO(J)
        ENDIF
      END DO
C
C
C-----  Protezione per pressioni ed entalpie fuori range
C
      PVTAV=PWSS
C
CC    IF(PVTAV.LE.810.8) THEN
CC      PVTAV=810.8
CC    ELSE IF(PVTAV.GE.400.E+05) THEN
CC      PVTAV=400.E+05
CC    ENDIF
C
      DO I=1,NZDSH
        HVTAV(I)=HSD(I)
      END DO
C
      PVT=PWSS
      HVT=HVRS
C
CC    IF(PVT.LE.810.8) THEN
CCC     PVT=810.8
CC    ELSE IF(PVT.GE.400.E+05) THEN
CC      PVT=400.E+05
CC    ENDIF
C
C
C----------------------------flussi di massa ed energia
C
      IF(PVTAV.LT.221.E+05)THEN
         CALL SATUR(PVTAV,2,HLS,HSS,NFL)
         CALL SATUR(PVTAV,3,RLS,RSS,NFL)
         CALL SATUR(PVTAV,7,TVS,Z,NFL)
      ELSE
         PCRITICA=221.E+05
         CALL SATUR(PCRITICA,2,HLS,HSS,NFL)
         CALL SATUR(PCRITICA,3,RLS,RSS,NFL)
         CALL SATUR(PCRITICA,7,TVS,Z,NFL)
      ENDIF
C
C
C---- Pressione media dell'acqua alimento nel fascio tubiero
C
      PMFDW=(PFIN+PFOU)/2.
C
C---- Stato termodinamico dell'acqua alimento, densit� media (Vi=cost.)
C
      MFWTOT=0.
C
      DO I=1,NZDSH
        SFW=SHEV(PMFDW,HF(I),NFL)
        TFW(I)=TEV(PMFDW,SFW,NFL)
        ROFW(I)=ROEV(PMFDW,SFW,NFL)
      END DO
C
C
C---- Massa di liquido nelle diverse zone del fascio tubiero
C
      DO I=1,NZDSH
 	MLFW(I)=ROFW(I)*TBVDSHZ
        MFWTOT=MFWTOT+MLFW(I)
      END DO
C
      ROMFW=MFWTOT/TUBINVOL
C
C--- Tubes Side Heat Exchange Coefficient
C
      DO I=1,NZDSH
        IF (UTHTC.LE.0.) THEN
          CALL DSR0DITBOE(PMFDW,HF(I),WFDW,FTCSA,FTEQD,DITBOE(I))
        ELSE
          IF (UTHTC.LE.10.) THEN
            CALL DSR0USRDITBOE(PMFDW,HF(I),WFDW,FTCSA,FTEQD,DITBOE(I))
          ELSE
            DITBOE(I)=UTHTC
          END IF
        END IF
      END DO
C
C
      MVZT=0.
C
C----- Calcolo proprieta' zona di raccolta del vapore
C
      SVRS=SHEV(PVT,HVT,NFL)
      TVRS=TEV(PVT,SVRS,NFL)
      ROVRS=ROEV(PVT,SVRS,NFL)
      XVRS=YEV(PVT,SVRS,NFL)
      XVRS=(HVRS-HLS)/(HSS-HLS)
      XVRS=MIN(XVRS,1.)
      XVRS=MAX(XVRS,0.)
C
C
C--- derivata della densita` dell'acqua fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h  -  nella zona vapore
C
      DRODPVRS=1./A2EV(PVT,SVRS,NFL)
     &        -1./(ROVRS*TVRS)*BEV(PVT,SVRS,NFL)
C
C
C--- derivata della densita` dell'acqua fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p  -  nella zona vapore
C
      DRODHVRS=BEV(PVT,SVRS,NFL)/TVRS
C
C
      MVZT=MVZT+SHIV*ROVRS
C
      DO I=1,NZDSH
C
        SVZ=SHEV(PVTAV,HVTAV(I),NFL)
        TVZ(I)=TEV(PVTAV,SVZ,NFL)
        ROVZ=ROEV(PVTAV,SVZ,NFL)
        MVZT=MVZT+SHVDSHZ*ROVZ
        XVZ(I)=(HSD(I)-HLS)/(HSS-HLS)
        XVZ(I)=MIN(XVZ(I),1.)
        XVZ(I)=MAX(XVZ(I),0.)
        MVZ(I)=SHVDSHZ/TIVWT*MVZT
C
C--- derivata della densita` dell'acqua fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h
C
        DRODP(I)=1./A2EV(PVTAV,SVZ,NFL)-
     &           1./(ROVZ*TVZ(I))*BEV(PVTAV,SVZ,NFL)
C
C--- derivata della densita` dell'acqua fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p
C
	DRODH(I)=BEV(PVTAV,SVZ,NFL)/TVZ(I)
C
C
C--- Shell Side Desuperheating zone Heat Exchange Coefficient
C
        IF (USHTC.LE.0.) THEN
          CALL DSR0HADAL(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL(I))
        ELSE
          IF (USHTC.LE.10.) THEN
            CALL DSR0HADALUT(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL(I))
          ELSE
            HADAL(I)=USHTC
          END IF
        END IF
      END DO
C
C
C     write(6,*)'Speed= ',SWS/(ROVZ*FCSA)
C
C	write(6,*)' MVZT= ',MVZT
C
C
C---- Calcolo potenze termiche scambiate  ---------------------------------------
C
C---- Scambio nella zona di desurriscaldamento - lato shell
C
      QDSHT=0.
      QSHIST=0.
C
      DO I=1,NZDSH
        IF (COUNTERFLOW) THEN
	  ITB=NZDSH-I+1
	ELSE
	  ITB=I
	END IF
        QDSH(I)=ADSH*HADAL(I)*DSHSUPZ*(TVZ(I)-TM(ITB))
        QSHIS(I)=GSIF*SHIS/FLOAT(NZDSH)*ALFA*(TVZ(I)-TAMS)
        QDSHT=QDSHT+QDSH(I)
        QSHIST=QSHIST+QSHIS(I)
C       write(6,*)' TVZ(',I,')',TVZ(I),'TM(',ITB,')',TM(ITB)
      END DO
C
C
C---- Scambio nella zona di desurriscaldamento - lato tubi
C
      DO I=1,NZDSH
        QFDW(I)=DITBOE(I)*TBSDSHZ*(TM(I)-TFW(I))
C       write(6,*)' TM(',I,')',TM(I),'TFW(',I,')',TFW(I)
      END DO
C
C     write(6,*)' TBSDSHZ = ',TBSDSHZ,' DSHSUPZ = ',DSHSUPZ
C
C---- calore scambiato fra parete esterna shell e ambiente
C
      QSHE=GEST*SHOS*(TAMS-TEST)
C
C
C
C--- calcolo dei termini noti delle equazioni di conservazione dell'energia
C
      SHDSH(1)=SWSDHS-SWS*HSD(1)-QDSH(1)-QSHIS(1)
C
      DO I=2,NZDSH
        SHDSH(I)=SWS*(HSD(I-1)-HSD(I))-QDSH(I)-QSHIS(I)
      END DO
C
C
      SMV=SWS+SWSOINV-SWSINV-SWSO
C
      SHV=SWSDHS-SWS*HVRS+SWSODHSOINV-SWSOINV*HVRS
     &     -QDSHT-QSHIST-SWSO*(HSD(NZDSH)-HVRS)
C
C
      IF (WFDW.GE.0.) THEN
        SHFDW(1)=WFDW*(HFIN-HF(1))+QFDW(1)
	DO I=2,NZDSH
          SHFDW(I)=WFDW*(HF(I-1)-HF(I))+QFDW(I)
	END DO
      ELSE
        SHFDW(NZDSH)=ABS(WFDW)*(HFOU-HF(NZDSH))+QFDW(NZDSH)
        DO I=1,NZDSH-1
         SHFDW(NZDSH-I)=ABS(WFDW)*(HF(NZDSH)-HF(NZDSH-I))+QFDW(NZDSH-I)
        END DO
      END IF

C
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni nella zona vapore
C
      CALL DSR0NF(IFUN,IPD,DATI,RNI)
C
C
      RETURN
      END
C
C
C
C---------------------------------------------------------------------------------
C
C      Calcolo stazionario e transitorio 
C
C---------------------------------------------------------------------------------
C
C
      SUBROUTINE DSR0NF(IFUN,IPD,DATI,RNI)
C
C
      DIMENSION DATI(*),RNI(*)
C
      PARAMETER (MAXIO=5,MAXCI=15)
C
      DIMENSION QDSH(MAXCI)
      DIMENSION QFDW(MAXCI)
      DIMENSION SHDSH(MAXCI),SHFDW(MAXCI)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
      LOGICAL KREGIM,COUNTERFLOW
      COMMON/REGIME/KREGIM
C
      COMMON/DSR0VAR0/MVZT,MVZ,MLFW,ROMFW
      COMMON/DSR0VAR1/PFIN,HFIN,PFOU,FTFF,WFDW
      COMMON/DSR0VAR2/SHDSH,SHFDW,SHV,SMV
      COMMON/DSR0VAR3/TBMDSHZ
      COMMON/DSR0VAR4/QDSH,QFDW,QSHE,QSHIST
      COMMON/DSR0DER0/DRODHVRS,DRODPVRS
C
      REAL MVZ(MAXCI),MVZT,MLFW(MAXCI)
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      SHOS    = DATI(IPD+2)
      SHIS    = DATI(IPD+3)
      TIVWT   = DATI(IPD+4)
      FCSA    = DATI(IPD+5)
      EQD     = DATI(IPD+6)
      SHTC    = DATI(IPD+7)
      NZDSH   = DATI(IPD+8)
      NTUB    = DATI(IPD+9)
      TUBOD   = DATI(IPD+10)
      TUBLENGH= DATI(IPD+11)
      DSHSUP  = DATI(IPD+12)
      USHTC   = DATI(IPD+13)
      SHID    = DATI(IPD+14)
      SHLENGH = DATI(IPD+15)
      SHIV    = DATI(IPD+16)
      SSCIZ   = DATI(IPD+17)
      FTCSA   = DATI(IPD+18)
      FTEQD   = DATI(IPD+19)
      TTHICK  = DATI(IPD+20)
      TUBRO   = DATI(IPD+21)
      TUBCP   = DATI(IPD+22)
      TUBK    = DATI(IPD+23)
      HTA     = DATI(IPD+24)
      UTHTC   = DATI(IPD+25)
C
      NZON=NZDSH
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C
C--- Calcolo dei termini delle perdite di carico dell'acqua alimento
C
C     CALL DSR0_MOODY_FF(PFIN,HFIN,WFDW,FTEQD,FTCSA,FRICF)
C     FRICF=0.05
C     write(6,*)'Friction factor=',FRICF
C
C     XK = Form pressure loss coefficient default = 1.
C
C     XK=1.
C
C     CDPFDW=0.5*(FRICF*TUBLENGH/FTEQD+XK)*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=0.5*(FTFF*(TUBLENGH/FTEQD+XK))*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=0.5*(FTFF*FRICF*TUBLENGH/FTEQD+XK)*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=0.5*FTFF*(1./(FTCSA**2.*ROMFW))
      CDPFDW=FTFF*(1./(FTCSA**2.*ROMFW))
C     write(6,*)'FTCSA = ',FTCSA,' CDPFDW= ',CDPFDW,' ROMFW= ',ROMFW
C
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni
C
      AV11=MVZT
      AV12=-(SHIV+TIVWT)
      AV21=(SHIV+TIVWT)*DRODHVRS
      AV22=(SHIV+TIVWT)*DRODPVRS
C
      TN1=SHV
      TN2=SMV
C
C
C--- Calcolo del determinate
C
CCCCCC      DET=A21*A32*A13-A23*A32*A11-A12*A21*A33
      DETV=AV11*AV22-AV12*AV21
C
C--- Calcolo dei termini noti delle equazioni
C
C
C     SKX=16.49E-03*FCSA/0.012
C     SKX=0.
C
C
C--- Calcolo della derivata della pressione  dP/dt
C
      DPDT=(AV11*TN2-AV21*TN1)/DETV
C
C
C--- Calcolo della derivata dell'entalpia del vapore  dHv/dt
C
      DHVDT= (TN1*AV22-TN2*AV12)/DETV
C
C
C
      IF (KREGIM) THEN
C
C___ Pressione nel riscaldatore
C
C        RNI(1)= SMV/W0
C       RNI(1)= 0.
         RNI(1)= DPDT/P0
C
C
C___ Entalpia vapore zona di desurriscaldamento
C
        DO I=1,NZDSH
           RNI(1+I)=SHDSH(I)/(MVZ(I)*H0)
C          RNI(1+I)=SHDSH(I)/(W0*H0)
C          RNI(1+I)=0.
C 	   write(6,*)' SHDSH(I)= ',SHDSH(I)
         END DO
C
C
C___ Entalpia vapore zona di condensazione
C
C   	RNI(NZDSH+2)= SHV/(W0*H0)
      	RNI(NZDSH+2)= DHVDT/H0
C
C
C___ Temperatura metallo parete shell
C
        RNI(NZDSH+3)= (QSHIST-QSHE)/(W0*H0)
C       RNI(NZDSH+3)= 0.
C
C
C___ Temperatura metallo fascio tubiero
C
C
      DO I=1,NZDSH
        IF (COUNTERFLOW) THEN
	  ISH=NZDSH-I+1
 	ELSE
 	  ITB=I
 	END IF
        RNI(NZDSH+3+I)=(QDSH(ISH)-QFDW(I))/(W0*H0)
C       RNI(NZDSH+NZDSC+6+I)=0.
C      write(6,*)' QDSH(ISH)= ',QDSH(ISH),' ISH= ',ISH
C     $          ,' QFDW(I)= ',QFDW(I),' I=',I
      END DO
C
C
C___ Entalpia acqua alimento
C
      DO I=1,NZDSH
       RNI(2*NZDSH+3+I)= SHFDW(I)/(W0*H0)
C       write(6,*)' SHFDW(I)= ',SHFDW(I),' I= ',I
      END DO
C
C
C___ Portata acqua alimento nel fascio tubiero
C
C       write(6,*)'FTCSA = ',FTCSA,' CDPFDW= ',CDPFDW,' ROMFW= ',ROMFW
C       RNI(3*NZDSH+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(P0)
C       RNI(3*NZDSH+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
        RNI(3*NZDSH+4)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
C       RNI(3*NZDSH+4)=((PFIN-PFOU)/CDPFDW-WFDW*ABS(WFDW))/(W0*W0)
C       RNI(3*NZDSH+4)=((PFIN-PFOU)/CDPFDW-FTFF*WFDW*ABS(WFDW))/(W0*W0)
C       RNI(3*NZDSH+4)=(PFIN-PFOU-FTFF*WFDW*ABS(WFDW))/(W0*W0)
C
      ELSE
C
C___ Pressione nel riscaldatore
C
        RNI(1)=DPDT/P0
C
C
C___ Entalpia vapore zona di desurriscaldamento
C
        DO I=1,NZDSH
          RNI(1+I)=SHDSH(I)/(MVZ(I)*H0)
        END DO
C
C
C___ Entalpia vapore zona di condensazione
C
 	RNI(NZDSH+2)= DHVDT/H0
C
C
C___ Temperatura metallo parete shell
C
        RNI(NZDSH+3)= (QSHIST-QSHE)/(SHTC*T0)
C
C
C___ Temperatura metallo fascio tubiero
C
C
      DO I=1,NZDSH
        IF (COUNTERFLOW) THEN
	  ISH=NZDSH-I+1
 	ELSE
 	  ITB=I
 	END IF
        RNI(NZDSH+3+I)=(QDSH(ISH)-QFDW(I))/(TBMDSHZ*T0)
      END DO
C
C
C___ Entalpia acqua alimento
C
        DO I=1,NZDSH
         RNI(2*NZDSH+3+I)= SHFDW(I)/(MLFW(I)*H0)
        END DO
C
C
C___ Portata acqua alimento nel fascio tubiero
C
C       RNI(3*NZDSH+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/P0
C       RNI(3*NZDSH+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
        RNI(3*NZDSH+4)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
C
C
      END IF
C
C
      RETURN
      END
C---------------------------------------------------------------------------------
C************************************************************************
      SUBROUTINE DSR0D1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      RETURN
      END
C
C************************************************************************
      SUBROUTINE DSR0DITBOE(P,H,W,SEZ,D,DBHTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Dittus-Boelter Heat transfert correlation
C
C
C
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL MU,LAM
C
      NFL=1
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      SFW=SHEV(P,H,NFL)
      TFW=TEV(P,SFW,NFL)
      RO=ROEV(P,SFW,NFL)
      TIT=YEV(P,SFW,NFL)
C
      CP=CPEV(P,SFW,TIT,0.5,NFL)
      MU=ETEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
      RE=ABS(W)*D/(SEZ*MU)
      PR=CP*MU/LAM
      DBHTC=.023*LAM*RE**.8*PR**.4/D+HTSTAT
C     write(6,*)' D= ',D,' Sez. = ',SEZ,'Speed= ',W/(RO*SEZ)
C     write(6,*)'DBHTC= ',DBHTC
C
      RETURN
      END
C
C
C************************************************************************
      SUBROUTINE DSR0HADAL(P,H,W,SEZ,D,HADHTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Hadaller Heat transfert correlation
C
C
C
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL MU,LAM
C
      NFL=1
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      S=SHEV(P,H,NFL)
      T=TEV(P,S,NFL)
      RO=ROEV(P,S,NFL)
      TIT=YEV(P,S,NFL)
C
      CP=CPEV(P,S,TIT,0.5,NFL)
      MU=ETEV(P,T,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,T,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
      RE=ABS(W)*D/(SEZ*MU)
      PR=CP*MU/LAM
      HADHTC=.008348*LAM*RE**.8774*PR**.6112/D+HTSTAT
C     write(6,*)' D= ',D,' Sez. = ',SEZ,'Speed= ',W/(RO*SEZ)
C     write(6,*)'HADHTC= ',HADHTC
C
      RETURN
      END
C
C
C
      SUBROUTINE DSR0_MOODY_FF(P,H,W,DIA,SEZ,FRICF)
C
C  Friction factor according to Moody chart
C
C     ROUGHNESS     Tubes roughness - default = 0.0000023
C     DIA           Hydraulic diameter
C     P             Fluid pressure
C     H             Fluid enthalpy
C     FRICF         Friction factor  
C
C
      REAL MU
C
      COMMON/DSR0BLOCKS/IBL1X,IBL2X
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
      DATA ROUGHNESS/0.000023/
C
      SFW=SHEV(P,H,NFL)
      TFW=TEV(P,SFW,NFL)
      RO=ROEV(P,SFW,NFL)
      TIT=YEV(P,SFW,NFL)
C
      CALL SATUR(P,3,ROW,ROV,NFL)
      RWV=ROW/ROV
C
      MU=ETEV(P,TFW,RO,RWV,TIT,0.5,NFL)
C
      RE=ABS(W)*DIA/(SEZ*MU)
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
        FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
          FRICF=64./RE
        ELSE
          IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
          DO WHILE (I.LE.100)
            IT=IT+1
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
            END IF
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
              WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
              WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
          END DO
C
C   SOLUZIONE
C
          WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP1_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBL1X,IBL2X
        END IF
      END IF
      RETURN
      END
C
C
C
C~FORAUS_DSR0~C
C
C      SUBROUTINE DSR0USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
C      DITBOE=14000.
C      RETURN
C      END
C
C
C      SUBROUTINE DSR0HADAL(P,H,W,SEZ,D,HADHTC)
C      HADHTC = 5000.
C      RETURN
C      END
C
C~FORAUS_DSR0~C
C
