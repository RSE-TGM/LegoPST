C***********************************************************************
C*                                                                     *
C*                   CESI RICERCA    February 2007                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE LDCHI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/LDCH01/IBLOC
      COMMON/LDCH02/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'LDCH'/
C
      CALL LDCHI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
C
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HM',I2,A4,2X,'--US-- ENTALPIA MEDIA FLUIDO', 
     1' CELLA ',I2,' TUBO')
   20 CONTINUE
C
      DO 30 K=1,NCEL-1
      WRITE(IFO,3001)K,IOB,K
 3001 FORMAT('PU',I2,A4,2X,'--US-- PRESSIONE FLUIDO', 
     1' USCITA CELLA ',I2,' TUBO')
   30 CONTINUE
      WRITE(IFO,3101)IOB
 3101 FORMAT('PUTU',A4,2X,'--US-- PRESSIONE FLUIDO USCITA TUBO')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('WITU',A4,2X,'--US-- PORTATA FLUIDO INGRESSO TUBO')
      DO 40 K=2,NCEL
      WRITE(IFO,3002)K,IOB,K
 3002 FORMAT('WI',I2,A4,2X,'--US-- PORTATA FLUIDO INGRESSO CELLA ',I2)
   40 CONTINUE
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3013)J,K,IOB,J,K
 3013     FORMAT('TL',I1,I1,A4,2X,'--UA-- Lead Temperature - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
          WRITE(IFO,3023)J,K,IOB,J,K
 3023     FORMAT('GL',I1,I1,A4,2X,'--UA-- Heat Transfer Coefficient - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
        END DO
      END DO
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3003)J,K,IOB,J,K
 3003     FORMAT('QT',I1,I1,A4,2X,'--UA-- POTENZA SCAMBIATA', 
     1           ' PARETE ',I1,' CELLA ',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3014)IOB
 3014 FORMAT('HITI',A4,2X,'--UA-- ENTALPIA FLUIDO IGRESSO TUBO - W<0' )
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('HOLD',A4,2X,'--UA-- ENTALPIA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HILD',A4,2X,'--IN-- ENTALPIA FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('PITU',A4,2X,'--IN-- PRESSIONE FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WUTU',A4,2X,'--IN-- PORTATA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('HDLC',A4,2X,'--IN-- ENTALPIA FLUIDO USCITA TUBO',
     1' (INVERSIONE PORTATA)')
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,4003)J,K,IOB,J,K
 4003     FORMAT('TW',I1,I1,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA ' 
     1           ,I1,' CELLA',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO TUBO')
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCHI4(IOB,MOD)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      COMMON/LDCH01/IBLOC
      COMMON/LDCH02/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
    1 WRITE(6,1000)NPMAX
 1000 FORMAT(//10X,'TUBAZIONE SENZA PARETE METALLICA CON SCAMBIO '//10X
     $ ,'NUMERO DI PARETI DI SCAMBIO PER OGNI CELLA (MAX = ',I2,') ?')
      READ(5,*) NPAR
      IF(NPAR.GE.1.AND.NPAR.LE.NPMAX)GO TO 3
      WRITE(6,1004) NPAR
 1004 FORMAT(/10X,'ERRORE - N. PARETI =',I3)
      GO TO 1
    3 CONTINUE
      WRITE(6,1003) NCMAX
 1003 FORMAT(//10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.NCMAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
    5 CONTINUE
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCHI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      DIMENSION NTUB(NCMAX),DIAI(NCMAX),HLU(NCMAX),DZE(NCMAX)
      DIMENSION RTNUMB(NCMAX),RODDIAM(NCMAX),RTLENG(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX),SGICDIAM(NCMAX)              
      DIMENSION HTCS(NCMAX),SUP(NPMAX,NCMAX)                                      
      CHARACTER*8 NT,ND,NL,NZ,NR,SP(NPMAX)                                  
      CHARACTER*10 RTN,RTD,RTL,RTP,RTDZ,SGIC                                
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA RTN/'RodsNumb ='/,RTD/'RodExDia ='/,RTL/'RodLengh ='/                 
      DATA RTP/'RodPitch ='/ ,RTDZ/'RodDelZ  ='/                 
      DATA NT/'ChanNumb'/,ND/'ChanExDi'/,NL/'ChanLeng'/,NZ/'ChanDZ'/                  
      DATA SGIC/'SGICSDiam='/               
      DATA NR/'HTCorSel'/SP/'HTrSurf1','HTrSurf2','HTrSurf3','HTrSurf4'
     $       ,'HTrSurf5','HTrSurf6'/                          
C                                                                       
      WRITE(6,*) ' Inizio I2'
C-----------------------------------------------------                                                    
      NCEL=NSTATI/3                                                     
      NPAR=(NUSCIT-2)/NSTATI
C                                                                       
      NN0=IV1-1                                                         
      NN1=NCEL+IV1-1                                                    
      NN2=2*NCEL+IV1-1                                                  
      NN3=3*NCEL+IV1-1                                                  
      NEQ=NSTATI+NUSCIT                                          
C                                                                       
      WRITE(6,*) 'NSTATI ',NSTATI,' NUSCIT ',NUSCIT,' NINGRE',NINGRE                                                    
      WRITE(6,*) 'IFUN ',IFUN                                                  
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C                                                                       
   1  CONTINUE                                                          
      WRITE(14,4000)
 4000 FORMAT ('*   Channel Model Selection :')
      WRITE(14,4001)
 4001 FORMAT ('*   0 --> Core coolant with fuel rods arranged',
     $                                   ' in triangular arrays')                                                  
      WRITE(14,4002)
 4002 FORMAT ('*   1 --> Core coolant with fuel rods arranged',
     $                                   ' in square arrays' )                                                 
      WRITE(14,4003)                                                 
 4003 FORMAT ('*   2 --> Cilindrical pipe' )
      WRITE(14,4004)
 4004 FORMAT (4X,'ChanMdSel=',10X,'*')
      DO 5 I=1,NCEL                                                     
        WRITE(14,1002)I                                                   
        WRITE(14,4006)
 4006 FORMAT ('*   Fuel rods data')
        WRITE(14,1013) RTN,RTD,RTL,RTP,RTDZ       
 1013 FORMAT(3(4X,A10,10X,'*'),5X)                               
        WRITE(14,4007)
 4007 FORMAT ('*   Liquid lead channel data')
        WRITE(14,1003) NT,ND,NL,NZ,SGIC,NR,(SP(J),J=1,NPAR)        
    5 CONTINUE                                                          
 1002 FORMAT('*   VOLUMETRIC NODE ',I2,'  *',55X)
 1003 FORMAT(3(4X,A8,' =',10X,'*'),5X)                               
C                                                                       
      WRITE(6,*) ' uscita I2 con IFUN 1'                                                    
      RETURN                                                            
C                                                                       
C-----LETTURA DEI DATI                                                  
C 
   10 CONTINUE                                                                      
      WRITE(6,*) ' sto leggendo F14'                                                    
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004)CMSL                                                  
C                                                                       
      WRITE(6,*) ' sto leggendo celle F14   CMSL', CMSL                                                   
      DO 15 I=1,NCEL                                                    
        READ(14,1004)                                                     
      WRITE(6,*) ' sto leggendo celle in do F14'                                                    
        READ(14,1004)                                                     
        READ(14,1004) RTNUMB(I),RODDIAM(I),RTLENG(I),RODPITCH(I)
     $               ,RODTDZ(I)
      WRITE(6,*) ' sto leggendo celle 2 F14'                                                    
        READ(14,1004)                                                     
        READ(14,1004) TUB ,DIAI(I),HLU(I),DZE(I),SGICDIAM(I),HTCS(I)                  
     $              ,(SUP(J,I),J=1,NPAR)                                
        NTUB(I)=TUB                                                       
   15 CONTINUE                                                          
C                                                                       
      WRITE(6,*) ' sto caricando dati righe vuote'
      DO J=1,NCEL
        IF (RTNUMB(J).LE.0) THEN
          RTNUMB(J)=RTNUMB(J-1)                                                 
          RODDIAM(J)=RODDIAM(J-1)                                                 
          RTLENG(J)=RTLENG(J-1)                                                   
          RODPITCH(J)=RODPITCH(J-1)                                                   
          RODTDZ(J)=RODTDZ(J-1)                                                 
        END IF                                         
      END DO
C                                                    
      DO 21 I=1,NCEL                                                    
        IF(NTUB(I).GT.0) GOTO 21                                          
        NTUB(I)=NTUB(I-1)                                                 
        DIAI(I)=DIAI(I-1)                                                 
        HLU(I)=HLU(I-1)                                                   
        DZE(I)=DZE(I-1)                                                   
        SGICDIAM(I)=SGICDIAM(I-1)
        HTCS(I)=HTCS(I-1)                                                 
        DO 20 J=1,NPAR                                                    
          SUP(J,I)=SUP(J,I-1)                                               
   20   CONTINUE                                                          
   21 CONTINUE
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C                                                                       
      DATI(ID2)=NCEL                                                    
      DATI(ID2+1)=NPAR                                                  
      WRITE(6,*) ' sto caricando vettore dati'                                                    
C                                                                       
      DO 25 I=1,NCEL                                                    
        K=ID2+(7+NPAR)*(I-1)+1                                                  
        S=PIGR*DIAI(I)*HLU(I)*NTUB(I)                                     
        V=S*DIAI(I)/4.                                                    
        A=V/HLU(I)                                                        
        DATI(K+1)=V                                                       
        DATI(K+2)=HLU(I)                                                  
        DATI(K+3)=A                                                       
        DATI(K+4)=DIAI(I)                                                 
C        DATI(K+5)=2.*HLU(I)/(DIAI(I)*A*A)                                 
        DATI(K+6)=DZE(I)*9.81                                             
        DATI(K+7)=HTCS(I)                                                 
        DO J=1,NPAR                                               
          DATI(K+7+J)=SUP(J,I)
        END DO                                                
       write(6,*)'nel vettore dati HLU(',I,') =',HLU(I)                                              
   25 CONTINUE                                                          
C                                                                       
      ID2 = ID2+(7+NPAR)*NCEL+1                                               
C      ID2 = ID2+NCEL+1
      ID2 = ID2+NCEL
      DATI(ID2+1)=CMSL                                             
      ID2 = ID2+1
      WRITE(6,*) ' sto caricando normalizzazioni'                                                    
      DO J=1,NCEL
        DATI(ID2+J)=RTNUMB(J)                                              
        DATI(ID2+NCEL+J)=RODDIAM(J)                                              
        DATI(ID2+2*NCEL+J)=RTLENG(J)                                                  
        DATI(ID2+3*NCEL+J)=RODPITCH(J)                                                
        DATI(ID2+4*NCEL+J)=RODTDZ(J)                                       
        DATI(ID2+5*NCEL+J)=SGICDIAM(J)                                       
        DATI(ID2+6*NCEL+J)=NTUB(J)                                       
      END DO
      ID2 = ID2+7*NCEL+1                                              
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
      DO I=1,NCEL                                                    
        CNXYU(NN0+I)=H0                                                   
        CNXYU(NN1+I)=P0                                                   
        CNXYU(NN2+I)=W0
      END DO                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*(I-1)*NPAR+2*J-1)=T0                                     
          CNXYU(NN3+2*(I-1)*NPAR+2*J)=GAM0
        END DO
      END DO                                      
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=W0*H0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ-2)=H0                                                     
      CNXYU(IV1+NEQ-1)=H0                                                   
C                                                                       
      CNXYU(IV1+NEQ)=H0                                                   
      CNXYU(IV1+NEQ+1)=P0                                                   
      CNXYU(IV1+NEQ+2)=W0                                                   
      CNXYU(IV1+NEQ+3)=H0                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(IV1+NEQ+3+(I-1)*NPAR+J)=T0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ+NPAR*NCEL+4)=1.                                         
C                                                                       
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.                           
C                                                                       
C*******************************                                        
      DO 45 I=1,NCEL                                                    
        TOL(NCEL+I)=.01E5/P0                                              
        TOL(2*NCEL+I)=.1/W0                                               
   45 CONTINUE                                                          
C*******************************                                        
C                                                                       
C-----STAMPE                                                            
C                                                                       
      WRITE(6,3000)                                                     
C                                                                       
      DO 60 I=1,NCEL                                                    
        K=ID1+(7+NPAR)*(I-1)+1                                                  
        V= DATI(K+1)                                                      
        S= DATI(K+2)                                                      
        A= DATI(K+3)                                                      
        D=DATI(K+4)                                                       
        C=DATI(K+6)                                                       
        C=C/9.81                                                          
        WRITE(6,3001) I,V,S,A,D,C                                         
   60 CONTINUE                                                          
C                                                                       
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3000 FORMAT(6X,'CELLA',4X,'VOLUME     LUNGHEZZA    SEZIONE     ',      
     $           'DIAM.INT.  DISLIVELLO'//)                             
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)                                     
 3010 FORMAT(6X,3E11.4/)                                                
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCHC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
C-----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*80 SccsID
C
C---     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
C
      COMMON/REGIME/KREGIM                                              
C
      EXTERNAL LDCH
C
C----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'%W%\t %I%\t %G%'/          
C
C----     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
      NVAR=NEQ+NINGRE                                             
C                                                                       
      ISTA=LDCHISTA05(IFUN)                                                 
C                                                                       
      GO TO (10,20,30),IFUN                                             
C
C---topologia jacobiano
C
   10 CONTINUE
C
      DO I=1,NEQ                                                     
        DO J=1,NVAR                                                    
          AJAC(I,J)=1.                                                      
        END DO
      END DO
C                                                          
      RETURN                                                            
C                                                                       
C
C---calcolo residui
C
   20 CONTINUE
C
      CALL LDCH (IFUN,IXYU,XYU,IPD,DATI,RNI)                                   
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))                     
      IF(ISTA.NE.0) CALL LDCHSTAS05(ISTA)                                   
C                                                                       
      RETURN                                                            
C  
   30 CONTINUE
C
C---calcolo jacobiano
C
C      jacobiano numerico
C
C
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      CALL LDCHJC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,LDCH)
                  
C                                                                       
      RETURN                                                            
C                                                                       
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCHJC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                  NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/WAD1NQ/NEQ
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      DO J=1,NCOL
        IF (J.GE.NCEL+1.AND.J.LE.2*NCEL) THEN
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
          VAR=VARP
C
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCH (IFUN,IXYU,XYU,IPD,DATI,RNI)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
      INTEGER CMSL
      REAL TK(NCMAX),QTCV(NCMAX),QCV(NPMAX,NCMAX),QTCDA(NCMAX)
      REAL QTCDB(NCMAX),SUBCHNUM(NCMAX),CHANFF(NCMAX),VLEAD(NCMAX)
      REAL SW(NCMAX),SH(NCMAX),SP(NCMAX),GSPEED(NCMAX)                                   
      REAL LHTC,MU(NCMAX),MU_T_LEAD                                   
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
      DIMENSION RTNUMB(NCMAX),RODDIAM(NCMAX),RTLENG(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX),SGICDIAM(NCMAX)             
      DIMENSION EHYD(NCMAX)            
C
      COMMON/LDCHPARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/LDCHTERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/LDCHMEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/LDCHDATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX),DIAI(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZG(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
C                                                                       
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
C                                                                       
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NNN=NCEL+1                                                        
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
C                                                                       
C--------- Data ------                                                         
C                                                                       
      DO I=1,NCEL                                                    
        K3=IPD+(7+NPAR)*(I-1)+1                                                 
        V(I)=DATI(K3+1)                                                   
        HLU(I)=DATI(K3+2)                                                 
C        AREA(I)=DATI(K3+3)                                                
        DIAI(I)=DATI(K3+4)                                                
C        CKF(I)=DATI(K3+5)                                                 
        DZG(I)=DATI(K3+6)                                                 
        HTCS(I)=DATI(K3+7)                                                
        DO J=1,NPAR                                               
          SUP(J,I)=DATI(K3+7+J)
        END DO                                               
        write(6,*)'da vettore dati HLU(',I,') =',HLU(I)                                              
      END DO                                               
C                                                    
      KD=IPD+(7+NPAR)*NCEL+1
C                                                  
C      KD=KD+NCEL+1
      KD=KD+NCEL
      CMSL=DATI(KD+1)                                             
      KD=KD+1
          write(6,*)'CMSL =',CMSL
C                                              
      DO J=1,NCEL
        RTNUMB(J)=DATI(KD+J)                                              
        RODDIAM(J)=DATI(KD+NCEL+J)                                              
        RTLENG(J)=DATI(KD+2*NCEL+J)                                                  
        RODPITCH(J)=DATI(KD+3*NCEL+J)                                              
        RODTDZ(J)=DATI(KD+4*NCEL+J)                                      
        SGICDIAM(J)=DATI(KD+5*NCEL+J)                                      
        SUBCHNUM(J)=DATI(KD+6*NCEL+J)                                      
      END DO
      DO J=1,NCEL
          write(6,*)'RTNUMB (',J,')=',RTNUMB(J)                                              
          write(6,*)'RTDIAM (',J,')=',RODDIAM(J)                                             
          write(6,*)'RTLENG (',J,')=',RTLENG(J)                                             
          write(6,*)'RTPITCH (',J,')=',RODPITCH(J)                                             
          write(6,*)'RODTDZ (',J,')=',RODTDZ(J)                                             
          write(6,*)'SGICDIAM (',J,')=',SGICDIAM(J)                                             
          write(6,*)'SUBCHNUM (',J,')=',SUBCHNUM(J)                                             
      END DO
C                                                                       
C
C----   Output variables
C
      K5=IXYU-1                                                         
      K6=IXYU-1+NCEL                                                        
      K7=IXYU-1+2*NCEL                                                        
      K8=IXYU-1+3*NCEL                                                        
C
      DO I=1,NCEL                                                    
        HM(I)=XYU(K5+I)*H0                                                   
        P(I+1)=XYU(K6+I)*P0                                                  
        WI(I)=XYU(K7+I)*W0                                                    
        DO J=1,NPAR                                                    
          TLP(J,I)=XYU(K8+2*(I-1)*NPAR+2*J-1)*T0                                     
          GL(J,I)=XYU(K8+2*(I-1)*NPAR+2*J)*GAM0
          QT(J,I)=XYU(K8+2*NCEL*NPAR+(I-1)*NPAR+J)*W0*H0                                     
          write(6,*)'TLP (',J,',',I,')=',TLP(J,I)                                              
          write(6,*)'GL (',J,',',I,')=',GL(J,I)                                              
          write(6,*)'QT (',J,',',I,')=',QT(J,I)                                              
        END DO                                                                                         
      END DO                                                                                         
      HITI=XYU(IXYU+NEQ-2)*H0                                             
      HOLD =XYU(IXYU+NEQ-1)*H0                                              
C
C----   Input variables
C
      HILD  =XYU(IXYU+NEQ)*H0                                                
      P(1)=XYU(IXYU+NEQ+1)*P0                                              
      WI(NNN)=XYU(IXYU+NEQ+2)*W0                                            
      HDLC=XYU(IXYU+NEQ+3)*H0                                                
C
      DO I=1,NCEL
       DO J=1,NPAR                                                    
         TW(J,I)=XYU(IXYU+NEQ+3+(I-1)*NPAR+J)*T0                                    
          write(6,*)'TW (',J,',',I,')=',TW(J,I)                                              
       END DO                                                                                         
      END DO                                                                                         
C
      CF=XYU(IXYU+NEQ+NPAR*NCEL+4)                                      
        write(6,*)'CF =',CF                                              
C
C
C------ Equivalent HYdraulic Diameter, Lead Volume and Mass speed @*v
C
      DO I=1,NCEL
        SELECT CASE (CMSL)
          CASE (0)
            RPITCH=RODPITCH(I)/RODDIAM(I)
            EHYD(I)=RODDIAM(I)*(2.*3.**0.5/PIGR*RPITCH**2.-1.)
            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
            SUBCHSEC=3.**0.5/4.*RODPITCH(I)*RODPITCH(I)
            FLOWSEC(I)=(SUBCHSEC-0.5*RODSEC)*SUBCHNUM(I)
            VLEAD(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
        write(6,*)'FLOWSEC (',I,')=',FLOWSEC(I),'WI (',I,')=',WI(I)                                              
        write(6,*)'SUBCHNUM (',I,')=',SUBCHNUM(I)                                              
        write(6,*)'GSPEED (',I,')=',GSPEED(I)                                             
          CASE (1)
            RPITCH=RODPITCH(I)/RODDIAM(I)
            EHYD(I)=RODDIAM(I)*(4./PIGR*RPITCH**2.-1.)
            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
            SUBCHSEC=RODPITCH(I)*RODPITCH(I)
            FLOWSEC(I)=(SUBCHSEC-RODSEC)*SUBCHNUM(I)
            VLEAD(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
          CASE (2)
            EHYD(I)=DIAI(I)
            FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
            VLEAD(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
         CASE DEFAULT
            EHYD(I)=DIAI(I)
            FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
            VLEAD(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
        END SELECT
      END DO
C
C
C
      DO I=1,NCEL
        CKF(I)=2.*HLU(I)/(EHYD(I)*FLOWSEC(I)*FLOWSEC(I))                                 
        write(6,*)'CKF (',I,')=',CKF(I)                                             
      END DO
C
C----------- Lead Physical properties
C
C-----------   TK ---> Thermal Conductivity                                                                      
C-----------   RO ---> Density                                                                      
C-----------   DRODH ---> d@/dh                                                                      
C                                    
      DO I=1,NCEL
        TL(I)=T_H_LEAD(HM(I))
        write(6,*)'HM (',I,')=',HM(I) ,'TL (',I,')=',TL(I)                                              
        RO(I)=RO_T_LEAD(TL(I))                                            
        write(6,*)'RO (',I,')=',RO(I)                                              
        DRODH(I)=DRODH_LEAD(HM(I))
        write(6,*)'DRODH (',I,')=',DRODH(I)                                              
        TK(I)=TC_H_LEAD(HM(I))
        MU(I)=MU_T_LEAD(TL(I))
        write(6,*)'TL(',I,')=',TL(I),' MU=',MU(I) ,'TK=',TK(I)                                              
      END DO                                  
C
      TDLC=T_H_LEAD(HDLC)                                               
      TILD=T_H_LEAD(HILD)                                               
C
C
C----------- Friction factor
C                                                                       
      DO I=1,NCEL
        RE=GSPEED(I)*EHYD(I)/MU(I)
        FRICF0=0.3164/RE**0.25                                                
           write(6,*)'EHYD(',I,')=',EHYD(I),'RE=',RE                                              
           write(6,*)'GSPEED(',I,')=',GSPEED(I),'FRICF0=',FRICF0                                              
        SELECT CASE (CMSL)
          CASE (0)
            ATR=0.58*(1.-EXP(-70.*(RPITCH-1.)))+9.2*(RPITCH-1.)
            DELTATR=0.57+0.18*(RPITCH-1.)+0.53*(1-EXP(-ATR))
            CHANFF(I)=FRICF0*DELTATR                                               
      write(6,*)'CHANFF(',I,')=',CHANFF(I),'ATR=',ATR,'DELTAT=',DELTATR                                            
          CASE (1)
            DELTASQ=0.59+0.19*(RPITCH-1.)+0.52*(1-EXP(10.*(RPITCH-1.)))
            CHANFF(I)=FRICF0*DELTASQ                                               
          CASE DEFAULT
            CHANFF(I)=FRICF0                                             
        END SELECT
      END DO        
C
C
C
C----------- Heat Transfer Coefficient
C                                                                       
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          IF (HTCS(I).LT.0.) THEN
            CALL LDCH_UHTC(HTCS(I),TL(I),RODPITCH(I),RODDIAM(I)
     $                                    ,GSPEED(I),EHYD(I),LHTC(J,I))
          ELSE
           write(6,*)'prima di chiamare LDCH_HTC TL (',I,')=',TL(I)                                              
            CALL LDCH_HTC(HTCS(I),TL(I),RODPITCH(I),RODDIAM(I),GSPEED(I)
     $                                             ,EHYD(I),LHTC(J,I))
           write(6,*)'LHTC (',J,',',I,')=',LHTC(J,I)                                              
          END IF        
        END DO        
      END DO        
C
C
C----------- Convective Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        QTCV(I)=0.
        DO J=1,NPAR
          QCV(J,I)=LHTC(J,I)*SUP(J,I)*(TL(I)-TW(J,I))
          QTCV(I)=QTCV(I)+QCV(J,I)
        END DO        
      END DO        
C
C
C----------- Conductive Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        IF (I.LT.NCEL) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I+1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I+1)/TK(I+1))
          QTCDA(I)=-GHTC*HTS*(TL(I)-TL(I+1))
        write(6,*)'GHTC =',GHTC ,'HTS =',HTS ,'TL (',I,')=',TL(I)                                              
        write(6,*)'TK (',I,')=',TK(I),'HLU (',I,')=',HLU(I)                                              
        ELSE
          QTCDA(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TDLC)/(HLU(I)/2.)
        END IF
        IF (I.GT.1) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I-1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I-1)/TK(I-1))
          QTCDB(I)=-GHTC*HTS*(TL(I)-TL(I-1))
        ELSE
          QTCDB(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TILD)/(HLU(I)/2.)
        END IF
      END DO        
C
C
C---------- Conservation Equations' Constants 
C
C---------- Sw ---->  Mass Conservation
C---------- Sp ---->  Momentum Conservation
C---------- Sh ---->  Energy Conservation
C
      DO I=1,NCEL
        SW(I)=WI(I)-WI(I+1)
        SP(I)=P(I)-P(I+1)-CKF(I)*CF*CHANFF(I)*WI(I)*ABS(WI(I))/RO(I)
     $                                                 -RO(I)*DZG(I)
        IF (WI(I).GE.0.) THEN
          IF (I.EQ.1) THEN
            SHI=WI(I)*(HILD-HM(I))
          ELSE
            SHI=WI(I)*(HM(I-1)-HM(I))
          END IF
        ELSE
          SHI=0.
        END IF
C
        IF (WI(I+1).LE.0.) THEN
          IF (I.EQ.NCEL) THEN
            SHO=WI(I+1)*(HDLC-HM(I))
          ELSE
            SHO=WI(I+1)*(HM(I+1)-HM(I))
          END IF
        ELSE
          SHO=0.
        END IF
C
        SH(I)=SHI-SHO-QTCV(I)+QTCDA(I)+QTCDB(I)
      END DO
      IF (IFUN.EQ.2.AND.ITERT.EQ.0) THEN
        DO I=1,NCEL
         write(6,*)'QTCDA(',I,')',QTCDA(I),'QTCDB(',I,')',QTCDB(I)
        END DO
      END IF
C
      NN2=2*NCEL
      NN3=3*NCEL
C
      IF (KREGIM) THEN                                         
        DO I=1,NCEL                                                    
          RNI(I)     =SH(I)/(W0*H0)                                     
          RNI(NCEL+I)=SP(I)/P0                                          
          RNI(NN2+I) =SW(I)/W0                                          
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(GL(J,I)-LHTC(J,I))/GAM0         
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QT(J,I)-QCV(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0                
       ELSE
        DO I=1,NCEL                                                    
          RNI(I)     =SW(I)/(VLEAD(I)*DRODH(I)*H0)                          
          RNI(NCEL+I)=(RO(I)*SW(I)/DRODH(I)-SH(I))/(VLEAD(I)*P0)            
          RNI(NN2+I) =FLOWSEC(I)/HLU(I)*SP(I)/W0                           
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(LHTC(J,I)-GL(J,I))/GAM0          
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QCV(J,I)-QT(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0      
C                                                                       
       END IF
C                                                                       
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCH_HTC(HTCS,TL,PITCH,D,G,DH,LHTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C     HTCS  = Heat Transfer Correlation Selection code
C     TL    = Lead Temperature
C     PITCH = Lattice pitch
C     D     = Rod outside diameter
C     G     = Mass speed @�V
C     DH    = Hydraulic diameter
C     LHTC  = Lead Heat Transfer Coefficient
C
C
C
C     p = lattice pitch
C     D = rod outside diameter
C
C
C     Selection Code    Correlations for outside tube flow - triangular arrays
C                                                           
C                  1    V.M. Borishanski et al.  Nu=24.151*lg[-8.12 +12.76p/D-3.65(p/D)**2]+0.0174{1-exp[-6(p/D-1)]}(Pe-200)**0.9 
C                  2    H. Graber                Nu=0.25+6.2p/D+(0.32p/D-0.07)Pe**(0.8-0.024p/D)
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles with spacers
C                                                           
C                  3    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.09Pe**(0.64+0.264p/D) 
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles without spacers
C                                                           
C                  4    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.07Pe**(0.64+0.264p/D) 
C
C
C
C     Selection Code    Correlations for outside tube flow - doesn't refer to any particular lattice
C                                                           
C                  5    H. Calamai et al.        Nu=4.+0.16(p/D)**5+0.33(p/D)**3.8(Pe/100.)**0.86
C
C
C     Selection Code    Correlations for inside tube flow 
C                                                           
C                  6    Kirillow - Stromquist    Nu=A+0.018Pe**0.8  
C                                                                | 4.5                  Pe < 1000
C                                                             A=<  5.4-0.0009Pe  1000 < Pe < 2000
C                                                                | 3.6                  Pe > 2000
C                                                           
C                  7    Lubarsky                 Nu=0.625Pe**0.4
C                                                                
C                  8    Seban - Shimazaki        Nu=5.+0.025Pe**0.8 - Pure liquid lead
C                  9                             Nu=3.3+0.014Pe**0.8 - without special purification 
C
C
C            default    Subbotin                 Nu=7.55p/D-20(p/D)**-13+(3.67/90)(p/D)**-2Pe**(0.19p/D+0.56)
C probably used in RELAP5/PARCS
C
      INTEGER HTCSC
      REAL LHTC,K,MU,MU_T_LEAD,NU
C
      HTCSC=INT(HTCS)
C
      PD=PITCH/D
C
      K=TC_T_LEAD(TL)
      write(6,*)'TL=',TL,' K=',K                                              
C
      MU=MU_T_LEAD(TL)
      write(6,*)'TL=',TL,' MU=',MU                                              
C
      CP=CP_T_LEAD(TL)
      write(6,*)'TL=',TL,' CP=',CP                                              
C
      RE=G*DH/MU
C
      PR=MU*CP/K      
C
      PE=RE*PR     
C
      SELECT CASE (HTCSC)
        CASE (1)
          A0TR=-8.12 +12.76*PD-3.65*PD**2.
          A1TR=-6.*(PD-1.)
          NU=24.151*LOG(A0TR)+0.0174*(1.-EXP(A1TR))*(PE-200.)**0.9
        CASE (2)
          NU=0.25+6.2*PD+(0.32*PD-0.07)*PE**(0.8-0.024*PD)
        CASE (3)
          NU=7.55*PD-14./PD**5.-0.09*PE**(0.64+0.264*PD)
        CASE (4)
          NU=7.55*PD-14./PD**5.-0.07*PE**(0.64+0.264*PD)
        CASE (5)
          NU=4.+0.16*PD**5.+0.33*PD**3.8*(Pe/100.)**0.86
        CASE (6)
          IF (PE.LT.1000.) AKS=4.5
          IF (PE.GE.1000..AND.PE.LE.2000.) THEN
            AKS=5.4+0.0009*PE
          END IF
          IF (PE.GT.2000.) AKS=3.6
          NU=AKS+0.018*PE**0.8
        CASE (7)
          NU=0.625*PE**0.4
        CASE (8)
          NU=5.+0.025*PE**0.8
        CASE (9)
          NU=3.3+0.014*PE**0.8
      CASE DEFAULT 
          NU=7.55*PD-20./PD**13.+3.67/(90.*PD**2.)*PE**(0.19*PD+0.56)
      write(6,*)' RE=',RE,' PR=',PR,' PE=',PE  ,' NU=',NU                                            
      END SELECT
C
      LHTC=K/DH*NU
      write(6,*)' LHTC=',LHTC                                              
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      FUNCTION LDCHISTA05(IFUN)                                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      LDCHISTA05=0                                                          
      IF(KREGIM) LDCHISTA05=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) LDCHISTA05=1                         
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LDCHSTAS05(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      REAL LHTC
C
      COMMON/LDCHPARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/LDCHTERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/LDCHMEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/LDCHDATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX),DIAI(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZG(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      WRITE(6,1001)                                                     
      DO 10 I=1,NCEL                                                    
      G=WI(I)/FLOWSEC(I)                                                    
      AM=RO(I)*FLOWSEC(I)*HLU(I)                                          
      T=TL(I)-273.16                                                    
      WRITE(6,1002) I,WI(I),HM(I),P(I+1),AM,RO(I),G,T          
   10 CONTINUE                                                          
      DO 20 J=1,NPAR                                                    
      WRITE(6,1003) J,J,J                                               
      DO 20 I=1,NCEL                                                    
      T=TW(J,I)-273.16                                                  
      WRITE(6,1004) I,T,LHTC(J,I),QT(J,I)                             
   20 CONTINUE                                                          
      RETURN                                                            
 1001 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',    
     $       6X,'MASSA TOT.',5X,'DENS.MEDIA',4X,            
     $       'PORT.SPEC.',6X,'TEMPERATURA',4X//)                        
 1002 FORMAT(1X,I3,5X,8(E12.5,3X))                                      
 1003 FORMAT(//1X,'CELLA',4X,'TEMP.PAR.',I2,7X,'COEFF.SCAMBIO',I2,      
     $       3X,'POT. TERM.',I2,7X//)                                   
 1004 FORMAT(1X,I3,5X,8(E12.5,6X))                                      
      END                                                               
C
C
C
      SUBROUTINE LDCHD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      RETURN
      END
C
C
C~FORAUS_LDCH~C 
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE LDCH_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE LDCH_UHTC SIA CHIAMATA DA LDCH
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   HTCS < 0.
C
C  La subroutine fornisce al modulo LDCH il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]          
C   H     entalpia specifica del fluido           [J/kg]        
C   S     entropia specifica del fluido           [J/kg/C] 
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]     
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   HTCS  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato 
C         come si vuole.
C         RICORDATI CHE HTCS E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]   
C   Q     potenza totale scambiata                [W]           
C   SUP   superficie di scambio                   [m**2]        
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE LDCH_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_LDCH~C 

