C***********************************************************************
C*                                                                     *
C*                   CESI RICERCA    April 2007                        *
C*                                                                     *
C*     liquid Lead helicoidal coil Steam Generator Shell               *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE LSGSI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/LSGS01/IBLOC
      COMMON/LSGS02/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'LSGS'/
C
      CALL LSGSI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
C
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HM',I2,A4,2X,'--US-- ENTALPIA MEDIA FLUIDO', 
     1' CELLA ',I2,' TUBO')
   20 CONTINUE
C
      DO 30 K=1,NCEL-1
      WRITE(IFO,3001)K,IOB,K
 3001 FORMAT('PU',I2,A4,2X,'--US-- PRESSIONE FLUIDO', 
     1' USCITA CELLA ',I2,' TUBO')
   30 CONTINUE
      WRITE(IFO,3101)IOB
 3101 FORMAT('PUTU',A4,2X,'--US-- PRESSIONE FLUIDO USCITA TUBO')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('WITU',A4,2X,'--US-- PORTATA FLUIDO INGRESSO TUBO')
      DO 40 K=2,NCEL
      WRITE(IFO,3002)K,IOB,K
 3002 FORMAT('WI',I2,A4,2X,'--US-- PORTATA FLUIDO INGRESSO CELLA ',I2)
   40 CONTINUE
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3013)J,K,IOB,J,K
 3013     FORMAT('TL',I1,I1,A4,2X,'--UA-- Lead Temperature - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
          WRITE(IFO,3023)J,K,IOB,J,K
 3023     FORMAT('GL',I1,I1,A4,2X,'--UA-- Heat Transfer Coefficient - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
        END DO
      END DO
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3003)J,K,IOB,J,K
 3003     FORMAT('QT',I1,I1,A4,2X,'--UA-- POTENZA SCAMBIATA', 
     1           ' PARETE ',I1,' CELLA ',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3014)IOB
 3014 FORMAT('HITI',A4,2X,'--UA-- ENTALPIA FLUIDO IGRESSO TUBO - W<0' )
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('HOLD',A4,2X,'--UA-- ENTALPIA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HILD',A4,2X,'--IN-- ENTALPIA FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('PITU',A4,2X,'--IN-- PRESSIONE FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WUTU',A4,2X,'--IN-- PORTATA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('HDLC',A4,2X,'--IN-- ENTALPIA FLUIDO USCITA TUBO',
     1' (INVERSIONE PORTATA)')
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,4003)J,K,IOB,J,K
 4003     FORMAT('TW',I1,I1,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA ' 
     1           ,I1,' CELLA',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO TUBO')
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGSI4(IOB,MOD)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      COMMON/LSGS01/IBLOC
      COMMON/LSGS02/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
    1 WRITE(6,1000)NPMAX
 1000 FORMAT(//10X,'TUBAZIONE SENZA PARETE METALLICA CON SCAMBIO '//10X
     $ ,'NUMERO DI PARETI DI SCAMBIO PER OGNI CELLA (MAX = ',I2,') ?')
      READ(5,*) NPAR
      IF(NPAR.GE.1.AND.NPAR.LE.NPMAX)GO TO 3
      WRITE(6,1004) NPAR
 1004 FORMAT(/10X,'ERRORE - N. PARETI =',I3)
      GO TO 1
    3 CONTINUE
      WRITE(6,1003) NCMAX
 1003 FORMAT(//10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.NCMAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
    5 CONTINUE
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGSI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      DIMENSION NTUB(NCMAX),DIAI(NCMAX),HLU(NCMAX)
      DIMENSION TNUMB(NCMAX),TDIAM(NCMAX),TLENG(NCMAX),HROWN(NCMAX)           
      DIMENSION RTPITCH(NCMAX),SGSDZ(NCMAX),SGICDIAM(NCMAX)              
      DIMENSION HTCS(NCMAX),SUP(NPMAX,NCMAX),SGFSEC(NCMAX)
      DIMENSION EHYD(NCMAX)                              
      CHARACTER*10 NR,SP(NPMAX)                                  
      CHARACTER*10 TN,TD,TL,HRN,SGISED,SGHEIGHT,SGESID,SGDZ                                
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA TN/'TubesNumb='/,TD/'TbExDiam ='/,TL/'TbLenght ='/                 
      DATA HRN/'HelRowsN ='/               
      DATA SGISED/'InShExDi ='/,SGHEIGHT/'SGHeight ='/                 
      DATA SGESID/'ExShInDi ='/ ,SGDZ/'SGShelDZ ='/               
      DATA NR/'HTCorSel ='/,SP/'HTrSurf1 =','HTrSurf2 =','HTrSurf3 ='
     $       ,'HTrSurf4 =','HTrSurf5 =','HTrSurf6 ='/                          
C                                                                       
      WRITE(6,*) ' Inizio I2'
C-----------------------------------------------------                                                    
      NCEL=NSTATI/3                                                     
      NPAR=(NUSCIT-2)/NSTATI
C                                                                       
      NN0=IV1-1                                                         
      NN1=NCEL+IV1-1                                                    
      NN2=2*NCEL+IV1-1                                                  
      NN3=3*NCEL+IV1-1                                                  
      NEQ=NSTATI+NUSCIT                                          
C                                                                       
      WRITE(6,*) 'NSTATI ',NSTATI,' NUSCIT ',NUSCIT,' NINGRE',NINGRE                                                    
      WRITE(6,*) ' NCEL',NCEL,'NPAR',NPAR                                                  
      WRITE(6,*) 'IFUN ',IFUN                                                  
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C                                                                       
   1  CONTINUE                                                          
      WRITE(14,4000)
 4000 FORMAT ('*   liquid Lead Steam Generator Shell with helicoidal'
     $        ,' tubes')
      DO 5 I=1,NCEL                                                     
        WRITE(14,1002)I                                                   
        WRITE(14,4001)
 4001 FORMAT ('*   Steam generator tubes data')
        WRITE(14,1013) TN,TD,TL,HRN     
       WRITE(14,4002)
 4002 FORMAT ('*   Steam generator shell data')
        WRITE(14,1013) SGESID,SGISED,SGHEIGHT,SGDZ,NR,(SP(J),J=1,NPAR)        
 1013 FORMAT(3(4X,A10,10X,'*'),5X)                               
    5 CONTINUE                                                          
 1002 FORMAT('*   Volumetric Node ',I2,'  *',55X)
C                                                                       
      WRITE(6,*) ' uscita I2 con IFUN 1'                                                    
      RETURN                                                            
C                                                                       
C-----LETTURA DEI DATI                                                  
C 
   10 CONTINUE                                                                      
      WRITE(6,*) ' sto leggendo F14'                                                    
      READ(14,1004)                                                     
      READ(14,1004)                                                     
C                                                                       
      DO 15 I=1,NCEL                                                    
        READ(14,1004)                                                     
        READ(14,1004)                                                     
      WRITE(6,*) ' sto leggendo F14 primo set'                                                    
        READ(14,1004) TNUMB(I),TDIAM(I),TLENG(I),HROWN(I)
        READ(14,1004)                                                     
      WRITE(6,*) ' sto leggendo F14 secondo set'                                                    
        READ(14,1004) DIAI(I),SGICDIAM(I),HLU(I),SGSDZ(I),HTCS(I)     
     $               ,(SUP(J,I),J=1,NPAR)                  
C        READ(14,1004) SGSDZ(I),HTCS(I),(SUP(J,I),J=1,NPAR)                  
   15 CONTINUE                                                          
C                                                                       
      DO I=1,NCEL
        DO J=1,NPAR
           write(6,*)'SUP (',J,',',I,')=',SUP(J,I)
        END DO
      END DO                                             
      WRITE(6,*) ' sto caricando dati righe vuote'
      DO J=1,NCEL
        IF (TNUMB(J).LE.0) THEN
          TNUMB(J)=TNUMB(J-1)                                                 
          TDIAM(J)=TDIAM(J-1)                                                 
          TLENG(J)=TLENG(J-1)                                                   
          HROWN(J)=HROWN(J-1)                                                   
          DIAI(J)=DIAI(J-1)                                                 
          HLU(J)=HLU(J-1)                                                   
          SGSDZ(J)=SGSDZ(J-1)                                                   
          SGICDIAM(J)=SGICDIAM(J-1)
          HTCS(J)=HTCS(J-1)                                                 
          DO J0=1,NPAR                                                    
            SUP(J0,J)=SUP(J0,J-1)                                               
           write(6,*)'SUP (',J0,',',J,')=',SUP(J0,J)                                              
          END DO
        END IF                                         
      END DO
C                                                    
C      DO 21 I=1,NCEL                                                    
C        IF(TNUMB(I).GT.0) GOTO 21                                          
C        DIAI(I)=DIAI(I-1)                                                 
C        HLU(I)=HLU(I-1)                                                   
C        SGSDZ(I)=SGSDZ(I-1)                                                   
C        SGICDIAM(I)=SGICDIAM(I-1)
C        HTCS(I)=HTCS(I-1)                                                 
C        DO 20 J=1,NPAR                                                    
C          SUP(J,I)=SUP(J,I-1)                                               
C   20   CONTINUE                                                          
C   21 CONTINUE
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C
      DO I=1,NCEL
        ANT=(DIAI(I)-SGICDIAM(I))/2.
        RTPITCH(I)=ANT/(HROWN(I)+1.)
      WRITE(6,*) ' RTPITCH =',RTPITCH(I)                                                    
      END DO
C
C------ Equivalent HYdraulic Diameter
C
      DO I=1,NCEL
        NPASSI=0.5*(DIAI(I)-SGICDIAM(I))/RTPITCH(I)-1
        SGSEC=PIGR/4.*(DIAI(I)**2.-SGICDIAM(I)**2.)
        SOMSEZTUB=0.
        SOMPT=0.
      WRITE(6,*) ' NPASSI =',NPASSI                                                    
        DO J=1,NPASSI
          SUMI=(SGICDIAM(I)+2.*J*RTPITCH(I)+TDIAM(I))**2.
          SUME=(SGICDIAM(I)+2.*J*RTPITCH(I)-TDIAM(I))**2.
          SOMSEZTUB=SOMSEZTUB+PIGR/4.*(SUMI-SUME)
          SOMPT=SOMPT+2.*(SGICDIAM(I)+2.*J*RTPITCH(I))
        END DO
        SGFSEC(I)=SGSEC-SOMSEZTUB
        PB=PIGR*(DIAI(I)+SGICDIAM(I)+SOMPT)
        EHYD(I)=4.*SGFSEC(I)/PB
      END DO
C
C                                                                       
      DATI(ID2)=NCEL                                                    
      DATI(ID2+1)=NPAR                                                  
      WRITE(6,*) ' sto caricando vettore dati'                                                    
C                                                                       
      DO 25 I=1,NCEL                                                    
        K=ID2+(7+NPAR)*(I-1)+1                                                  
        S=PIGR*DIAI(I)*HLU(I)                                     
        VSHELL=S*DIAI(I)/4.                                                    
        VTUB=PIGR*TDIAM(I)*TDIAM(I)/4.*TLENG(I)*TNUMB(I)
        VLEAD=VSHELL-VTUB                                                   
        write(6,*)'VSHELL=',VSHELL,'VTUB=',VTUB,'VLEAD=',VLEAD
C        A=V/HLU(I)                                                        
C        DATI(K+1)=V                                                       
        DATI(K+1)=VLEAD                                                       
        DATI(K+2)=HLU(I)                                                  
C        DATI(K+3)=A                                                       
        DATI(K+3)=SGFSEC(I)                                                       
        DATI(K+4)=DIAI(I)                                                 
C        DATI(K+5)=2.*HLU(I)/(DIAI(I)*A*A)                                 
        DATI(K+5)=2.*HLU(I)/(EHYD(I)*SGFSEC(I)*SGFSEC(I))                                 
        DATI(K+6)=SGSDZ(I)*9.81                                             
        DATI(K+7)=HTCS(I)                                                 
        DO J=1,NPAR                                               
          DATI(K+7+J)=SUP(J,I)
        END DO                                                
   25 CONTINUE                                                          
C                                                                       
      ID2 = ID2+(7+NPAR)*NCEL+1                                               
C      ID2 = ID2+NCEL+1
      ID2 = ID2+NCEL
      WRITE(6,*) ' sto caricando normalizzazioni'                                                    
      DO J=1,NCEL
        DATI(ID2+J)=TNUMB(J)                                              
        DATI(ID2+NCEL+J)=TDIAM(J)                                              
        DATI(ID2+2*NCEL+J)=TLENG(J)                                                  
        DATI(ID2+3*NCEL+J)=RTPITCH(J)                                                
        DATI(ID2+4*NCEL+J)=SGSDZ(J)                                       
        DATI(ID2+5*NCEL+J)=SGICDIAM(J)                                       
      END DO
      ID2 = ID2+6*NCEL+1                                              
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
      DO I=1,NCEL                                                    
        CNXYU(NN0+I)=H0                                                   
        CNXYU(NN1+I)=P0                                                   
        CNXYU(NN2+I)=W0
      END DO                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*(I-1)*NPAR+2*J-1)=T0                                     
          CNXYU(NN3+2*(I-1)*NPAR+2*J)=GAM0
        END DO
      END DO                                      
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=W0*H0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ-2)=H0                                                     
      CNXYU(IV1+NEQ-1)=H0                                                   
C                                                                       
      CNXYU(IV1+NEQ)=H0                                                   
      CNXYU(IV1+NEQ+1)=P0                                                   
      CNXYU(IV1+NEQ+2)=W0                                                   
      CNXYU(IV1+NEQ+3)=H0                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(IV1+NEQ+3+(I-1)*NPAR+J)=T0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ+NPAR*NCEL+4)=1.                                         
C                                                                       
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.                           
C                                                                       
C*******************************                                        
      DO 45 I=1,NCEL                                                    
        TOL(NCEL+I)=.01E5/P0                                              
        TOL(2*NCEL+I)=.1/W0                                               
   45 CONTINUE                                                          
C*******************************                                        
C                                                                       
C-----STAMPE                                                            
C                                                                       
      WRITE(6,3000)                                                     
C                                                                       
      DO 60 I=1,NCEL                                                    
        K=ID1+(7+NPAR)*(I-1)+1                                                  
        V= DATI(K+1)                                                      
        S= DATI(K+2)                                                      
        A= DATI(K+3)                                                      
        D=DATI(K+4)                                                       
        C=DATI(K+6)                                                       
        C=C/9.81                                                          
        WRITE(6,3001) I,V,S,A,D,C                                         
   60 CONTINUE                                                          
C                                                                       
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3000 FORMAT(6X,'CELLA',4X,'VOLUME     LUNGHEZZA    SEZIONE     ',      
     $           'DIAM.INT.  DISLIVELLO'//)                             
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)                                     
 3010 FORMAT(6X,3E11.4/)                                                
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGSC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
C-----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*80 SccsID
C
C---     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
C
      COMMON/REGIME/KREGIM                                              
C
      EXTERNAL LSGS
C
C----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'%W%\t %I%\t %G%'/          
C
C----     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
      NVAR=NEQ+NINGRE                                             
C                                                                       
      ISTA=LSGSISTA05(IFUN)                                                 
C                                                                       
      GO TO (10,20,30),IFUN                                             
C
C---topologia jacobiano
C
   10 CONTINUE
C
      DO I=1,NEQ                                                     
        DO J=1,NVAR                                                    
          AJAC(I,J)=1.                                                      
        END DO
      END DO
C                                                          
      RETURN                                                            
C                                                                       
C
C---calcolo residui
C
   20 CONTINUE
C
      CALL LSGS (IFUN,IXYU,XYU,IPD,DATI,RNI)                                   
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))                     
      IF(ISTA.NE.0) CALL LSGSSTAS05(ISTA)                                   
C                                                                       
      RETURN                                                            
C  
   30 CONTINUE
C
C---calcolo jacobiano
C
C      jacobiano numerico
C
C
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      CALL LSGSJC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,LSGS)
                  
C                                                                       
      RETURN                                                            
C                                                                       
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGSJC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                  NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/WAD1NQ/NEQ
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      DO J=1,NCOL
        IF (J.GE.NCEL+1.AND.J.LE.2*NCEL) THEN
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
          VAR=VARP
C
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGS (IFUN,IXYU,XYU,IPD,DATI,RNI)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
      REAL TK(NCMAX),QTCV(NCMAX),QCV(NPMAX,NCMAX),QTCDA(NCMAX)
      REAL QTCDB(NCMAX),SGFSEC(NCMAX)
      REAL SW(NCMAX),SH(NCMAX),SP(NCMAX),GSPEED(NCMAX)                                   
      REAL LHTC,MU(NCMAX),MU_T_LEAD                                    
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
      DIMENSION TNUMB(NCMAX),TDIAM(NCMAX),TLENG(NCMAX)            
      DIMENSION RTPITCH(NCMAX),SGSDZ(NCMAX),SGICDIAM(NCMAX)             
      DIMENSION EHYD(NCMAX),SGSFF(NCMAX)            
C
      COMMON/LSGSPARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/LSGSTERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/LSGSMEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/LSGSDATS05/V(NCMAX),HLU(NCMAX),AREA(NCMAX),DIAI(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZG(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
C                                                                       
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
C                                                                       
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NNN=NCEL+1                                                        
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
C                                                                       
C--------- Data ------                                                         
C                                                                       
      DO I=1,NCEL                                                    
        K3=IPD+(7+NPAR)*(I-1)+1                                                 
        V(I)=DATI(K3+1)                                                   
        HLU(I)=DATI(K3+2)                                                 
        AREA(I)=DATI(K3+3)                                                
        DIAI(I)=DATI(K3+4)                                                
        CKF(I)=DATI(K3+5)                                                 
        DZG(I)=DATI(K3+6)                                                 
        HTCS(I)=DATI(K3+7)                                                
        DO J=1,NPAR                                               
          SUP(J,I)=DATI(K3+7+J)
        END DO                                               
        write(6,*)'CKF(',I,') =',CKF(I)                                              
      END DO                                               
C                                                    
      KD=IPD+(7+NPAR)*NCEL+1
C                                                  
C      KD=KD+NCEL+1
      KD=KD+NCEL
C                                              
      DO J=1,NCEL
        TNUMB(J)=DATI(KD+J)                                              
        TDIAM(J)=DATI(KD+NCEL+J)                                              
        TLENG(J)=DATI(KD+2*NCEL+J)                                                  
        RTPITCH(J)=DATI(KD+3*NCEL+J)                                              
        SGSDZ(J)=DATI(KD+4*NCEL+J)                                      
        SGICDIAM(J)=DATI(KD+5*NCEL+J)                                      
      END DO
      DO J=1,NCEL
          write(6,*)'TNUMB (',J,')=',TNUMB(J)                                              
          write(6,*)'TDIAM (',J,')=',TDIAM(J)                                             
          write(6,*)'TLENG (',J,')=',TLENG(J)                                             
          write(6,*)'RTPITCH (',J,')=',RTPITCH(J)                                             
          write(6,*)'SGSDZ (',J,')=',SGSDZ(J)                                             
          write(6,*)'SGICDIAM (',J,')=',SGICDIAM(J)                                             
      END DO
C                                                                       
C
C----   Output variables
C
      K5=IXYU-1                                                         
      K6=IXYU-1+NCEL                                                        
      K7=IXYU-1+2*NCEL                                                        
      K8=IXYU-1+3*NCEL                                                        
C
      DO I=1,NCEL                                                    
        HM(I)=XYU(K5+I)*H0                                                   
        P(I+1)=XYU(K6+I)*P0                                                  
        WI(I)=XYU(K7+I)*W0                                                    
        DO J=1,NPAR                                                    
          TLP(J,I)=XYU(K8+2*(I-1)*NPAR+2*J-1)*T0                                     
          GL(J,I)=XYU(K8+2*(I-1)*NPAR+2*J)*GAM0
          QT(J,I)=XYU(K8+2*NCEL*NPAR+(I-1)*NPAR+J)*W0*H0                                     
          write(6,*)'TLP (',J,',',I,')=',TLP(J,I)                                              
          write(6,*)'GL (',J,',',I,')=',GL(J,I)                                              
          write(6,*)'QT (',J,',',I,')=',QT(J,I)                                              
        END DO                                                                                         
      END DO                                                                                         
      HITI=XYU(IXYU+NEQ-2)*H0                                             
      HOLD =XYU(IXYU+NEQ-1)*H0                                              
C
C----   Input variables
C
      HILD  =XYU(IXYU+NEQ)*H0                                                
      P(1)=XYU(IXYU+NEQ+1)*P0                                              
      WI(NNN)=XYU(IXYU+NEQ+2)*W0                                            
      HDLC=XYU(IXYU+NEQ+3)*H0                                                
C
      DO I=1,NCEL
       DO J=1,NPAR                                                    
         TW(J,I)=XYU(IXYU+NEQ+3+(I-1)*NPAR+J)*T0                                    
          write(6,*)'TW (',J,',',I,')=',TW(J,I)                                              
       END DO                                                                                         
      END DO                                                                                         
C
      CF=XYU(IXYU+NEQ+NPAR*NCEL+4)                                      
        write(6,*)'CF =',CF                                              
C
C
C------ Equivalent HYdraulic Diameter and Mass speed @*V
C
      DO I=1,NCEL
        NPASSI=0.5*(DIAI(I)-SGICDIAM(I))/RTPITCH(I)-1
        SGSEC=PIGR/4.*(DIAI(I)**2.-SGICDIAM(I)**2.)
        SOMSEZTUB=0.
        SOMPT=0.
        DO J=1,NPASSI
          SUMI=(SGICDIAM(I)+2.*J*RTPITCH(I)+TDIAM(I))**2.
          SUME=(SGICDIAM(I)+2.*J*RTPITCH(I)-TDIAM(I))**2.
          SOMSEZTUB=SOMSEZTUB+PIGR/4.*(SUMI-SUME)
          SOMPT=SOMPT+2.*(SGICDIAM(I)+2.*J*RTPITCH(I))
        END DO
        SGFSEC(I)=SGSEC-SOMSEZTUB
        PB=PIGR*(DIAI(I)+SGICDIAM(I)+SOMPT)
        EHYD(I)=4.*SGFSEC(I)/PB
        GSPEED(I)=ABS(WI(I))/SGFSEC(I)
      END DO
C
C----------- Lead Physical properties
C
C-----------   TK ---> Thermal Conductivity                                                                      
C-----------   RO ---> Density                                                                      
C-----------   DRODH ---> d@/dh                                                                      
C                                    
      DO I=1,NCEL
        TL(I)=T_H_LEAD(HM(I))
        write(6,*)'HM (',I,')=',HM(I) ,'TL (',I,')=',TL(I)                                              
        RO(I)=RO_T_LEAD(TL(I))                                            
        write(6,*)'RO (',I,')=',RO(I)                                              
        DRODH(I)=DRODH_LEAD(HM(I))
        write(6,*)'DRODH (',I,')=',DRODH(I)                                              
        TK(I)=TC_H_LEAD(HM(I))
        MU(I)=MU_T_LEAD(TL(I))
        write(6,*)'TL(',I,')=',TL(I),' MU=',MU(I)                                              
      END DO                                  
C
      TDLC=T_H_LEAD(HDLC)                                               
      TILD=T_H_LEAD(HILD)                                               
C
C
C----------- Friction factor
C                                                                       
      DO I=1,NCEL
        RE=GSPEED(I)*EHYD(I)/MU(I)
        SGSFF(I)=0.3164/RE**0.25                                                
        write(6,*)'GSPEED(',I,')=',GSPEED(I),' MU=',MU(I)                                              
        write(6,*)'EHYD(',I,')=',EHYD(I),' RE=',RE                                              
      END DO        
C
C
C
C----------- Heat Transfer Coefficient
C                                                                       
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
C
          IF (HTCS(I).LT.0.) THEN
C                                                                       
C  CHIAMA LA SUBROUTINE UTENTE LSGS_UHTC
C                                                                       
           CALL LSGS_UHTC(HTCS(I),HM(I),TL(I),RO(I),EHYD(I),GSPEED(I)
     $                                                      ,LHTC(J,I))
          ELSE
C                                                                       
C  COEFFICIENTE DI SCAMBIO DATO DALLE CORRELAZIONI STANDARD
C 
C          PITCH=0.0136
C          DIO=0.0085                                                                     
C          CALL LSGS_HTC(HTCS(I),TL(I),PITCH,DIO,G,DIAI(I),LHTC(J,I))
           write(6,*)'prima di chiamare LSGS_HTC TL (',I,')=',TL(I)                                              
           CALL LSGS_HTC(HTCS(I),TL(I),RTPITCH(I),TDIAM(I),GSPEED(I)
     $                                             ,EHYD(I),LHTC(J,I))
           write(6,*)'LHTC (',J,',',I,')=',LHTC(J,I)                                              
          END IF        
        END DO        
      END DO        
C
C
C----------- Convective Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        QTCV(I)=0.
        DO J=1,NPAR
          QCV(J,I)=LHTC(J,I)*SUP(J,I)*(TL(I)-TW(J,I))
          QTCV(I)=QTCV(I)+QCV(J,I)
           write(6,*)'SUP (',J,',',I,')=',SUP(J,I),'QCV(J,I)=',QCV(J,I)                                             
        END DO        
      END DO        
C
C
C----------- Conductive Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        IF (I.LT.NCEL) THEN
          HTS=MIN(AREA(I),AREA(I+1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I+1)/TK(I+1))
          QTCDA(I)=-GHTC*HTS*(TL(I)-TL(I+1))
C          QCDA=-TK(I)*AREA(I)*(TL(I)-TL(I+1))/((HLU(I)+HLU(I+1))/2.)
        ELSE
          QTCDA(I)=-TK(I)*AREA(I)*(TL(I)-TDLC)/(HLU(I)/2.)
        END IF
        IF (I.GT.1) THEN
          HTS=MIN(AREA(I),AREA(I-1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I-1)/TK(I-1))
          QTCDB(I)=-GHTC*HTS*(TL(I)-TL(I-1))
C          QCDB=-TK(I)*AREA(I)*(TL(I)-TL(I-1))/((HLU(I)+HLU(I-1))/2.)
        ELSE
          QTCDB(I)=-TK(I)*AREA(I)*(TL(I)-TILD)/(HLU(I)/2.)
        END IF
      END DO        
C
C
C---------- Conservation Equations' Constants 
C
C---------- Sw ---->  Mass Conservation
C---------- Sp ---->  Momentum Conservation
C---------- Sh ---->  Energy Conservation
C
      DO I=1,NCEL
        SW(I)=WI(I)-WI(I+1)
        SP(I)=P(I)-P(I+1)-CKF(I)*CF*SGSFF(I)*WI(I)*ABS(WI(I))/RO(I)
     &                                                -RO(I)*DZG(I)
        WRITE(6,*)'SGSFF(I)',SGSFF(I),'DZG(I)',DZG(I)
        IF (WI(I).GE.0.) THEN
          IF (I.EQ.1) THEN
            SHI=WI(I)*(HILD-HM(I))
          ELSE
            SHI=WI(I)*(HM(I-1)-HM(I))
          END IF
        ELSE
          SHI=0.
        END IF
C
        IF (WI(I+1).LE.0.) THEN
          IF (I.EQ.NCEL) THEN
            SHO=WI(I+1)*(HDLC-HM(I))
          ELSE
            SHO=WI(I+1)*(HM(I+1)-HM(I))
          END IF
        ELSE
          SHO=0.
        END IF
C
        SH(I)=SHI-SHO-QTCV(I)+QTCDA(I)+QTCDB(I)
      END DO
C      IF (IFUN.EQ.2.AND.ITERT.EQ.0) THEN
        DO I=1,NCEL
         write(6,*)'QTCDA(',I,')',QTCDA(I),'QTCDB(',I,')',QTCDB(I)
        END DO
C      END IF
C
      NN2=2*NCEL
      NN3=3*NCEL
C
      IF (KREGIM) THEN                                         
        DO I=1,NCEL                                                    
          RNI(I)     =SH(I)/(W0*H0)                                     
          RNI(NCEL+I)=SP(I)/P0                                          
          RNI(NN2+I) =SW(I)/W0                                          
         write(6,*)'RNI(',I,')',RNI(I),'RNI(NCEL+I)(',I,')',RNI(NCEL+I)
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(GL(J,I)-LHTC(J,I))/GAM0         
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QCV(J,I)-QT(J,I))/(W0*H0)
         write(6,*)'RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)',
     $              RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)
          END DO
        END DO
         write(6,*)'3*NCEL+3*NPAR*NCEL+1',(3*NCEL+3*NPAR*NCEL+1)
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
         write(6,*)'3*NCEL+3*NPAR*NCEL+2',(3*NCEL+3*NPAR*NCEL+2)
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0                
         write(6,*)'3*NCEL+3*NPAR*NCEL+2',RNI(3*NCEL+3*NPAR*NCEL+2)
       ELSE
        DO I=1,NCEL                                                    
          RNI(I)     =SW(I)/(V(I)*DRODH(I)*H0)                          
          RNI(NCEL+I)=(RO(I)*SW(I)/DRODH(I)-SH(I))/(V(I)*P0)            
          RNI(NN2+I) =AREA(I)/HLU(I)*SP(I)/W0                           
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(LHTC(J,I)-GL(J,I))/GAM0          
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QCV(J,I)-QT(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0      
C                                                                       
       END IF
C                                                                       
        write(6,*)'pippo'
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGS_HTC(HTCS,TL,PITCH,D,G,DH,LHTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C     HTCS  = Heat Transfer Correlation Selection code
C     TL    = Lead Temperature
C     PITCH = Lattice pitch
C     D     = Rod outside diameter
C     G     = Mass speed @�V
C     DH    = Hydraulic diameter
C     LHTC  = Lead Heat Transfer Coefficient
C
C
C
C     p = lattice pitch
C     D = rod outside diameter
C
C
C     Selection Code    Correlations for outside tube flow - helicoidal coil - staggered arrangement
C                                                           
C                                                           
C                       Babcock & Wilcox     Nu=4.03 + 0.228*Pe**0.67
C
CC
C
C
      INTEGER HTCSC
      REAL LHTC,K,MU,MU_T_LEAD,NU
C
      HTCSC=INT(HTCS)
C
      PD=PITCH/D
C
      K=TC_T_LEAD(TL)
      write(6,*)'TL=',TL,' K=',K                                              
C
      MU=MU_T_LEAD(TL)
      write(6,*)'TL=',TL,' MU=',MU                                              
C
      CP=CP_T_LEAD(TL)
      write(6,*)'TL=',TL,' CP=',CP                                              
C
      RE=G*DH/MU
C
      PR=MU*CP/K      
C
      PE=RE*PR     
C
      SELECT CASE (HTCSC)
             CASE (1)
              NU=1.
             CASE (2)
              NU=1.
             CASE (3)
              NU=1.
             CASE (4)
              NU=1.
             CASE (5)
              NU=1.
             CASE (6)
              NU=1.
             CASE (7)
              NU=1.
             CASE (8)
              NU=1.
      CASE DEFAULT 
          NU=4.03 + 0.228*Pe**0.67
      write(6,*)' NU=',NU                                              
      END SELECT
C
      LHTC=K/DH*NU
      write(6,*)' LHTC=',LHTC                                              
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      FUNCTION LSGSISTA05(IFUN)                                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      LSGSISTA05=0                                                          
      IF(KREGIM) LSGSISTA05=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) LSGSISTA05=1                         
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE LSGSSTAS05(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      REAL LHTC
C
      COMMON/LSGSPARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/LSGSTERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/LSGSMEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/LSGSDATS05/V(NCMAX),HLU(NCMAX),AREA(NCMAX),DIAI(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZG(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      WRITE(6,1001)                                                     
      DO 10 I=1,NCEL                                                    
      G=WI(I)/AREA(I)                                                    
      AM=RO(I)*AREA(I)*HLU(I)                                          
      T=TL(I)-273.16                                                    
      WRITE(6,1002) I,WI(I),HM(I),P(I+1),AM,RO(I),G,T          
   10 CONTINUE                                                          
      DO 20 J=1,NPAR                                                    
      WRITE(6,1003) J,J,J                                               
      DO 20 I=1,NCEL                                                    
      T=TW(J,I)-273.16                                                  
      WRITE(6,1004) I,T,LHTC(J,I),QT(J,I)                             
   20 CONTINUE                                                          
      RETURN                                                            
 1001 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',    
     $       6X,'MASSA TOT.',5X,'DENS.MEDIA',4X,            
     $       'PORT.SPEC.',6X,'TEMPERATURA',4X//)                        
 1002 FORMAT(1X,I3,5X,8(E12.5,3X))                                      
 1003 FORMAT(//1X,'CELLA',4X,'TEMP.PAR.',I2,7X,'COEFF.SCAMBIO',I2,      
     $       3X,'POT. TERM.',I2,7X//)                                   
 1004 FORMAT(1X,I3,5X,8(E12.5,6X))                                      
      END                                                               
C
C
C
      SUBROUTINE LSGSD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      RETURN
      END
C
C
C~FORAUS_LSGS~C 
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE LSGS_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE LSGS_UHTC SIA CHIAMATA DA LSGS
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   HTCS < 0.
C
C  La subroutine fornisce al modulo LSGS il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]          
C   H     entalpia specifica del fluido           [J/kg]        
C   S     entropia specifica del fluido           [J/kg/C] 
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]     
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   HTCS  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato 
C         come si vuole.
C         RICORDATI CHE HTCS E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]   
C   Q     potenza totale scambiata                [W]           
C   SUP   superficie di scambio                   [m**2]        
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE LSGS_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_LSGS~C 

