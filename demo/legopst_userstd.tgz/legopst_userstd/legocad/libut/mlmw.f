C/**********************************************************************
C*
C*	Fortran Source:		mlmw.f
C*	Instance:		1
C*	Description:	
C*	%created_by:	speziag %
C*	%date_created:	Wed Nov 25 10:32:27 1998 %
C*
C**********************************************************************/
C
C
      SUBROUTINE MLMWI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/MLMW01/IBLOC
      COMMON/MLMW02/NCEL,NPAR,NGS
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'MLMW'/
C
C   PARETE METALLICA SOTTILE A CELLE 
C
C
C
      CALL MLMWI4(IOB,MOD)
C
C
      NSTATI= 3*NCEL
      NUSCIT= 2*NCEL
C
      SELECT CASE (NGS)
         CASE (0)
          NINGRE= 4*NCEL
         CASE (1,2)
           NINGRE= 4*NCEL+3
         CASE (3)
           NINGRE= 4*NCEL+6
         CASE DEFAULT
           NINGRE= 4*NCEL
       END SELECT
C
C
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      DO K=1,NCEL
        WRITE(IFO,3000)K,IOB,K
 3000   FORMAT('TMI',I1,A4,2X,'--US-- TEMPERATURA MEDIA STRATO '
     $  ,'INTERNO METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3001)K,IOB,K
 3001   FORMAT('TMC',I1,A4,2X,'--US-- TEMPERATURA MEDIA STRATO '
     $  ,' CENTRALE METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3002)K,IOB,K
 3002   FORMAT('TME',I1,A4,2X,'--US-- TEMPERATURA MEDIA STRATO '
     $  ,'ESTERNO METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3003)K,IOB,K
 3003   FORMAT('QI_',I1,A4,2X,'--UA-- POTENZA SCAMBIATA DALLA SUPERF. '
     $  ,'INTERNA METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3004)K,IOB,K
 3004   FORMAT('QE_',I1,A4,2X,'--UA-- POTENZA SCAMBIATA DALLA SUPERF. '
     $  ,'ESTERNA METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3005)K,IOB,K
 3005   FORMAT('TFI',I1,A4,2X,'--IN-- TEMPERATURA FLUIDO INTERNO ' 
     $  ,'CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3006)K,IOB,K
 3006   FORMAT('GFI',I1,A4,2X,'--IN-- COEFF. DI SCAMBIO TERMICO ' 
     $  ,'FLUIDO INTERNO - METALLO CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3007)K,IOB,K
 3007   FORMAT('TFE',I1,A4,2X,'--IN-- TEMPERATURA FLUIDO ESTERNO ' 
     $  ,'CELLA ',I1)
      END DO
C
      DO K=1,NCEL
        WRITE(IFO,3008)K,IOB,K
 3008   FORMAT('GFE',I1,A4,2X,'--IN-- COEFF. DI SCAMBIO TERMICO ' 
     $  ,'FLUIDO ESTERNO - METALLO CELLA ',I1)
      END DO
C
      SELECT CASE (NGS)
             CASE (0)
             CASE (1)
                 WRITE(IFO,3009)IOB
 3009            FORMAT('TIGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'INTERNO METALLO GIUNZIONE INFERIORE')
                WRITE(IFO,3010)IOB
 3010            FORMAT('TCGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'CENTRALE METALLO GIUNZIONE INFERIORE')
                 WRITE(IFO,3011)IOB
 3011            FORMAT('TEGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'ESTERNO METALLO GIUNZIONE INFERIORE')
             CASE (2)
                 WRITE(IFO,3012)IOB
 3012            FORMAT('TIGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'INTERNO METALLO GIUNZIONE SUPERIORE')
                 WRITE(IFO,3013)IOB
 3013            FORMAT('TCGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'CENTRALE METALLO GIUNZIONE SUPERIORE')
                 WRITE(IFO,3014)IOB
 3014            FORMAT('TEGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'ESTERNO METALLO GIUNZIONE SUPERIORE')
             CASE (3)
                 WRITE(IFO,3015)IOB
 3015            FORMAT('TIGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'INTERNO METALLO GIUNZIONE INFERIORE')
                 WRITE(IFO,3016)IOB
 3016            FORMAT('TCGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'CENTRALE METALLO GIUNZIONE INFERIORE')
                 WRITE(IFO,3017)IOB
 3017            FORMAT('TEGI',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'ESTERNO METALLO GIUNZIONE INFERIORE')
                 WRITE(IFO,3018)IOB
 3018            FORMAT('TIGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'INTERNO METALLO GIUNZIONE SUPERIORE')
                 WRITE(IFO,3019)IOB
 3019            FORMAT('TCGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'CENTRALE METALLO GIUNZIONE SUPERIORE')
                 WRITE(IFO,3020)IOB
 3020            FORMAT('TEGS',A4,2X,'--IN-- TEMPERATURA MEDIA STRATO '
     $                 ,'ESTERNO METALLO GIUNZIONE SUPERIORE')
             CASE DEFAULT
       END SELECT
C
C
      RETURN
      END
      SUBROUTINE MLMWI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/MLMW01/IBLOC
      COMMON/MLMW02/NCEL,NPAR,NGS
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      PARAMETER (MAX=9)
C
C
    1 WRITE(6,1001) MAX
 1001 FORMAT(//10X,'PARETE METALLICA SOTTILE'//
     $ 10X,'NUMERO DI CELLE (01 -',I3,') ?')
      READ(5,*) NCEL
      IF(NCEL.LE.0.OR.NCEL.GT.MAX) THEN
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
      END IF
C
    6 CONTINUE
C
      WRITE(6,1003) 
 1003 FORMAT(//10X,'GIUNZIONI AGLI ESTREMI'//
     $ 10X,'0  --> Nessuna giunzione'//
     $ 10X,'1  --> Giunzione estremo inferiore'//
     $ 10X,'2  --> Giunzione estremo superiore'//
     $ 10X,'3  --> Giunzione sui due estremi')
      READ(5,*) NGS
      IF(NGS.EQ.0.OR.NGS.EQ.1.OR.NGS.EQ.2.OR.NGS.EQ.3)GO TO 5
      WRITE(6,1004) NGS
 1004 FORMAT(/10X,'ERRORE  - selezione giunzione -->',I3,/)
      GO TO 6
C
C
C
    5 CONTINUE
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C
C
      SUBROUTINE MLMWI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBLOC1,IBLOC2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=9)
      CHARACTER*4 NK,ISPA,NT,NDI,NDE,NL,IPO1,IPO2,NR,NC,THIC
      CHARACTER*4 VARCN,VARSGNZ,NGS
      CHARACTER*4 GINF(8)
      INTEGER VAR
      LOGICAL LGA1,LGB1,LGC1,LGA2
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
      DIMENSION NTUB(MAX),DIAE(MAX),THICK(MAX),HLU(MAX)
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      DATA NR/'ROM'/,NC/'CM'/,NK/'COND'/,ISPA/'    '/,PIGR/3.1415926/
      DATA NT/'NTUB'/,THIC/'THIC'/,NDE/'DIAE'/,NL/'LUNG'/
      DATA NGS/'SGNZ'/
      DATA GINF/'TEGI','TME9','TME8','TME7','TME6','TME5','TME4','TME3'/
C
      NVAR=IV2-IV1+1
C
      NCEL=NSTATI/3
      NG=(NINGRE-4*NCEL)/3
      NEQ=5*NCEL 
C
C - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
C
C ---- Recupero numero di celle attraverso decodifica dell'ultima
C ---- variabile di uscita
C
      LGA1=(VARSGNZ.EQ.'TEGI'.OR.VARSGNZ.EQ.'TME9'.OR.VARSGNZ.EQ.'TME8')
      LGB1=(VARSGNZ.EQ.'TME7'.OR.VARSGNZ.EQ.'TME6'.OR.VARSGNZ.EQ.'TME5')
      LGC1=(VARSGNZ.EQ.'TME4'.OR.VARSGNZ.EQ.'TME3'.OR.VARSGNZ.EQ.'TME2')
      LGA2=(VARSGNZ.EQ.'TEGS'.OR.VARSGNZ.EQ.'TME1')
      WRITE (VARCN,'(A4)')VAR(IV2,1)
      READ (VARCN(1:4),'(A4)')VARSGNZ
C
      SELECT CASE(NG)
         CASE (0)
            SGNZ=0.
         CASE (1)
C            SELECT CASE(VARSGNZ)
C               CASE ('TEGI','TME9','TME8','TME7','TME6','TME5'
C     $              ,'TME4','TME3','TME2')
C                 SGNZ=1.
C               CASE ('TEGS','TME1')
C                 SGNZ=2.
C               CASE DEFAULT
C            END SELECT
            IF (LGA1.OR.LGB1.OR.LGC1) THEN 
	      SGNZ=1.
	    END IF
C	    
            IF (LGA2) THEN 
	      SGNZ=2.
	    END IF
         CASE (2)
             SGNZ=3.
         CASE DEFAULT
      END SELECT
C
      GO TO (10,20),IFUN
C
C  SCRITTURA SIMBOLI DEI DATI
C
   10 CONTINUE
      WRITE(14,101)NR,ISPA,NC,ISPA,NK,ISPA
  101 FORMAT(3(4X,2A4,' =',10X,'*'),5X)
C
      DO 15 I=1,NCEL
      WRITE(14,102)I
  102 FORMAT('*   DATI DELLA CELLA ',I3,'*',55X)
      WRITE(14,103) NT,I,NDE,I,THIC,I,NL,I
  103 FORMAT(3(4X,A4,I4,' =',10X,'*'),5X)
   15 CONTINUE
      RETURN
C
C  LETTURA DEI DATI
C
   20 READ(14,201)
      READ(14,201) ROM,CM,COND
  201 FORMAT(3(14X,F10.0,1X),5X)
C
      DO 25 I=1,NCEL
      READ(14,201)
      READ(14,201) TUB,DIAE(I),THICK(I),HLU(I)
      NTUB(I)=TUB
   25 CONTINUE
C
      DO 30 I=1,NCEL
      IF(NTUB(I).GT.0) GO TO 30
      NTUB(I)=NTUB(I-1)
      DIAE(I)=DIAE(I-1)
      THICK(I)=THICK(I-1)
      HLU(I)=HLU(I-1)
   30 CONTINUE
C
C  Memorizzazione dati
C
      DATI(ID2)=NCEL
      DATI(ID2+1)=ROM
      DATI(ID2+2)=CM
      DATI(ID2+3)=COND
      ID2=ID2+3
C
      DO J=1,NCEL
        DATI(ID2+J)=NTUB(J)
        DATI(ID2+NCEL+J)=DIAE(J)
        DATI(ID2+2*NCEL+J)=THICK(J)
        DATI(ID2+3*NCEL+J)=HLU(J)
      END DO
      DATI(ID2+4*NCEL+1)=NG
      DATI(ID2+4*NCEL+2)=SGNZ
      ID2=ID2+4*NCEL+3
C
C---costanti di normalizzazione
C
C---- Output Variables
C
      DO I=1,3*NCEL
        CNXYU(IV1+I-1)=T0
      END DO
C
      DO I=3*NCEL+1,5*NCEL
        CNXYU(IV1+I-1)=W0*H0
      END DO
C
C---- Input Variables
C
      DO I=5*NCEL+1,6*NCEL
        CNXYU(IV1+I-1)=T0
      END DO
C
      DO I=6*NCEL+1,7*NCEL
        CNXYU(IV1+I-1)=1000.
      END DO
C
      DO I=7*NCEL+1,8*NCEL
        CNXYU(IV1+I-1)=T0
      END DO
C
      DO I=8*NCEL+1,9*NCEL
        CNXYU(IV1+I-1)=1000.
      END DO
C
C
      IF (NG.GT.0) THEN
        DO I=9*NCEL+1,9*NCEL+3*NG
          CNXYU(IV1+I-1)=T0
        END DO
      END IF
C
C
C
      DO I=1,NCEL
        SME=PIGR*DIAE(I)*HLU(I)*NTUB(I)
        THICKS=THICK(I)/3.
        DSEC=DIAE(I)-2.*THICKS
        SMEC=PIGR*DSEC*HLU(I)*NTUB(I)
        DSCI=DIAE(I)-4.*THICKS
        DIAI=DIAE(I)-2.*THICK(I)
        SMCI=PIGR*DSCI*HLU(I)*NTUB(I)     
        SMI=PIGR*DIAI*HLU(I)*NTUB(I)     
        VMSE=PIGR*(DIAE(I)**2.-DSEC**2.)*HLU(I)*NTUB(I)/4.
        XMSE=ROM*VMSE
        VMSC=PIGR*(DSEC**2.-DSCI**2.)*HLU(I)*NTUB(I)/4.
        XMSC=ROM*VMSC
        VMSI=PIGR*(DSCI**2.-DIAI**2.)*HLU(I)*NTUB(I)/4.
        XMSI=ROM*VMSI
        WRITE(6,601) I
        WRITE(6,*)' Superficie parete esterna ',SME,' mq'
        WRITE(6,*)' Superficie di separazione strato esterno-',
     $            'strato centrale ',SMEC,' mq'
        WRITE(6,*)' Superficie di separazione strato centrale-',
     $            'strato interno ',SMCI,' mq'
        WRITE(6,*)' Superficie parete interna      ',SMI,' mq'
        WRITE(6,*)' Volume metallo strato esterno  ',VMSE,' mc'
        WRITE(6,*)' Massa metallo strato esterno   ',XMSE,' kg'
        WRITE(6,*)' Volume metallo strato centrale ',VMSC,' mc'
        WRITE(6,*)' Massa metallo strato centrale  ',XMSC,' kg'
        WRITE(6,*)' Volume metallo strato interno  ',VMSI,' mc'
        WRITE(6,*)' Massa metallo strato interno   ',XMSI,' kg'
      END DO
C
      RETURN
  601 FORMAT(//6X,'CELLA',4X,I1,/)
      END
C
C
C
      SUBROUTINE MLMWC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $                  IBLOC1,IBLOC2)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      EXTERNAL MLMW
C
C
      NCEL=DATI(IPD)
      NG=DATI(IPD+3+4*NCEL+1)
      NSTATI=3*NCEL
      NUSCIT=2*NCEL
      NINGRE=4*NCEL+3*NG
      NEQ=5*NCEL
      NVAR=9*NCEL+3*NG
C
      GO TO(100,200,300),IFUN
C
C---Topologia Jacobiano
C
  100 CONTINUE
C
      DO I=1,NEQ
        DO J=1,NVAR
          AJAC(I,J)=1.
        END DO
      END DO
C
      RETURN
C
C
C---calcolo residui
C
  200 CALL MLMW(IFUN,IXYU,XYU,IPD,DATI,RNI)
      RETURN
C
C---calcolo jacobiano numerico
C
  300 CONTINUE
C
      EPS    = 1.E-3
      EPSLIM = 1.E-4
      CALL MLMWJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,MLMW)
      RETURN
C
      END
C
      SUBROUTINE MLMWJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
      DO 30 J=1,NCOL
C
        VAR=EPS*XYU(IXYU+J-1)
        IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
C
      DO 10 K=1,NCOL
        CXYU(K)=XYU(IXYU+K-1)
        CCXYU(K)=XYU(IXYU+K-1)
        IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
        IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
   10 CONTINUE
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
      CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
      CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
      DO 20 I=1,NRIG
        AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
        IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
   20 CONTINUE
C
   30 CONTINUE
C
C
      RETURN
      END
C
C
      SUBROUTINE MLMW(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      PARAMETER (MAX=9)
      LOGICAL KREGIM
      DIMENSION XYU(*),DATI(*),RNI(*)
      DIMENSION NTUB(MAX),DIAE(MAX),THICK(MAX),HLU(MAX)
      DIMENSION TMC(MAX),TMI(MAX),TME(MAX),QI(MAX),QE(MAX)
      DIMENSION TFI(MAX),GFI(MAX),TFE(MAX),GFE(MAX)
      DIMENSION SMEX(MAX),SMEXC(MAX),SMCIN(MAX),SMIN(MAX)
      DIMENSION VMSEX(MAX),VMSCE(MAX),VMSIN(MAX)
      DIMENSION ASEX(MAX),ASCE(MAX),ASI(MAX)
      DIMENSION QTCDCA(MAX),QTCDCI(MAX),QTCDIA(MAX),QTCDII(MAX)
      DIMENSION QTCDEA(MAX),QTCDEI(MAX),DXL(MAX),TIG(2),TCG(2),TEG(2)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/ KREGIM 
      DATA PIGR/3.1415926/,DX/1./
C
C---decodifica dati e variabili
C
      NCEL=DATI(IPD)
      NG=DATI(IPD+3+4*NCEL+1)
      SGNZ=DATI(IPD+3+4*NCEL+2)
      ROM=DATI(IPD+1)
      CM=DATI(IPD+2)
      COND=DATI(IPD+3)
C
      DO J=1,NCEL
        NTUB(J)=DATI(IPD+3+J)
        DIAE(J)=DATI(IPD+3+NCEL+J)
        THICK(J)=DATI(IPD+3+2*NCEL+J)
        HLU(J)=DATI(IPD+3+3*NCEL+J)
      END DO
C
C-- Output variables
C
      DO I=1,NCEL
C
        TMI(I)=XYU(IXYU+I-1)*T0
        TMC(I)=XYU(IXYU+NCEL+I-1)*T0
        TME(I)=XYU(IXYU+2*NCEL+I-1)*T0
C
        QI(I)=XYU(IXYU+3*NCEL+I-1)*W0*H0
        QE(I)=XYU(IXYU+4*NCEL+I-1)*W0*H0
C
C-- Input variables
C
        TFI(I)=XYU(IXYU+5*NCEL+I-1)*T0
C
        GFI(I)=XYU(IXYU+6*NCEL+I-1)*1000.
C
        TFE(I)=XYU(IXYU+7*NCEL+I-1)*T0
C
        GFE(I)=XYU(IXYU+8*NCEL+I-1)*1000.
C
      END DO
C
      SELECT CASE (INT(SGNZ))
         CASE(0)
            DO I=1,2
              TIG(I)=0.
              TCG(I)=0.
              TEG(I)=0.
            END DO
         CASE(1)
            TIG(1)=XYU(IXYU+9*NCEL)*T0
            TCG(1)=XYU(IXYU+9*NCEL+1)*T0
            TEG(1)=XYU(IXYU+9*NCEL+2)*T0
            TIG(2)=0.
            TCG(2)=0.
            TEG(2)=0.
         CASE(2)
            TIG(1)=0.
            TCG(1)=0.
            TEG(1)=0.
            TIG(2)=XYU(IXYU+9*NCEL)*T0
            TCG(2)=XYU(IXYU+9*NCEL+1)*T0
            TEG(2)=XYU(IXYU+9*NCEL+2)*T0
         CASE(3)
            DO I=1,NG
              TIG(I)=XYU(IXYU+9*NCEL+3*(I-1))*T0
              TCG(I)=XYU(IXYU+9*NCEL+3*(I-1)+1)*T0
              TEG(I)=XYU(IXYU+9*NCEL+3*(I-1)+2)*T0
              write(6,*)'CASE(3)  NG',NG
              write(6,*)'TIG(',I,')',TIG(I)
              write(6,*)'TCG(',I,')',TCG(I)
              write(6,*)'TEG(',I,')',TEG(I)
            END DO
         CASE DEFAULT
            DO I=1,2
              TIG(I)=0.
              TCG(I)=0.
              TEG(I)=0.
            END DO
      END SELECT
C
C-- Calcolo grandezze geometriche (superfici, volumi etc...)
C
      DO I=1,NCEL
        SMEX(I)=PIGR*DIAE(I)*HLU(I)*NTUB(I)
        THICKS=THICK(I)/3.
        DSEC=DIAE(I)-2.*THICKS
        SMEXC(I)=PIGR*DSEC*HLU(I)*NTUB(I)
        DSCI=DIAE(I)-4.*THICKS
        DIAI=DIAE(I)-2.*THICK(I)
        SMCIN(I)=PIGR*DSCI*HLU(I)*NTUB(I)
        SMIN(I)=PIGR*DIAI*HLU(I)*NTUB(I)
        VMSEX(I)=PIGR*(DIAE(I)**2.-DSEC**2.)*HLU(I)*NTUB(I)/4.
        VMSCE(I)=PIGR*(DSEC**2.-DSCI**2.)*HLU(I)*NTUB(I)/4.
        VMSIN(I)=PIGR*(DSCI**2.-DIAI**2.)*HLU(I)*NTUB(I)/4.
        ASEX(I)=PIGR*(DIAE(I)**2.-DSEC**2.)*NTUB(I)/4.
        ASCE(I)=PIGR*(DSEC**2.-DSCI**2.)*NTUB(I)/4.
        ASI(I)=PIGR*(DSCI**2.-DIAI**2.)*NTUB(I)/4.
        DXL(I)=DX*HLU(I)
       END DO
C
C-- Calcolo potenza termica scambiata fra le sezioni trasversali
C
C--
      SELECT CASE (INT(SGNZ))
         CASE(0)
           QTCDEI(1)=0.
           QTCDCI(1)=0.
           QTCDII(1)=0.
           QTCDEA(NCEL)=0.
           QTCDCA(NCEL)=0.
           QTCDIA(NCEL)=0.
         CASE(1)
           QTCDEI(1)=-COND/DXL(1)*ASEX(1)*(TME(1)-TEG(1))
           QTCDCI(1)=-COND/DXL(1)*ASCE(1)*(TMC(1)-TCG(1))
           QTCDII(1)=-COND/DXL(1)*ASI(1)*(TMI(1)-TIG(1))
           QTCDEA(NCEL)=0.
           QTCDCA(NCEL)=0.
           QTCDIA(NCEL)=0.
         CASE(2)
           QTCDEI(1)=0.
           QTCDCI(1)=0.
           QTCDII(1)=0.
           QTCDEA(NCEL)=-COND/DXL(NCEL)*ASEX(NCEL)*(TME(NCEL)-TEG(2))
           QTCDCA(NCEL)=-COND/DXL(NCEL)*ASCE(NCEL)*(TMC(NCEL)-TCG(2))
           QTCDIA(NCEL)=-COND/DXL(NCEL)*ASI(NCEL)*(TMI(NCEL)-TIG(2))
         CASE(3)
           QTCDEI(1)=-COND/DXL(1)*ASEX(1)*(TME(1)-TEG(1))
           QTCDCI(1)=-COND/DXL(1)*ASCE(1)*(TMC(1)-TCG(1))
           QTCDII(1)=-COND/DXL(1)*ASI(1)*(TMI(1)-TIG(1))
           QTCDEA(NCEL)=-COND/DXL(NCEL)*ASEX(NCEL)*(TME(NCEL)-TEG(2))
           QTCDCA(NCEL)=-COND/DXL(NCEL)*ASCE(NCEL)*(TMC(NCEL)-TCG(2))
           QTCDIA(NCEL)=-COND/DXL(NCEL)*ASI(NCEL)*(TMI(NCEL)-TIG(2))
         CASE DEFAULT
           QTCDEI(1)=0.
           QTCDCI(1)=0.
           QTCDII(1)=0.
           QTCDEA(NCEL)=0.
           QTCDCA(NCEL)=0.
           QTCDIA(NCEL)=0.
      END SELECT
C--
      DO I=1,NCEL
        IF (I.LT.NCEL) THEN
          HTSEA=MIN(ASEX(I),ASEX(I+1))
          GHTCEA=2./(DXL(I)/COND+DXL(I+1)/COND)
          QTCDEA(I)=-GHTCEA*HTSEA*(TME(I)-TME(I+1))
          HTSCA=MIN(ASCE(I),ASCE(I+1))
          GHTCCA=2./(DXL(I)/COND+DXL(I+1)/COND)
          QTCDCA(I)=-GHTCCA*HTSCA*(TMC(I)-TMC(I+1))
          HTSIA=MIN(ASI(I),ASI(I+1))
          GHTCIA=2./(DXL(I)/COND+DXL(I+1)/COND)
          QTCDIA(I)=-GHTCIA*HTSIA*(TMI(I)-TMI(I+1))
        END IF
C
        IF (I.GT.1) THEN
          HTSEI=MIN(ASEX(I),ASEX(I-1))
          GHTCEI=2./(DXL(I)/COND+DXL(I-1)/COND)
          QTCDEI(I)=-GHTCEI*HTSEI*(TME(I)-TME(I-1))
          HTSCI=MIN(ASCE(I),ASCE(I-1))
          GHTCCI=2./(DXL(I)/COND+DXL(I-1)/COND)
          QTCDCI(I)=-GHTCCI*HTSCI*(TMC(I)-TMC(I-1))
          HTSII=MIN(ASI(I),ASI(I-1))
          GHTCII=2./(DXL(I)/COND+DXL(I-1)/COND)
          QTCDII(I)=-GHTCII*HTSII*(TMI(I)-TMI(I-1))
        END IF
      END DO
C
C-- Calcolo residui
C
C
C-- Conservazione dell'energia nello strato di metallo interno
C
      DO J=1,NCEL
        A0=GFI(J)*SMIN(J)
        A1=COND*SMCIN(J)/(THICK(J)/3.)
        IF (KREGIM) THEN
          SELECT CASE (INT(SGNZ))
            CASE (0)
              IF (J.EQ.1) THEN
                SXA=MIN(ASI(J),ASI(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                                    +A30*(TMI(J+1)-TMI(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                                          +TMI(J+1)-TMI(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASI(J),ASI(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                                    +A20*(TMI(J-1)-TMI(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                    RNI(J)=(A02*(TFI(J)-TMI(J))+A12*(TMC(J)-TMI(J))
     $                                          +TMI(J-1)-TMI(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=MIN(ASI(J),ASI(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                  +A20*(TMI(J-1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                     +A23*(TMI(J-1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (1)
C
              IF (J.EQ.1) THEN
                SXI=ASI(J)
                SXA=MIN(ASI(J),ASI(J+1))
                A2=COND*SXI/DXL(J)
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                  RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                   +A20*(TIG(1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                     +A23*(TIG(1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASI(J),ASI(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                                    +A20*(TMI(J-1)-TMI(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                    RNI(J)=(A02*(TFI(J)-TMI(J))+A12*(TMC(J)-TMI(J))
     $                                          +TMI(J-1)-TMI(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=MIN(ASI(J),ASI(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                 +A20*(TMI(J-1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TMI(J-1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (2)
C
              IF (J.EQ.1) THEN
                SXA=MIN(ASI(J),ASI(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                                       +A30*(TMI(J+1)-TMI(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                                          +TMI(J+1)-TMI(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=ASI(J)
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                   +A20*(TMI(J-1)-TMI(J))+A30*(TIG(2)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TMI(J-1)-TMI(J))+TIG(2)-TMI(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=MIN(ASI(J),ASI(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                 +A20*(TMI(J-1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TMI(J-1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (3)
C
              IF (J.EQ.1) THEN
                SXI=ASI(J)
                SXA=MIN(ASI(J),ASI(J+1))
                A2=COND*SXI/DXL(J)
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                  RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                   +A20*(TIG(1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TIG(1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=ASI(J)
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                   +A20*(TMI(J-1)-TMI(J))+A30*(TIG(2)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TMI(J-1)-TMI(J))+TIG(2)-TMI(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASI(J),ASI(J-1))
                  SXA=MIN(ASI(J),ASI(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(J)=(TFI(J)-TMI(J)+A10*(TMC(J)-TMI(J))
     $                 +A20*(TMI(J-1)-TMI(J))+A30*(TMI(J+1)-TMI(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(J)=(A03*(TFI(J)-TMI(J))+A13*(TMC(J)-TMI(J))
     $                   +A23*(TMI(J-1)-TMI(J))+TMI(J+1)-TMI(J))/T0
                  END IF
                END IF
              END IF
C
            CASE DEFAULT
C
          END SELECT
        ELSE
          RNI(J)=1./(ROM*VMSIN(J)*CM)*(COND*SMCIN(J)/(THICK(J)/3.)*
     $                                                   (TMC(J)-TMI(J))
     $           -GFI(J)*SMIN(J)*(TMI(J)-TFI(J))+QTCDIA(J)+QTCDII(J))/T0
        END IF
      END DO
C
C
C-- Conservazione dell'energia nello strato di metallo centrale
C
      DO J=1,NCEL
        A0=3.*COND/THICK(J)*SMEXC(J)
        A1=3.*COND/THICK(J)*SMCIN(J)
        IF (KREGIM) THEN
          SELECT CASE (INT(SGNZ))
            CASE (0)
              IF (J.EQ.1) THEN
                SXA=MIN(ASCE(J),ASCE(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                                       +A30*(TMC(J+1)-TMC(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                                             +TMC(J+1)-TMC(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                                        +A20*(TMC(J-1)-TMC(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                    RNI(NCEL+J)=(A02*(TME(J)-TMC(J))+A12*(TMI(J)-TMC(J))
     $                                             +TMC(J-1)-TMC(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=MIN(ASCE(J),ASCE(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                  +A20*(TMC(J-1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (1)
C
              IF (J.EQ.1) THEN
                SXI=ASCE(J)
                SXA=MIN(ASCE(J),ASCE(J+1))
                A2=COND*SXI/DXL(J)
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                  RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                    +A20*(TCG(1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                      +A23*(TCG(1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                                       +A20*(TMC(J-1)-TMC(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                    RNI(NCEL+J)=(A02*(TME(J)-TMC(J))+A12*(TMI(J)-TMC(J))
     $                                             +TMC(J-1)-TMC(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=MIN(ASCE(J),ASCE(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                  +A20*(TMC(J-1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (2)
C
              IF (J.EQ.1) THEN
                SXA=MIN(ASCE(J),ASCE(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                                       +A30*(TMC(J+1)-TMC(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                                             +TMC(J+1)-TMC(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=ASCE(J)
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                    +A20*(TMC(J-1)-TMC(J))+A30*(TCG(2)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TCG(2)-TMC(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=MIN(ASCE(J),ASCE(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                  +A20*(TMC(J-1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (3)
C
              IF (J.EQ.1) THEN
                SXI=ASCE(J)
                SXA=MIN(ASCE(J),ASCE(J+1))
                A2=COND*SXI/DXL(J)
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                  RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                    +A20*(TCG(1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                      +A23*(TCG(1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=ASCE(J)
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                    +A20*(TMC(J-1)-TMC(J))+A30*(TCG(2)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TCG(2)-TMC(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASCE(J),ASCE(J-1))
                  SXA=MIN(ASCE(J),ASCE(J+1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(NCEL+J)=(TME(J)-TMC(J)+A10*(TMI(J)-TMC(J))
     $                  +A20*(TMC(J-1)-TMC(J))+A30*(TMC(J+1)-TMC(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                    RNI(NCEL+J)=(A03*(TME(J)-TMC(J))+A13*(TMI(J)-TMC(J))
     $                        +A23*(TMC(J-1)-TMC(J))+TMC(J+1)-TMC(J))/T0
                  END IF
                END IF
              END IF
C
            CASE DEFAULT
C
          END SELECT
        ELSE
          RNI(NCEL+J)=1./(ROM*VMSCE(J)*CM)*(COND/(THICK(J)/3.)*
     $            (SMEXC(J)*(TME(J)-TMC(J))-SMCIN(J)*(TMC(J)-TMI(J)))
     $                                         +QTCDCA(J)+QTCDCI(J))/T0
        END IF
      END DO
C
C
C-- Conservazione dell'energia nello strato di metallo esterno
C
      DO J=1,NCEL
        A0=GFE(J)*SMEX(J)
        A1=COND*SMEXC(J)/(THICK(J)/3.)
        IF (KREGIM) THEN
          SELECT CASE (INT(SGNZ))
            CASE (0)
              IF (J.EQ.1) THEN
                SXA=MIN(ASEX(J),ASEX(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                                        +A30*(TME(J+1)-TME(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                                              +TME(J+1)-TME(J))/T0
                END IF     
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                                       +A20*(TME(J-1)-TME(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                    RNI(2*NCEL+J)=(A02*(TFE(J)-TME(J))
     $                         +A12*(TMC(J)-TME(J))+TME(J-1)-TME(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=MIN(ASEX(J),ASEX(J+1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                  +A20*(TME(J-1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TME(J-1)-TME(J))+TME(J+1)-TME(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (1)
C
              IF (J.EQ.1) THEN
                SXI=ASEX(J)
                A2=COND*SXI/DXL(J)
                SXA=MIN(ASEX(J),ASEX(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                    +A20*(TEG(1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TEG(1)-TME(J))+TME(J+1)-TME(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  IF (A0.GT.A2) THEN
                    A10=A1/A0
                    A20=A2/A0
                    RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                                        +A20*(TME(J-1)-TME(J)))/T0
                  ELSE
                    A02=A0/A2
                    A12=A1/A2
                  RNI(2*NCEL+J)=(A02*(TFE(J)-TME(J))+A12*(TMC(J)-TME(J))
     $                                              +TME(J-1)-TME(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=MIN(ASEX(J),ASEX(J+1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                  +A20*(TME(J-1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TME(J-1)-TME(J))+TME(J+1)-TME(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (2)
C
              IF (J.EQ.1) THEN
                SXA=MIN(ASEX(J),ASEX(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                                        +A30*(TME(J+1)-TME(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                                              +TME(J+1)-TME(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=ASEX(J)
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                    +A20*(TME(J-1)-TME(J))+A30*(TEG(2)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                          +A23*(TME(J-1)-TME(J))+TEG(2)-TME(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=MIN(ASEX(J),ASEX(J+1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                  +A20*(TME(J-1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TME(J-1)-TME(J))+TME(J+1)-TME(J))/T0
                  END IF
                END IF
              END IF
C
            CASE (3)
C
              IF (J.EQ.1) THEN
                SXI=ASEX(J)
                A2=COND*SXI/DXL(J)
                SXA=MIN(ASEX(J),ASEX(J+1))
                A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                IF (A0.GT.A3) THEN
                  A10=A1/A0
                  A20=A2/A0
                  A30=A3/A0
                  RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                    +A20*(TEG(1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                ELSE
                  A03=A0/A3
                  A13=A1/A3
                  A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TEG(1)-TME(J))+TME(J+1)-TME(J))/T0
                END IF
              ELSE
                IF (J.EQ.NCEL) THEN
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=ASEX(J)
                  A3=COND*SXA/DXL(J)
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                    +A20*(TME(J-1)-TME(J))+A30*(TEG(2)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                          +A23*(TME(J-1)-TME(J))+TEG(2)-TME(J))/T0
                  END IF
                ELSE
                  SXI=MIN(ASEX(J),ASEX(J-1))
                  A2=2.*COND*SXI/(DXL(J)+DXL(J-1))
                  SXA=MIN(ASEX(J),ASEX(J+1))
                  A3=2.*COND*SXA/(DXL(J)+DXL(J+1))
                  IF (A0.GT.A3) THEN
                    A10=A1/A0
                    A20=A2/A0
                    A30=A3/A0
                    RNI(2*NCEL+J)=(TFE(J)-TME(J)+A10*(TMC(J)-TME(J))
     $                  +A20*(TME(J-1)-TME(J))+A30*(TME(J+1)-TME(J)))/T0
                  ELSE
                    A03=A0/A3
                    A13=A1/A3
                    A23=A2/A3
                  RNI(2*NCEL+J)=(A03*(TFE(J)-TME(J))+A13*(TMC(J)-TME(J))
     $                        +A23*(TME(J-1)-TME(J))+TME(J+1)-TME(J))/T0
                  END IF
                END IF
              END IF
C
            CASE DEFAULT
C
          END SELECT
        ELSE
          RNI(2*NCEL+J)=1./(ROM*VMSEX(J)*CM)*
     $                (GFE(J)*SMEX(J)*(TFE(J)-TME(J))
     $                -COND*SMEXC(J)/(THICK(J)/3.)*(TME(J)-TMC(J))
     $                                         +QTCDEA(J)+QTCDEI(J))/T0
        END IF
      END DO
C
C
      DO J=1,NCEL
C
C-- Potenza termica scambiata fra parete e fluido interno
C
        RNI(3*NCEL+J)=(GFI(J)*SMIN(J)*(TMI(J)-TFI(J))-QI(J))/(W0*H0)
C
C
C-- Potenza termica scambiata fra parete e fluido esterno
C
        RNI(4*NCEL+J)=(GFE(J)*SMEX(J)*(TME(J)-TFE(J))-QE(J))/(W0*H0)
C
      END DO
C
      RETURN
      END
C
C
      SUBROUTINE MLMWD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      NCEL = DATI(IPD)
C
C
C-----Calcolo in stazionario
C
      NVARIABL=NSTATI+NUSCIT+NINGRE
      DO I = 1, 5*NCEL
        DO  J = 1,NVARIABL
          ITOPVA(I,J) = 1
        END DO
      END DO
C
      DO I=1,NCEL
C
C--residuo 1 --> NCEL Conservazione dell'energia nello strato centrale
C
      SIGNEQ(I) = ' ENERGY CONSERVATION INSIDE THE CENTRAL LAYER'
      UNITEQ(I) = 'K'
      COSNOR(I) = T0
C
C--residuo NCEL --> 2*NCEL Conservazione dell'energia nello strato interno
C
      SIGNEQ(NCEL+I) = ' ENERGY CONSERVATION INSIDE THE INNER LAYER'
      UNITEQ(NCEL+I) = 'K'
      COSNOR(NCEL+I) = T0
C
C--residuo 2*NCEL --> 3*NCEL Conservazione dell'energia nello strato esterno
C
      SIGNEQ(2*NCEL+I) = ' ENERGY CONSERVATION INSIDE THE OUTER LAYER'
      UNITEQ(2*NCEL+I) = 'K'
      COSNOR(2*NCEL+I) = T0
C
C--residuo 3*NCEL --> 4*NCEL Scambio termico fluido-strato interno
C
      SIGNEQ(3*NCEL+I) = ' HEAT TRANSFER FLUID - INNER LAYER'
      UNITEQ(3*NCEL+I) = 'W'
      COSNOR(3*NCEL+I) = W0*H0
C
C--residuo 4*NCEL --> 5*NCEL Scambio termico fluido-strato esterno
C
      SIGNEQ(4*NCEL+I) = ' HEAT TRANSFER FLUID - OUTER LAYER'
      UNITEQ(4*NCEL+I) = 'W'
      COSNOR(4*NCEL+I) = W0*H0
C
      END DO
C
C
C
      RETURN
      END
C
