C**********************************************************************
C modulo %M%
C tipo %Y%
C release %I%
C data %G%
C Puertollano project libut reserver %W%
C**********************************************************************
C**********************************************************************
C modulo tren.f
C tipo 
C release 5.2
C data 4/12/95
C reserver @(#)tren.f	5.2
C**********************************************************************
C*                                                                   *
C*                           modulo TREN                             *
C*                                                                   *
C*                   Stadio di turbina a reazione                    *
C*                                                                   *
C*********************************************************************
      SUBROUTINE TRENI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/TREN01/IBLOC
      COMMON/TREN02/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'TREN'/
C
      CALL TRENI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      NSTATI    =  0
      NUSCIT    =  4
      NINGRE    =  7
C
      WRITE(IFO,3001)IOB
 3001 FORMAT('HUTZ',A4,2X,
     $'--UA-- FLUID ENTHALPY AT THE REACTION STAGE OUTLET')
      WRITE(IFO,3002)IOB
 3002 FORMAT('WUTZ',A4,2X,
     $'--UA-- STEAM FLOW RATE AT THE REACTION STAGE OUTLET')
      WRITE(IFO,3003)IOB
 3003 FORMAT('PITZ',A4,2X,
     $'--UA-- STEAM PRESSURE AT THE REACTION STAGE INLET')
      WRITE(IFO,3005)IOB
 3005 FORMAT('QMEC',A4,2X,
     $'--UA-- MECHANICAL POWER OF THE REACTION TURBINE STAGE')
      WRITE(IFO,3008)IOB
 3008 FORMAT('WITZ',A4,2X,
     $'--IN-- STEAM FLOW RATE AT THE REACTION STAGE INLET')
      WRITE(IFO,3009)IOB
 3009 FORMAT('WSPZ',A4,2X,
     $'--IN-- FLOW RATE OF STEAM BLED FROM THE REACTION TURB. STAGE')
      WRITE(IFO,3010)IOB
 3010 FORMAT('HITZ',A4,2X,
     $'--IN-- STEAM ENTHALPY AT THE REACTION STAGE INLET')
      WRITE(IFO,3011)IOB
 3011 FORMAT('PUTZ',A4,2X,
     $'--IN-- STEAM PRESSURE AT THE REACTION STAGE OUTLET')
      WRITE(IFO,3012)IOB
 3012 FORMAT('SERC',A4,2X,
     $'--IN-- LOAD REJECTION OR TRIP SIGNAL')
      WRITE(IFO,3013)IOB
 3013 FORMAT('SEAV',A4,2X,
     $'--IN-- STARTING BUTTON OF THE REACTION TURBINE')
      WRITE(IFO,3014)IOB
 3014 FORMAT('RPMV',A4,2X,
     $'--IN-- ROTATIONAL SPEED OF THE REACTION TURBINE')
      RETURN
      END
C
C*********************************************************************
      SUBROUTINE TRENI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/TREN01/IBLOC
      COMMON/TREN02/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C*********************************************************************
      SUBROUTINE TRENI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBLOC1,IBLOC2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      INTEGER VAR
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C      REAL PIN0,HIN0,WIN0,PUS0,HUS0,VEL0,SIN0,HUIS0,ROI0
C      REAL ETAD0,CK0
      CHARACTER*8 PXIN0,HXIN0,WXIN0,PXUS0,HXUS0,VELX0
      DATA PXIN0/'PRES__IN'/, HXIN0/'ENTA__IN'/, WXIN0/'PORT__IN'/,
     $     PXUS0/'PRES_OUT'/, HXUS0/'ENTA_OUT'/, VELX0/'RPMV_NOM'/
C
C------STADIO TURBINA A REAZIONE
C
      GO TO (1,10),IFUN
C
C------SCRITTURA FILE 14
C
    1 WRITE (14,100) PXIN0, HXIN0, WXIN0
      WRITE (14,100) PXUS0, HXUS0, VELX0
  100 FORMAT(3(4X,A8,' =',10X,'*'),5X)
      RETURN
C
C------LETTURA FILE 14
C
   10 READ(14,102)
      READ(14,102) PIN0, HIN0, WIN0
      READ(14,102) PUS0, HUS0, VEL0
  102 FORMAT(3(14X,F10.0,1X),5X)
C
C---- CALCOLO NEL PUNTO DI LAVORO (ASSEGNATO ATTRAVERSO
C---- I DATI PIN0, HIN0, WIN0, PUS0, HUS0) DI:
C----       RENDIMENTO               ETAD0
C----       COEFFICIENTE D'EFFLUSSO  CK0
C----       SALTO ENTALPICO (NORM.)  DH0
C
      SIN0=SHEV(PIN0,HIN0,1)
      HUIS0=HEV(PUS0,SIN0,1)
      ROI0=ROEV(PIN0,SIN0,1)
C
      ETAD0=(HIN0-HUS0)/(HIN0-HUIS0)
      CK0=(W0*W0/P0)*(PIN0*PIN0-PUS0*PUS0)*ROI0
     $    /(PIN0*WIN0*WIN0)
      DH0=(HIN0-HUS0)/H0
C
C---- STAMPA
C
      WRITE (6,3000) ETAD0
 3000 FORMAT(//'   NOMINAL THERMODYNAMIC EFFICIENCY = ',F7.4)
C
C------MEMORIZZAZIONE DATI
C
      DATI(ID2  )=ETAD0
      DATI(ID2+1)=CK0
      DATI(ID2+2)=DH0
      DATI(ID2+3)=VEL0
C
C---- RISERVO 3 POSTI PER GLI STATI
C
      DATI(ID2+4)=0.
      DATI(ID2+5)=0.
      DATI(ID2+6)=0.
C___ PORTATA NOMINALE
      DATI(ID2+7)=WIN0
      ID2=ID2+7
CCC
CCC------TOLLERANZE
CCC
C !  3) pressione ingresso stadio
CC      PI=XYU(IV1+2)
CC      PPI=PI/100.
CC      IF(PPI.LT.1000.)PPI=1000.
CCC
CC      TOL(3)=PPI*PPI/(P0*P0)
C
C------VETTORE NORMALIZZAZIONI
C
      CNXYU(IV1)=H0
      CNXYU(IV1+1)=W0
      CNXYU(IV1+2)=P0
      CNXYU(IV1+3)=W0*H0
      CNXYU(IV1+4)=W0
      CNXYU(IV1+5)=W0
      CNXYU(IV1+6)=H0
      CNXYU(IV1+7)=P0
      CNXYU(IV1+8)=1.
      CNXYU(IV1+9)=1.
      CNXYU(IV1+10)=300.
C
      RETURN
      END
C
C*********************************************************************
      SUBROUTINE TRENC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $                  IBLOC1,IBLOC2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*100 SccsID
       DATA SccsID/'%W%\t %I%\t %G% Puerpro libut'/          
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/SOLV00/JACSI
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT                          !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      LOGICAL KREGIM,IZ,IAV,JFLOLOG
C
C------STADIO TURBINA A REAZIONE
C
      GO TO (1,10,10),IFUN
C
C------TOPOLOGIA JACOBIANO
C
    1 CONTINUE
      DO 5 I=1,4
      AJAC(I,I) = 1.
    5 CONTINUE
C
      AJAC(1,3 ) = 1.
      AJAC(1,7 ) = 1.
      AJAC(1,8 ) = 1.
      AJAC(1,11) = 1.
      AJAC(2,5 ) = 1.
      AJAC(2,6 ) = 1.
      AJAC(3,5 ) = 1.
      AJAC(3,8 ) = 1.
      AJAC(4,1 ) = 1.
      AJAC(4,5 ) = 1.
      AJAC(4,7 ) = 1.
      AJAC(4,11) = 1.
C
      RETURN
C
C
C------DECODIFICA DATI
C
   10 ETAD0  = DATI(IPD  )
      CK0    = DATI(IPD+1)
      DH0    = DATI(IPD+2)
      VEL0   = DATI(IPD+3)
C
      ROI    = DATI(IPD+4)
      ROISUPI= DATI(IPD+5)
      ETAAD  = DATI(IPD+6)
C____ PORTATA NOMINALE
      WIN0   = DATI(IPD+7)
C
C------DECODIFICA VARIABILI
C
C !  1) entalpia  uscita   stadio
      HS=XYU(IXYU)
C !  2) portata      "       "
      QU=XYU(IXYU+1)
C !  3) pressione ingresso stadio
      PI=XYU(IXYU+2)
C !  4) potenza meccanica fornita dallo stadio
      POTM=XYU(IXYU+3)
      QI=XYU(IXYU+4)
      QSP=XYU(IXYU+5)
      HI=XYU(IXYU+6)
      PU=XYU(IXYU+7)
      IZ=JFLOLOG(XYU(IXYU+8))
      IAV=JFLOLOG(XYU(IXYU+9))
      VEL=XYU(IXYU+10)
C
      IF(KREGIM)GO TO 102
      IF(ITERT.NE.0)GO TO 101
C
 102  NFL=1
      PID=PI*P0
      HID=HI*H0
      IF(PID.LT.1000.)PID=1000.
      IF(PID.GT.400.E5)PID=400.E5
      IF(HID.GT.4180.E3) HID=4180.E3
      SIN=SHEV(PID,HID,NFL)
      ROI=ROEV(PID,SIN,NFL)
      DATI(IPD+4)=ROI
      ROISUPI=ROI/PI
      DATI(IPD+5)=ROISUPI
C
 101  CONTINUE
C
C---- CALCOLO DEL RENDIMENTO FUNZIONE DELLA VELOCITA`
C
      IF(KREGIM.OR.ITERT.LE.0) THEN
	  X=VEL*300./VEL0
C____ CALCOLO RENDIMENTO PER PORTATA DI VAPORE MOLTO PICCOLA RISPETTO
C     ALLA PORTATA NOMINALE ( CURVA SPERIMENTALE)
      CKK =4.969*(QI*W0/WIN0)+.18
      IF(CKK.GT.1.)CKK=1.
      ETAAD=CKK*ETAD0*(2*X-X*X)
	IF (ETAAD .LT. 0.001) ETAAD=0.001
	  DATI(IPD+6)=ETAAD
      ENDIF
      ETAAD=DATI(IPD+6)
C
      IF(.NOT.IZ) GO TO 12
C
C
C------CALCOLO RESIDUI IN RIFIUTO DI CARICO O SCATTO
C
C
C     PUD=1.E5
      PUD=PU*P0
      CALL SATUR(PUD,2,HLS,HVS,1)
C
      RNI(1)=HS-HVS/H0
C
C ! protezione per portate negative
      IF (QI .LT. 0.) QI=0.
C
      RNI(2)=QU+QSP-QI
      RNI(3)=PI-PU-CK0*QI*ABS(QI)/(ROI*(1.+PU/PI))
      RNI(4)=POTM-QI*DH0*ETAAD
      IF(IFUN.EQ.3) GO TO 90
      RETURN
C
 12   IF (.NOT.IAV) GO TO 22
C
C------CALCOLO RESIDUI IN FASE DI AVVIAMENTO
C
      RNI(1)=-HS+HI-ETAAD*DH0
      RNI(2)=QU+QSP-QI
      RNI(3)=PI-PU-CK0*QI*ABS(QI)/(ROI*(1.+PU/PI))
      RNI(4)=POTM-QI*(HI-HS)
      IF(IFUN.EQ.3) GO TO 80
      RETURN
C
C
C------CALCOLO RESIDUI IN CONDIZIONI NORMALI DI FUNZIONAMENTO
C
   22 CONTINUE
      NFL=1
      PUD=PU*P0
      PID=PI*P0
      HID=HI*H0
C
C******* PROTEZIONE PER PRESSIONI NEGATIVE
C
      IF(PID.LT.1000.)PID=1000.
      IF(PUD.LT.1000.)PUD=1000.
C
      SIN=SHEV(PID,HID,NFL)
C
      HUIS=HEV(PUD,SIN,NFL)/H0
      RNI(1)=-HS+HI-ETAAD*(HI-HUIS)
      RNI(2)=QU+QSP-QI
      RNI(3)=PI*PI-PU*PU-CK0*QI*ABS(QI)/ROISUPI
      RNI(4)=POTM-QI*(HI-HS)
C
C
C------CORREZIONE PER LO JACOBIANO
C
      QI=QI+1./W0
      QU=QU+1./W0
      IF(IFUN.EQ.2)RETURN
C
C
C----- CALCOLO DELLO JACOBIANO ANALITICO
C----- IN CONDIZIONI NORMALI DI FUNZIONAMENTO
C
C
      ROISO=ROEV(PUD,SIN,NFL)
      TISO=TEV(PUD,SIN,NFL)
      TI=TEV(PID,SIN,NFL)
C
      DHISHI=TISO/TI
      DHISPI=-DHISHI/ROI
      DHISPU=1./ROISO
C
      AJAC(1,1)=1.
      AJAC(1,3)=-ETAAD*DHISPI*P0/H0
      AJAC(1,7)=-1.+ETAAD*(1.-DHISHI)
      AJAC(1,8)=-ETAAD*DHISPU*P0/H0
      AJAC(1,11)=0.
CCC      AJAC(1,11)=-(HI-HUIS)*ETAD0*300.*
CCC     &           (2./VEL0-2.*VEL*300./(VEL0*VEL0))
C
      AJAC(2,2)=-1.
      AJAC(2,5)=1.
      AJAC(2,6)=-1.
C
      AJAC(3,3)=-2.*PI
      AJAC(3,5)=2.*CK0*ABS(QI)/ROISUPI
      AJAC(3,8)=2.*PU
C
      AJAC(4,1)=-QI
      AJAC(4,4)=-1.
      AJAC(4,5)=HI-HS
      AJAC(4,7)=QI
      AJAC(4,11)=0.
      RETURN
C
C---- CALCOLO DELLO JACOBIANO ANALITICO
C---- IN FASE DI AVVIAMENTO
C
C
   80 AJAC(1,1)=1.
      AJAC(1,3)=0.
      AJAC(1,7)=-1.
      AJAC(1,8)=0.
      AJAC(1,11)=0.
C
      AJAC(2,2)=-1.
      AJAC(2,5)=1.
      AJAC(2,6)=-1.
C
      AJAC(3,3)=-1.
      AJAC(3,5)=2.*CK0*ABS(QI)/(ROI*(1.+PU/PI))
      AJAC(3,8)=1.
C
C
      AJAC(4,1)=-QI
      AJAC(4,4)=-1.
      AJAC(4,5)=HI-HS
      AJAC(4,7)=QI
      AJAC(4,11)=0.
C
      RETURN
C
C---- CALCOLO DELLO JACOBIANO ANALITICO
C---- IN RIFIUTO DI CARICO O SCATTO
C
  90  AJAC(1,1)=-1.
      AJAC(1,3)=0.
      AJAC(1,7)=0.
      AJAC(1,8)=0.
      AJAC(1,11)=0.
C
      AJAC(2,2)=-1.
      AJAC(2,5)=1.
      AJAC(2,6)=-1.
C
      AJAC(3,3)=-1.
      AJAC(3,5)=2.*CK0*ABS(QI)/(ROI*(1.+PU/PI))
      AJAC(3,8)=1.
C
      AJAC(4,1)=0.
      AJAC(4,4)=-1.
      AJAC(4,5)=DH0
      AJAC(4,7)=0.
      AJAC(4,11)=0.
      RETURN
      END
CC
      SUBROUTINE TREND1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $   XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
