C***********************************************************************
C*                                                                     *
C*                   CESI RICERCA    October 2007                      *
C*                                                                     *
C*                      Heavy Metal Tee rel.0                          *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE TEE0I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/TEE001/IBLOC
      COMMON/TEE002/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'TEE0'/
C
      CALL TEE0I4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 2
      NUSCIT= 8
      NINGRE= 8
C
      WRITE(IFO,3000)IOB
 3000 FORMAT('HMEN',A4,2X,'--US-- Heavy Metal ENthalpy') 
C
      WRITE(IFO,3101)IOB
 3101 FORMAT('PSTP',A4,2X,'--US-- Pressure at end of STraight Passage')
C
      WRITE(IFO,3002)IOB
 3002 FORMAT('HINV',A4,2X,'--UA-- reverse flow ENthalpy at wyes inlet') 
C
      WRITE(IFO,3108)IOB
 3108 FORMAT('WWIN',A4,2X,'--UA-- Wyes inlet mass flow rate')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('HSTP',A4,2X,'--UA-- Enthalpy at end of STraight Passage')
C
      WRITE(IFO,3103)IOB
 3103 FORMAT('PSBR',A4,2X,'--UA-- Pressure at end of the Side BRanch')
C
      WRITE(IFO,3104)IOB
 3104 FORMAT('HSBR',A4,2X,'--UA-- Enthalpy at end of the Side BRanch')
C
      WRITE(IFO,3105)IOB
 3105 FORMAT('THMT',A4,2X,'--UA-- Heavy Metal Temperature')
C
      WRITE(IFO,3106)IOB
 3106 FORMAT('GHTC',A4,2X,'--UA-- Fluid Heat Transfer Coefficient') 
C
      WRITE(IFO,3107)IOB
 3107 FORMAT('QTPW',A4,2X,'--UA-- Thermal power')
C
      WRITE(IFO,3001)IOB
 3001 FORMAT('PTEE',A4,2X,'--IN-- Pressure at wyes inlet')
C
      WRITE(IFO,3109)IOB
 3109 FORMAT('HWIE',A4,2X,'--IN-- Wyes Inlet Enthalpy')
C
      WRITE(IFO,3110)IOB
 3110 FORMAT('WSTP',A4,2X,'--IN-- STraight Passage mass flow rate' )
C
      WRITE(IFO,3111)IOB
 3111 FORMAT('HSTI',A4,2X,'--IN-- reverse flow ENthalpy at end ',
     $                          ' of the STraight Passage')
C
      WRITE(IFO,3112)IOB
 3112 FORMAT('WSBR',A4,2X,'--IN-- Side BRanch mass flow rate' )
C
      WRITE(IFO,3113)IOB
 3113 FORMAT('HSBI',A4,2X,'--IN-- reverse flow ENthalpy at end ',
     $                          ' of the Side BRanch')
C
      WRITE(IFO,4003)IOB
 4003 FORMAT('TWAL',A4,2X,'--IN-- Wyes WALL temperature ') 
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('FCAD',A4,2X,'--IN-- Friction Coefficient ADjuster')
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0I4(IOB,MOD)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
      COMMON/TEE001/IBLOC
      COMMON/TEE002/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      WRITE(6,1000)
 1000 FORMAT(//10X,'Heavy Metal Tee '//)
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      INTEGER VAR
      INTEGER FluidIndex,WyeIndex,FI
      LOGICAL JPB,JPB1,JLEAD,JLBE,JLBE1,JNA,JNA1,JSODIUM
      CHARACTER*8 SP,ALF,STPDZ,SDBDZ                           
      CHARACTER*8 RTN,RTD,RTL,RTP,RTDZ,HLC,FluidT,ROUGH                                
      CHARACTER*10 FluidType                               
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA FluidT/'Fluid '/
      DATA RTN/'ChanDia'/,RTD/'StPasDia'/,RTL/'StPasLen'/                 
      DATA STPDZ/'StPasDz'/             
      DATA RTP/'SidBrDia'/ ,RTDZ/'SidBrLen'/,SDBDZ/'SidBrDz'/                 
      DATA HLC/'HLossS'/ ,ROUGH/'Roughnes'/              
      DATA SP/'HTraSurf'/,ALF/'Alfa'/
C                                                                       
C-----------------------------------------------------                                                    
C                                                                       
      NN0=IV1-1                                                         
      NEQ=NSTATI+NUSCIT                                          
C                                                                       
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C                                                                       
   1  CONTINUE 
C                                                         
      WRITE(14,3800)
 3800 FORMAT ('*   Heavy Metal Selection : Lead, LBE, Sodium')
C                                                         
      WRITE(14,'(4X,A6,A4,10X,A1)')FluidT,'   =','*'
      WRITE(14,3900)
 3900 FORMAT ('*   -')
C                                                         
      WRITE(14,4000)
 4000 FORMAT ('*   Wyes Model Selection :')
C                                                         
      WRITE(14,4001)                                                 
 4001 FORMAT ('*   0 --> Diverging wyes - Tee' )
C                                                         
      WRITE(14,4002)
 4002 FORMAT ('*   1 --> .....')                                                  
C                                                         
      WRITE(14,4003)
 4003 FORMAT (4X,'WyesMdSl =',10X,'*')
C                                                         
      WRITE(14,4004)
 4004 FORMAT ('*   -')
C                                                         
      WRITE(14,4005)
 4005 FORMAT ('*   Heavy metal wyes data')
C                                                         
      WRITE(14,4006)
 4006 FORMAT ('*       ChanDia - [m] Diameter of the entrance ')
C                                                         
      WRITE(14,4007)
 4007 FORMAT ('*       StPasDia - [m] Straight Passage Diameter')
C                                                         
      WRITE(14,4008)
 4008 FORMAT ('*       StPasLen - [m] Straight Passage Lenght')
C                                                         
      WRITE(14,4018)
 4018 FORMAT ('*       StPasDz  - [m] Straight Passage Elevation')
C                                                         
      WRITE(14,1013) RTN,RTD,RTL,STPDZ
C                                                         
      WRITE(14,4009)
 4009 FORMAT ('*       SidBrDia - [m] Side Branch Diameter')
C                                                         
      WRITE(14,4010)
 4010 FORMAT ('*       SidBrLen - [m] Side Branch Lenght')
C                                                         
      WRITE(14,4011)
 4011 FORMAT ('*       Alfa     - [�] Side Branch angle (def. 90�)')
C                                                         
      WRITE(14,4021)
 4021 FORMAT ('*       SidBrDz  - [m] Side Branch Elevation')
C                                                         
      WRITE(14,1013) RTP,RTDZ,ALF,SDBDZ
C                                                         
      WRITE(14,4012)
 4012 FORMAT ('*       Roughnes - [m] wyes roughness ')
C                                                         
      WRITE(14,4013)
 4013 FORMAT ('*       HTraSurf - [m2] Heat Transfer Surface')
      WRITE(14,1013) ROUGH,SP    
C                                                                       
 1013 FORMAT(3(4X,A8,' =',10X,'*'),5X)
C                                                                       
C                                                                       
      RETURN                                                            
C                                                                      
C-----LETTURA DEI DATI                                                  
C 
   10 CONTINUE                                                                      
C      WRITE(6,*) ' sto leggendo F14 -0'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 -1'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 2 FluidType'                                                    
      READ(14,'(14X,A10)') FluidType                                                     
C      WRITE(6,*) ' sto leggendo F14 - 3' , FluidType                                                  
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 4' , FluidType                                                  
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 5'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 6 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 7 -'                                                    
      READ(14,1004)WyeIndex                                                  
C                                                                       
C      WRITE(6,*) ' sto leggendo celle F14   WyeIndex', WyeIndex                                                   
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle in do F14'                                                    
      READ(14,1004)
C      WRITE(6,*) ' sto leggendo celle 2 F14'                                                    
      READ(14,1004)                                                     
      READ(14,1004)                                                     
      READ(14,1004) ChanDia,StPasDia,StPasLen,StPasDz           
      READ(14,1004)
C      WRITE(6,*) ' sto leggendo celle 3 F14'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 5 F14'                                                    
      READ(14,1004)                                                     
      READ(14,1004) SidBrDia,SidBrLen,Alfa,SidBrDz                                                   
C      WRITE(6,*) ' sto leggendo celle 6 F14'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 7 F14'                                                    
      READ(14,1004)                                       
C      WRITE(6,*) ' ET(I),WD(I)',ET(I),WD(I)                                                   
      READ(14,1004) Roughness,HTraSurf                                                    
C      WRITE(6,*) ' sto leggendo celle 9 F14'                                                    
C
C---- Fluid index assignement
C
C
C
C--- SELECT CASE on CHARACTER type not supported by GNU FORTRAN ----
C
C      Select Case  (FluidType)
C        Case ("PB","Pb","pB","pb")
C          FluidIndex=1
C          write(6,'(26x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(26x,1A,I5)')'Type  : ',FluidIndex                                             
C        Case ('Lead','lead')
C          FluidIndex=1
C          write(6,'(26x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(26x,1A,I5)')'Type  : ',FluidIndex                                             
C        Case ('LBE','Lbe','lbe')
C          FluidIndex=2
C          write(6,'(26x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(26x,1A,I5)')'Type  : ',FluidIndex                                             
C        Case ('Sodium','sodium','NA','Na','nA','na')
C          FluidIndex=3.
C          write(6,'(26x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(26x,1A,I5)')'Type  : ',FluidIndex                                             
C        Case Default
C          FluidIndex=1
C          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
C          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
C          write(6,*)'WARNING!!! default case - Fluid Index   ='
C     $              ,FluidIndex                                             
C      End Select
C
       JPB=(FluidType.EQ.'PB'.OR.FluidType.EQ.'Pb')
       JPB1=(FluidType.EQ.'pB'.OR.FluidType.EQ.'pb')
       JLEAD=(FluidType.EQ.'Lead'.OR.FluidType.EQ.'lead')
       JLBE=(FluidType.EQ.'LBE'.OR.FluidType.EQ.'Lbe')
       JLBE1=(FluidType.EQ.'lbe')
       JSODIUM=(FluidType.EQ.'Sodium'.OR.FluidType.EQ.'sodium')
       JNA=(FluidType.EQ.'NA'.OR.FluidType.EQ.'Na')
       JNA1=(FluidType.EQ.'nA'.OR.FluidType.EQ.'na')
C
       IF (JPB.OR.JPB1.OR.JLEAD) THEN
          FluidIndex=1
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JLBE.OR.JLBE1) THEN
          FluidIndex=2
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JNA.OR.JNA1.OR.JSODIUM) THEN
          FluidIndex=3.
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE
          FluidIndex=1
          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
          write(6,*)'WARNING!!! default case - Fluid Index   ='
     $              ,FluidIndex                                             
       END IF                                             
CC                                           
C
C--- ---------------------------------------------------------------- ----
C
C
C------ General data calculation
C
C
      Select Case  (WyeIndex)
C
        Case (0)
C
          write(6,'(21x,1A)')'Wyes model : Cilindrical Tee'                                          
          write(6,'(11x,1A,I5)')'Wyes Model Selection : ',WyeIndex                                             
C
C
C------ Equivalent HYdraulic Diameter of the wye inlet, Heat Transfer Surface
C
            FLOWSEC=PIGR/4.*ChanDia**2.
            PB=PIGR*ChanDia
            EHYD=4.*FLOWSEC/PB
            HTSWY=PIGR*ChanDia*StPasLen/2.
C
C
C------ Equivalent HYdraulic Diameter of the Straight Passage
C
            StFLOWSEC=PIGR/4.*StPasDia**2.
            StPB=PIGR*StPasDia
            StEHYD=4.*StFLOWSEC/StPB
            HTSSP=PIGR*StPasDia*StPasLen/2.
C
C
C------ Equivalent HYdraulic Diameter of the Side Branch
C
            SbFLOWSEC=PIGR/4.*SidBrDia**2.
            SbPB=PIGR*SidBrDia
            SbEHYD=4.*SbFLOWSEC/SbPB
            HTSSB=PIGR*SidBrDia*SidBrLen
C
C------ Control volume and Heat Transfer Surface
C
            VOLC=FLOWSEC*StPasLen/2.+StFLOWSEC*StPasLen/2.
            VOLSP=StFLOWSEC*StPasLen/2.
            VOLSB=SbFLOWSEC*SidBrLen
            VOLTEE=VOLC+VOLSP+VOLSB
            IF (HTraSurf.EQ.0.) THEN
              HTraSurf=HTSWY+HTSSP+HTSSB
            END IF
C
C
        Case (1)
          write(6,'(18x,1A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C
C------ Equivalent HYdraulic Diameter
C
        Case (2)
          write(6,'(18x,1A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C
C------ Equivalent HYdraulic Diameter
C
        Case Default
C
C------ Equivalent HYdraulic Diameter of the wye inlet
C
            FLOWSEC=PIGR/4.*ChanDia**2.
            PB=PIGR*ChanDia
            EHYD=4.*FLOWSEC/PB
            HTSWY=PIGR*ChanDia*StPasLen/2.
C
C
C------ Equivalent HYdraulic Diameter of the Straight Passage
C
            StFLOWSEC=PIGR/4.*StPasDia**2.
            StPB=PIGR*StPasDia
            StEHYD=4.*StFLOWSEC/StPB
            HTSSP=PIGR*StPasDia*StPasLen/2.
C
C
C------ Equivalent HYdraulic Diameter of the Side Branch
C
            SbFLOWSEC=PIGR/4.*SidBrDia**2.
            SbPB=PIGR*SidBrDia
            SbEHYD=4.*SbFLOWSEC/SbPB
            HTSSB=PIGR*SidBrDia*SidBrLen
C
C------ Control volume
C
            VOLC=FLOWSEC*StPasLen/2.+StFLOWSEC*StPasLen/2.
            VOLSP=StFLOWSEC*StPasLen/2.
            VOLSB=SbFLOWSEC*SidBrLen
            VOLTEE=VOLC+VOLSP+VOLSB
            IF (HTraSurf.EQ.0.) THEN
              HTraSurf=HTSWY+HTSSP+HTSSB
            END IF
C
          write(6,*)'WARNING!!! Wye model is not assigned'                                        
          write(6,*)'WARNING!!! default case - Wye model ='
     $             ,' Cilindrical Tee'                                          
          write(6,*)'WARNING!!! default case -'
     $             ,' Wye Model Selection =',WyeIndex                                             
C
      End Select
C
C                                                                       
C
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C                                                                       
      DATI(ID2)=FluidIndex                                                    
      DATI(ID2+1)=WyeIndex                                                  
      DATI(ID2+2)=ChanDia                                                  
      DATI(ID2+3)=StPasDia                                                  
      DATI(ID2+4)=StPasLen                                                  
      DATI(ID2+5)=SidBrDia                                                
      DATI(ID2+6)=SidBrLen                                                
      DATI(ID2+7)=Alfa                                                  
      DATI(ID2+8)=Roughness
      DATI(ID2+9)=HTraSurf
      DATI(ID2+10)=StPasDz
      DATI(ID2+11)=SidBrDz
C                                                                       
      ID2 = ID2+12                                           
C      WRITE(6,*) ' sto caricando normalizzazioni'                                                    
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
      CNXYU(NN0+1)=H0                                                   
      CNXYU(NN0+2)=P0                                                   
      CNXYU(NN0+3)=H0                                                   
      CNXYU(NN0+4)=W0                                                   
C      CNXYU(NN0+4)=P0                                                   
      CNXYU(NN0+5)=H0                                                   
      CNXYU(NN0+6)=P0                                                   
      CNXYU(NN0+7)=H0
      CNXYU(NN0+8)=T0
      CNXYU(NN0+9)=GAM0
      CNXYU(NN0+10)=W0*H0
      CNXYU(NN0+11)=P0
C      CNXYU(NN0+11)=W0
      CNXYU(NN0+12)=H0                                                   
      CNXYU(NN0+13)=W0
      CNXYU(NN0+14)=H0                                                   
      CNXYU(NN0+15)=W0
      CNXYU(NN0+16)=H0                                                   
      CNXYU(NN0+17)=T0
      CNXYU(NN0+18)=1.                                                   
C                                                                       
C                                                                       
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.                           
C                                                                       
C*******************************                                        
        TOL(2)=.01E5/P0                                              
        TOL(4)=.01E5/P0                                              
        TOL(6)=.01E5/P0                                              
        TOL(11)=.1/W0                                               
        TOL(13)=.1/W0                                               
        TOL(15)=.1/W0                                               
C*******************************                                        
C                                                                       
C-----STAMPE                                                            
C                                                                       
C                                                                       
      FI=DATI(ID1)
      WIndex=DATI(ID1+1)
      CD=DATI(ID1+2)
      StD=DATI(ID1+3)
      StL=DATI(ID1+4)
      SBD=DATI(ID1+5)
      SBL=DATI(ID1+6)
      AF=DATI(ID1+7)
      RG=DATI(ID1+8)
      HTS=DATI(ID1+9)
      WRITE(6,*)                           
      WRITE(6,'(20x,1A,I5)')'Fluid Index :',FI                                
      WRITE(6,'(20x,1A,I5)')'Wyes Index  :',WIndex                                      
      WRITE(6,'(13x,1A,F12.6)')'Wye Inlet Diameter :',CD                                    
      WRITE(6,'(6x,1A,F12.6)')'Straight Passage Diameter :',StD                                       
      WRITE(6,'(8x,1A,F12.6)')'Straight Passage Lenght :',StL                                       
      WRITE(6,'(/,10X,A,2X,A,3X,A,F10.5,A,3X,A,F10.5,A)')IBLOC1,IBLOC2
     $                     ,'Str. Pass. elev. ',StPasDz,' [m]'
     $                     ,'Str. Pass. Len',StL,' [m]'                                                     
      WRITE(6,'(10x,1A,F12.6)')'Side Branche Diameter :',SBD                                     
      WRITE(6,'(12x,1A,F12.6)')'Side Branche Lenght :',SBL                                     
      WRITE(6,'(/,10X,A,2X,A,3X,A,F10.5,A)')IBLOC1,IBLOC2
     $                     ,'Side Bran. elev. ',SidBrDz,' [m]'                                                     
      WRITE(6,'(10x,1A,F12.6)')'Heat Transfer Surface :',HTS                                     
      WRITE(6,*)                           
      WRITE(6,*)                           
C                                                                       
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)                                     
 3010 FORMAT(6X,3E11.4/)                                                
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C
C
      LOGICAL KREGIM                                                    
C
C-----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*80 SccsID
C
C---     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
C
      COMMON/REGIME/KREGIM                                              
C
      COMMON/TEE0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      EXTERNAL TEE0
C
C----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'%W%\t %I%\t %G%'/          
C
C----     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      IBLOC1X=IBLOC1
      IBLOC2X=IBLOC2
C
      NSTATI= 2
      NUSCIT= 8
      NINGRE= 8
      NEQ=NSTATI+NUSCIT                                               
      NVAR=NEQ+NINGRE                                             
C                                                                       
      ISTA=TEE0ISTA05(IFUN)                                                 
C                                                                       
      GO TO (10,20,30),IFUN                                             
C
C---topologia jacobiano
C
   10 CONTINUE
C
      DO I=1,NEQ                                                     
        DO J=1,NVAR                                                    
          AJAC(I,J)=1.                                                      
        END DO
      END DO
C                                                          
      RETURN                                                            
C                                                                       
C
C---calcolo residui
C
   20 CONTINUE
C
      CALL TEE0 (IFUN,IXYU,XYU,IPD,DATI,RNI)                                   
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
 1001 FORMAT(///1X,9(1H*),' Component',2X,1A4,' - ',1A4,' ',100(1H*))                     
      IF(ISTA.NE.0) CALL TEE0STAS05(ISTA)                                   
C                                                                       
      RETURN                                                            
C  
   30 CONTINUE
C
C---calcolo jacobiano
C
C      jacobiano numerico
C
C
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      CALL TEE0JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,TEE0)
                  
C                                                                       
      RETURN                                                            
C                                                                       
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                  NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/TEE0NQ/NEQ
C
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      DO J=1,NCOL
        IF (J.EQ.2..OR.J.EQ.6.OR.J.EQ.11) THEN
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
          VAR=VARP
C
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C       DO I=1,NRIG
C          write(6,*)'equazione ',I
C         DO J=1,NCOL
C          write(6,*)'var ',j,'J ',AJAC(I,J)
C      END DO
C      END DO
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0 (IFUN,IXYU,XYU,IPD,DATI,RNI)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      LOGICAL KREGIM                                                    
C
      INTEGER WyeIndex,FluidIndex
C
      REAL MU,MUI,MUSTP,MUSB
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
C
      COMMON/TEE0PRESSDROP/FLOWSEC,WWIN,StFLOWSEC,WSTP,SbFLOWSEC,WSBR,RO
      COMMON/TEE0LACANES/ FRICFst,StPasLen,StEHYD,CSIst,FRICFsb,SidBrLen
     $                   ,SbEHYD,CSIs
C                                                                       
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
C                                                                       
C                                                                       
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA GA/9.81/                                              
C                                                                       
      NSTATI= 2
      NUSCIT= 8
      NINGRE= 8
      NEQ=NSTATI+NUSCIT                                               
C                                                                       
C--------- Data ------                                                         
C                                                                       
      FluidIndex=DATI(IPD)
      WyeIndex=DATI(IPD+1)
      ChanDia=DATI(IPD+2)
      StPasDia=DATI(IPD+3)
      StPasLen=DATI(IPD+4)
      SidBrDia=DATI(IPD+5)
      SidBrLen=DATI(IPD+6)
      Alfa=DATI(IPD+7)
      Roughness=DATI(IPD+8)
      HTraSurf=DATI(IPD+9)
      StPasDz=DATI(IPD+10)
      SidBrDz=DATI(IPD+11)
C                                                                       
C
C----   Output variables
C
      NN0=IXYU-1                                                         
C
      HMEN=XYU(NN0+1)*H0                                                   
      PSTP=XYU(NN0+2)*P0                                                   
C      PTEE=XYU(NN0+2)*P0                                                   
      HINV=XYU(NN0+3)*H0                                                   
      WWIN=XYU(NN0+4)*W0                                                   
C      PSTP=XYU(NN0+4)*P0                                                   
      HSTP=XYU(NN0+5)*H0                                                   
      PSBR=XYU(NN0+6)*P0                                                   
      HSBR=XYU(NN0+7)*H0
      THMT=XYU(NN0+8)*T0
      GHTC=XYU(NN0+9)*GAM0
      QTPW=XYU(NN0+10)*W0*H0
C
C----   Input variables
C
      PTEE=XYU(NN0+11)*P0
C      WWIN=XYU(NN0+11)*W0
      HWIE=XYU(NN0+12)*H0                                                   
      WSTP=XYU(NN0+13)*W0
      HSTI=XYU(NN0+14)*H0                                                   
      WSBR=XYU(NN0+15)*W0
      HSBI=XYU(NN0+16)*H0                                                   
      TWAL=XYU(NN0+17)*T0
      FCAD=XYU(NN0+18)*1.                                                   
C
C
C
C------ Equivalent HYdraulic Diameter, Heavy Volume and Mass speed @*v
C
        SELECT CASE (WyeIndex)
          CASE (0)
C
C
C------ Equivalent HYdraulic Diameter of the wye inlet
C
            FLOWSEC=PIGR/4.*ChanDia**2.
            PB=PIGR*ChanDia
            EHYD=4.*FLOWSEC/PB
            GSPEED=ABS(WWIN)/FLOWSEC                                                 
            Fc2=FLOWSEC*FLOWSEC                                                 
C
C
C------ Equivalent HYdraulic Diameter of the Straight Passage
C
            StFLOWSEC=PIGR/4.*StPasDia**2.
            StPB=PIGR*StPasDia
            StEHYD=4.*StFLOWSEC/StPB
            StGSPEED=ABS(WSTP)/StFLOWSEC                                                 
            Fst2=StFLOWSEC*StFLOWSEC                                                 
C
C
C------ Equivalent HYdraulic Diameter of the Side Branch
C
            SbFLOWSEC=PIGR/4.*SidBrDia**2.
            SbPB=PIGR*SidBrDia
            SbEHYD=4.*SbFLOWSEC/SbPB
            SbGSPEED=ABS(WSBR)/SbFLOWSEC                                                 
            Fs2=SbFLOWSEC*SbFLOWSEC                                                 
C
C------ Control volume
C
            VOLC=FLOWSEC*StPasLen/2.+StFLOWSEC*StPasLen/2.
            VOLSP=StFLOWSEC*StPasLen/2.
            VOLSB=SbFLOWSEC*SidBrLen
            HMVOL=VOLC+VOLSP+VOLSB
C
C
         CASE DEFAULT
C
C------ Equivalent HYdraulic Diameter of the wye inlet
C
            FLOWSEC=PIGR/4.*ChanDia**2.
            PB=PIGR*ChanDia
            EHYD=4.*FLOWSEC/PB
            GSPEED=ABS(WWIN)/FLOWSEC
            Fc2=FLOWSEC*FLOWSEC                                                 
C
C
C------ Equivalent HYdraulic Diameter of the Straight Passage
C
            StFLOWSEC=PIGR/4.*StPasDia**2.
            StPB=PIGR*StPasDia
            StEHYD=4.*StFLOWSEC/StPB
            StGSPEED=ABS(WSTP)/StFLOWSEC                                                 
            Fst2=StFLOWSEC*StFLOWSEC                                                 
C
C
C------ Equivalent HYdraulic Diameter of the Side Branch
C
            SbFLOWSEC=PIGR/4.*SidBrDia**2.
            SbPB=PIGR*SidBrDia
            SbEHYD=4.*SbFLOWSEC/SbPB
            SbGSPEED=ABS(WSBR)/SbFLOWSEC                                                 
            Fs2=SbFLOWSEC*SbFLOWSEC                                                 
C
C------ Control volume
C
            VOLC=FLOWSEC*StPasLen/2.+StFLOWSEC*StPasLen/2.
            VOLSP=StFLOWSEC*StPasLen/2.
            VOLSB=SbFLOWSEC*SidBrLen
            HMVOL=VOLC+VOLSP+VOLSB
C
          write(6,*)'WARNING!!! Wye model is not assigned'                                        
          write(6,*)'WARNING!!! default case - Wye model ='
     $             ,' Cilindrical Tee'                                          
          write(6,*)'WARNING!!! default case -'
     $             ,' Wye Model Selection =',WyeIndex                                             
C
C
      END SELECT
C
C
C----------- Heavy Metal Physical properties
C
C-----------   TK ---> Thermal Conductivity                                                                      
C-----------   RO ---> Density                                                                      
C                                    
C
      CALL TEE0_FLUID_PROP(FluidIndex,HMEN,THM,RO,TK,MU,CP,BETAP,UQ)
C
C
      CALL TEE0_FLUID_PROP(FluidIndex,HWIE,TI,ROI,TKI,MUI,CPI,BETAPI
     $                                                            ,UQI)
      CALL TEE0_FLUID_PROP(FluidIndex,HSTI,TSTP,ROSTP,TKSTP,MUSTP,CPSTP
     $                                                 ,BETAPSTP,UQSTP)
      CALL TEE0_FLUID_PROP(FluidIndex,HSBI,TSB,ROSB,TKSB,MUSB,CPSB
     $                                                   ,BETAPSB,UQSB)
C
C
C----------- Friction factor
C                                                                       
C&        RE=GSPEED*EHYD/MU
C&        FRICF0=0.3164/RE**0.25                                                
C&           write(6,*)'EHYD=',EHYD,'RE=',RE                                              
        SELECT CASE (WyeIndex)
          CASE (0)
            CALL TEE0_MOODY_FF(Roughness,StEHYD,StGSPEED,MU,FRICFst)
C          write(6,*)'ROUGHNESS,StEHYD,FRICFst',Roughness,StEHYD,FRICFst
            CALL TEE0_MOODY_FF(Roughness,SbEHYD,SbGSPEED,MU,FRICFsb)
C          write(6,*)'ROUGHNESS,SbEHYD,FRICFsb',Roughness,SbEHYD,FRICFsb
            CALL TEE0_LOC_FC(WyeIndex,Alfa,CSIs,CSIst)
C          write(6,*)'valore restituito','CSIs =',CSIs,'CSIst =',CSIst
C&            FFXLD=FRICF*HLU/EHYD                                          
C&            CFC=FRICF*HLU/EHYD+CSILOC                                           
C&            write(6,*)'CFC =',CFC
C&          CASE (1)
C&          CASE (2)
            CFCst=FRICFst*StPasLen/StEHYD+CSIst                                            
            CFCsb=FRICFsb*SidBrLen/SbEHYD+CSIs                                            
C          write(6,*)'valore restituito ','CFCst =',CFCst,'CFCsb =',CFCsb
C          write(6,*)'valore restituito ','CFCst =',CFCst,'CFCsb =',CFCsb
C          write(6,*)'valore restituito ','CFCst =',CFCst,'CFCsb =',CFCsb
          CASE DEFAULT
            CALL TEE0_MOODY_FF(Roughness,StEHYD,StGSPEED,MU,FRICFst)
C          write(6,*)'ROUGHNESS,StEHYD,FRICFst',Roughness,StEHYD,FRICFst
            CALL TEE0_MOODY_FF(Roughness,SbEHYD,SbGSPEED,MU,FRICFsb)
C          write(6,*)'ROUGHNESS,SbEHYD,FRICFsb',Roughness,SbEHYD,FRICFsb
            CALL TEE0_LOC_FC(WyeIndex,Alfa,CSIs,CSIst)
C          write(6,*)'valore restituito','CSIs =',CSIs,'CSIst =',CSIst
            CFCst=FRICFst*StPasLen/StEHYD+CSIst                                            
            CFCsb=FRICFsb*SidBrLen/SbEHYD+CSIs                                            
C          write(6,*)'valore restituito','CFCst =',CFCst,'CFCsb =',CFCsb
        END SELECT
C
C
C
C----------- Heat Transfer Coefficient
C                                                                       
C                                                                       
C           write(6,*)'prima di chiamare TEE0_HTC HM (',I,')=',HM(I)                                              
      CALL TEE0_HTC(HTCS,RODPITCH,RODDIAM,GSPEED,EHYD,TK,MU,CP,HTC)
C           write(6,*)'HTC =',HTC                                             
C
C
C----------- Convective Heat Transfer
C                                                                       
C                                                                       
       QCV=HTC*HTraSurf*(THM-TWAL)
C
C
C----------- Conductive Heat Transfer
C                                                                       
C                                                                       
C&        IF (I.LT.NCEL) THEN
C&          HTS=MIN(FLOWSEC(I),FLOWSEC(I+1))
C&          GHTC=2./(HLU(I)/TK(I)+HLU(I+1)/TK(I+1))
C&          QTCDA(I)=-GHTC*HTS*(TL(I)-TL(I+1))
C        write(6,*)'GHTC =',GHTC ,'HTS =',HTS ,'TL (',I,')=',TL(I)                                              
C        write(6,*)'TK (',I,')=',TK(I),'HLU (',I,')=',HLU(I)                                              
C&        ELSE
C&          QTCDA(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TDLC)/(HLU(I)/2.)
C&        END IF
C&        IF (I.GT.1) THEN
C&          HTS=MIN(FLOWSEC(I),FLOWSEC(I-1))
C&          GHTC=2./(HLU(I)/TK(I)+HLU(I-1)/TK(I-1))
C&          QTCDB(I)=-GHTC*HTS*(TL(I)-TL(I-1))
C&        ELSE
C&          QTCDB(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TILD)/(HLU(I)/2.)
C&        END IF
C
C
C---------- Conservation Equations' Constants and coefficient 
C
C---------- Sw ---->  Mass Conservation
C---------- Sp ---->  Momentum Conservation
C---------- Sh ---->  Energy Conservation
C
      A0=HMVOL*(1./UQ+BETAP/CP)
      B0=RO*HMVOL*BETAP/CP
      B1=RO*HMVOL
      DET=A0*B1-B0*HMVOL
C
      SW=WWIN-WSTP-WSBR
C
      SHI=0.
C
      IF (WWIN.GE.0.) THEN
        SHI=WWIN*(HWIE-HMEN)
      END IF
C
      IF (WSTP.LE.0.) THEN
        SHI=SHI+WSTP*(HMEN-HSTI)
      END IF
C
      IF (WSBR.LE.0.) THEN
            SHI=SHI+WSBR*(HMEN-HSBI)
      END IF
C
C
C      SH=SHI-QCV+QTCDA+QTCDB
      SH=SHI-QCV
C
      IF (IFUN.EQ.2.AND.ITERT.EQ.0) THEN
C         write(6,*)'QTCDA(',I,')',QTCDA(I),'QTCDB(',I,')',QTCDB(I)
        DARCYst=FCAD*CFCst*WSTP*ABS(WSTP)/(2.*RO*Fst2)
        DARCYsb=FCAD*CFCsb*WSBR*ABS(WSBR)/(2.*RO*Fs2)
C         write(6,*)'DARCYst',DARCYst,'DARCYsb',DARCYsb
      END IF
C
      NN2=2*NCEL
      NN3=3*NCEL
C
      IF (KREGIM) THEN                                         
        RNI(1)=SH/(W0*H0)                                     
        RNI(2)=SW/W0                                          
      ELSE
        RNI(1)=(A0*SH+HMVOL*SW)/(DET*H0)                          
        RNI(2)=(B0*SH+B1*SW)/(DET*P0)            
      END IF
        RNI(3)=(HINV-HMEN)/H0
        RNI(4)=(PTEE-PSTP-FCAD*CFCst*WSTP*ABS(WSTP)/(2.*RO*Fst2)
     $         -RO*GA*StPasDz)/P0                                          
        RNI(5)=(HSTP-HMEN)/H0
        RNI(6)=(PTEE-PSBR-FCAD*CFCsb*WSBR*ABS(WSBR)/(2.*RO*Fs2)
     $         -RO*GA*SidBrDz)/P0                                        
        RNI(7)=(HSBR-HMEN)/H0
        RNI(8)=(THMT-THM)/T0
        RNI(9)=(GHTC-HTC)/GAM0
        RNI(10)=(QTPW-QCV)/(W0*H0)
C          write(6,*)'DET',DET
C                                                                       
      RETURN                                                            
      END                                                               
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE TEE0_FLUID_PROP(FluidType,H,T,RO,TK,MU,CP,BETAP,UQ)
C
      INTEGER FluidType
C
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C
      Select Case  (FluidType)
        Case (1)
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LEAD(T)
          BETAP=1.
          UQ=1.
C          write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
        Case (2)
C         Case ('LBE')
          T=T_H_LBE(H)
          RO=RO_T_LBE(T)
          TK=TC_T_LBE(T)
          MU=MU_T_LBE(T)
          CP=CP_T_LBE(T)
          BETAP=BETAP_T_LBE(T)
          UQ=UQ_T_LBE(T)
C          write(6,*)'Case LBE ','T=',T,' MU=',MU                                        
C       Case (3)
C         Case ('Sodium')
        Case Default
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LBE(T)
          BETAP=1.
          UQ=1.
C          write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
C        write(6,*)'Propriet� fluidi'                                             
C        write(6,*)'RO=',RO,' CP=',CP ,'BETAP=',BETAP                                              
C        write(6,*)'UQ=',UQ                                              
      RETURN
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0_HTC(HTCS,PITCH,D,G,DH,K,MU,CP,HTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C     HTCS  = Heat Transfer Correlation Selection code
C     HME   = Heavy Metal Enthalpy
C     THM   = Temperature of the Heavy Metal
C     PITCH = Lattice pitch
C     D     = Rod outside diameter
C     G     = Mass speed @�V
C     DH    = Hydraulic diameter
C     HTC   = Heat Transfer Coefficient
C
C
C
C     p = lattice pitch
C     D = rod outside diameter
C
C
C     Selection Code    Correlations for outside tube flow - triangular arrays
C                                                           
C                  1    V.M. Borishanski et al.  Nu=24.151*lg[-8.12 +12.76p/D-3.65(p/D)**2]+0.0174{1-exp[-6(p/D-1)]}(Pe-200)**0.9 
C                  2    H. Graber                Nu=0.25+6.2p/D+(0.32p/D-0.07)Pe**(0.8-0.024p/D)
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles with spacers
C                                                           
C                  3    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.09Pe**(0.64+0.264p/D) 
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles without spacers
C                                                           
C                  4    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.07Pe**(0.64+0.264p/D) 
C
C
C
C     Selection Code    Correlations for outside tube flow - doesn't refer to any particular lattice
C                                                           
C                  5    H. Calamai et al.        Nu=4.+0.16(p/D)**5+0.33(p/D)**3.8(Pe/100.)**0.86
C
C
C     Selection Code    Correlations for inside tube flow 
C                                                           
C                  6    Kirillow - Stromquist    Nu=A+0.018Pe**0.8  
C                                                                | 4.5                  Pe < 1000
C                                                             A=<  5.4-0.0009Pe  1000 < Pe < 2000
C                                                                | 3.6                  Pe > 2000
C                                                           
C                  7    Lubarsky                 Nu=0.625Pe**0.4
C                                                                
C                  8    Seban - Shimazaki        Nu=5.+0.025Pe**0.8 - Pure liquid lead
C                  9                             Nu=3.3+0.014Pe**0.8 - without special purification 
C
C
C            default    Subbotin                 Nu=7.55p/D-20(p/D)**-13+(3.67/90)(p/D)**-2Pe**(0.19p/D+0.56)
C probably used in RELAP5/PARCS
C
      INTEGER HTCSC
C
      REAL K,MU,NU
C
C      HTCSC=INT(HTCS)
      HTCSC=7
C      write(6,*)'TEE0 '
C      write(6,*)'HTCSC= ',HTCSC
C      write(6,*)' PITCH,D,G,DH,K,MU,CP,LHTC='                                              
C      write(6,*) PITCH,D,G,DH,K,MU,CP,LHTC                                             
C
      SELECT CASE (HTCSC)
        CASE (0)
          PD=1.
        CASE (1,2,3,4,5,6,7,8,9)
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pitch/Pin diameter not assigned'
	    write(6,*)'             Default value assumed 1.3'
            PD=1.3
	  ELSE
           PD=PITCH/D
	  END IF
        CASE DEFAULT 
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pin diameter not assigned'
	    write(6,*)'             Default value assumed 0.01 m'
            PD=1.3
	  ELSE
            PD=PITCH/D
	  END IF
      END SELECT
C      write(6,*)'PD= ',PD
C
      RE=G*DH/MU
C
      PR=MU*CP/K      
C
      PE=RE*PR     
C      write(6,*)' routine HTC     PE=',PE                                              
C
      SELECT CASE (HTCSC)
        CASE (1)
          A0TR=-8.12 +12.76*PD-3.65*PD**2.
          A1TR=-6.*(PD-1.)
          NU=24.151*LOG(A0TR)+0.0174*(1.-EXP(A1TR))*(PE-200.)**0.9
        CASE (2)
          NU=0.25+6.2*PD+(0.32*PD-0.07)*PE**(0.8-0.024*PD)
        CASE (3)
          NU=7.55*PD-14./PD**5.-0.09*PE**(0.64+0.264*PD)
        CASE (4)
          NU=7.55*PD-14./PD**5.-0.07*PE**(0.64+0.264*PD)
        CASE (5)
          NU=4.+0.16*PD**5.+0.33*PD**3.8*(Pe/100.)**0.86
        CASE (6)
          IF (PE.LT.1000.) AKS=4.5
          IF (PE.GE.1000..AND.PE.LE.2000.) THEN
            AKS=5.4+0.0009*PE
          END IF
          IF (PE.GT.2000.) AKS=3.6
          NU=AKS+0.018*PE**0.8
        CASE (7)
C      write(6,*)' TEE0 case 7 RE=',RE,' PR=',PR,' PE=',PE                                             
          NU=0.625*PE**0.4
C          write(6,*)' NU=',NU                                            
        CASE (8)
          NU=5.+0.025*PE**0.8
        CASE (9)
          NU=3.3+0.014*PE**0.8
      CASE DEFAULT 
          NU=7.55*PD-20./PD**13.+3.67/(90.*PD**2.)*PE**(0.19*PD+0.56)
C      write(6,*)' RE=',RE,' PR=',PR,' PE=',PE  ,' NU=',NU                                            
      END SELECT
C
      HTC=K/DH*NU
C      write(6,*)' LHTC=',LHTC                                              
C
      RETURN
      END
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
C
      SUBROUTINE TEE0_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C                       Moody friction factor 
C
C  Parametri in ingresso:  ROUGHNESS, DIA,GSPEED,MU 
C  Parametri in uscita:    FRICF
C
C
C  ROUGHNESS [m] - Roughness
C  DIA       [m] - Equivalent Hydraulic Diameter
C  GSPEED    
C  MU        
C  FRICF
C
C-------------------------------------------------------------------------
C
      REAL MU
C
      COMMON/TEE0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
C
      RE=GSPEED*DIA/MU
C      write(6,*)'TEE0   GSPEED',GSPEED,' DIA = ',DIA
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
	FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
	  FRICF=64./RE
	ELSE
	  IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
	  IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25                                                
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
	  DO WHILE (I.LE.100)
            IT=IT+1
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
	    END IF
	    
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
          END DO
C
C   SOLUZIONE
C
          WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP0_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBLOC1X,IBLOC2X
        END IF
      END IF
      RETURN                                                            
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE TEE0_LOC_FC(WyeIndex,Alfa,CSIs,CSIst)
C
C
      PARAMETER (NFSdbFC=7,NQSdbQC=10,NCSIcs=NFSdbFC*NQSdbQC)
      PARAMETER (NDUMMY=2,NQSTdbQC=10,NCSIcst=NDUMMY*NQSTdbQC)
C
      INTEGER WyeIndex
C
      DIMENSION TABFSdbFC(NFSdbFC),TABNQSdbQC(NQSdbQC),TABCSIcs(NCSIcs)
      DIMENSION TABDUMMY(NDUMMY),TABNQSTdbQC(NQSTdbQC)
      DIMENSION TABCSIcst(NCSIcst)
C
      COMMON/TEE0PRESSDROP/FLOWSEC,WWIN,StFLOWSEC,WSTP,SbFLOWSEC,WSBR,RO
C
C
      DATA TABFSdbFC/0.09,0.19,0.27,0.35,0.44,0.55,1./
      DATA TABNQSdbQC/0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1./
      DATA TABCSIcs/2.80,4.50,6.00,7.88,9.40,11.1,13.0,15.80,20.0,24.7,
     $              1.41,2.00,2.50,3.20,3.97, 4.95,6.50,8.45,10.8,13.3,
     $              1.37,1.81,2.30,2.83,3.40, 4.07,4.80,6.00, 7.18,8.9, 
     $              1.10,1.54,1.90,2.35,2.73, 3.22,3.80,4.32, 5.28,6.53,
     $              1.22,1.45,1.67,1.89,2.11, 2.38,2.58,3.04, 3.84,4.75,
     $              1.09,1.20,1.40,1.59,1.65, 1.77,1.94,2.20, 2.68,3.30,
     $              0.90,1.00,1.13,1.20,1.40, 1.50,1.60,1.80, 2.06,2.80/
C
C
      DATA TABDUMMY/0.,2./
      DATA TABNQSTdbQC/0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1./
      DATA TABCSIcst/0.7,0.64,0.6,0.57,0.55,0.51,0.49,0.55,0.62,0.7,
     $               0.7,0.64,0.6,0.57,0.55,0.51,0.49,0.55,0.62,0.7/
      DATA DUMMY/1./
C
C
C
      Select Case  (WyeIndex)
        Case (1)
C
C         Wyes of the type Fs+Fst>Fc ; Fst=Fc ; Alfa=90�
C
C           FLOWSEC   = Tube diameter
C           WWIN      = main stream flow section
C           StFLOWSEC = Gasket thickness
C           WSTP      = Gasket diameter
C           SbFLOWSEC = Gasket flow section
C           WSBR      = Expansion coefficient
C           Alfa      = Contraction coefficient
C           CSIs      = Linear loss coefficient
C           CSIst     = Linear loss coefficient
C             
C
          FSdbFC=SbFLOWSEC/FLOWSEC
          FSTdbFC=StFLOWSEC/FLOWSEC
          IF (WWIN.NE.0.) THEN
            QSdbQC=ABS(WSBR/WWIN)
            QSTdbQC=ABS(WSTP/WWIN)
          ELSE
            QSdbQC=1.
            QSTdbQC=1.
          END IF
C
          CALL LINTAB(TABFSdbFC,NFSdbFC,TABNQSdbQC,NQSdbQC,TABCSIcs,
     $                QSdbQC,FSdbFC,CSIcs,Z1,Z2)
C          write(6,*)'CSI locale ','QSdbQC=',QSdbQC,' CSIcs=',CSIcs                                           
C
          IF (QSdbQC.NE.0.) THEN
            CSIs=CSIcs*(FSdbFC/QSdbQC)**2.
          ELSE
            CSIs=CSIcs
          END IF
C          write(6,*)'CSI locale ',' CSIs=',CSIs                                           
C
          CALL LINTAB(TABDUMMY,NDUMMY,TABNQSTdbQC,NQSTdbQC,TABCSIcst,
     $                QSTdbQC,DUMMY,CSIcst,Z1,Z2)
C
          IF (abs(QSTdbQC-1.).GT.1.E-5) THEN
            CSIst=CSIcst/(1.-QSTdbQC**2.)*FSTdbFC**2.
          ELSE
            CSIst=CSIcst
          END IF
C
C
        Case Default
C                   No local Head loss
C
          FSdbFC=SbFLOWSEC/FLOWSEC
          FSTdbFC=StFLOWSEC/FLOWSEC
          IF (WWIN.NE.0.) THEN
            QSdbQC=ABS(WSBR/WWIN)
            QSTdbQC=ABS(WSTP/WWIN)
          ELSE
            QSdbQC=1.
            QSTdbQC=1.
          END IF
C
          CALL LINTAB(TABFSdbFC,NFSdbFC,TABNQSdbQC,NQSdbQC,TABCSIcs,
     $                QSdbQC,FSdbFC,CSIcs,Z1,Z2)
C          write(6,*)'CSI locale ','QSdbQC=',QSdbQC,' CSIcs=',CSIcs                                           
C
          IF (QSdbQC.NE.0.) THEN
            CSIs=CSIcs*(FSdbFC/QSdbQC)**2.
          ELSE
            CSIs=CSIcs
          END IF
C
C          write(6,*)'CSI locale ',' CSIs=',CSIs                                           
          CALL LINTAB(TABDUMMY,NDUMMY,TABNQSTdbQC,NQSTdbQC,TABCSIcst,
     $                QSTdbQC,DUMMY,CSIcst,Z1,Z2)
C          write(6,*)'CSI locale ','QSTdbQC=',QSTdbQC,' CSIcst=',CSIcst                                           
C
          IF (abs(QSTdbQC-1.).GT.1.E-5) THEN
            CSIst=CSIcst/(1.-QSTdbQC**2.)*FSTdbFC**2.
C           write(6,*)'CSI locale ','QSTdbQC=',QSTdbQC                                     
C           write(6,*)' QSTdbQC.NE.1. CSI locale ',' CSIst=',CSIst                                           
          ELSE
            CSIst=CSIcst
C          write(6,*)'QSTdbQC.EQ.1.  CSI locale ',' CSIst=',CSIst                                           
          END IF
C
      End Select
C
      RETURN
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      FUNCTION TEE0ISTA05(IFUN)                                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      TEE0ISTA05=0                                                          
      IF(KREGIM) TEE0ISTA05=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) TEE0ISTA05=1                         
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE TEE0STAS05(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C
      COMMON/TEE0PRESSDROP/FLOWSEC,WWIN,StFLOWSEC,WSTP,SbFLOWSEC,WSBR,RO
      COMMON/TEE0LACANES/ FRICFst,StPasLen,StEHYD,CSIst,FRICFsb,SidBrLen
     $                   ,SbEHYD,CSIs
C
      COMMON/TEE0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
C
      Fst2=StFLOWSEC*StFLOWSEC                                                 
      Fs2=SbFLOWSEC*SbFLOWSEC
      FFstLD=FRICFst*StPasLen/StEHYD
      FFsbLD=FRICFsb*SidBrLen/SbEHYD                                                
      CFCst=FRICFst*StPasLen/StEHYD+CSIst                                            
      CFCsb=FRICFsb*SidBrLen/SbEHYD+CSIs                                            
      DARCYst=CFCst*WSTP*ABS(WSTP)/(2.*RO*Fst2)
      STFSPEED=ABS(WSTP)/(StFLOWSEC*RO)
      DARCYsb=CFCsb*WSBR*ABS(WSBR)/(2.*RO*Fs2)
C
      WRITE(6,*)                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)' -----  Straight Passage  -----'                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)'                      Mass flow rate :',WSTP ,'[kg/s]'                                                    
      WRITE(6,*)'             Moody friction factor f :',FRICFst,'[-]'
      WRITE(6,*)'                              f(L/D) :',FFstLD,'[-]'
      WRITE(6,*)'   Local pressure drop coefficient K :',CSIst,'[-]'
      WRITE(6,*)'  Pressure drop coefficient f(L/D)+K :',CFCst,'[-]'
      WRITE(6,*)' Darcy pressure drop [f(L/D)+K]@VV/2 :',DARCYst,'[Pa]'
C
      WRITE(6,*)                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)' -----  Side Branche  -----'                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)'                      Mass flow rate :',WSBR ,'[kg/s]'                                                    
      WRITE(6,*)'             Moody friction factor f :',FRICFsb,'[-]'
      WRITE(6,*)'                              f(L/D) :',FFsbLD,'[-]'
      WRITE(6,*)'   Local pressure drop coefficient K :',CSIs,'[-]'
      WRITE(6,*)'  Pressure drop coefficient f(L/D)+K :',CFCsb,'[-]'
      WRITE(6,*)' Darcy pressure drop [f(L/D)+K]@VV/2 :',DARCYsb,'[Pa]'
C
      WRITE(34,1005)IBLOC1X,IBLOC2X,FFstLD,CSIst,CFCst,STFSPEED                                                      
     $              ,AVREIN                                                      
1005  FORMAT('Block ',2A4,5x,'f(L/D)',F12.6,5x,'Form loss coefficient K'
     $       ,F12.6,5x,'f(L/D)+K',F12.6,5x,'Average speed [m/s]',F12.6
     $       ,5x,'Average Reynolds number RE  ',F15.6 )
C
      RETURN                                                            
      END                                                               
C
C
C
      SUBROUTINE TEE0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      RETURN
      END
C
C
C~FORAUS_TEE0~C 
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE TEE0_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE TEE0_UHTC SIA CHIAMATA DA TEE0
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   HTCS < 0.
C
C  La subroutine fornisce al modulo TEE0 il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]          
C   H     entalpia specifica del fluido           [J/kg]        
C   S     entropia specifica del fluido           [J/kg/C] 
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]     
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   HTCS  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato 
C         come si vuole.
C         RICORDATI CHE HTCS E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]   
C   Q     potenza totale scambiata                [W]           
C   SUP   superficie di scambio                   [m**2]        
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE TEE0_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_TEE0~C 

