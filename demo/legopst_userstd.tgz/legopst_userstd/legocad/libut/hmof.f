C**********************************************************************
C modulo HMOF.f
C tipo 
C release 5.3
C data 13/10/2007
C reserver @(#)HMOF.f	5.3
C**********************************************************************
C
C**********************************************************************
C
C   Heavy Metal Orifice Flow meter
C
C   ref. Frank M. White - Fluid Mechanics - McGraw-Hill - 1986
C    
C
C   Vincenzo Casamassima
C   SSG - Generation Systems Departement
C   CESI Ricerca
C   via Rubattino, 54
C   20134 Milan
C   Italy
C**********************************************************************
C
      SUBROUTINE HMOFI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMOF00/IBLOC
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 NOMAPP
      CHARACTER*4 MOD
      DATA MOD/'HMOF'/
C
C
C
      CALL HMOFI4(IOB,MOD)
C
C
C
      NSTATI=0
      NUSCIT=3
      NINGRE=5
C
      WRITE(NOMAPP,'(A1)')IBLOC
      WP=0.
      IF(NOMAPP(1:1).EQ.'+')WP=1.
      IF(NOMAPP(1:1).EQ.'-')WP=2.
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
      IF (WP.EQ.0.) THEN
        WRITE(IFO,3000)IOB
3000    FORMAT('WTUB',A4,2X,'--UA-- FLUID MASS FLOW RATE ')
        WRITE(IFO,3001)IOB
3001    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3002)IOB
3002    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT METER INLET -W<0')
        WRITE(IFO,3003)IOB
3003    FORMAT('PITU',A4,2X,'--IN-- UPSTREAM PRESSURE ')
        WRITE(IFO,3004)IOB
3004    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3005)IOB
3005    FORMAT('PUTU',A4,2X,'--IN-- DOWNSTREAM PRESSURE')
        WRITE(IFO,3006)IOB
3006    FORMAT('HUTI',A4,2X,'--IN-- FLUID ENTHALPY AT METER OUTLET-W<0')
        WRITE(IFO,3007)IOB
3007    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      IF (WP.EQ.1.) THEN
        WRITE(IFO,3008)IOB
3008    FORMAT('PITU',A4,2X,'--UA-- PIPE INLET PRESSURE ')
        WRITE(IFO,3009)IOB
3009    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3010)IOB
3010    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3011)IOB
3011    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
      WRITE(IFO,3012)IOB
3012    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3013)IOB
3013    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3014)IOB
3014    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3015)IOB
3015    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      IF (WP.EQ.2.) THEN
        WRITE(IFO,3016)IOB
3016    FORMAT('PUTU',A4,2X,'--UA-- PIPE OUTLET PRESSURE ')
        WRITE(IFO,3017)IOB
3017    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3018)IOB
3018    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3019)IOB
3019    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3020)IOB
3020    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3021)IOB
3021    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
         WRITE(IFO,3022)IOB
3022    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3023)IOB
3023    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      RETURN
      END
      SUBROUTINE HMOFI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMOF00/IBLOC
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MODU
      CHARACTER*1 ICA,IMEN,IPIU
      CHARACTER*1 IBL
      CHARACTER*4 MOD
      DATA IBL/' '/
      DATA IPIU/'+'/
      DATA IMEN/'-'/
C
    2 WRITE(6,2999)
 2999 FORMAT(//10X,'GIVE A CHARACTER'
     $ /5X,' - FLOW RATE AS OUTPUT =========> BLANK'
     $ /5X,' - INLET PRESSURE AS OUTPUT ====>   +'
     $ /5X,' - OUTLET PRESSURE AS OUTPUT ===>   -')
      READ(5,3001)ICA
      IF(ICA.EQ.IPIU)GO TO 1
      IF(ICA.EQ.IMEN)GO TO 1
      IF(ICA.EQ.IBL)GO TO 1
      GO TO 2
 3001 FORMAT(A)
    1 CONTINUE
C
      WRITE(MODU,'(A1,A3)')ICA,MOD
      IF(ICA.EQ.IBL)MODU=MOD
      WRITE(IBLOC,'(2A4)')MODU,IOB
C
      RETURN
      END
      SUBROUTINE HMOFI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,NOM1,NOM2,
     $ IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*4 CS1,CS2,WL1,WL2,PM1,PM2,PV1
     $,PV2,HM1,HM2,DZ1,DZ2
      CHARACTER*4 NOMAPP
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
      COMMON / NORM / P0,H0,T0,Q0,R0,AL0,V0,DP0
      DATA CS1/'COEF'/,CS2/'F.  '/
      DATA WL1/'PORT'/,WL2/'ATA'/,PM1/'P1 M'/,PM2/'ONTE'/
      DATA PV1/'P2 V'/,PV2/'ALLE'/,HM1/'ENTA'/,HM2/'LPIA'/
      DATA DZ1/'DISL'/,DZ2/'IV. '/
C
      GO TO (1,10),IFUN
C
C      SCRITTURA DEI SIMBOLI SUL FILE 14
C
    1 WRITE(14,1010)
 1010 FORMAT('*   DATA TO BE ASSIGNED TO DEFINE THE HEAD LOSS')
      WRITE(14,1020)WL1,WL2,PM1,PM2,PV1,PV2,HM1,HM2,CS1,CS2
      WRITE(14,1011)
 1011 FORMAT('*   SEAL ADDED TO THE HEAD LOSS')
      WRITE(14,1020)DZ1,DZ2
 1020 FORMAT(3(4X,2A4,' =',10X,'*'),5X)
      RETURN
C
C      LETTURA  DEI DATI DAL FILE 14
C
   10 READ(14,1070)
      READ(14,1070)
      READ(14,1070) WL,PM,PV,H,CS
      READ(14,1070)
      READ(14,1070) DZ
 1070 FORMAT(3(14X,F10.0,1X),5X)
C
C   CALCOLO DEL COEFFICIENTE DI PERDITA DI CARICO
C
C
	RK0=0.
C
	IF(WL.GT.0.) THEN
	  IFL=1
          TLEAD=T_H_LEAD(H)
          RO=RO_T_LEAD(TLEAD)
 	  RK0=2.*(PM-PV)*RO/(WL*WL)
	  GO TO 15
	ENDIF
	   RK0= CS
 15   CONTINUE
C
C      DECODE(1,2222,NOM1)IWP
C 2222 FORMAT(A1,3X)
C
C -----   inizio modifica istruzione di DECODE   -----
      WRITE(NOMAPP,'(A1)')NOM1
      IWP=0
      IF(NOMAPP(1:1).EQ.'+')IWP=1
      IF(NOMAPP(1:1).EQ.'-')IWP=2
C -----    fine modifica istruzione di DECODE    -----
C
C       MEMORIZZAZIONE DATI
C
      RKK=RK0
      WRITE(6,3023)RKK
 3023 FORMAT(//10X,'HEAD LOSS COEFFICIENT = ',E12.5/)
C
      DATI(ID1)=RK0
      DATI(ID1+1)=IWP
      DATI(ID1+2)=DZ*9.81
      ID2=ID2+2
C
C   COSTANTI DI NORMALIZZAZIONE
C
      CNXYU(IV1)=Q0
      CNXYU(IV1+1)=H0
      CNXYU(IV1+2)=H0
      CNXYU(IV1+3)=P0
      CNXYU(IV1+4)=H0
      CNXYU(IV1+5)=P0
      CNXYU(IV1+6)=H0
      CNXYU(IV1+7)=1.
C
      IF (IWP.EQ.1) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+3)=Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+5)=Q0
      END IF
C
C   TOLLERANZA PER LA SOLUZIONE DELL'EQUAZIONE
C    viene posta 1000 pascal / P0
C     se viene data la differenza di pressione nominale
C     viene posta 1/100 di quest'ultima.
C
C      TOL(1)=1000./P0
C$$$
C      IF(WL.GT.0.) TOL(1)=(PM-PV)/100./P0
C$$$
C
      IF(IWP.EQ.0)WRITE(6,502)'*** FLOW RATE AS OUTPUT ***'
      IF(IWP.EQ.1)WRITE(6,502)'*** INLET PRESSURE AS OUTPUT ***'
      IF(IWP.EQ.2)WRITE(6,502)'*** OUTLET PRESSURE AS OUTPUT ***'
  502 FORMAT(14X,A)
      RETURN
      END
C
      SUBROUTINE HMOFC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RN,NOM1,NOM2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER TPOType
      REAL MU,MU_T_LEAD
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      COMMON/NORM/P0,H0,T0,Q0,R0,AL0,V0,DP0
      COMMON/TOLEG00/TOLIN(100)
      DATA SccsID/'@(#)HMOF.f	5.3\t 5.3\t 10/3/96'/          
      DATA PIGRECO/3.141592653/          
C
      IFL=1
      GO TO (1,10,10),IFUN
C
C   DEFINIZIONE DELLA TOPOLOGIA
C
  1   CONTINUE
C
      DO J=1,3
        DO I=1,8
          AJAC(J,I)=1.
        END DO
      END DO
C
      RETURN
C 
C   DECODIFICA DEI DATI
C
   10 RK0=DATI(IPD)
      IWP=DATI(IPD+1)
      RGZ=DATI(IPD+2)
C
C   DECODIFICA DELLE VARIABILI
C
      W=XYU(IXYU)*Q0
      HUTU=XYU(IXYU+1)*H0
      HITI=XYU(IXYU+2)*H0
      PM=XYU(IXYU+3)*P0
      HITU=XYU(IXYU+4)*H0
      PV=XYU(IXYU+5)*P0
      HUTI=XYU(IXYU+6)*H0
      FC=XYU(IXYU+7)
C
      IF (IWP.EQ.1) THEN
        PM=XYU(IXYU)*P0
        W=XYU(IXYU+3)*Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        PV=XYU(IXYU)*P0
        W=XYU(IXYU+5)*Q0
      END IF
CC
      DP = PM-PV
      PMED=(0.5*PM+0.5*PV)
      IF (PM.GE.PV) THEN
         TLEADI=T_H_LEAD(HITU)
         RO=RO_T_LEAD(TLEADI)
         MU=MU_T_LEAD(TLEADI)
      write(6,*)'TLEADI=',TLEADI,' MU=',MU                                              
      ELSE
         TLEADU=T_H_LEAD(HUTI)
         RO=RO_T_LEAD(TLEADU)
         MU=MU_T_LEAD(TLEADU)
      write(6,*)'TLEADU=',TLEADU,' MU=',MU                                              
       END IF
C
      PipeD=0.0529
      ObD=0.03246
C
C      TOLIN(1)=50./P0
C     TOLIN(1)=0.001/Q0
C
C--- Orifice Flow Section Area 
C
      OFSA=PIGRECO*ObD*ObD/4.
C
C--- Reynolds Number
C
      FSA=PIGRECO*PipeD*PipeD/4.
      G=ABS(W)/FSA
      RE=G*PipeD/MU
      Write(6,*)'RE=',RE
C
C--- Beta ratio of the device 
C
      Beta=ObD/PipeD
C
C--- Correction factors F1 - F2
C
      TPOType=2
      Select Case  (TPOType)
          Case (1)
            F1=0.
            F2=0.
          Case (2)
            F1=0.4333
            F2=0.47
          Case Default
            F1=0.4333
            F2=0.47
      End Select
C
C--- Beta function FB
C
      FB=0.5959+0.0312*Beta**2.1-0.184*Beta**8.
      Write(6,*)'Beta=',Beta,'FB=',FB
C
C--- Dimensionless Discharge coefficient Cd
C
      Cd=FB+91.71*Beta**2.5/RE**0.75+0.09*Beta**4./(1.-Beta**4.)*F1
     $                                           -0.0337*Beta**3.*F2
      Write(6,*)'Cd=',Cd
C
C   CALCOLO DEL RESIDUO
C
      RK0=(1.-Beta**2.)/(Cd*OFSA)**2.
      Write(6,*)'RK0=',RK0
      IF(IFUN.EQ.3) GO TO 40
      RN(1) = (DP-FC*RK0/RO/2.*W*ABS(W))/(Q0*Q0)
      RN(2) = (HITU-HUTU)/H0
      RN(3) = (HUTI-HITI)/H0

      RETURN
C
C     CALCOLO DELLO JACOBIANO
C
   40 IWPP=IWP+1
      GO TO (42,46,48),IWPP
C
C________ USCITA IN PORTATA
C
C   42 AJAC(1,1) = FC*RK0/RO*(ABS(W)+.1)/P0
   42 AJAC(1,1) = FC*RK0/RO*ABS(W)/Q0
      AJAC(1,4) = -1.
      AJAC(1,6) = 1.
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/Q0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
        GO TO 50
C
C________ USCITA IN PRESSIONE A MONTE
C
  46  AJAC(1,1) = -1.
C      AJAC(1,4) = FC*RK0/RO*(ABS(W)+.1)/P0
      AJAC(1,4) = FC*RK0/RO*ABS(W)/P0
      AJAC(1,6) = 1.
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
       GO TO 50
C
C________ USCITA IN PRESSIONE A VALLE
C
 48   AJAC(1,1) = 1.
      AJAC(1,4) = -1.
C      AJAC(1,6) = FC*RK0/RO*(ABS(W)+.1)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(1,6) = FC*RK0/RO*ABS(W)/P0
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
  50   RETURN
      END
CC
      SUBROUTINE HMOFD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
