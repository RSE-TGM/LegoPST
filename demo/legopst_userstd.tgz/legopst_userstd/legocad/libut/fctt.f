C**********************************************************************
C modulo %M%
C tipo %Y%
C release %I%
C data %G%
C reserver %W%
C**********************************************************************
      SUBROUTINE FCTTI3 (IFO,IOB,DEBL)
      PARAMETER (NV=11)
C
      CHARACTER*4 IBLOC*8
      CHARACTER*4 IOB, MOD, DEBL*80
      CHARACTER*4 NOMI(NV), TIPI(NV)*2, DESC(NV)*50
C
      DATA MOD/'FCTT'/
      DATA (NOMI(I), TIPI(I), DESC(I), I=1,NV) /
     $ 'WTOT','UA','TOTAL FLUE GASES FLOW RATE (HRSG INLET)',
     $ '%CO2','UA','CO2 PARTIAL PRESSURE IN FLUE GASES (%)',
     $ '%PH2','UA','H2O PARTIAL PRESSURE IN FLUE GASES (%)',
     $ '%PO2','UA','O2 PARTIAL PRESSURE IN FLUE GASES (%)',
     $ '%H2O','UA','H2O MASS RATIO IN FLUE GASES (%)',
     $ 'WFUM','IN','FLUE GASES FLOW RATE AT C.C. OUTLET',
     $ 'XCOM','IN','COMB./AIR MASS RATIO AT C.C. OUTLET',
     $ 'XSTE','IN','STEAM/AIR MASS RATIO AT C.C. OUTLET',
     $ 'XXCH','IN','H/C MOLAR RATIO (FUEL MEAN CHEM. COMP.)',
     $ 'ZMN2','IN','INERT MASS PERCENTAGE (FUEL MEAN CHEM. COMP.)',
     $ 'WAR0','IN','ADDICTIVE AIR FLOW RATE FROM GATE 0'/
C
C
      CALL FCTTI4 (IOB,MOD,IBLOC,NAG)
C
      WRITE(IFO,2999)MOD,IOB,IOB,MOD,DEBL
      WRITE(IFO,3000)(NOMI(I), IOB, TIPI(I), DESC(I), I = 1,NV-1)
      DO I = 1, NAG
        NOMI(NV)( 4:) = CHAR(I+48)
        DESC(NV)(35:) = CHAR(I+48)
        WRITE(IFO,3000)NOMI(NV), IOB, TIPI(NV), DESC(NV)
      ENDDO
      RETURN
 2999 FORMAT(2A4,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
 3000 FORMAT(2A4,'  --',A2,'-- ',A)
      END
C
C
C
      SUBROUTINE FCTTI4 (IOB,MOD,IBLOC,NAG)
      CHARACTER*4 IOB, MOD, IBLOC*8
C
    1 WRITE(6,2)
    2 FORMAT(10X,'NUMBER OF ADDICTIVE AIR GATES (0 - 9) ?')
      READ(5,*,ERR=1) NAG
      IF (NAG .LT. 0 .OR. NAG .GT. 9) GOTO 1
      RETURN
      END
C
C
      SUBROUTINE FCTTI2 (IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
C
      REAL VAR(MX1,2)
      DIMENSION XYU(*),DATI(*),CNXYU(*),TOL(*)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
C
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
C
C---Miscelatore chimico aria e fumi
C
      GO TO(100,200), IFUN
C
  100 WRITE(14,500) 'Wfum Min'
      RETURN
C
C---lettura e memorizzazione dati
C
  200 READ(14,501)
      READ(14,501) WMIN, XCH, XN2
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  501 FORMAT(3(14X,F10.0,1X))
C
      NAG = NINGRE - 5
      DATI(ID2  ) = FLOAT(NAG)
      DATI(ID2+1) = WMIN / W0
      ID2 = ID2+1
C
C---costanti di normalizzazione
C
      CNXYU(IV1  ) = W0
      DO I = 1, 4
        CNXYU(IV1+I) = 1.
      ENDDO
      CNXYU(IV1+5) = W0
      CNXYU(IV1+6) = 1.
      CNXYU(IV1+7) = 1.
      CNXYU(IV1+8) = 1.
      CNXYU(IV1+9) = 1.
      DO I = 1, NAG
        CNXYU(IV1+9+I) = W0
      ENDDO
C
      RETURN
      END
C
C
C
      SUBROUTINE FCTTC1 (IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
       DATA SccsID/'%W%\t %I%\t %G%'/
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/NEQUAZ/NEQMOD
C
      EXTERNAL FCTT
C
C---Miscelatore chimico aria e fumi
C
      NAG = NINT(DATI(IPD))
      GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100 NEQMOD = 1
      AJAC (1,1) = 1.
      AJAC (1,6) = 1.
      DO I = 1, NAG
        AJAC (1,I+10) = 1.
      ENDDO
      RETURN
C
C---calcolo residui
C
  200 IF (.NOT. KREGIM) NEQMOD = 1
      CALL FCTT (IFUN,IXYU,XYU,IPD,DATI,RNI)
      RETURN
C
C---calcolo jacobiano
C
  300 IF (KREGIM) THEN
        NSTATI = 0
        NUSCIT = 5
        NINGRE = 5 + NAG
        EPS    = 1.E-3
        EPSLIM = 1.E-4
        CALL NAJAC (AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $              NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,FCTT)
      ELSE
        NEQMOD = 1
        AJAC(1,1) = -1.
        AJAC(1,6) = 1.
        DO I = 1, NAG
          AJAC(1,I+10) = 1.
        ENDDO
      ENDIF
      RETURN
C
      END
C
C
C
      SUBROUTINE FCTT (IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      DIMENSION XYU(*),DATI(*),RNI(*)
      DIMENSION G(5), F(5), X(5), V(5), W(5)
      DATA W /75.002, 22.981,  0.686,  0.050,  1.281/
      DATA G /28.014, 31.998, 18.015, 44.009, 39.948/
      DATA GH, GC /1.008, 12.011/
C
C---Miscelatore chimico aria e fumi
C   calcolo residui
C
C---decodifica dati e variabili
C
      NAG = NINT(DATI(IPD))
      WLN = DATI(IPD+1)
C
      WTOT = XYU(IXYU  )
      ZCO2 = XYU(IXYU+1)
      ZPH2 = XYU(IXYU+2)
      ZPO2 = XYU(IXYU+3)
      ZH2O = XYU(IXYU+4)
      WFUM = XYU(IXYU+5)
      XCOM = XYU(IXYU+6)
      XSTE = XYU(IXYU+7)
      XXHC = XYU(IXYU+8)
      XXN2 = XYU(IXYU+9)/100.
C
      WARI = 0.
      DO I = 1, NAG
        WARI = WARI + AMAX1(0., XYU(IXYU+9+I))
      ENDDO
      IF (WFUM .LT. WLN) WFUM = WLN
C
      IF (XXHC .LT. 0.) XXHC = 0.
      IF (XXHC .GT. 4.) XXHC = 4.
      IF (XXN2 .LT. 0.) XXN2 = 0.
      IF (XXN2 .GT. .1) XXN2 = .1
      GX = GC + XXHC * GH
      Y0 = 100. * WFUM / (WFUM + (1. + XCOM + XSTE) * WARI)
      Y1 = Y0 * XCOM * (1. - XXN2)
      Y2 = Y0 * XSTE
      Y3 = Y0 * XCOM * XXN2
      YMOLT = (1. + 0.25 * XXHC) * G(2) / GX
      YSTECH = W(2) / YMOLT
      IF (Y1 .LT. 0.) Y1 = 0.
      IF (Y1 .GT. YSTECH) Y1 = YSTECH
      UDIV = 100. + Y1 + Y2 + Y3
C
      V(1) = Y3
      V(2) = - Y1 * YMOLT
      V(3) = G(3) * 0.5 * XXHC * Y1 / GX + Y2
      V(4) = G(4) * Y1 / GX
      V(5) = 0.
      DO I = 1, 5
        F(I) = (W(I) + V(I)) / UDIV
      ENDDO
C
      XGEQ = 0.
      DO I = 1, 5
        XGEQ = XGEQ + F(I) / G(I)
      ENDDO
      XGEQ = 1. / XGEQ
      DO I = 1, 5
        X(I) = XGEQ * F(I) / G(I)
      ENDDO
C
C---calcolo residui
C
      RNI(1) = WTOT - WFUM - WARI
      IF (KREGIM) THEN
        RNI(2) = (ZCO2 - 100. * X(4)) / 10.
        RNI(3) = (ZPH2 - 100. * X(3)) / 10.
        RNI(4) = (ZPO2 - 100. * X(2)) / 50.
        RNI(5) = (ZH2O - 100. * F(3)) / 10.
      ELSE
        RNI(2) = 100. * X(4)
        RNI(3) = 100. * X(3)
        RNI(4) = 100. * X(2)
        RNI(5) = 100. * F(3)
      ENDIF
C
      RETURN
      END
C
C
C
      SUBROUTINE FCTTD1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
