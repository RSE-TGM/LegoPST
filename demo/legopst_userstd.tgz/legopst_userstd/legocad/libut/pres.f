C**********************************************************************
C modulo pres.f
C tipo 
C release  3.1
C data 9/5/94
C reserver @(#)pres.f	3.1
C**********************************************************************
C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE PRESI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/PRES01/IBLOC
      COMMON/PRES02/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'PRES'/
C
      CALL PRESI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      DO I=1,NCEL
      WRITE(IFO,3001)I,IOB,I
 3001 FORMAT('QR',I2,A4,2X,
     $'--US-- POTENZA RESIDUA DI DECADIMENTO GRUPPO ',I2)
      ENDDO
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('QRES',A4,2X,
     $'--UA-- POTENZA RESIDUA TOTALE DI DECADIMENTO')
      WRITE(IFO,3005)IOB
 3005 FORMAT('QNE0',A4,2X,
     $'--IN-- POTENZA NEUTRONICA')
      RETURN
      END
      SUBROUTINE PRESI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/PRES01/IBLOC
      COMMON/PRES02/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      MAX=10
   1  WRITE(6,1001)MAX
 1001 FORMAT(10X,'N. DI GRUPPI DI RADIOISOTOPI (MAX=',I2,')?')
      READ(5,*)NCEL
      IF(NCEL.LE.0.OR.NCEL.GT.MAX)GO TO 1
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
C
      RETURN
      END
      SUBROUTINE PRESI1(IFUN,K,IBL1,IBL2,NSTATI,NUSCIT,NINGRE)
C
C      POTENZA RESIDUA A NUMERO DI RADIOISOTOPI VARIABILE(MAX=6)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      NRMAX=10
      GO TO(1,10),IFUN
    1 WRITE(6,1000)
 1000 FORMAT(//10X,'POTENZA RESIDUA - N.RADIOISOTOPI?')
    2 READ(5,*)NRI
 1001 FORMAT(I2)
      IF(NRI.LT.1.OR.NRI.GT.NRMAX)GO TO 2
      NSTATI=NRI
      NUSCIT=1
      NINGRE=1
      RETURN
C
   10 IF(K.GT.NRI)GO TO 20
      IF(K.EQ.1)WRITE(6,1002)
      WRITE(6,1003)K
      GO TO 50
   20 IF(K.EQ.NRI+2)GO TO 30
      WRITE(6,1004)
      WRITE(6,1005)
      GO TO 50
   30 WRITE(6,1006)
      WRITE(6,1007)
   50 RETURN
 1002 FORMAT(20X,'VARIABILI DI STATO')
 1003 FORMAT(10X,'POTENZA RESIDUA GR.RADIOISOT.',I1)
 1004 FORMAT(20X,'VARIABILE DI USCITA')
 1005 FORMAT(10X,'POTENZA RESIDUA')
 1006 FORMAT(20X,'VARIABILE DI INGRESSO')
 1007 FORMAT(10X,'POTENZA - FLUSSO NEUTRONICO')
      END
      SUBROUTINE PRESI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $ IBL1,IBL2,IER,CNXYU,TOL)
C
C      POTENZA RESIDUA
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER VAR
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
      CHARACTER*4 KRIS,TRIS
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      DATA KRIS/'KRIS'/,TRIS/'TRIS'/
      NRI=IV2-IV1-1
      GO TO(1,10),IFUN
C***SCRITTURA SIMBOLI DATI
    1 WRITE(14,1000)(KRIS,I,I=1,NRI),(TRIS,I,I=1,NRI)
 1000 FORMAT(3(4X,A4,I4,' =',10X,'*'),5X)
      RETURN
C***LETTURA DATI E MEMORIZZAZIONE
   10 NRI2=2*NRI
      DATI(ID2)=NRI
      READ(14,1001)
      READ(14,1001)(DATI(ID2+I),I=1,NRI2)
 1001 FORMAT(3(14X,F10.0,1X),5X)
      ID2=ID2+NRI2+1
C***NORMALIZZAZIONE
      NRII=NRI+2
      DO 20 I=1,NRII
      CNXYU(IV1+I-1)=W0*H0
   20 CONTINUE
C***TOLLERANZE STANDARD(1.E-4)
      RETURN
      END
      SUBROUTINE PRESC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
       DATA SccsID/'@(#)pres.f	3.1\t 3.1\t 9/5/94'/          
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C       POTENZA RESIDUA
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      NRI=DATI(IPD)
      GO TO (1,10,30),IFUN
C***TOPOLOGIA
    1 DO 5 I=1,NRI
      AJAC(I,I)=1.
      AJAC(I,NRI+2)=1.
      AJAC(NRI+1,I)=1.
   5  CONTINUE
      AJAC(NRI+1,NRI+1)=1.
      RETURN
C***DERIVATE E RESIDUI
   10 PRES=XYU(IXYU+NRI)
      PFN=XYU(IXYU+NRI+1)
      SP=0.
      DO 20 I=1,NRI
      PRI=XYU(IXYU+I-1)
      G  =DATI(IPD+I)
      T  =DATI(IPD+NRI+I)
      RNI(I)=(G*PFN-PRI)/T
      SP=SP+PRI
   20 CONTINUE
      RNI(NRI+1)=PRES-SP
      RETURN
C***JACOBIANO
   30 DO 40 I=1,NRI
      G=DATI(IPD+I)
      T=DATI(IPD+NRI+I)
      AJAC(I,I)=-1./T
      AJAC(I,NRI+2)=G/T
      AJAC(NRI+1,I)=1.
   40 CONTINUE
      AJAC(NRI+1,NRI+1)=-1.
      RETURN
      END
C
C
C******************************************************************************
C
      SUBROUTINE PRESD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
C
C