C=======================================================================
C* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
C*                                                                     *
C*                            modulo   R S E 0                         *
C*         Rotor thermal Stress Evaluator and Machine Life analisys               *
C*            per:  Rotori di turbina                                  *
C*                                                                     *
C* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
C ======================================================================
C
      SUBROUTINE RSE0D1()
C  serve solo per il nuovo LEGO
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0I3(IFO,IOB,DEBL)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NV = 28, IT = 19, IC = IT + 1, IR = NV - 1)
      CHARACTER*4 DEBL*80, IBLOC*8, IOB, MOD, NOMI(NV),
     $             TIPI(NV)*2, DESC(NV)*50
      LOGICAL ROTORE
C
      DATA (NOMI(I), TIPI(I), DESC(I), I=1,NV) /
     $  'TSRT','UA','TEMPERATURA ALLA SUPERFICIE DEL ROTORE',
     $  'TMRT','UA','TEMPERATURA MEDIA DEL ROTORE',
     $  'TFOR','UA','TEMPERATURA AL FORO INTERNO DEL ROTORE',
     $  'DTH0','UA','DT TEMPERATURA MEDIA ROTORE - TEMP. AL FORO',
     $  'DTH1','UA','DT TEMP. SUPERF. DEL ROTORE - TEMP. MEDIA ROTORE',
     $  'SV1S','UA','TENSIONE ALLA CAVA (O AL RACCORDO DISCO)',
     $  'SV0F','UA','TENSIONE AL FORO DEL ROTORE',
     $  'SRG1','UA','TENSIONE ALLA CAVA AMMISSIBILE PER LA REGOLAZIONE',
     $  'SRG0','UA','TENSIONE AL FORO AMMISSIBILE PER LA REGOLAZIONE',
     $  'SRT1','UA','TENSIONE ALLA CAVA LIMITE PER TRIP',
     $  'SRT0','UA','TENSIONE AL FORO LIMITE PER TRIP',
     $  'SXFB','UA','MARGINE PER ACCELERAZIONE / PRESA DI CARICO',
     $  'SXFE','UA','MARGINE PER DISCESA DI CARICO',
     $  'ENNE','UA','RIPETIBILITA'' DELLA MANOVRA',
     $  'WVAP','IN','PORTATA DI VAPORE IN TURBINA',
     $  'OMEG','IN','VELOCITA'' DI ROTAZIONE DELLA TURBINA',
     $  'TCAS','IN','TEMPERATURA DELLA CASSA DEL ROTORE',
     $  'HVAP','IN','ENTALPIA DEL VAPORE IN TURBINA',
     $  'PVAP','IN','PRESSIONE DEL VAPORE IN TURBINA',
C
     $  'TSUP','UA','TEMPERATURA ALLA SUPERFICIE INTERNA COLLETTORE',
     $  'TEST','UA','TEMPERATURA ALLA SUPERFICIE ESTERNA COLLETTORE',
     $  'TMED','UA','TEMPERATURA MEDIA SULLO SPESSORE DEL METALLO',
     $  'GSUP','UA','TENSIONE ALLA SUPERFICIE INTERNA COLLETTORE',
     $  'ENNE','UA','RIPETIBILITA'' DELLA MANOVRA',
     $  'WCOL','IN','PORTATA DI FLUIDO NEL COLLETTORE',
     $  'HCOL','IN','ENTALPIA DEL FLUIDO NEL COLLETTORE',
     $  'PCOL','IN','PRESSIONE DEL FLUIDO NEL COLLETTORE',
C
     $  'RSET','IN','RESET DELLA RIPETIBILITA'' E DELLE TEMPERATURE' /
C
      CALL RSE0I4(IOB,MOD,IBLOC,ROTORE)
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
      IF (ROTORE) THEN
        WRITE (IFO,3000) (NOMI(I), IOB, TIPI(I), DESC(I), I =  1, IT)
      ELSE
        WRITE (IFO,3000) (NOMI(I), IOB, TIPI(I), DESC(I), I = IC, IR)
      ENDIF
      WRITE (IFO,3000) NOMI(NV), IOB, TIPI(NV), DESC(NV)
      RETURN
 2999 FORMAT(A,2X,'BL.-',A4,'- **** REGOL. ',A4,' - ',A)
 3000 FORMAT(2A4,'  --',A2,'-- ',A)
      END
C
C ======================================================================
C
      SUBROUTINE RSE0I4 (IOB, MOD, IBLOC, ROTORE)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*4 IOB, MOD, IBLOC*8
      CHARACTER ICA
      LOGICAL ROTORE
C
      MOD = 'RSE0'
    2 WRITE(6,2999)
      READ(5,1999)ICA
      IF (ICA .EQ. '+') THEN
        ROTORE = .FALSE.
        IBLOC = ICA // MOD(1:3) // IOB
      ELSE IF (ICA .EQ. ' ') THEN
        ROTORE = .TRUE.
        IBLOC = MOD // IOB
      ELSE
        GO TO 2
      ENDIF
      RETURN
 1999 FORMAT(A)
 2999 FORMAT (//10X,
     $   'ASSEGNA UN CARATTERE PER IL TIPO DI COMPONENTE'
     $   /5X,' - STRESS TERMICI SU ROTORE DI TURBINA  ===> BLANK'
     $   /5X,' - STRESS TERMICI SU COLLETTORE CALDAIA ===>   + ')
      END
C
C ======================================================================
C
      SUBROUTINE RSE0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBL1,IBL2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (PIG = 3.141592653589793, PIG2 = 2. * PIG)
      PARAMETER (ENNZER = 1. / 95000.)
      INTEGER VAR(MX1,2)
      DIMENSION XYU(*),DATI(*),CNXYU(*),TOL(*)
      LOGICAL KREGIM, ROTORE
      CHARACTER *8 IBLOC
      PARAMETER (NR = 10, NR1 = NR-1, MR = NR*2-1, MR1 = MR-1)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON /REGIME/ KREGIM
C
      COMMON /AUSIL1/ NSTATI,NUSCIT,NINGRE
C
      DIMENSION DATIMP (10), R(19), D(10)
      DATA SMAX, SMIN, TRAZ /0., 0., 0./
C
      WRITE (IBLOC, 1000) IBL1, IBL2
      ROTORE = IBLOC(1:1) .NE. '+'
C
      GO TO (100, 200) IFUN
C
  100 IF (ROTORE) THEN
        WRITE (14, 500) 'R.intern', 'R.estern', 'Conducib', 'Tipo Imp'
      ELSE
        WRITE (14, 500) 'R.intern', 'R.estern', 'Conducib', 'Norma n.',
     $                  'Tipo mat', 'N.Tubaz.', 'Coeff.CS', 'Beta p  ',
     $                  'Beta T  '
      ENDIF
      RETURN
C
C---lettura e memorizzazione dati
C
  200 READ(14,501)
      IF (ROTORE) THEN
        READ(14,501) RINT, REST, COND, TIMP
        AROT = 1.
      ELSE
        READ(14,501) RINT, REST, COND, ANOR, TIMP, ANTU, WMOLT, BETAP,
     $               BETAT
        ANTU = ANINT(ANTU)
        IF (ANTU.LT.1.) ANTU = 1.
        ANOR = ANINT(ANOR)
        AROT = 0.
        IF (WMOLT .LE. 0.) WMOLT = 1.
        IF (BETAP .LE. 0.) THEN
          IF (INT(ANOR).EQ.1) THEN
            BETAP = 2.9
          ELSE IF (INT(ANOR).EQ.2) THEN
            BETAP = 3.1
          ELSE
            WRITE (*, *) 'ERRORE NELLA ROUTINE RSE0I2'
            STOP 'TIPO DI NORMA SCONOSCIUTA - IMPOSSIBILE PROCEDERE'
          END IF
        END IF
        IF (BETAT .LE. 0.) BETAT = 2.0
      ENDIF
      TIMP = ANINT(TIMP)
C
      DATI(ID2   ) = RINT
      DATI(ID2+ 1) = REST
      DATI(ID2+ 2) = COND
      DATI(ID2+ 3) = TIMP
      IF (ROTORE) THEN
        CALL RSE0DR (TIMP, DATIMP)
        DO 6 I = 1, 10
    6     DATI (ID2+3+I) = DATIMP(I)
      ELSE
        DATI(ID2+ 4) = ANTU
        DATI(ID2+ 5) = ANOR
        DATI(ID2+ 6) = WMOLT
        CALL RSE0DC (TIMP, ANOR, DATIMP)
        DATI(ID2+ 7) = BETAT
        DATI(ID2+ 8) = BETAP
        DO 7 I = 1, 5
    7     DATI (ID2+8+I) = DATIMP(I)
        DATI(ID2+65) = DATIMP(6)
        DATI(ID2+66) = DATIMP(7)
C  SUPERFICIE (altezza = 1. m)
	DATI(ID2+69) = PIG2 * RINT
      ENDIF
      DATI(ID2+14) = AROT
      DATI(ID2+15) = SMAX
      DATI(ID2+16) = SMIN
      DATI(ID2+17) = TRAZ
      DATI(ID2+18) = 0.
      DATI(ID2+19) = ENNZER
      DATI(ID2+20) = 0.
C
      DATI(ID2+80) = SMAX
      DATI(ID2+81) = SMIN
      DATI(ID2+82) = TRAZ
      DATI(ID2+83) = 0.
      DATI(ID2+84) = ENNZER
      DATI(ID2+85) = 0.
C
C---   CALCOLO RAGGI CONFINI
C
      IF (ROTORE) THEN
        RA = RINT * 1000.
        RB = REST * 1000.
      ELSE
C  NOTA: per i collettori (e assimilati) uso il sistema MKS
        RB = RINT
        RA = REST
      END IF
      XX = (RA-RB) / FLOAT(MR*MR-1)
      B1 = RB - XX
      DO 10 I = 3, MR, 2
        N = MR - I + 1
        R(N) = XX * FLOAT(I*I) + B1
   10 CONTINUE
C
C---   CALCOLO RAGGI CENTRI FETTE
C
      R(1) = RA
      R(MR) = RB
      DO 20 I = 2, MR1, 2
        R(I) = .5 * (R(I+1) + R(I-1))
   20 CONTINUE
C
C---MATRICE D PER IL CALCOLO DELLA TEMPERATURA MEDIA
C
      CCT = (RB-RA)*(RB+RA)
      D(1) = R(1)*(R(3)-R(1))/CCT
      L = 1
      DO 70 I = 3, MR1, 2
         L = L+1
         D(L) = R(I)*(R(I+2)-R(I-2))/CCT
   70 CONTINUE
      D(NR) = R(MR)*(R(MR)-R(MR-2))/CCT
C
      DO 8 I = 1, 19
    8     DATI (ID2+30+I) = R(I)
      DO 9 I = 1, 10
    9     DATI (ID2+49+I) = D(I)
      ID2 = ID2 + 88
C  (cfr. il file "LIS_DATI.LIS" che contiene il significato di tutti
C  gli elementi del vettore DATI)
C
C---costanti di normalizzazione
C
      IF (ROTORE) THEN
        CNXYU(IV1  ) = T0
        CNXYU(IV1+1) = T0
        CNXYU(IV1+2) = T0
        CNXYU(IV1+3) = T0
        CNXYU(IV1+4) = T0
        CNXYU(IV1+5) = 10.
        CNXYU(IV1+6) = 10.
        CNXYU(IV1+7) = 10.
        CNXYU(IV1+8) = 10.
        CNXYU(IV1+9) = 10.
        CNXYU(IV1+10)= 10.
        CNXYU(IV1+11)= 100.
        CNXYU(IV1+12)= 100.
        CNXYU(IV1+13)= 1.E+5
        CNXYU(IV1+14)= W0
        CNXYU(IV1+15)= 300.
        CNXYU(IV1+16)= T0
        CNXYU(IV1+17)= H0
        CNXYU(IV1+18)= P0
        CNXYU(IV1+19)= 1.
      ELSE
        CNXYU(IV1  ) = T0
        CNXYU(IV1+1) = T0
        CNXYU(IV1+2) = T0
        CNXYU(IV1+3) = 10.
        CNXYU(IV1+4) = 1.E+5
        CNXYU(IV1+5) = W0
        CNXYU(IV1+6) = H0
        CNXYU(IV1+7) = P0
        CNXYU(IV1+8) = 1.
      END IF
C
      RETURN
  500 FORMAT(3(4X, A8, ' =', 10X, '*'))
  501 FORMAT(3(14X, F10.0, 1X))
 1000 FORMAT(2A4)
      END
C
C ======================================================================
C
      SUBROUTINE RSE0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (ENNZER = 1. / 95000.)
      PARAMETER (PIG = 3.141592653589793)
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      PARAMETER (NR = 10, NR1 = NR-1, MR = NR*2-1, MR1 = MR-1)
      DIMENSION  AT(10),  BT(10), CT(10)
      DIMENSION   R(20),  BB(10)
      DIMENSION   A(10),   B(10),  C(10),  D(10)
      DIMENSION TEA(10), DDDATI(12)
      CHARACTER*8 IBLOC
      LOGICAL ROTORE
      PARAMETER (GG = 9.80665)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT                          !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C---
      COMMON /NEQUAZ/ NEQMOD
C
C
C____________ COEFFICIENTI PER DEFINIRE LO SCAMBIO FLUIDO PARETE
C             COPIATI DA GAMTERT
        DATA CCW/4.0125/,CCV/7.495/,AAW/0.0375/,AAV/0.0167E-5/
C
      NEQMOD = 0
C  E' un modulo di regolazione...
      IF (IFUN .NE. 2) RETURN
C
C   CALCOLO RESIDUI
C
C---DECODIFICA VARIABILI E DATI
C
      RINT = DATI(IPD   )
      REST = DATI(IPD+ 1)
      COND = DATI(IPD+ 2)
      TIMP = DATI(IPD+ 3)
C
      CP   = DATI(IPD+ 9)
      RO   = DATI(IPD+10)
      ALFA = DATI(IPD+11)
      EE   = DATI(IPD+12)
      POIS = DATI(IPD+13)
      AROT = DATI(IPD+14)
      ROTORE = INT(AROT) .EQ. 1
      DO 8 I = 1, 19
    8   R(I) = DATI (IPD+30+I)
      DO 9 I = 1, 10
    9   D(I) = DATI (IPD+49+I)
C
      IF (ROTORE) THEN
        BETA = DATI(IPD+ 7)
C--BIP espresso in (kg/mm^2)*s^2
        BIP  = DATI(IPD+ 8)
C
        GK = COND/(1000.*4186.)
C--PP espresso in mm^2
        PP = GK*DTINT/(CP*RO)
C
C  AEC = alfa * E / (1-ni)
C--AEC espresso in kg/mm^2
        AEC = 0.34310001
C
        TCAV  = XYU(IXYU  ) * T0
        TMRT  = XYU(IXYU+1) * T0
        TFOR  = XYU(IXYU+2) * T0
        DTH0  = XYU(IXYU+3) * T0
        DTH1  = XYU(IXYU+4) * T0
        GCAV  = XYU(IXYU+5) * 10.
        GFOR  = XYU(IXYU+6) * 10.
        SRG1  = XYU(IXYU+7) * 10.
        SRG0  = XYU(IXYU+8) * 10.
        SRT1  = XYU(IXYU+9) * 10.
        SRT0  = XYU(IXYU+10) * 10.
        SXFB  = XYU(IXYU+11) * 100.
        SXFE  = XYU(IXYU+12) * 100.
C
        ENNE  = XYU(IXYU+13) * 1.E+5
        WVAP  = XYU(IXYU+14) * W0
        OMEG  = XYU(IXYU+15) * 300.
        TCAS  = XYU(IXYU+16) * T0
        HVAP  = XYU(IXYU+17) * H0
        PVAP  = XYU(IXYU+18) * P0
        ISET = NINT(XYU(IXYU+19))
      ELSE
C - COLLETTORI
        ANTU  = DATI(IPD+ 4)
        ANOR  = DATI(IPD+ 5)
        WMOLT = DATI(IPD+ 6)
        BETAT = DATI(IPD+ 7)
        BETAP = DATI(IPD+ 8)
        UTS   = DATI(IPD+65)
        SNER  = DATI(IPD+66)
        SUP   = DATI(IPD+69)
        GSTAZ = DATI(IPD+88)
C...variabili...
        TSUP = XYU(IXYU  ) * T0
        TEST = XYU(IXYU+1) * T0
        TMED = XYU(IXYU+2) * T0
        GSUP = XYU(IXYU+3) * 10.
        ENNE = XYU(IXYU+4) * 1.E+5
        WCOL = XYU(IXYU+5) * W0
        HCOL = XYU(IXYU+6) * H0
        PCOL = XYU(IXYU+7) * P0
        ISET = NINT(XYU(IXYU+8))
C  versione 2.1
	TCEL=TMED-273.15
        IF (COND.LE.0.) COND = RSE0XX(INT(TIMP), 14, TCEL)
        CP = RSE0XX(INT(TIMP), 11, TCEL)
        IF (CP.LE.0. .OR. COND.LE.0.) THEN
          WRITE (*, *) 'Errore in RSE0C1 - impossibile procedere'
          RETURN
        END IF
        PP = COND * DTINT / (CP * RO)
      ENDIF
C
C---    INIZIALIZZAZIONE TEMPERATURE E SOLLECITAZIONI
C
      IF (ROTORE) THEN
C - ROTORI
        OMEG = (2*3.14/60)*OMEG
        SCF = BIP*OMEG*OMEG
      ELSE
C - COLLETTORI - uso le stesse variabili (locali)
        PVAP = PCOL
        HVAP = HCOL
      END IF
C
C---   INIZIALIZZAZIONE TEMPERATURE
C
      IF (PVAP .LT. 610.) THEN
        PVAP = 610.
      ELSE IF (PVAP .GT. 400.E5) THEN
        PVAP = 400.E5
      END IF
      IF (HVAP .GT. 4200.E3) THEN
        HVAP = 4200.E3
      ELSE IF (HVAP .LT. 1.E3) THEN
        HVAP = 1.E3
      END IF
      SC = SHEV(PVAP, HVAP, 1)
      TC = TEV(PVAP, SC, 1)
C
      IF (ROTORE .AND. WVAP.LE.0.1) THEN
        TCC = TCAS
      ELSE
        TCC = TC
      END IF
C  dati per il calcolo delle sollecitazioni
      IF (.NOT. ROTORE) THEN
        DDDATI(1) = REST
        DDDATI(2) = RINT
        DDDATI(3) = ALFA
        DDDATI(4) = EE
        DDDATI(5) = POIS
        DDDATI(6) = BETAT
        DDDATI(7) = BETAP
        DDDATI(8) = ANOR
        DDDATI(9) = UTS
        DDDATI(10) = SNER
        DDDATI(11) = 210000.
        DDDATI(12) = TIMP
      END IF
C
      IF (KREGIM) GOTO 1111
C
C-----------------------------------------------------------------------
C---CALCOLO DEL TRANSITORIO
C-----------------------------------------------------------------------
C
      WRITE (IBLOC, 112) IBL1, IBL2
  112 FORMAT(2A4)
C
C  reset:
      IF (ISET .EQ. 1) THEN
        DATI(IPD+19) = ENNZER
        DATI(IPD+20) = 0.
        DATI(IPD+84) = ENNZER
        DATI(IPD+85) = 0.
        DO 111 J = 1, 4
          DATI(IPD +14 +J) = 0.
  111     DATI(IPD +79 +J) = 0.
        IF (ROTORE) THEN
	    PC=0.
	    CALL RSE0SR(TIMP,TCC,TCC,TCC,PC,PC,
     &              DTH1,DTH0,CSRG1,CSRG0,CSRT1,CSRT0,SXFB,SXFE)
          RNI(1) = TCC / T0
          RNI(2) = TCC / T0
          RNI(3) = TCC / T0
          RNI(4) = DTH0 / T0
          RNI(5) = DTH1 / T0
          RNI(6) = 0. / 10.
          RNI(7) = 0. / 10.
          RNI(8) = CSRG1 / 10.
          RNI(9) = CSRG0 / 10.
          RNI(10)= CSRT1 / 10.
          RNI(11)= CSRT0 / 10.
          RNI(12)= SXFB / 100.
          RNI(13)= SXFE / 100.
          RNI(14)= 95000. / 1.E+5
        ELSE
          RNI(1) = TCC / T0
          RNI(2) = TCC / T0
          RNI(3) = TCC / T0
C  soll. "statica" (dovuta solo alla pressione)
          PRESS = PVAP / 1.0E+6
          CALL RSE0SS(DDDATI, TCC, TCC, PRESS, SIGMA)
          GSTAZ = SIGMA / GG
          RNI(4) = GSTAZ / 10.
          RNI(5) = 95000. / 1.E+5
        END IF
C  reset delle temperature
        DO 1334 J = 1, 10
          IF (ITERT.LE.0) DATI(IPD +20 +J) = TCC
 1334     DATI(IPD +69 +J) = TCC
        IF (.NOT. ROTORE) THEN
          IF (ITERT.LE.0) THEN
            DATI(IPD+67) = TCC
            DATI(IPD+68) = TCC
            DATI(IPD+88) = GSTAZ
          END IF
          DATI(IPD+86) = TCC
          DATI(IPD+87) = TCC
        END IF
        RETURN
      END IF
C
C  ripesco i valori memorizzati
      SMAX = DATI(IPD+15)
      SMIN = DATI(IPD+16)
      TRAZ = DATI(IPD+17)
      TSTAM = DATI(IPD+18)
      CPRE = DATI(IPD+19)
      CATT = DATI(IPD+20)
      IF (.NOT.ROTORE) THEN
        TSMAX = DATI(IPD+67)
        TSMIN = DATI(IPD+68)
      END IF
C
C---CALCOLO MATRICI PER IL SISTEMA LINEARE
C
C--    MATRICI A, B, C
C
      DO 30 I = 2, NR1
        LR = 2*I
        AA = PP*R(LR-2)/R(LR-1)/(R(LR-1)-R(LR-3))/(R(LR)-R(LR-2))
        CC = PP*R(LR)/R(LR-1)/(R(LR+1)-R(LR-1))/(R(LR)-R(LR-2))
        AT(I) = AA
        CT(I) = CC
        BT(I) = 1. + AA + CC
   30 CONTINUE
C
C---A, B, C SUI CONTORNI
      AT(1) = 0.
      CT(1) = PP*R(2)/R(1)/(R(3)-R(1))/(R(2)-R(1))
      BT(1) = 1. + CT(1)
C
      CT(NR) = 0.
      AT(NR) = PP*R(MR1)/R(MR)/(R(MR)-R(MR-2))/(R(MR)-R(MR1))
      BT(NR) = 1. + AT(NR)
C
C---RIDEFINIZIONE DI B (METODO DI GAUSS)
C
      BB(1) = BT(1)
      DO 40 I = 2, NR
        BB(I) = BT(I) - AT(I)*CT(I-1)/BB(I-1)
   40 CONTINUE
C
C---------MATRICI DEFINITIVE-------
C
      A(1) = 0
      DO 50 I = 2, NR
        A(I) = AT(I) / BB(I-1)
   50 CONTINUE
      C(NR) = 0.
      B(NR) = BB(NR)
      DO 60 I = 1, NR1
        B(I) = 1. / BB(I)
        C(I) = CT(I) / BB(I)
   60 CONTINUE
C
C-- Coefficiente di scambio
      IF (ROTORE) THEN
        CS = RSE0CS(TIMP, WVAP, TCAS, OMEG, PVAP,
     $              DATI,  IPD, DTINT)
      ELSE
        ESSE = SHEV(PVAP, HVAP, 1)
        RO = ROEV(PVAP, ESSE, 1)
        IF (PVAP .LE. 221.2E5) THEN
          TITO = YEV(PVAP, ESSE, 1)
        ELSE
          TITO = 1.
        END IF
        TWALL = DATI(IPD +20)
        D0 = 2. * RINT
CC        CRIG = 1.
	GI = WCOL / (ANTU * RINT*RINT*PIG)
        VEL= MAX(ABS(GI/RO), 0.1)
CC        QU = ABS((TWALL - TC) * SUP * CS)
CC        CALL GAM01(PVAP, HVAP, ESSE, TC, RO, TITO, TWALL, D0, CRIG,
CC     $             GI, QU, SUP, COESCA)
C
C
          IF(TITO.LE.0) THEN
C___ ACQUA SOTTORAFFREDDATA
          GAMI=3000.*VEL**0.8+10.
          GO TO 130
          ELSE IF(TITO.LT.1.) THEN
C___ MISCELA
          GAMI=15000.
          GO TO 130
          ELSE IF(TITO.GE.1.) THEN
C___ VAPORE SURRISCALDATO
          GAMI=500.*VEL**0.8+10.
          ENDIF
 130      CS=WMOLT*GAMI
          CS=CS*PP/COND/(R(MR1)-R(MR))
      END IF
C          IF(ITERT.EQ.0.AND.IFUN.EQ.2) THEN
C            WRITE(6,*)'   *** RSE0  CS', CS
C          ENDIF
C
C---    CALCOLO TEMPERATURE E SOLLECITAZIONI
C
      DO 1000 J = 1, 10
 1000   TEA(J) = DATI(IPD +20 +J)
C
      DO 1100 J = 2, 10
 1100   TEA(J) = TEA(J) + A(J)*TEA(J-1)
      TEA(10) = (TEA(10) + CS*TCC) / (B(10)+CS)
      TM = TEA(10)*D(10)
C
      DO 1200 J = 9, 1, -1
        TEA(J) = B(J)*TEA(J) + C(J)*TEA(J+1)
 1200   TM = TM +TEA(J)*D(J)
C
      TEX1 = TEA(10)
      TEX2 = TEA(1)
C     IF(ITERT.EQ.0.AND.IFUN.EQ.2) THEN
C        WRITE(6,*)'   *** RSE0  TEA(1), TEA(10), TM', TEA(1), TEA(10), 
C    $   TM, AEC, BETA
C     ENDIF
C
      IF (ROTORE) THEN
C - ROTORI
        STF = AEC*(TM-TEA(1))
        SEF = SQRT(ABS(STF*STF +SCF*SCF +STF*SCF))
        STC = AEC*BETA*(TM-TEA(10))
C
        CALL RSE0FR (TM, SEF, IBLOC)
        CALL RSE0MX (TSTAM, STC, SMAX, SMIN, TRAZ, CPRE, CATT, IBLOC)
C
      ELSE
C
C - COLLETTORI
C - Calcolo sollecitazioni (e tutto il resto)
C   NOTA: le tensioni sono in [MPa] per cui anche le pressioni:
        PRESS = PVAP / 1.0E+6
        CALL RSE0SX(DDDATI, TM, TEA(10), PRESS, TSTAM, CPRE, GSTAZ,
     $              SMAX, SMIN, TSMAX, TSMIN, TRAZ, GSUP, CATT, IBLOC)
      END IF
C
      IF (CPRE .GT. ENNZER) THEN
        ENNEC = 1. / (CPRE + CATT)
      ELSE IF (CATT .GT. ENNZER) THEN
        ENNEC = 1. / CATT
      ELSE
        ENNEC = 1. / CPRE
      ENDIF
C
      IF (ROTORE) THEN
	  CALL RSE0SR(TIMP,TEX1,TM,TEX2,STC,SEF,
     &              DTH1,DTH0,CSRG1,CSRG0,CSRT1,CSRT0,SXFB,SXFE)
        RNI(1) = TEX1 / T0
        RNI(2) = TM / T0
        RNI(3) = TEX2 / T0
        RNI(4) = DTH0 / T0
        RNI(5) = DTH1 / T0
        RNI(6) = STC / 10.
        RNI(7) = SEF / 10.
        RNI(8) = CSRG1 / 10.
        RNI(9) = CSRG0 / 10.
        RNI(10)= CSRT1 / 10.
        RNI(11)= CSRT0 / 10.
        RNI(12)= SXFB / 100.
        RNI(13)= SXFE / 100.
        RNI(14)= ENNEC / 1.E+5
      ELSE
        RNI(1) = TEX1 / T0
        RNI(2) = TEX2 / T0
        RNI(3) = TM / T0
        RNI(4) = GSUP / 10.
        RNI(5) = ENNEC / 1.E+5
      END IF
C
      DO 1300 J = 1, 10
 1300   DATI(IPD +69 +J) = TEA(J)
C
C  salvataggio dati
      DATI(IPD+80) = SMAX
      DATI(IPD+81) = SMIN
      DATI(IPD+82) = TRAZ
      DATI(IPD+83) = TSTAM
      DATI(IPD+84) = CPRE
      DATI(IPD+85) = CATT
      IF (.NOT. ROTORE) THEN
        DATI(IPD+86) = TSMAX
        DATI(IPD+87) = TSMIN
      END IF
C
      IF (ITERT .LE. 0) THEN
C  aggiorno il vettore delle T calcolate SOLO alle iterazioni "buone"
        DO 113 J = 1, 10
  113     DATI(IPD +20 +J) = DATI(IPD +69 +J)
C  faccio lo stesso con SMAX, SMIN, TRAZ, TSTAM, CPRE, CATT
        DO 114 J = 1, 6
  114     DATI(IPD +14 +J) = DATI(IPD +79 +J)
        IF (.NOT.ROTORE) THEN
C  piu' TSMAX e TSMIN (solo per i collettori)
          DO 115 J = 1, 2
  115       DATI(IPD +66 +J) = DATI(IPD +85 +J)
        END IF
      END IF
C
      RETURN
C
C-----------------------------------------------------------------------
C      CALCOLO DELLO STAZIONARIO
C-----------------------------------------------------------------------
C
C---CALCOLO RESIDUI
C
 1111 CONTINUE
C
      PC = 0.
      ENNEC = 1. / DATI(IPD+19)
C
C
      IF (ROTORE) THEN
	  CALL RSE0SR(TIMP,TCC,TCC,TCC,PC,PC,
     &              DTH1,DTH0,CSRG1,CSRG0,CSRT1,CSRT0,SXFB,SXFE)
        XYU(IXYU)   = TCC / T0
        XYU(IXYU+1) = TCC / T0
        XYU(IXYU+2) = TCC / T0
        XYU(IXYU+3) = DTH0 / T0
        XYU(IXYU+4) = DTH1 / T0
        XYU(IXYU+5) = PC / 10.
        XYU(IXYU+6) = PC / 10.
        XYU(IXYU+7) = CSRG1 / 10.
        XYU(IXYU+8) = CSRG0 / 10.
        XYU(IXYU+9) = CSRT1 / 10.
        XYU(IXYU+10)= CSRT0 / 10.
        XYU(IXYU+11)= SXFB / 100.
        XYU(IXYU+12)= SXFE / 100.
        XYU(IXYU+13)= ENNEC / 1.E+5
      ELSE
        XYU(IXYU)   = TCC / T0
        XYU(IXYU+1) = TCC / T0
        XYU(IXYU+2) = TCC / T0
C  soll. "statica" (dovuta solo alla pressione)
        PRESS = PVAP / 1.0E+6
        CALL RSE0SS(DDDATI, TCC, TCC, PRESS, SIGMA)
        GSTAZ = SIGMA / GG
        XYU(IXYU+3) = GSTAZ / 10.
        XYU(IXYU+4) = ENNEC / 1.E+5
      END IF
C
C  memorizzo nel vettore DATI i valori utili per proseguire
C  col transitorio:
      DO 1333 J = 1, 10
        DATI(IPD +69 +J) = TCC
 1333   DATI(IPD +20 +J) = TCC
      IF (.NOT. ROTORE) THEN
        DATI(IPD+67) = TCC
        DATI(IPD+68) = TCC
        DATI(IPD+86) = TCC
        DATI(IPD+87) = TCC
        DATI(IPD+88) = GSTAZ
      END IF
C
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0MX(TSTAM, STC, SMAX, SMIN, TRAZ, CPRE, CATT, IBLOC)
C
C    DETERMINA E AGGIORNA I VALORI MASSIMO E MINIMO DELLA
C    SOLLECITAZIONE IN FONDO CAVA - PER I ROTORI
C - ex SIGMAX
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      CHARACTER*8 IBLOC
      CATT = RSE0CV (SMAX, SMIN)
                                
      IF (STC .LT. 0.) THEN
        IF (TRAZ .EQ. 0) THEN
            TRAZ = -1.
        ELSE IF (TRAZ .EQ. 1) THEN
            TRAZ = -2.
        ELSE IF (TRAZ .EQ. 2) THEN
            CALL RSE0FC (TSTAM, CPRE, CATT, SMAX, SMIN, TRAZ, IBLOC)
        ENDIF
      ELSE IF (STC .GT. 0.) THEN
        IF (TRAZ .EQ. 0) THEN
             TRAZ =  1.
        ELSE IF (TRAZ .EQ. -1.) THEN
            TRAZ =  2.
        ELSE IF (TRAZ .EQ. -2.) THEN
            CALL RSE0FC (TSTAM, CPRE, CATT, SMAX, SMIN, TRAZ, IBLOC)
        ENDIF
      ENDIF
           
      IF (STC .GT. SMAX) SMAX = STC
      IF (STC .LT. SMIN) SMIN = STC
                                   
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0FC (TSTAM, CPRE, CATT, SMAX, SMIN, TRAZ, IBLOC)
C
C    Routine invocata al termine di ogni ciclo di fatica
C - ex FINCIC
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*8 IBLOC
      PARAMETER (UNO = 1.)
      PARAMETER (GRAV = 9.80665)
C
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT                          !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
C
      IF (TEMPO - TSTAM .LT. 4.*DTINT) RETURN
      IF (SMAX .LT. 3.6 .AND. SMIN .GT. -3.6) GOTO 1
C
      IF (ITERT.LE.0) THEN
        IF (IBLOC(1:1).NE.'+') THEN
          GG = GRAV
        ELSE
          GG = 1.
        END IF
        PRINT *
        PRINT 2, TEMPO
        PRINT *, '     MODULO   T S M L   - BLOCCO ',IBLOC
        PRINT *, '     RICONOSCIUTO TERMINE CICLO DI FATICA'
        PRINT *
C
        IF (TRAZ .GT. 0.) THEN
          PRINT *, '            SIGMA MASSIMA CICLO = ', SMAX/GG
          PRINT *, '            SIGMA MINIMA  CICLO = ', SMIN/GG
        ELSE
          PRINT *, '            SIGMA MINIMA  CICLO = ', SMIN/GG
          PRINT *, '            SIGMA MASSIMA CICLO = ', SMAX/GG
        ENDIF
        IF (CATT .LE. 0.) THEN
          PRINT *, '    CICLO CON RIPETIBILITA''   INFINITA'
        ELSE
          PRINT *, '    CICLO CON RIPETIBILITA'' ', NINT(1./CATT)
        ENDIF
      ENDIF
C
    1 CPRE = CPRE + CATT
      CATT = 0.
      SMAX = 0.
      SMIN = 0.
      TRAZ = SIGN (UNO, -TRAZ)
      TSTAM = TEMPO
C
      RETURN
    2 FORMAT (7X, '************  T = ', F10.3, ' s')
      END
C
C ======================================================================
C
      SUBROUTINE RSE0FR(TM, SEF, IBLOC)
C
C---Routine che effettua la verifica della frattura
C    fragile in corrispondenza del foro rotore.
C   Qualora la sollecitazione equivalente al foro risultasse maggiore
C    o uguale a quella ammissibile,compare un messaggio che segnala
C    l'accaduto.
C
C     IMPLICIT DOUBLE PRECISION (A-H, O-Z)                               !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      CHARACTER*8 IBLOC
C
      SEF2 = RSE0AQ (TM-273.15)
      IF (ITERT.LE.0) THEN
        IF (SEF .GT. SEF2) THEN
          PRINT *
          PRINT *, '     MODULO   T S M L   - BLOCCO ',IBLOC
          PRINT *,'    LA SOLLECITAZIONE AL FORO SUPERA'
          PRINT *,'       IL VALORE AMMISSIBILE !!!!'
          PRINT *
          PRINT *,'             SEF AMMISS.:',SEF2
          PRINT *,'             SEF ATTUALE:',SEF
          PRINT *
          PRINT *,'        SI VERIFICA FRATTURA FRAGILE'
          PRINT *,'    IN CORRISPONDENZA DEL FORO ROTORE !!!'
          PRINT *
CD         STOP
        ENDIF
      ENDIF
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0AQ (TM)                                         !SNGL
C      DOUBLE PRECISION FUNCTION RSE0AQ (TM)                             !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C   La funzione RSE0AQ
C   (ex SEFAMM = Sigma Equivalente Foro AMMissibile -
C           ora  sigmA eQuivalente foro ammissibile) deve resti-
C     tuire il valore massimo ammissibile (in Kg/mm^2) per la tensione
C     equivalente [secondo Von Mises] al foro del rotore, in funzione
C     della temperatura media del rotore stesso (TM, in ^C).
C
C
      IF (TM .LE. 40.) THEN
        RSE0AQ =  0.177* TM+ 17.
      ELSE
        RSE0AQ = -0.019* TM+ 42.5
      ENDIF
C
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0DR (TIMP, DATIMP)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION DATIMP(10), VALORI (5,6)
C
C     Assegna i dati caratteristici dei singoli impianti - ROTORI
C
C---CP espresso in kcal/kg*^C
      PARAMETER (CP=.1378)
C---RO espresso in kg/mm^3
      PARAMETER (RO=7.75E-6)
C -i segg. sono in [mks]-
      PARAMETER (ALFA = 12.E-06, EE = 210000., POIS = 0.3)
C
C   VALORI = Matrice dei dati impianto (DATIMP)
C            (VEDI PROGRAMMI CFST E SAPT/SMPT PER IL SIGNIFICATO)
C      BIP ESPRESSO IN (kg/mm^2)*s^2
C
C                        S07         S09     S11  BETA      BIP
C
      DATA  VALORI  /0.712920E-4, 4.275E-7, 1.0, 2.15, 0.92680385E-6,
     $               0.492780E-4, 6.000E-7, 3.2, 2.70, 0.16867951E-5,
     $               0.696088E-4, 2.550E-7, 1.0, 2.31, 0.96007773E-6,
     $               0.499389E-4, 3.450E-7, 3.2, 4.05, 0.16867951E-5,
     $               0.712920E-4, 4.275E-7, 1.0, 1.73, 0.92680385E-6,
     $               0.492780E-4, 6.000E-7, 3.2, 2.16, 0.16867951E-5/
C
      PRINT *,'         MODULO    T S M L'
      PRINT *,'         THERMAL STRESS AND MACHINE LIFE ANALYSIS'
                                                                 
      IF (TIMP.EQ.1) THEN
        PRINT *,'         IMPIANTO TOSI 320 MW - STADIO AP'
      ELSE IF (TIMP.EQ.2) THEN
        PRINT *,'         IMPIANTO TOSI 320 MW - STADIO MP'
      ELSE IF (TIMP.EQ.3) THEN
        PRINT *,'         IMPIANTO TOSI 660 MW - STADIO AP'
      ELSE IF (TIMP.EQ.4) THEN
        PRINT *,'         IMPIANTO TOSI 660 MW - STADIO MP'
      ELSE IF (TIMP.EQ.5) THEN
        PRINT *,'         IMPIANTO ANSALDO 320 MW - STADIO AP'
      ELSE IF (TIMP.EQ.6) THEN
        PRINT *,'         IMPIANTO ANSALDO 320 MW - STADIO MP'
      ELSE
        CALL RSE0DAT (TIMP, DATIMP(1), DATIMP(4))
        RETURN
      ENDIF
C
      DO 1 I = 1, 5
    1   DATIMP (I) = VALORI (I, INT(TIMP))
      DATIMP(6) = CP
      DATIMP(7) = RO
      DATIMP(8) = ALFA
      DATIMP(9) = EE
      DATIMP(10) = POIS
C
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0DC (TIMP, ANOR, DATIMP)
C
C     Assegna i dati caratteristici dei singoli impianti - COLLETTORI
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION DATIMP(7)
C
      ILTIPO = INT(TIMP)
      PRINT *, ' Routine RSE0DC - MATERIALE N.', ILTIPO
      IF (ILTIPO.EQ.1) THEN
        PRINT *,
     $   ' *** Acciaio al carbonio (%C <= 0.30) (A106-C) ***'
      ELSE IF (ILTIPO.EQ.2) THEN
        PRINT *,
     $   ' *** Acciaio basso legato 2 1/4 Cr - 1 Mo (A335-P22) ***'
      ELSE IF (ILTIPO.EQ.3) THEN
        PRINT *,
     $   ' *** Acciaio basso legato 1 Cr - 1/2 Mo (A335-P12) ***'
      ELSE
C  stop:
        CALL RSE0DAC()
      ENDIF
C  i seguenti sono i valori a temperatura ambiente (alcuni restano
C  costanti)
      CP = RSE0XX(ILTIPO, 8, DUM)
      RO = RSE0XX(ILTIPO, 9, DUM)
      ALFA = RSE0XX(ILTIPO, 7, DUM)
      EE = RSE0XX(ILTIPO, 1, DUM)
      POIS = RSE0XX(ILTIPO, 6, DUM)
      UTS  = RSE0XX(ILTIPO, 4, DUM)
      SNER = RSE0XX(ILTIPO, 5, DUM)
      IF (CP.EQ.-1 .OR. RO.EQ.-1 .OR. ALFA.EQ.-1 .OR. EE.EQ.-1
     $          .OR. POIS.EQ.-1 .OR. UTS.EQ.-1 .OR. SNER.EQ.-1) THEN
        WRITE (*, *) 'ERRORE NELLA ROUTINE RSE0DC'
        STOP 'DATI INCOMPLETI O ERRATI - IMPOSSIBILE PROCEDERE'
      END IF
      DATIMP(1) = CP
      DATIMP(2) = RO
      DATIMP(3) = ALFA
      DATIMP(4) = EE
      DATIMP(5) = POIS
      DATIMP(6) = UTS
      DATIMP(7) = SNER
C
      RETURN
      END
C
C ======================================================================
C
C      SUBROUTINE RSE0DAT (TIMP, DATCOE, DATSFO)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      DIMENSION DATCOE(3), DATSFO(2)
C
C      PRINT *
C      PRINT *, '    SUBROUTINE RSE0DAT - (DATI IMPIANTO * MODULO RSE0)'
C      PRINT *
C      PRINT *, '    ATTENZIONE:'
C      PRINT *, '       IL TIPO DI IMPIANTO (DATO GEOMETRICO TIMP) NON'
C      PRINT *, '       E'' COMPRESO FRA 1 E 6 (O NON E'' INTERO) !!!'
C      PRINT *
C      PRINT *, '    ATTIVARE FORTRAN AUSILIARIO (FORAUS) SE SI VUOLE'
C      PRINT *, '    USARE UN IMPIANTO NON STANDARD, O CORREGGERE TIMP'
C      PRINT *
C      PRINT *, '    NOTA:       IMPIANTI STANDARD     A P       M P'
C      PRINT *, '              /        TOSI 320MW      1         2'
C      PRINT *, '    TIMP =   {         TOSI 660MW      3         4'
C      PRINT *, '              /     ANSALDO 320MW      5         6'
C      PRINT *
C
C      STOP
C      END
C
C ======================================================================
C
      SUBROUTINE RSE0DAC()
C
      PRINT *
      PRINT *, '    ATTENZIONE:'
      PRINT *, '       IL TIPO DI MATERIALE (DATO GEOMETRICO TIMP) NON'
      PRINT *, '       E'' COMPRESO FRA 1 E 3 (O NON E'' INTERO) !!!'
      PRINT *
      PRINT *, '   +------------------------------------------+'
      PRINT *, '   | Materiali  disponibili         | indice  |'
      PRINT *, '   +--------------------------------+---------+'
      PRINT *, '   | Acciaio al carbonio (%C <= 30.)|    1    |'
      PRINT *, '   | Acciaio inox "lox Cr"(A335-P22)|    2    |'
      PRINT *, '   | Acciaio inox (sigla A335-P12)  |    3    |'
      PRINT *, '   +------------------------------------------+'
      PRINT *
      STOP 'CORREGGERE IL VALORE DI TIMP PRIMA DI RIPRENDERE L''ESECUZIO
     $NE'
      END
C
C ======================================================================
C
       REAL FUNCTION RSE0CS (TIMP, WVAP, TCAS,                          !SNGL
     $                 OMEG, PVAP, DATI, IPD, DTINT)                    !SNGL
C       DOUBLE PRECISION  FUNCTION RSE0CS (TIMP, WVAP, TCAS,             !DBLE
C     $                 OMEG, PVAP, DATI, IPD, DTINT)                    !DBLE
C       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
C---       Funzione per il calcolo coefficiente di scambio
C
C       Parametri d'ingresso: TIMP, WVAP, TCAS, OMEG, PVAP
C
C       Parametri d'uscita  : RSE0CS
C
       DIMENSION DATI(*)
       INTEGER   IPD
       COMMON/INTEGR/TSTOP,TEMPO,DDTINT,NPAS,CDT                          !SNGL       
C
       EXTERNAL RSE0CC
C
C       WRITE(6, *) 'RSE0CS', TIMP, WVAP, TCAS, OMEG, PVAP, DTINT

       IF (TIMP .NE. AINT(TIMP) .OR. TIMP .LT. 1. .OR. TIMP .GT. 6.)
     $     THEN
           RSE0CS = RSE0CC (TIMP, WVAP, TCAS, OMEG, PVAP,
     $                      DATI, IPD, DTINT)
           GOTO 910
       ENDIF
C
C-------Acquisizione dei dati relativi alle singole macchine
C
       S02 = 70.
       S03 = 0.145
       S04 = 7.E-5
       S05 = 1015.148
       S06 = 8.378
       S09 = DATI(IPD+ 5)
C
       GO TO (100, 100, 200, 200, 300, 300) INT(TIMP)
C
C------- CALCOLO DEL COEFFICIENTE DI SCAMBIO PER TOSI 320MW -----
C
C-------Turbina non alimentata-------
C
  100  IF (WVAP .LE .0.1) THEN
         CS = S09*TCAS*TCAS*TCAS
         GO TO 910
C
C-------Turbina in fase di rullaggio-------
C
       ELSE IF(WVAP .LT .(50./3.6)) THEN
         CS = S02+OMEG*(S03+OMEG*S04)
         GO TO 910
C
C-------Turbina in fase di presa di carico------
C
       ELSE IF(WVAP .LT .(300./3.6)) THEN
         Q = 1.141*WVAP-20.013
         GO TO 900
C
       ELSE IF(WVAP .LT .(735./3.6)) THEN
         Q = 1.241*WVAP-4.167
         GO TO 900
C
       ELSE
         Q = 1.021*WVAP+41.566
         GO TO 900
C
       END IF
C
C-------CALCOLO DEL COEFFICIENTE DI SCAMBIO PER TOSI 660MW-----
C
C-------Turbina non alimentata-------
C
  200  IF(WVAP .LE .0.1) THEN
         CS = S09*TCAS*TCAS*TCAS
         GO TO 910
C
C-------Turbina in fase di rullaggio-------
C
       ELSE IF(WVAP .LT .(43./3.6)) THEN
         CS = S02+OMEG*(S03+OMEG*S04)
         GO TO 910
C
C-------Turbina in fase di presa di carico------
C
       ELSE 
         Q = (WVAP-43./3.6)/((2110.-43.)/(660.*3.6))
         GO TO 900
C
       END IF
             
C-------CALCOLO DEL COEFFICIENTE DI SCAMBIO PER ANSALDO 320MW----
C
C-------Turbina non alimentata
C
  300  IF (WVAP .LE .0.1) THEN
         CS = S09*TCAS*TCAS*TCAS
         GO TO 910
       ELSE
C
C-------Turbina alimentata
C
         CS = 461.86*(PVAP*1.E-6)**0.8
         GO TO 910
       END IF
C
C-------Calcoli finali-------
C
  900  CS  = S05 + S06 * Q * 1.E-6
  910  CONTINUE
C       if (TEMPOLOC.NE.TEMPO) THEN
C       WRITE(6, *)  TEMPO, TIMP, PVAP, TCAS, OMEG, WVAP, CS 
C       TEMPOLOC = TEMPO        
C       ENDIF

       S07 = DATI(IPD+ 4)
       S11 = DATI(IPD+ 6)
       S17 = S07 * DTINT     
       CS  = CS * S17 / S11
C       WRITE(6, *) 'RSE0CS900b', S05, S06, Q, S07, S11, DTINT, CS   
C
       RSE0CS = CS
C
       RETURN
       END
C
C ======================================================================
C
C      REAL FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG, PVAP, DATI          !SNGL
C     $ , IPD, DTINT)                                                    !SNGL
C      DOUBLE PRECISION FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG,         !DBLE
C     $  PVAP, DATI, IPD, DTINT)                                         !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      PRINT *, '              MODULO   T S M L'
C      PRINT *, 'MANCA IL FORAUS DI RSE0CC PER TIMP # [1,2,3,4,5,6]'
C  impostare la funzione desiderata
C      RSE0CC = 1.
C      STOP
C      END
C
C ======================================================================
C
       REAL FUNCTION RSE0CV (SMAX, SMIN)                                !SNGL
C       DOUBLE PRECISION FUNCTION RSE0CV (SMAX, SMIN)                    !DBLE
C       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
C---   Funzione per il calcolo del consumo di vita secondo
C        l'algoritmo di LANGER
C
C      Parametri d'ingresso: SMAX, SMIN
C      Parametri d'uscita  : RSE0CV
C
C                         100.
C     NOTA: R1 = LN ( ----------- )       OVE:    RA = 30.
C                      100. - RA
C
C
       PARAMETER (E = 18280., SE = 17., R1 = 0.356674943)
       PARAMETER (COEF = (4. / (E*R1)) **2)
C
       C1 = COEF * ( SMAX-SE)**2
       C2 = COEF * (-SMIN-SE)**2
C
       IF (SMAX .LE. SE .AND. SMIN .GE. -SE) THEN
           RSE0CV = 0.
       ELSE IF (SMIN .GE. -SE) THEN
           RSE0CV = C1 / 4.
       ELSE IF (SMAX .LE.  SE) THEN
           RSE0CV = C2 / 4.
       ELSE
           RSE0CV = C1*C2 * (1./C1 + 1./C2 + 2./SQRT(C1*C2)) / 4.
       ENDIF
C
       RETURN
       END
C
C ======================================================================
C
      SUBROUTINE RSE0SX (DDDATI, TM, TI, PP, TSTAM, CPRE, GSTAZ,
     $           SMAX, SMIN, TSMAX, TSMIN, TRAZ, GSUP, CATT, IBLOC)
C
C  * * * *                routine   T S M L S X                  * * * *
C
C  Per i Collettori.
C
C  Aggiorna i valori delle sollecitazioni massima SMAX e minima SMIN,
C  calcola inoltre le temperature corrispondenti TSMAX e TSMIN, il
C  parametro TRAZ, la soll. equivalente di uscita GSUP, ed il consumo di
C  vita CATT.
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                      
      PARAMETER (GG = 9.80665)
      PARAMETER (EPS = 0.1)
      CHARACTER * 8 IBLOC
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT                     
CD     COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS            
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      REAL DDDATI(12)
C
      LANOR = INT(DDDATI(8))
      ITIPOC = INT(DDDATI(12))
C
C  Calcolo soll. equivalenti
       IF (AMOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0) WRITE (*, *)
      CALL RSE0SS(DDDATI, TM, TI, PP, SIGMA)
C
C  Calcolo soll. di uscita (GSUP) in [kg/mm^2]
      GSUP = SIGMA / GG
C
      IF (GSUP-GSTAZ .LT. -EPS) THEN
        IF (TRAZ .EQ. 0) THEN
          TRAZ = -1.
        ELSE IF (TRAZ .EQ. 1) THEN
          TRAZ = -2.
        ELSE IF (TRAZ .EQ. 2) THEN
C  Riconosciuta fine ciclo di fatica
          CALL RSE0FC(TSTAM, CPRE, CATT, SMAX, SMIN, TRAZ, IBLOC)
        ENDIF
      ELSE IF (GSUP-GSTAZ .GT. EPS) THEN
        IF (TRAZ .EQ. 0) THEN
          TRAZ =  1.
        ELSE IF (TRAZ .EQ. -1.) THEN
          TRAZ =  2.
        ELSE IF (TRAZ .EQ. -2.) THEN
          CALL RSE0FC(TSTAM, CPRE, CATT, SMAX, SMIN, TRAZ, IBLOC)
        ENDIF
      ENDIF
C
C  aggiorno i valori estremi del ciclo
      IF (SIGMA.GT.SMAX .AND. SIGMA.GT.0.0) THEN
        SMAX = SIGMA
***        TSMAX = TM
        TSMAX = TI
      ELSE IF (SIGMA.LT.SMIN .AND. SIGMA.LT.0.0) THEN
        SMIN = SIGMA
***        TSMIN = TM
        TSMIN = TI
      END IF
C
C  calcolo la T* (mi occorre in [^C], mentre tutte le altre sono in [K])
      TSTAR = 0.75 * TSMIN + 0.25 * TSMAX - 273.15
C
C - Calcolo del consumo di vita CATT
      IF (LANOR .EQ. 1) THEN
        SIGA = RSE0ST(SMAX, SMIN, TSTAR, ITIPOC, DDDATI(9))
        CATT = RSE0NT(SIGA, TSTAR)
      ELSE IF (LANOR .EQ. 2) THEN
        SIGA = RSE0SA(SMAX, SMIN, TSTAR, ITIPOC)
        CATT = RSE0NA(SIGA, TSTAR)
      END IF
      IF (MOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0) THEN
        WRITE (*, *) ' * T star = ', TSTAR
        WRITE (*, *) ' * NEL CICLO: MAX: ', SMAX/GG, ', MIN: ', SMIN/GG
      END IF
C
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0SS(DDDATI, TM, TI, PP, SIGMA)
C
C  * * * *                routine   T S M L S S                  * * * *
C
C  Calcola i valori delle sollecitazioni dati i parametri geometrici del
C  componente e le temperature significative.
C  Si utilizza avendo gia' ricavato la distribuzione di temperatura,
C  ovvero i due valori significativi, corrispondenti rispettivamente
C  alla temperatura media del metallo ed a quella superficiale.
C
C  In ingresso occorrono:
C      - temperatura media del metallo TM
C      - temperatura superficiale del metallo TI (circa uguale a quella
C                                                 del fluido)
C      - pressione PP
C      - un vettore contenente i dati seguenti:
C            DDDATI(1) = raggio esterno REST
C            DDDATI(2) = raggio interno RINT
C            DDDATI(3) = coeff. di dilatazione lineare ALFA
C            DDDATI(4) = Modulo di Young EE
C            DDDATI(5) = coeff. di Poisson POIS
C            DDDATI(6) = Coeff. di moltiplicazione delle
C                        sollecitazioni di temperatura RKT
C            DDDATI(7) = Coeff. di moltiplicazione delle
C                        sollecitazioni di pressione RKP
C            DDDATI(8) = codice norma prescelta ANOR
C                        1 : TRD - 2 : ASME
C
C  In uscita si ottengono, secondo la normativa prescelta, i valori
C  delle sollecitazioni equivalenti minima e massima (all'istante
C  attuale). Queste andranno poi confrontate fra loro per ricavare
C  i valori massimo e minimo che servono per il calcolo del consumo di
C  vita complessivo della manovra.
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT                          !SNGL
CD     COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      PARAMETER (GG = 9.80665)
      PARAMETER (IR = 1, ITETA = 2, IZ = 3)
      DIMENSION SIGP(3), SIGT(3), DELTAS(3), SIGINT(3), DDDATI(12)
C
      DO 1 I = 1, 3
        SIGP(I) = 0.
    1   SIGT(I) = 0.
      SIGPPP = 0.
C
      REST = DDDATI(1)
      RINT = DDDATI(2)
      ALFA = DDDATI(3)
      EE = DDDATI(4)
      POIS = DDDATI(5)
      RKT = DDDATI(6)
      RKP = DDDATI(7)
      ANOR = DDDATI(8)
      SPES = REST - RINT
C  versione 2.1
      ILMAT = INT(DDDATI(12))
      TCEL=TM-273.15
      EE = RSE0XX(ILMAT, 3, TCEL)
      ALFA = RSE0XX(ILMAT, 12, TCEL)
      IF (SPES.LE.0.0 .OR. ALFA.LE.0.0 .OR.
     $    EE.LE.0.0   .OR. POIS.LE.0.0) THEN
        WRITE(*, *) 'ERRORE in RSE0SS - dati scorretti'
        RETURN
      END IF
C
      SIGT(IR) = 0.
      SIGT(ITETA) = ALFA * EE * (TM - TI) / (1. - POIS)
      SIGT(IZ) = SIGT(ITETA)
      IF (MOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0) THEN
        WRITE (*, *) '%%% ROUTINE RSE0SS - tempo = ', TEMPO, ' %%%'
        WRITE (*, *) ' - T superf.:', TI-273.16, ' - T media:',TM-273.16
        WRITE (*, *) ' - sollecitazione di temperatura:',SIGT(ITETA)/GG
      END IF
C
      DEST = REST * 2.
      DINT = RINT * 2.
      IF (INT(ANOR) .EQ. 1) THEN
C  norme TRD
        SIGPPP = PP * 0.25 * (DEST + DINT) / SPES
        IF (MOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0)
     $    WRITE (*, *) ' - sollecitazione di pressione (TRD):',SIGPPP/GG
        SIGMA = RKP * SIGPPP + RKT * SIGT(ITETA)
      ELSE IF (INT(ANOR) .EQ. 2) THEN
C  norme ASME
        UU = DEST / DINT
        U2 = UU * UU
        SIGP(IR) = -PP
        SIGP(ITETA) = PP * (U2 + 1.) / (U2 - 1.)
        SIGP(IZ) = PP / (U2 - 1.)
        IF (MOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0)
     $    WRITE (*, *) ' - soll. p (ASME) r/teta/z:', (SIGP(I)/GG,I=1,3)
        SIGINT(IR) = SIGP(IR) + SIGT(IR)
        SIGINT(ITETA) = RKP * SIGP(ITETA) + RKT * SIGT(ITETA)
        SIGINT(IZ) = RKP * SIGP(IZ) + RKT * SIGT(IZ)
        SIGMA = 0.
        DO 2 I = 1, 3
          IP = MOD(I, 3) +1
          IF (ABS(SIGINT(IP)) .GT. ABS(SIGINT(I))) THEN
            DELTAS(I) = SIGINT(IP) - SIGINT(I)
          ELSE
            DELTAS(I) = SIGINT(I) - SIGINT(IP)
          END IF
          IF (ABS(DELTAS(I)).GT.ABS(SIGMA)) THEN
            SIGMA = DELTAS(I)
          END IF
    2   CONTINUE
      ELSE
        WRITE (*, *) 'ERRORE in RSE0SS - Norma non prevista'
        STOP 'Indicare 1 per le TRD oppure 2 per le ASME'
      END IF
C
      IF (MOD(TEMPO, 30.).EQ.0. .AND. ITERT.LE.0)
     $  WRITE (*, *) ' Sollecitazione equiv.:', SIGMA/GG
C
      RETURN
      END
C
C ======================================================================
C
      SUBROUTINE RSE0SR(TIMP,TROTK,TMRTK,TFOROK,SV1S,SV0S,
     &                  DTH1,DTH0,CSRG1,CSRG0,CSRT1,CSRT0,SXFB,SXFE)
C
C     Calcola i valori di tensione ammissibili per la regolazione e i
C     valori limiti per il trip
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      REAL KS,K1
C
      TKP=425.8
      AKS=0.75
      AKF=0.6
      Y=317.2
      Z=439.8
      KS=0.17244
      K1=0.66178
C
      TROT=TROTK-273.16
      TMRT=TMRTK-273.16
      TFORO=TFOROK-273.16
C
      SV1=ABS(SV1S)
      SV0=ABS(SV0S)
C
      IF (TROT.LE.TKP) THEN
	  G1=Y-KS*TROT
	ELSE
	  G1=Z-K1*TROT
	END IF
C
      IF (TFORO.LE.TKP) THEN
	  G0=Y-KS*TFORO
	ELSE
	  G0=Z-K1*TFORO
	END IF
C
      CSRG1=AKF*G1
      CSRG0=AKF*G0
      CSRT1=AKS*G1
      CSRT0=AKS*G0
C
      DTH1=TROT-TMRT
      DTH0=TMRT-TFORO
	IF (DTH1.GT.1.) THEN
	  S1DT=-1.*SV1
	  S0DT=-1.*SV0
	ELSE IF ((DTH1.GE.-1.).AND.(DTH1.LE.1.)) THEN
	  S1DT=-1.*DTH1*SV1
	  S0DT=-1.*DTH1*SV0
	ELSE IF (DTH1.LE.-1.) THEN
	  S1DT=SV1
	  S0DT=SV0
	END IF
C
      IF (CSRG1.EQ.0.) THEN
	  SXFB=-9999999.
	  SXFE= 9999999.
	  WRITE(6,*)' Attenzione !!! CSRG1 =0. valore di SXFB - inf.'
	  WRITE(6,*)' Attenzione !!! CSRG1 =0. valore di SXFE + inf.'
	ELSE
	  IF ((CSRG1-S1DT).LT.(CSRG0-S0DT)) THEN
          SXFB=5.*(CSRG1-S1DT)/CSRG1
	  ELSE
          SXFB=5.*(CSRG0-S0DT)/CSRG1
  	  END IF
C
        IF ((CSRG1+S1DT).LT.(CSRG0+S0DT)) THEN
          SXFE=5.*(CSRG1+S1DT)/CSRG1
 	   ELSE
          SXFE=5.*(CSRG0+S0DT)/CSRG1
	  END IF
	END IF
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0SA(SIGMAX, SIGMIN, TSTAR, ITIPOC)               !SNGL
C      DOUBLE PRECISION FUNCTION RSE0SA(SIGMAX, SIGMIN, TSTAR, ITIPOC)   !DBLE
C
C  * * * *                routine   T S M L S A                  * * * *
C
C  Calcolo della Sigma equivalente secondo le norme Asme, da impiegare
C  nella valutazione del consumo di vita del componente.
C
C  Calcola il valore dell'ampiezza della sollecitazione "corretta",
C  ossia "Sa" secondo le norme ASME (americane) dati i valori delle
C  sollecitazioni equivalenti massima e minima.
C  Queste vengono opportunamente corrette da coefficienti che dipendono
C  sia dal tipo di componente che dalla temperatura caratteristica del
C  ciclo di sollecitazione.
C
C  Ingressi:
C        - sollecitazione equivalente massima SIGMAX
C        - sollecitazione equivalente minima SIGMIN
C        - la temperatura di riferimento TSTAR      (REAL *4)
C        - il tipo di componente ITIPOC            (INTEGER *4)
C           EZERO = Modulo di Young di riferimento
C                       (a T = T ambiente)
C
C  Nota: questa metodologia non e' applicabile per una temperatura
C  caratteristica superiore ai 375^C.
C
C  In uscita restituisce -1.0 in caso di errore (il valore dovrebbe
C  sempre essere positivo).
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (EZERO = 210000.)
C
      RSE0SA = -1.0
C
      IF (SIGMAX .LT. SIGMIN) THEN
        WRITE (*, *) 'ERRORE in RSE0SA: sollecitazioni non corrette'
        RETURN
      ELSE IF (TSTAR .LT. 0.) THEN
        WRITE (*, *) 'ERRORE in RSE0SA: temperatura non corretta'
        RETURN
      ELSE IF (TSTAR .GT. 375.) THEN
        WRITE (*, *) 'Routine RSE0SA: Attenzione: T* troppo grande - ',
     $               '          la normativa ASME non e'' applicabile'
      END IF
C
      ESTAR = RSE0XX(ITIPOC, 3, TSTAR)
      IF (ESTAR.EQ.-1.0) THEN
        WRITE (*, *) 'ERRORE in RSE0SA: non posso procedere'
        RETURN
      END IF
C
C  determinazione della "S alt" (punto 3.2.3)
      ESSALT = ABS(SIGMAX) + ABS(SIGMIN)
C
C  infine:
      RSE0SA = 0.5 * ESSALT * EZERO / ESTAR
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0NA(SIGAA, TSTAR)                                !SNGL
C      DOUBLE PRECISION FUNCTION RSE0NA(SIGAA, TSTAR)                    !DBLE
C
C  * * * *                routine   T S M L N A                  * * * *
C
C  Valuta la ripetibilita' di una manovra, data la sigma equivalente e
C  la temperatura caratteristica, secondo le norme ASME, colle formule
C  fornite dall'ENEL.
C
C  Viene restituito il consumo di vita corrispondente (cfr. la procedura
C  RSE0NT).
C
C  In caso di errore il valore restituito e' -1.
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (AA = 8160.3713, BB = 46.194127, BETA = 2.5531901)
      PARAMETER (ZERO = 0.1E-07)
      PARAMETER (RILLIM = 95000.)
C---- vecchia formula:
C      PARAMETER (BETA = 2.36, NUMP = 2)
C      DIMENSION TI(NUMP), AATI(NUMP), BBTI(NUMP)
C      DATA TI   /     20.,    300. /
C      DATA AATI /   9465.,   8063. /
C      DATA BBTI /     64.,     54. /
C----
      RSE0NA = -1.
C
C---- vecchia formula
C      IF (TSTAR .LE. 0.) THEN
C        WRITE (*, *) 'Errore in RSE0NA: T* troppo piccola'
C        RETURN
C      ELSE IF (TSTAR .GT. 375.) THEN
CD       WRITE (*, *) 'Routine RSE0NA: Attenzione: T* troppo grande - ',
CD    $               '          la normativa ASME non e'' applicabile'
C      END IF
C
C      AA = RSE0IN(TSTAR, TI, AATI, NUMP)
C      BB = RSE0IN(TSTAR, TI, BBTI, NUMP)
C----
      DUM = SIGAA - BB
      IF (ABS(DUM) .LT. ZERO) THEN
        RNK = RILLIM
      ELSE
        DUM = AA / DUM
        IF (DUM .LT. 0.0) THEN
          RNK = RILLIM
        ELSE
          RNK = DUM ** BETA
        END IF
      END IF
C
      IF (RNK .GE. RILLIM) THEN
        RSE0NA = 0.
      ELSE
        RSE0NA = 1. / RNK
      END IF
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0ST(SIGMAX, SIGMIN, TSTAR, ITIPOC, DDDATI)       !SNGL
C      DOUBLE PRECISION FUNCTION RSE0ST(SIGMAX, SIGMIN, TSTAR, ITIPOC,
C                                        DDDATI)                         !DBLE
C
C  * * * *                routine   T S M L S T                  * * * *
C
C  Calcola il valore dell'ampiezza della sollecitazione "corretta",
C  ossia "2 sigma a" secondo le norme TRD (tedesche) dati i valori delle
C  sollecitazioni di pressione e di temperatura (da calcolare prima).
C  Queste vengono opportunamente corrette da coefficienti che dipendono
C  sia dal tipo di componente che dalla temperatura caratteristica del
C  ciclo di sollecitazione.
C  In seguito alla prima riunione dell'11 gennaio 1993, si e' fissato
C  che -almeno per il momento- il valore della tensione di snervamento
C  alla temperatura caratteristica (tau*) sia in realta' parametrizzato
C  solo in funzione del componente (percio', almeno in questa procedura,
C  ci si svincola dalla temperatura).
C
C  Ingressi:
C        - la sollecitazione composta massima SIGMAX
C        - la sollecitazione composta minima SIGMIN
C        - un vettore di dati, contenente:
C           DDDATI(1) = Tensione di rottura del materiale [MPa]
C           DDDATI(2) = Tensione di snervamento del materiale [MPa]
C
C  In uscita restituisce -1.0 in caso di errore (il valore dovrebbe
C  sempre essere positivo).
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION DDDATI(2)
C
      RSE0ST = -1.0
C
      IF (SIGMAX .LT. SIGMIN) THEN
        WRITE (*, *) 'ERRORE in RSE0ST: sollecitazioni non corrette'
        RETURN
      END IF
C
      UTS    = DDDATI(1)
      YIELDT = DDDATI(2)
C  La seguente e' la tensione di snervamento alla temperatura T*
      YIELS  = RSE0XX(ITIPOC, 13, TSTAR)
      IF (YIELS .LT. 0.) THEN
        WRITE (*, *) 'ERRORE in RSE0ST: tensione di snervam. a T* ' //
     $               'non corretta'
        RETURN
      END IF
C
C  calcolo di Delta sigma (punto 2.3)
      DELTAS = ABS(SIGMAX) + ABS(SIGMIN)
C
C  calcolo del fattore di moltiplicazione "f" (punto 2.4)
C  prima calcolo "f3" in funzione della tensione di snervamento a 20^C
      IF (YIELDT .LE. 360.) THEN
        EFFE3 = 1.0
      ELSE IF (YIELDT .LT. 600.) THEN
        EFFE3 = 1.2
      ELSE
        EFFE3 = 1.4
      END IF
C
C  poi; "super elastic case"
      IF (DELTAS .GT. 2.0*YIELS) THEN
        EFFE = EFFE3 * DELTAS * 0.5 / YIELS
      ELSE
C  "elastic case"
        DUM = 4.0 * UTS * UTS -
     $        (2.0 * YIELS - DELTAS) * (2.0 * YIELS - DELTAS)
        IF (ABS(DUM) .LT. ZERO) THEN
          WRITE (*, *) 'Errore in RSE0ST: parametro f non calcolabile'
          RETURN
        END IF
        EFFE = EFFE3 * 4.0 * UTS * UTS / DUM
      END IF
C
C  infine:
      RSE0ST = EFFE * DELTAS
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0NT(SIGAA, TSTAR)                                !SNGL
C      DOUBLE PRECISION FUNCTION RSE0NT(SIGAA, TSTAR)                    !DBLE
C
C  * * * *                routine   T S M L N T                  * * * *
C
C  Calcola il numero di cicli per il quale si ha la formazione della
C  prima cricca, data l'ampiezza di sollecitazione (2 sigma a -
C  variabile SIGAA) e la temperatura di riferimanto (tau * - variabile
C  TSTAR), secondo le norme tedesche (figura B della TRD 301, Annex 1,
C  Edition 4.75, maggio 1988).
C
C  Restituisce in uscita il consumo di vita dato dal numero di cicli
C  suddetto; se il valore del numero di cicli e' infinito (ossia se si
C  resta al di sotto del limite di fatica) il consumo sara' nullo.
C
C  In caso di errore il valore restituito e' -1.
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (RILLIM = 95000., ZERO = 0.1E-07)
      PARAMETER (TMAX = 1440.)
      DOUBLE PRECISION ESSE1, ESSE2, ESSE3, AS1(3), AS2(3), AS3(3),
     $                 AA, BI, CI, DUM
      DATA AS1 / 78724.99997, 965775936.9,     13137.5 /
      DATA AS2 /  2877.06645, 4861735.668, 2542.868719 /
      DATA AS3 / 528.0508475, 261452.4563, 1448.305085 /
C
      RSE0NT = -1.
C
      IF (TSTAR .GT. TMAX) THEN
        WRITE (*, *) 'Errore in RSE0NT: T* troppo grande'
        RETURN
      ELSE IF (TSTAR .LE. 0.) THEN
        WRITE (*, *) 'Errore in RSE0NT: T* troppo piccola'
        RETURN
      END IF
C
C  calcolo dei parametri S1, S2 e S3
      ESSE1 = AS1(1) + AS1(2) / (TSTAR - AS1(3))
      ESSE2 = AS2(1) + AS2(2) / (TSTAR - AS2(3))
      ESSE3 = AS3(1) + AS3(2) / (TSTAR - AS3(3))
C
C  calcolo del parametro C
      DUM = ESSE1 - ESSE2
C
      IF (ABS(DUM) .LT. ZERO) THEN
        WRITE (*, *) 'Errore in RSE0NT: parametro C non calcolabile'
        RETURN
      END IF
      DUM = (ESSE2 - ESSE3) / DUM
      IF (DUM .LT. 0.) THEN
        WRITE (*, *) 'Errore in RSE0NT: parametro C non calcolabile'
        RETURN
      END IF
      CI = SQRT(DUM)
C
C  calcolo del parametro B
      DUM = CI * CI * (1.0 - CI * CI)
      IF (ABS(DUM) .LT. ZERO) THEN
        WRITE (*, *) 'Errore in RSE0NT: parametro B non calcolabile'
        RETURN
      END IF
      BI = (ESSE1 - ESSE2) / DUM
      IF (BI .LT. 0.) THEN
        WRITE (*, *) 'Errore in RSE0NT: parametro B negativo'
        RETURN
      END IF
C
C  calcolo del parametro A
      AA = ESSE1 - BI * CI * CI
C
C  valutazione di n^
C  se il valore di "2sigmaa" e' minore uguale ad A, n^ vale infinito
      IF (SIGAA .LE. AA) THEN
        RNK = RILLIM
      ELSE
C  altrimenti, uso la formula
        RNK = 10.0 ** ((LOG10(SIGAA - AA) - LOG10(BI)) / LOG10(CI))
C  divido per 5 (coeff. di sicurezza)
C        RNK = RNK / 5.
        RNK = RNK / 2.
      END IF
C
      IF (RNK .GE. RILLIM) THEN
        RSE0NT = 0.
      ELSE
        RSE0NT = 1. / RNK
      END IF
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0XX (ILMAT, ILDATO, TT)                          !SNGL
C      DOUBLE PRECISION FUNCTION RSE0XX (ILMAT, ILDATO, TT)              !DBLE
C
C  * * * *                routine   T S M L X X                  * * * *
C
C  Questa funzione restituisce il valore della caratteristica del
C  componente richiesta. Tutti i dati propri di ciascun materiale sono
C  conservati qui e pertanto si deve modificare questa procedura per
C  assegnare dei nuovi valori.
C
C  In ingresso si deve specificare il numero corrispondente al
C  materiale (in totale sono NUCOMP), il codice corrispondente al tipo
C  di dato richiesto, e -se serve- la temperatura di riferimento.
C
C  In caso di errore restituisce -1.0.
C
C  Dati disponibili:
C
C !    ILDATO =  !   parametro fornito                                 !
C ----------------------------------------------------------------------
C !      1       !  Modulo di Young E [MPa] a T fissata (di esercizio) !
C !      2       !  Modulo di Young E [MPa] a T ambiente               !
C !      3       !  Modulo di Young E [MPa] - fornire anche T          !
C !      4       !  Tensione di rottura del materiale [MPa]            !
C !      5       !  Tensione di snervamento del materiale [MPa]        !
C !      6       !  Modulo di Poisson ni                               !
C !      7       !  Coeff. di dilatazione lineare alfa [1/K]           !
C !      8       !  Calore specifico Cp [J / kg K]                     !
C !      9       !  Densita' RO [kg / m^3]                             !
C !     10       !  ...                                                !
C !     11       !  Calore specifico Cp al variare della temperatura   !
C !     12       !  Coeff. di dilatazione lineare alfa in funzione     !
C !              !    della temperatura                                !
C !     13       !  Tensione di snervamento del materiale [MPa]        !
C !              !    in funzione della temperatura                    !
C !     14       !  Conducibilita' termica k [W / m K]                 !
C !              !    in funzione della temperatura                    !
C ----------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C  numero max di materiali disponibili
      PARAMETER (NUMAT = 3)
C
      PARAMETER (RNI = 0.3)
      PARAMETER (ALFA0 = 12.E-06)
C  Colombo pag. B-68 (va abbastanza bene come valore a 150^C)
      PARAMETER (CP0 = 502.)
C  (dal Colombo pag. C-13 era 7860.)
      PARAMETER (RO = 7763.)
C
C  Dati per determinare E* (modulo di Young in funzione della
C  temperatura); suppongo che dipenda anche dal componente
C  -NTI... e' il numero massimo di coppie di punti disponibili-
      PARAMETER (NTIY = 12, NTIS = 13, NTCP = 13, NTALF = 12, NTK = 13)
      DIMENSION TTIY(NTIY, NUMAT), YOUNG(NTIY, NUMAT), NUMPY(NUMAT)
      DIMENSION EE(NUMAT)
      DIMENSION SNER(NTIS, NUMAT), TTIS(NTIS, NUMAT), NUMPS(NUMAT)
      DIMENSION UTS(NUMAT), YIELDT(NUMAT)
      DIMENSION CP(NTCP, NUMAT), TTCP(NTCP, NUMAT), NUMCP(NUMAT)
      DIMENSION ALFA(NTALF, NUMAT), TALF(NTALF, NUMAT), NALF(NUMAT)
      DIMENSION COND(NTK, NUMAT), TKON(NTK, NUMAT), NKON(NUMAT)
C
      DATA TTIY  /     21.,     93.,    149.,    204.,    260.,
     $                316.,    371.,    427.,    482.,    538.,
     $                                             0.,      0.,
     $                 21.,     93.,    149.,    204.,    260.,
     $                316.,    371.,    427.,    482.,    538.,
     $                                             0.,      0.,
     $                 25.,    100.,    150.,    200.,    250.,
     $                300.,    350.,    400.,    450.,    475.,
     $                                           500.,    550./
      DATA YOUNG /
C  Acciaio al carbonio (C <= 30%; ASME A106-C)
     $             192300., 191000., 188900., 186100., 182000.,
     $             177200., 171000., 161300., 149100., 137300.,
     $                                             0.,      0.,
C  Acciaio basso legato 2 1/4 Cr - 1 Mo (ASME A335-P22)
     $             206100., 203400., 199900., 197200., 193000.,
     $             188900., 183400., 177200., 168900., 158600.,
     $                                             0.,      0.,
C  Acciaio basso legato 1 Cr - 1/2 Mo (ASME A335-P12)
     $             205000., 200000., 196000., 193000., 190000.,
     $             187000., 183000., 179000., 174000., 172000.,
     $                                        169700., 164800./
      DATA NUMPY / 10, 10, 13 /
C
      DATA TTIS  /   40.,  100.,  150.,  200.,  250.,  300.,
     $              350.,  400.,  450.,  475.,    0.,    0.,
     $                                                   0.,
     $               21.,   93.,  149.,  204.,  260.,  316.,
     $              371.,  427.,  482.,  538.,    0.,    0.,
     $                                                   0.,
     $               40.,  100.,  150.,  200.,  250.,  300.,
     $              350.,  400.,  425.,  450.,  475.,  500.,
     $                                                 525./
      DATA SNER  /  241.,  218.,  214.,  208.,  198.,  183.,
     $              175.,  168.,  156.,  154.,    0.,    0.,
     $                                                   0.,
     $              207.,  192.,  187.,  186.,  186.,  186.,
     $              186.,  184.,  177.,  163.,    0.,    0.,
     $                                                   0.,
     $              207.,  192.,  185.,  181.,  179.,  176.,
     $              166.,  156.,  155.,  151.,  146.,  143.,
     $                                                 139./
      DATA NUMPS / 10, 10, 12 /
C
      DATA EE   / 192300., 206100., 205000. /
C
      DATA UTS    / 414.12, 414.12, 414.04 /
      DATA YIELDT /  241.0,  241.0,  207.0 /
C
      DATA TTCP  /   21.,    93.,   149.,   204.,   260.,   316.,
     $              371.,   427.,   482.,   538.,     0.,     0.,
     $                                                        0.,
     $               21.,    93.,   149.,   204.,   260.,   316.,
     $              371.,   427.,   482.,   538.,     0.,     0.,
     $                                                        0.,
     $               25.,   100.,   150.,   200.,   250.,   300.,
     $              350.,   400.,   425.,   450.,   475.,   500.,
     $                                                      550./
      DATA CP    /  478.2,  494.1,  510.4,  526.3,  541.0,  556.9,
     $              581.2,  608.8,  665.3,  684.6,    0.0,    0.0,
     $                                                        0.0,
     $              478.2,  494.1,  510.4,  526.3,  541.0,  556.9,
     $              581.2,  608.8,  665.3,  684.6,    0.0,    0.0,
     $                                                        0.0,
     $              439.5,  477.2,  498.1,  523.3,  540.0,  560.9,
     $              577.7,  602.8,  611.2,  627.9,  644.6,  657.2,
     $                                                      690.7/
      DATA NUMCP / 10, 10, 13 /
C
      DATA TALF  /   21.,     93.,    149.,    204.,    260.,    316.,
     $              371.,    427.,    482.,    538.,      0.,      0.,
     $               21.,     93.,    149.,    204.,    260.,    316.,
     $              371.,    427.,    482.,    538.,      0.,      0.,
     $               50.,    100.,    150.,    200.,    250.,    300.,
     $              350.,    400.,    425.,    450.,    500.,    550./
      DATA ALFA /  10.93E-6,  11.48E-6,  11.88E-6,  12.28E-6,  12.64E-6,
     $             13.01E-6,  13.39E-6,  13.77E-6,  14.11E-6,  14.35E-6,
     $                                                   0.0,       0.0,
     $             10.93E-6,  11.48E-6,  11.88E-6,  12.28E-6,  12.64E-6,
     $             13.01E-6,  13.39E-6,  13.77E-6,  14.11E-6,  14.35E-6,
     $                                                   0.0,       0.0,
     $             10.49E-6,  11.08E-6,  11.63E-6,  12.14E-6,  12.60E-6,
     $             13.02E-6,  13.40E-6,  13.74E-6,  13.89E-6,  14.02E-6,
     $                                              14.28E-6,  14.50E-6/
      DATA NALF / 10, 10, 12 /
C
      DATA TKON  /   21.,   93.,  149.,  204.,  260.,  316.,
     $              371.,  427.,  482.,  538.,    0.,    0.,
     $                                                   0.,
     $               21.,   93.,  149.,  204.,  260.,  316.,
     $              371.,  427.,  482.,  538.,    0.,    0.,
     $                                                   0.,
     $               25.,  100.,  150.,  200.,  250.,  300.,
     $              350.,  400.,  425.,  450.,  475.,  500.,
     $                                                 550./
      DATA COND /  62.30,  60.31,  57.45,  54.68,  51.57,  48.97,
     $             46.38,  43.96,  41.18,  39.11,    0.0,    0.0,
     $                                                       0.0,
     $             62.30,  60.31,  57.45,  54.68,  51.57,  48.97,
     $             46.38,  43.96,  41.18,  39.11,    0.0,    0.0,
     $                                                       0.0,
     $              41.9,   42.2,   41.9,   41.4,   40.6,   39.7,
     $              38.5,   37.4,   36.7,   36.3,   35.7,   35.0,
     $                                                      34.0/
      DATA NKON / 10, 10, 13 /
C
      RSE0XX = -1.0
      IF (ILMAT .GT. NUMAT  .OR.  ILMAT .LT. 1) THEN
        WRITE (*, *) 'Errore in RSE0XX - materiale sconosciuto'
        RETURN
      END IF
C
      IF (ILDATO .EQ. 1) THEN
        RSE0XX = EE(ILMAT)
      ELSE IF (ILDATO .EQ. 2) THEN
        RSE0XX = EE(ILMAT)
      ELSE IF (ILDATO .EQ. 3) THEN
        IF (TT .LT. 0  .OR.  TT .GT. 1000.) THEN
          WRITE (*, *) 'Errore in RSE0XX - temperatura non corretta'
          RETURN
        END IF
        RSE0XX = RSE0IN(TT, TTIY(1, ILMAT), YOUNG(1, ILMAT),
     $                  NUMPY(ILMAT))
      ELSE IF (ILDATO .EQ. 4) THEN
        RSE0XX = UTS(ILMAT)
      ELSE IF (ILDATO .EQ. 5) THEN
        RSE0XX = YIELDT(ILMAT)
      ELSE IF (ILDATO .EQ. 6) THEN
        RSE0XX = RNI
      ELSE IF (ILDATO .EQ. 7) THEN
        RSE0XX = ALFA0
      ELSE IF (ILDATO .EQ. 8) THEN
        RSE0XX = CP0
      ELSE IF (ILDATO .EQ. 9) THEN
        RSE0XX = RO
      ELSE IF (ILDATO .EQ. 11) THEN
        IF (TT .LT. 0  .OR.  TT .GT. 1000.) THEN
          WRITE (*, *) 'Errore in RSE0XX - temperatura non corretta'
          RETURN
        END IF
        RSE0XX = RSE0IN(TT, TTCP(1, ILMAT), CP(1, ILMAT), NUMCP(ILMAT))
      ELSE IF (ILDATO .EQ. 12) THEN
        IF (TT .LT. 0  .OR.  TT .GT. 1000.) THEN
          WRITE (*, *) 'Errore in RSE0XX - temperatura non corretta'
          RETURN
        END IF
        RSE0XX = RSE0IN(TT, TALF(1, ILMAT), ALFA(1, ILMAT), NALF(ILMAT))
      ELSE IF (ILDATO .EQ. 13) THEN
        IF (TT .LT. 0  .OR.  TT .GT. 1000.) THEN
          WRITE (*, *) 'Errore in RSE0XX - temperatura non corretta'
          RETURN
        END IF
        RSE0XX = RSE0IN(TT, TTIS(1, ILMAT), SNER(1, ILMAT),
     $                  NUMPS(ILMAT))
      ELSE IF (ILDATO .EQ. 14) THEN
        IF (TT .LT. 0. .OR.  TT .GT. 1000.) THEN
          WRITE (*, *) 'Errore in RSE0XX - temperatura non corretta'
          RETURN
        END IF
        RSE0XX = RSE0IN(TT, TKON(1, ILMAT), COND(1, ILMAT), NKON(ILMAT))
      ELSE
        WRITE (*, *) 'Errore in RSE0XX - non e'' previsto il dato n.',
     $               ILDATO
      END IF
C
      RETURN
      END
C
C ======================================================================
C
      REAL FUNCTION RSE0IN(X, XX, YY, NPU)                              !SNGL
C      DOUBLE PRECISION FUNCTION RSE0IN(X, XX, YY, NPU)                  !DBLE
C
C  Fa l'interpolazione lineare dati due vettori di coppie di valori.
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION XX(NPU), YY(NPU)
      PARAMETER (ZZERO = 0.1e-09)
C
      IF (NPU .LT. 2) THEN
        WRITE(*,*) 'Errore in RSE0IN - troppo pochi punti'
        RETURN
      END IF
      I1 = 0
      I2 = 0
      DO 1 I = 1, NPU - 1
        IF (X .GE. XX(I) .AND. X .LE. XX(I+1)) THEN
          I1 = I
        END IF
    1 CONTINUE
      IF (I1 .EQ. 0) THEN
        IF (X .LE. XX(1)) THEN
          I1 = 1
        ELSE
          I1 = NPU - 1
        END IF
      END IF
      I2 = I1 + 1
C
      DETE = XX(I2) - XX(I1)
      IF (ABS(DETE).LT.ZZERO) THEN
        WRITE(*,*) 'Errore in RSE0IN - denominatore nullo'
      ELSE
        RSE0IN = YY(I1) +(YY(I2) -YY(I1))*(X -XX(I1))/DETE
      END IF
C
      RETURN
      END
C
C ======================================================================
C
C~FORAUS_RSE0~C
C
C  FORTRAN AUSILIARIO DEL MODULO RSE0
C  (THERMAL STRESS AND MACHINE LIFE ANALISYS)
C  PER LA SUA SCRITTURA VEDERE IL MANUALE D'USO
C  O UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
CC ======================================================================
C
CC       REAL FUNCTION RSE0AQ (TM)                                       !SNGL
CC       DOUBLE PRECISION FUNCTION RSE0AQ (TM)                            !DBLE
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
CC
CC   La function RSE0AQ (Sigma Eqivalente Foro AMMissibile) deve resti-
CC      tuire il valore massimo ammissibile (in Kg/mm^2) per la tensione
CC      equivalente [secondo Von Mises] al foro del rotore, in funzione
CC      della temperatura media del rotore stesso (TM, in ^C).
CC
C          RSE0AQ =  ........ ?????
CC
CC      (Impostare valore fisso o funzione di TM)
CC
C       RETURN
C       END
CC
CC ======================================================================
CC
C       SUBROUTINE RSE0DAT (TIMP, DATIMP)
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C       DIMENSION DATCOE(3), DATSFO(2)
CC
CC     La subroutine RSE0DAT (RSE0 - DATI) deve assegnare i parametri
CC        caratteristici dell'impianto per il calcolo del coefficiente
CC        di scambio termico vapore / metallo ed i fattori di concen-
CC        trazione degli sforzi alla cava ed al foro.
CC
CC     DATO IN INGRESSO
CC        TIMP = Tipo di impianto non-standard (deve essere posto > 6)
CC
CC     DATI IN USCITA
CC        DATCOE = Vettore di dati utili per il calcolo del
CC                 coefficiente di scambio termico:
CC              DATCOE (1) = S07   (adimensionalizzazione Coeff.Scam.)
CC              DATCOE (2) = ...    a disposizione dell'utente
CC                         nella subroutine RSE0CC come DATI(IPD+ 5)
CC              DATCOE (3) = 1.0  se stadio di alta  pressione
CC              DATCOE (3) = 3.2  se stadio di media pressione
CC
CC        DATSFO = Vettore dei dati utili per il calcolo delle
CC                 sollecitazioni sul rotore:
CC              DATSFO (1) = fatt. di concentrazione sigma alla cava
CC              DATSFO (2) = sigma foro / omega^2  [in (kg/mm^2)/(rad/s)^2]
CC
C       RETURN
C       END
CC
CC ======================================================================
CC
CC       REAL FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG, PVAP, DATI, IPD)  !SNGL
CC       DOUBLE PRECISION FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG,        !DBLE
CC            PVAP, DATI, IPD)                                            !DBLE
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
CC
CC---       Function per il calcolo coefficiente di scambio termico
CC          fra il metallo del rotore, assimilato a corpo cilin-
CC          drico (valore medio) e:
CC             - il vapore se passa vapore (WVAP > 0.1 kg/s)
CC             - la cassa se non passa vapore (irraggiamento)
CC
CC       Parametri d'ingresso:
CC        TIMP = Tipo di impianto non-standard (deve essere > 6)
CC        WVAP = Portata di vapore in camera ruota [in kg/s]
CC        TCAS = Temperatura della cassa del rotore [in K]
CC        OMEG = Velocita' di rotazione della macchina [in rad/s]
CC        PVAP = Pressione del vapore in camera ruota [in Pa]
CC        DATI ed IPD come da standard LEGO
CC
CC       Il valore di RSE0CC deve essere fornito in   W / (m^2 * K)
CC
C       DIMENSION DATI(*)
C       INTEGER   IPD
CC
C       RSE0CC = ....
CC
C       RETURN
C       END
CC
CC ======================================================================
CC
CC       REAL FUNCTION RSE0CV (SMAX,SMIN)                                !SNGL
CC       DOUBLE PRECISION FUNCTION RSE0CV (SMAX,SMIN)                     !DBLE
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
CC
CC---       Function per il calcolo del consumo di vita
CC
CC   La function RSE0CV (calcolo del Consumo di Vita) deve restituire
CC       il valore del consumo di vita in funzione della:
CC
CC       Tensione massima e minima al fondo cava (come avviene nel-
CC       l'algoritmo di LANGER)
CC
CC       Deformazione massima al fondo cava (come avviene nell'algo-
CC       ritmo di TIMO): in questo caso e' necessario conoscere le
CC       equazioni di legame tra lo stato di tensione e lo stato di
CC       deformazione che si manifesta nel rotore ed includerle in
CC       questa Function)
CC
CC       Nota: il "consumo di vita" da restituire va inteso come
CC             reciproco della ripetibilita' di un ciclo di fatica
CC             alternata di Smax e Smin dati; se il ciclo ha ripe-
CC             tibilita' infinita (cioe' se non danneggia la macchina)
CC             restituire zero
CC
C          RSE0CV = ........??????
CC
CC      (Impostare la funzione desiderata)
CC
C       RETURN
C       END
CC
CC
C~FORAUS_RSE0~C
C ======================================================================
