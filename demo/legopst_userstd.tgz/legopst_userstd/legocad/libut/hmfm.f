C**********************************************************************
C modulo HMFM.f
C tipo 
C release 5.3
C data 13/10/2007
C reserver @(#)HMFM.f	5.3
C**********************************************************************
C
C**********************************************************************
C
C   Heavy Metal Flow meter
C
C   ref. Frank M. White - Fluid Mechanics - McGraw-Hill - 1986
C    
C
C   Vincenzo Casamassima
C   SSG - Generation Systems Departement
C   CESI Ricerca
C   via Rubattino, 54
C   20134 Milan
C   Italy
C**********************************************************************
C
      SUBROUTINE HMFMI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMFM00/IBLOC
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 NOMAPP
      CHARACTER*4 MOD
      DATA MOD/'HMFM'/
C
C
C
      CALL HMFMI4(IOB,MOD)
C
C
C
      NSTATI=0
      NUSCIT=3
      NINGRE=5
C
      WRITE(NOMAPP,'(A1)')IBLOC
      WP=0.
      IF(NOMAPP(1:1).EQ.'+')WP=1.
      IF(NOMAPP(1:1).EQ.'-')WP=2.
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
      IF (WP.EQ.0.) THEN
        WRITE(IFO,3000)IOB
3000    FORMAT('WTUB',A4,2X,'--UA-- FLUID MASS FLOW RATE ')
        WRITE(IFO,3001)IOB
3001    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3002)IOB
3002    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT METER INLET -W<0')
        WRITE(IFO,3003)IOB
3003    FORMAT('PITU',A4,2X,'--IN-- UPSTREAM PRESSURE ')
        WRITE(IFO,3004)IOB
3004    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3005)IOB
3005    FORMAT('PUTU',A4,2X,'--IN-- DOWNSTREAM PRESSURE')
        WRITE(IFO,3006)IOB
3006    FORMAT('HUTI',A4,2X,'--IN-- FLUID ENTHALPY AT METER OUTLET-W<0')
        WRITE(IFO,3007)IOB
3007    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      IF (WP.EQ.1.) THEN
        WRITE(IFO,3008)IOB
3008    FORMAT('PITU',A4,2X,'--UA-- PIPE INLET PRESSURE ')
        WRITE(IFO,3009)IOB
3009    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3010)IOB
3010    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3011)IOB
3011    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
      WRITE(IFO,3012)IOB
3012    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3013)IOB
3013    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3014)IOB
3014    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3015)IOB
3015    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      IF (WP.EQ.2.) THEN
        WRITE(IFO,3016)IOB
3016    FORMAT('PUTU',A4,2X,'--UA-- PIPE OUTLET PRESSURE ')
        WRITE(IFO,3017)IOB
3017    FORMAT('HUTU',A4,2X,'--UA-- FLUID OUTLET ENTHALPY ')
        WRITE(IFO,3018)IOB
3018    FORMAT('HITI',A4,2X,'--UA-- FLUID ENTHALPY AT PIPE INLET - W<0')
        WRITE(IFO,3019)IOB
3019    FORMAT('PUTU',A4,2X,'--IN-- PIPE OUTLET PRESSURE')
        WRITE(IFO,3020)IOB
3020    FORMAT('HITU',A4,2X,'--IN-- INLET FLUID ENTHALPY')
        WRITE(IFO,3021)IOB
3021    FORMAT('WTUB',A4,2X,'--IN-- PIPE FLUID MASS FLOW RATE ')
         WRITE(IFO,3022)IOB
3022    FORMAT('HUTI',A4,2X,'--IN-- FLUID DOWNSTREAM ENTHALPY - W<0')
        WRITE(IFO,3023)IOB
3023    FORMAT('AKTB',A4,2X,'--IN-- HEAD LOSS ADJUSTEMENT FACTOR')
      END IF
C
      RETURN
      END
      SUBROUTINE HMFMI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMFM00/IBLOC
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MODU
      CHARACTER*1 ICA,IMEN,IPIU
      CHARACTER*1 IBL
      CHARACTER*4 MOD
      DATA IBL/' '/
      DATA IPIU/'+'/
      DATA IMEN/'-'/
C
    2 WRITE(6,2999)
 2999 FORMAT(//10X,'GIVE A CHARACTER'
     $ /5X,' - FLOW RATE AS OUTPUT =========> BLANK'
     $ /5X,' - INLET PRESSURE AS OUTPUT ====>   +'
     $ /5X,' - OUTLET PRESSURE AS OUTPUT ===>   -')
      READ(5,3001)ICA
      IF(ICA.EQ.IPIU)GO TO 1
      IF(ICA.EQ.IMEN)GO TO 1
      IF(ICA.EQ.IBL)GO TO 1
      GO TO 2
 3001 FORMAT(A)
    1 CONTINUE
C
      WRITE(MODU,'(A1,A3)')ICA,MOD
      IF(ICA.EQ.IBL)MODU=MOD
      WRITE(IBLOC,'(2A4)')MODU,IOB
C
      RETURN
      END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMFMI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,NOM1,NOM2,
     $ IER,CNXYU,TOL)
C
C-------------------------------------------------------------------------
C
C     FLUID = Fluid through the flow meter (Lead, LBE, Sodium ....)
C     PID   = Main pipe internal diameter
C     OD    = Orifice Diameter
C     DC    = Dimensionless discharge coefficient Cd
C
C--------------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*8 PID,OD,DC,DFLUID,Fluid,TAPST
      CHARACTER*4 NOMAPP
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
      COMMON / NORM / P0,H0,T0,Q0,R0,AL0,V0,DP0
      DATA DFLUID/'Fluid'/
      DATA TAPST/'TAPSTYPE'/,PID/'Pipe Di.'/,OD/'Orif. d.'/
      DATA DC/'Cd      '/
C
      GO TO (1,10),IFUN
C
C      SCRITTURA DEI SIMBOLI SUL FILE 14
C
    1 WRITE(14,1010)
 1010 FORMAT('*   FLOW METER DATA')
      WRITE(14,1020)DFLUID,TAPST,PID,OD,DC
 1020 FORMAT(3(4X,A8,' =',10X,'*'),5X)
      RETURN
C
C      LETTURA  DEI DATI DAL FILE 14
C
   10 READ(14,1070)
      READ(14,1070)
      READ(14,1071) Fluid,TPOType,PipeD
      READ(14,1070) Orifd,Cd
 1070 FORMAT(3(14X,F10.0,1X),5X)
 1071 FORMAT(14X,A8,3X,2(14X,F10.0,1X),5X)
       write(6,*)'Fluid=',Fluid,'TPOType=',TPOType                                             
       write(6,*)'PipeD=',PipeD,'Orifd=',Orifd                                             
       write(6,*)'Cd=',Cd                                            
C
C
C----- SELECT CASE on CHARACTER type not supported by GNU FORTRAN -------
C
C      Select Case  (Fluid)
C          Case ('Lead')
C            FluidType=1.
C       write(6,*)Fluid,'FluidType=',FluidType                                             
C          Case ('LBE')
C            FluidType=2.
C       write(6,*)Fluid,'FluidType=',FluidType                                             
C          Case ('Sodium')
C            FluidType=3.
C       write(6,*)Fluid,'FluidType=',FluidType                                             
C          Case Default
C            FluidType=1.
C       write(6,*)'Case default ','FluidType=',FluidType                                             
C      End Select
C
      IF (Fluid.EQ.'Lead') THEN
         FluidType=1.
         write(6,*)Fluid,'FluidType=',FluidType
      ELSE IF (Fluid.EQ.'LBE') THEN
         FluidType=2.
         write(6,*)Fluid,'FluidType=',FluidType                                             
      ELSE IF (Fluid.EQ.'Sodium') THEN
         FluidType=3.
         write(6,*)Fluid,'FluidType=',FluidType                                             
      ELSE
         FluidType=1.
          write(6,*)'Case default ','FluidType=',FluidType                                             
      END IF
C                                              
 
C
C----- ------------------------------------------------------ -------
CC
C   CALCOLO DEL COEFFICIENTE DI PERDITA DI CARICO
C
C
C	RK0=0.
C
C	IF(WL.GT.0.) THEN
C	  IFL=1
C          TLEAD=T_H_LEAD(H)
C          RO=RO_T_LEAD(TLEAD)
C 	  RK0=2.*(PM-PV)*RO/(WL*WL)
C	  GO TO 15
C	ENDIF
C	   RK0= CS
C 15   CONTINUE
C
C      DECODE(1,2222,NOM1)IWP
C 2222 FORMAT(A1,3X)
C
C -----   inizio modifica istruzione di DECODE   -----
      WRITE(NOMAPP,'(A1)')NOM1
      IWP=0
      IF(NOMAPP(1:1).EQ.'+')IWP=1
      IF(NOMAPP(1:1).EQ.'-')IWP=2
C -----    fine modifica istruzione di DECODE    -----
C
C       MEMORIZZAZIONE DATI
C
C      RKK=RK0
C      WRITE(6,3023)RKK
 3023 FORMAT(//10X,'HEAD LOSS COEFFICIENT = ',E12.5/)
C
      DATI(ID1)=FluidType
      DATI(ID1+1)=IWP
      DATI(ID1+2)=TPOType
      DATI(ID1+3)=PipeD
      DATI(ID1+4)=Orifd
      DATI(ID1+5)=Cd
      ID2=ID2+5
C
C   COSTANTI DI NORMALIZZAZIONE
C
      CNXYU(IV1)=Q0
      CNXYU(IV1+1)=H0
      CNXYU(IV1+2)=H0
      CNXYU(IV1+3)=P0
      CNXYU(IV1+4)=H0
      CNXYU(IV1+5)=P0
      CNXYU(IV1+6)=H0
      CNXYU(IV1+7)=1.
C
      IF (IWP.EQ.1) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+3)=Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        CNXYU(IV1)=P0
        CNXYU(IV1+5)=Q0
      END IF
C
C   TOLLERANZA PER LA SOLUZIONE DELL'EQUAZIONE
C    viene posta 1000 pascal / P0
C     se viene data la differenza di pressione nominale
C     viene posta 1/100 di quest'ultima.
C
C      TOL(1)=1000./P0
C$$$
C      IF(WL.GT.0.) TOL(1)=(PM-PV)/100./P0
C$$$
C
      IF(IWP.EQ.0)WRITE(6,502)'*** FLOW RATE AS OUTPUT ***'
      IF(IWP.EQ.1)WRITE(6,502)'*** INLET PRESSURE AS OUTPUT ***'
      IF(IWP.EQ.2)WRITE(6,502)'*** OUTLET PRESSURE AS OUTPUT ***'
  502 FORMAT(14X,A)
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMFMC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RN,NOM1,NOM2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER TPOType,FluidType
      REAL MU
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      COMMON/NORM/P0,H0,T0,Q0,R0,AL0,V0,DP0
      COMMON/TOLEG00/TOLIN(100)
      DATA SccsID/'@(#)HMFM.f	5.3\t 5.3\t 10/3/96'/          
      DATA PIGRECO/3.141592653/          
C
      IFL=1
      GO TO (1,10,10),IFUN
C
C   DEFINIZIONE DELLA TOPOLOGIA
C
  1   CONTINUE
C
      DO J=1,3
        DO I=1,8
          AJAC(J,I)=1.
        END DO
      END DO
C
      RETURN
C 
C   DECODIFICA DEI DATI
C
   10 CONTINUE
      FluidType=DATI(IPD)
      IWP=DATI(IPD+1)
      TPOType=DATI(IPD+2)
      PipeD=DATI(IPD+3)
      Orifd=DATI(IPD+4)
      Cd=DATI(IPD+5)
C
C   DECODIFICA DELLE VARIABILI
C
      W=XYU(IXYU)*Q0
      HUTU=XYU(IXYU+1)*H0
      HITI=XYU(IXYU+2)*H0
      PM=XYU(IXYU+3)*P0
      HITU=XYU(IXYU+4)*H0
      PV=XYU(IXYU+5)*P0
      HUTI=XYU(IXYU+6)*H0
      FC=XYU(IXYU+7)
C
      IF (IWP.EQ.1) THEN
        PM=XYU(IXYU)*P0
        W=XYU(IXYU+3)*Q0
      END IF
C
      IF (IWP.EQ.2) THEN
        PV=XYU(IXYU)*P0
        W=XYU(IXYU+5)*Q0
      END IF
CC
      DP = PM-PV
      PMED=(0.5*PM+0.5*PV)
      IF (PM.GE.PV) THEN
        CALL HMFM_FLUID_PROP(FluidType,HITU,RO,MU)
C         TFLUIDI=T_H_LEAD(HITU)
C         RO=RO_T_LEAD(TFLUIDI)
C         MU=MU_T_LEAD(TFLUIDI)
C      write(6,*)'TFLUIDI=',TFLUIDI,' MU=',MU                                              
      ELSE
        CALL HMFM_FLUID_PROP(FluidType,HUTI,RO,MU)
C         TFLUIDO=T_H_LEAD(HUTI)
C         RO=RO_T_LEAD(TFLUIDO)
C         MU=MU_T_LEAD(TFLUIDO)
C      write(6,*)'TFLUIDO=',TFLUIDO,' MU=',MU                                              
       END IF
C
C      PipeD=0.0529
C      Orifd=0.03246
C
C      TOLIN(1)=50./P0
C     TOLIN(1)=0.001/Q0
C
C--- Orifice Flow Section Area 
C
      OFSA=PIGRECO*Orifd*Orifd/4.
C
C--- Reynolds Number
C
      FSA=PIGRECO*PipeD*PipeD/4.
      G=ABS(W)/FSA
      IF (G.NE.0.) THEN
        RE=G*PipeD/MU
      ELSE
        RE=.0001*PipeD/MU
      END IF                                               
C      Write(6,*)'RE=',RE
C
C--- Beta ratio of the device 
C
      Beta=Orifd/PipeD
C
C--- Correction factors F1 - F2
C
C      TPOType=2
      Select Case  (TPOType)
          Case (1)
            F1=0.
            F2=0.
          Case (2)
            F1=0.4333
            F2=0.47
          Case Default
            F1=0.4333
            F2=0.47
      End Select
C
C--- Beta function FB
C
      FB=0.5959+0.0312*Beta**2.1-0.184*Beta**8.
C      Write(6,*)'Beta=',Beta,'FB=',FB
C
C--- Dimensionless Discharge coefficient Cd
C
      Cd=FB+91.71*Beta**2.5/RE**0.75+0.09*Beta**4./(1.-Beta**4.)*F1
     $                                           -0.0337*Beta**3.*F2
      Write(16,*)'Cd=',Cd
C
C   CALCOLO DEL RESIDUO
C
      RK0=(1.-Beta**4.)/(Cd*OFSA)**2.
C      Write(6,*)'RK0=',RK0
      IF(IFUN.EQ.3) GO TO 40
C      RN(1) = (DP-FC*RK0/RO/2.*W*ABS(W))/(Q0*Q0)
      RN(1) = (DP-FC*RK0/RO/2.*W*ABS(W))/P0
      RN(2) = (HITU-HUTU)/H0
      RN(3) = (HUTI-HITI)/H0
C
C
      CSI=(1.-Beta**4.)/(Cd**2.)
      FSPEED=ABS(W)/(RO*OFSA)
      WRITE(34,1005)NOM1,NOM2,FFstLD,CSI,CSI,FSPEED                                                      
     $              ,RE                                                      
1005  FORMAT('Block ',2A4,5x,'f(L/D)',F12.6,5x,'Form loss coefficient K'
     $       ,F12.6,5x,'f(L/D)+K',F12.6,5x,'Average speed [m/s]',F12.6
     $       ,5x,'Average Reynolds number RE  ',F15.6 )
C      
      RETURN
C
C     CALCOLO DELLO JACOBIANO
C
   40 IWPP=IWP+1
      GO TO (42,46,48),IWPP
C
C________ USCITA IN PORTATA
C
C   42 AJAC(1,1) = FC*RK0/RO*(ABS(W)+.1)/P0
C   42 AJAC(1,1) = FC*RK0/RO*ABS(W)/Q0
   42 AJAC(1,1) = FC*RK0/RO*ABS(W)*Q0/P0
      AJAC(1,4) = -1.
      AJAC(1,6) = 1.
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
C      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/Q0
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
        GO TO 50
C
C________ USCITA IN PRESSIONE A MONTE
C
  46  AJAC(1,1) = -1.
C      AJAC(1,4) = FC*RK0/RO*(ABS(W)+.1)/P0
      AJAC(1,4) = FC*RK0/RO*ABS(W)/P0
      AJAC(1,6) = 1.
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
       GO TO 50
C
C________ USCITA IN PRESSIONE A VALLE
C
 48   AJAC(1,1) = 1.
      AJAC(1,4) = -1.
C      AJAC(1,6) = FC*RK0/RO*(ABS(W)+.1)/P0
C      AJAC(1,8) = RK0/RO/2.*(W*ABS(W)+.1*W)/P0
      AJAC(1,6) = FC*RK0/RO*ABS(W)/P0
      AJAC(1,8) = RK0/RO/2.*W*ABS(W)/P0
      AJAC(2,2) = 1.
      AJAC(2,5) = -1.
      AJAC(3,3) = 1.
      AJAC(3,7) = -1.
  50   RETURN
      END
CC
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMFM_FLUID_PROP(FluidType,H,RO,MU)
C
      INTEGER FluidType
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE
C
      Select Case  (FluidType)
          Case (1)
C           Case ('Lead')
            T=T_H_LEAD(H)
            RO=RO_T_LEAD(T)
            MU=MU_T_LEAD(T)
       write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
          Case (2)
C           Case ('LBE')
            T=T_H_LBE(H)
            RO=RO_T_LBE(T)
            MU=MU_T_LBE(T)
C       write(6,*)'Case LBE ','T=',T,' MU=',MU                                              
C          Case (3)
C           Case ('Sodium')
          Case Default
C           Case ('Lead')
            T=T_H_LEAD(H)
            RO=RO_T_LEAD(T)
            MU=MU_T_LEAD(T)
       write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
      RETURN
      END
CC
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMFMD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
