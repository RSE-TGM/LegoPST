C**********************************************************************
C modulo %M%
C tipo %Y%
C release %I%
C data %G%
C Puertollano project libut reserver %W%
C**********************************************************************
      SUBROUTINE VACTI3 (IFO,IOB,DEBL)
      PARAMETER (N0=3, N1=5, N2=5, N3=8, N4=7, N5=6, 
     $           N6=9, N7=11, NV=N0+N1+N2+N3+N4+N5+N6+N7)
C
      CHARACTER*4 IOB, MOD, IBLOC*8, DEBL*80
      CHARACTER*4 NOMI(NV), TIPI(NV)*2, DESC(NV)*50
      DIMENSION NUVAR(8)
C
      DATA MOD /'VACT'/
      DATA NUVAR /N0, N1, N2, N3, N4, N5, N6, N7/
C
      DATA (NOMI(I), TIPI(I), DESC(I), I=1,N0+N1+N2) /
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'AMLV','UA','MEASURE OF VALVE LIFT',
     $ 'ALZV','IN','LIFT OF THE VALVE',
C
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'AMLA','UA','MEASURE OF FIRST VALVE LIFT',
     $ 'AMLB','UA','MEASURE OF SECOND VALVE LIFT',
     $ 'ALZA','IN','LIFT OF FIRST VALVE',
     $ 'ALZB','IN','LIFT OF SECOND VALVE',
C
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'AMLA','UA','MEASURE OF BRANCH A VALVE LIFT',
     $ 'AMLB','UA','MEASURE OF BRANCH B VALVE LIFT',
     $ 'ALZA','IN','LIFT OF BRANCH A VALVE',
     $ 'ALZB','IN','LIFT OF BRANCH B VALVE'/
C
      DATA (NOMI(I), TIPI(I), DESC(I), I=1+N0+N1+N2,NV) /
     $ 'AEQA','UA','LIFT OF BRANCH A EQUIVALENT VALVE',
     $ 'AEQB','UA','LIFT OF BRANCH B EQUIVALENT VALVE',
     $ 'AML3','UA','MEASURE OF THREE WAY VALVE LIFT',
     $ 'AMLA','UA','MEASURE OF BRANCH A VALVE LIFT',
     $ 'AMLB','UA','MEASURE OF BRANCH B VALVE LIFT',
     $ 'ALZ3','IN','LIFT OF THREE WAY VALVE',
     $ 'ALZA','IN','LIFT OF BRANCH A VALVE',
     $ 'ALZB','IN','LIFT OF BRANCH B VALVE',
C 
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'PFLU','IN','FLUID PRESSURE',
     $ 'PSUP','IN','MAX. PRESSURE',
     $ 'PRNG','IN','PRESSURE RANGE',
     $ 'WFLU','IN','FLUID FLOW RATE',
     $ 'WMAX','IN','MAX. FLUID FLOW RATE',
     $ 'ALZB','IN','LIFT OF SECOND VALVE',
C
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'PFLU','IN','FLUID PRESSURE',         
     $ 'PSUP','IN','MAX. PRESSURE',
     $ 'PRNG','IN','PRESSURE RANGE',
     $ 'XMFG','IN','MALFUNCTIONING INDEX',
     $ 'XTRG','IN','TARGET LIFT DURING MALFUNCTIONING',
C
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'WPOM','IN','PUMP DISCHARGE VALVE FLOW RATE',
     $ 'WRIC','IN','RECIRCULATING FLOW RATE',
     $ 'WMIN','IN','MIN. PUMP FLOW RATE',
     $ 'OMPM','IN','PUMP ROTATIONAL SPEED',
     $ 'OMNM','IN','PUMP NOMINAL ROTATIONAL SPEED',
     $ 'KPRO','IN','PROPORTIONAL GAIN',
     $ 'KINT','IN','INTEGRATION TIME',
     $ 'ALZB','IN','LIFT OF THE SECOND VALVE',
C
     $ 'AEQV','UA','LIFT OF EQUIVALENT VALVE',
     $ 'WPOM','IN','PUMP DISCHARGE VALVE FLOW RATE',
     $ 'WRIC','IN','RECIRCULATING FLOW RATE',
     $ 'WMIN','IN','MIN. PUMP FLOW RATE',
     $ 'WMAX','IN','MAX. PUMP FLOW RATE',
     $ 'OMPM','IN','PUMP ROTATIONAL SPEED',
     $ 'OMIN','IN','PUMP MIN. ROTATIONAL SPEED',
     $ 'OMAX','IN','PUMP MAX. ROTATIONAL SPEED',
     $ 'KPRO','IN','PROPORTIONAL GAIN',
     $ 'KINT','IN','INTEGRATION TIME',
     $ 'ALZB','IN','LIFT OF THE SECOND VALVE'/     
C      
      CALL VACTI4 (IOB,MOD,IBLOC,NC)
      I2 = 0
      DO I = 1, NC+1
        I1 = I2+1
        I2 = I2+NUVAR(I)
      ENDDO
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
      WRITE(IFO,3000)(NOMI(I), IOB, TIPI(I), DESC(I), I = I1,I2)
      RETURN
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
 3000 FORMAT(2A4,'  --',A2,'-- ',A)
      END
C
C
C
      SUBROUTINE VACTI4 (IOB,MOD,IBLOC,NC)
      CHARACTER*4 IOB, MOD, IBLOC*8, ICA*1
C
    1 WRITE(6,2)
      READ(5,3,ERR=1)ICA
      NC = ICHAR(ICA) - 48
      IF (NC .LT. 0 .OR. NC .GT. 7) GOTO 1
C
      IBLOC = MOD(1:3) // ICA // IOB
C
      RETURN
    2 FORMAT (/5X,'SELECT THE VALVE ARRANGEMENT:',
     $        /5X,'   0 = ONLY ONE VALVE',
     $        /5X,'   1 = TWO VALVES (SERIAL ARR.)',
     $        /5X,'   2 = TWO VALVES (PARALLEL ARR.)',
     $        /5X,'   3 = THREE WAY VALVE',
     $        /5X,'   4 = THREE WAY RECIRCULATING VALVE',
     $        /5X,'   5 = SAFETY VALVE',
     $        /5X,'   6 = RECIRCULATING VALVE 1 (PI CONTROL)',
     $        /5X,'   7 = RECIRCULATING VALVE 2 (PI CONTROL)')

C     
    3 FORMAT (A)
      END
C
C
C
      SUBROUTINE VACTI2 (IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
C
      PARAMETER (OM0=314.1592)
      DIMENSION VAR(MX1,2), XYU(*),DATI(*),CNXYU(*),TOL(*)
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
      CHARACTER *4 BLOCCO
C
      WRITE (BLOCCO, '(A4)') IBL1
      READ (BLOCCO, '(3X,I1)') NC
      GO TO(1,10) IFUN
C
    1 CONTINUE
      IF (NC.EQ.2) THEN
        WRITE(14,500) 'Y0  (pu)'
      ENDIF  
      IF (NC .EQ. 4 .OR. NC .EQ. 5) THEN
        WRITE(14,500) 'TCORSA  '
      ENDIF  
      RETURN
C
   10 READ(14,501)
C
      IF (NC .EQ. 0 ) THEN
        DATI(ID2  ) = NC
        DO I = IV1, IV2
          CNXYU(I) = 1.
        ENDDO
        ID2 = ID2+1
      ELSE IF (NC .EQ. 1 ) THEN
        DATI(ID2  ) = NC
        DO I = IV1, IV2
          CNXYU(I) = 1.
        ENDDO
        ID2 = ID2+2
      ELSE IF (NC .EQ. 2 ) THEN
        READ(14,501) Y0
        IF(Y0.GT.1.)Y0=1.
        DATI(ID2  ) = NC
        DATI(ID2+1) = Y0
        DO I = IV1, IV2
          CNXYU(I) = 1.
        ENDDO
        ID2 = ID2+1+2
      ELSE IF (NC .EQ. 3 ) THEN
        DATI(ID2  ) = NC
        DO I = IV1, IV2
          CNXYU(I) = 1.
        ENDDO
        ID2 = ID2+3
      ELSE IF (NC .EQ. 4 .OR. NC .EQ. 5) THEN
        READ(14,501) TCORSA
        DATI(ID2  ) = NC
        DATI(ID2+3) = TCORSA
        ID2 = ID2+5
        IF (NC .EQ. 4) THEN
          CNXYU(IV1  ) = 1.
          CNXYU(IV1+1) = P0
          CNXYU(IV1+2) = P0
          CNXYU(IV1+3) = P0
          CNXYU(IV1+4) = W0
          CNXYU(IV1+5) = W0
          CNXYU(IV1+6) = 1.
        ELSE
          CNXYU(IV1  ) = 1.
          CNXYU(IV1+1) = P0
          CNXYU(IV1+2) = P0
          CNXYU(IV1+3) = P0
          CNXYU(IV1+4) = 1.
          CNXYU(IV1+5) = 1.
        ENDIF
      ELSE IF (NC .EQ. 6) THEN
        DATI (ID2  ) = NC
        CNXYU(IV1  ) = 1.
        CNXYU(IV1+1) = W0
        CNXYU(IV1+2) = W0
        CNXYU(IV1+3) = W0
        CNXYU(IV1+4) = OM0
        CNXYU(IV1+5) = OM0
        CNXYU(IV1+6) = 1.
        CNXYU(IV1+7) = 1.
        CNXYU(IV1+8) = 1.
        ID2 = ID2 + 4
      ELSE IF (NC. EQ. 7) THEN
        DATI (ID2   ) = NC
        CNXYU(IV1   ) = 1.
        CNXYU(IV1+1 ) = W0
        CNXYU(IV1+2 ) = W0
        CNXYU(IV1+3 ) = W0
        CNXYU(IV1+4 ) = W0
        CNXYU(IV1+5 ) = OM0
        CNXYU(IV1+6 ) = OM0
        CNXYU(IV1+7 ) = OM0
        CNXYU(IV1+8 ) = 1.
        CNXYU(IV1+9 ) = 1.
        CNXYU(IV1+10) = 1.
        ID2 = ID2+4                              
      ELSE
        DATI (ID2  ) =  NC
        DO I = IV1, IV2
          CNXYU(I) = 1.
        ENDDO
        ID2 = ID2
      ENDIF 
C
      RETURN
C      
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  501 FORMAT(3(14X,F10.0,1X))
C  
      END
C
C
C
      SUBROUTINE VACTC1 (IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*100 SccsID
       DATA SccsID/'%W%\t %I%\t %G% Puerpro libut'/     
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
      PARAMETER (OM0=314.1592)
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      LOGICAL KREGIM, APE, CHIU
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/NEQUAZ/NEQMOD
C
C---Lift of equivalent valves (serial, parall., 3-way)
C
      NC = NINT(DATI(IPD))
      IF (.NOT. KREGIM) THEN
        NEQMOD = 1
        IF (NC .EQ. 3) THEN
          NEQMOD = 2
        ENDIF 
      ENDIF

C
      GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100   CONTINUE
C
        IF (NC .EQ. 0) THEN
          AJAC(1,1) = 1.
          AJAC(1,3) = 1.
          IF (KREGIM) THEN
            AJAC(2,2) = 1.
            AJAC(2,3) = 1.
          ENDIF   
        ELSE IF (NC .EQ. 1 .OR. NC .EQ. 2) THEN
          AJAC(1,1) = 1.
          AJAC(1,4) = 1.
          AJAC(1,5) = 1.
          IF (KREGIM) THEN
            AJAC(2,2) = 1.
            AJAC(2,4) = 1.
            AJAC(3,3) = 1.
            AJAC(3,5) = 1.
          ENDIF  
        ELSE IF (NC .EQ. 3) THEN
          AJAC(1,1) = 1.
          AJAC(1,6) = 1.
          AJAC(1,7) = 1.
          AJAC(2,2) = 1.
          AJAC(2,6) = 1.
          AJAC(2,8) = 1.
          IF (KREGIM) THEN 
            AJAC(3,3) = 1.
            AJAC(3,6) = 1.
            AJAC(4,4) = 1.
            AJAC(4,7) = 1.
            AJAC(5,5) = 1.
            AJAC(5,8) = 1.
          ENDIF  
        ELSE IF (NC .EQ. 4) THEN
          AJAC(1,1) = 1.
          AJAC(1,2) = 1.
          AJAC(1,3) = 1.
          AJAC(1,4) = 1.
          AJAC(1,5) = 1.
          AJAC(1,6) = 1.
          AJAC(1,7) = 1.
        ELSE IF (NC .EQ. 5) THEN
          AJAC(1,1) = 1.
          AJAC(1,2) = 1.
          AJAC(1,3) = 1.
          AJAC(1,4) = 1.
          AJAC(1,5) = 1.
          AJAC(1,6) = 1.
        ELSE IF (NC .EQ. 6) THEN
          DO J = 1,9
           AJAC(1,J) = 1.
          END DO
        ELSE
          DO J = 1,11
           AJAC(1,J) = 1.
          END DO 
        ENDIF
        RETURN
C
C---calcolo residui
C
  200 CONTINUE
      IF (NC .EQ. 0) THEN
        AEQV = XYU(IXYU  )
        AMLV = XYU(IXYU+1)
        ALZV = XYU(IXYU+2)
        IF (KREGIM) THEN
          RNI(1) = AEQV - ALZV
          RNI(2) = AMLV - ALZV
        ELSE
          RNI(1) = AEQV - ALZV
          IF (ITERT.EQ.0) THEN
             DATI(IPD+1)=ALZV
             RNI(2) = ALZV
          ELSE
             RNI(2) = DATI(IPD+1)
          ENDIF
        ENDIF
      ELSE IF (NC .EQ. 1 .OR. NC .EQ. 2) THEN
        AEQV = XYU(IXYU  )
        AMLA = XYU(IXYU+1)
        AMLB = XYU(IXYU+2)
        ALZA = XYU(IXYU+3)
        ALZB = XYU(IXYU+4)
        IF (KREGIM) THEN
          IF (NC .EQ. 1) THEN
            RNI(1) = AEQV - ALZA * ALZB
          ELSE
            Y0=DATI(IPD+1)
            IF(Y0.LE.0.)THEN
              RNI(1) = AEQV - 0.5 * (ALZA + ALZB)
            ELSE
              RNI(1) = AEQV - ALZA-Y0*ALZB*(1.-ALZA)
            ENDIF           
          ENDIF           
          RNI(2) = AMLA - ALZA
          RNI(3) = AMLB - ALZB
        ELSE
          IF (NC .EQ. 1) THEN
            RNI(1) = AEQV - ALZA * ALZB
            IF(ITERT.EQ.0)THEN
              DATI(IPD+1)=ALZA
              DATI(IPD+2)=ALZB
              RNI(2) = ALZA
              RNI(3) = ALZB
             ELSE
              RNI(2) = DATI(IPD+1)
              RNI(3) = DATI(IPD+2)
             ENDIF
          ELSE
            Y0=DATI(IPD+1)
            IF(Y0.LE.0.)THEN
              RNI(1) = AEQV - 0.5 * (ALZA + ALZB)
            ELSE
              RNI(1) = AEQV - ALZA-Y0*ALZB*(1.-ALZA)
            ENDIF           
            IF(ITERT.EQ.0)THEN
              DATI(IPD+2)=ALZA
              DATI(IPD+3)=ALZB
              RNI(2) = ALZA
              RNI(3) = ALZB
            ELSE
              RNI(2) = DATI(IPD+2)
              RNI(3) = DATI(IPD+3)
            ENDIF
          ENDIF           
        ENDIF
      ELSE IF (NC .EQ. 3) THEN
        AEQA = XYU(IXYU  )
        AEQB = XYU(IXYU+1)
        AML3 = XYU(IXYU+2)
        AMLA = XYU(IXYU+3)
        AMLB = XYU(IXYU+4)
        ALZ3 = XYU(IXYU+5)
        ALZA = XYU(IXYU+6)
        ALZB = XYU(IXYU+7)
        IF (KREGIM) THEN
          RNI(1) = AEQA - ALZA * ALZ3
          RNI(2) = AEQB - ALZB * (1.-ALZ3) 
          RNI(3) = AML3 - ALZ3
          RNI(4) = AMLA - ALZA
          RNI(5) = AMLB - ALZB
        ELSE
          RNI(1) = AEQA - ALZA * ALZ3
          RNI(2) = AEQB - ALZB * (1.-ALZ3)          
          IF(ITERT.EQ.0)THEN
            DATI(IPD+1)=ALZ3
            DATI(IPD+2)=ALZA
            DATI(IPD+3)=ALZB
            RNI(3) = ALZ3
            RNI(4) = ALZA
            RNI(5) = ALZB
          ELSE
            RNI(3) = DATI(IPD+1)
            RNI(4) = DATI(IPD+2)
            RNI(5) = DATI(IPD+3)
          ENDIF
        ENDIF
      ELSE IF (NC .EQ. 4) THEN
        AEQV = XYU(IXYU  )
        PFLU = XYU(IXYU+1)*P0
        PSUP = XYU(IXYU+2)*P0
        PRNG = XYU(IXYU+3)*P0
        WFLU = XYU(IXYU+4)*W0
        WMAX = XYU(IXYU+5)*W0
        ALZB = XYU(IXYU+6)
C
        TCORSA = DATI(IPD+3)
C
        PINF = PSUP - PRNG
C      
        IF (KREGIM) THEN
          RNI(1) = 0. 
          DATI(IPD+1) = AEQV
          DATI(IPD+2) = AEQV
          DATI(IPD+4) = AEQV
          DATI(IPD+5) = AEQV
        ELSE
          IF (ITERT .LE. 0 .AND. IFUN .EQ. 2) THEN
            DATI(IPD+4) = DATI(IPD+2)
            DATI(IPD+5) = DATI(IPD+1)
          ENDIF
            ALZTP = DATI(IPD+4)
            ALZP = DATI(IPD+5)  
            IF (ALZTP .GE. 1.) THEN
              IF(PFLU .LT. PINF) THEN
                IF(WFLU .GE. WMAX) THEN
                  ALZT = 0.
                ELSE
                  ALZT = 1.
                ENDIF
              ELSE
                ALZT = 1.
              ENDIF
            ELSE IF (ALZTP .LE. 0.) THEN
              IF(PFLU .GE. PSUP) THEN
                ALZT = 1.
              ELSE
                ALZT = 0.
              ENDIF
            ENDIF
            ER = ALZT - ALZP
            IF (ABS(ER) .LT. 1.E-4) THEN
              SIG = 0.
            ELSE
              SIG = ABS(ER) / ER
            ENDIF
            ALZC = ALZP + SIG*DTINT/TCORSA
            IF (TCORSA .LT. DTINT) ALZC = ALZT
            IF (ALZC .LT. 0.) ALZC = 0.
            IF (ALZC .GT. 1.) ALZC = 1. 
            RNI(1) = AEQV-ALZC*ALZB 
            DATI(IPD+1) = ALZC
            DATI(IPD+2) = ALZT 
          ENDIF 
      ELSE IF (NC .EQ. 5) THEN
        AEQV = XYU(IXYU  )
        PFLU = XYU(IXYU+1)*P0
        PSUP = XYU(IXYU+2)*P0
        PRNG = XYU(IXYU+3)*P0
        XMFG = XYU(IXYU+4)
        XTRG = XYU(IXYU+5)
C
        PINF = PSUP - PRNG
C
        TCORSA = DATI(IPD+3)
        IF (KREGIM) THEN       
          IF (PFLU .GE. PSUP) ALZC = 1.
          IF (PFLU .LE. PINF) ALZC = 0.
          RNI(1) = AEQV - ALZC
          DATI(IPD+1) = ALZC
          DATI(IPD+2) = ALZC
          DATI(IPD+4) = ALZC
          DATI(IPD+5) = ALZC 
        ELSE          
          IF (ITERT .LE. 0 .AND. IFUN .EQ. 2) THEN
            DATI(IPD+4) = DATI(IPD+2)
            DATI(IPD+5) = DATI(IPD+1)
          ENDIF
            ALZP = DATI(IPD+5)
            ALZTP = DATI(IPD+4)   
            IF (XMFG .GE. 1.5) THEN
              ALZT = 1.
              TT = 1.
            ELSE IF (XMFG .GE. 0.5 .AND. XMFG .LT. 1.5) THEN
              IF (PFLU .GE. PSUP) THEN
                ALZT = XTRG
                TT = XTRG
              ELSE
                ALZT = ALZTP
                TT = 1.
              ENDIF
            ELSE
              TT = 1.
              IF (ALZTP .GE. 1.E-2) THEN
                IF(PFLU .LT. PINF) THEN
                  ALZT = 0.
                ELSE
                  ALZT = 1.
                ENDIF
              ELSE IF (ALZTP .LE. 0.) THEN
                IF(PFLU .GE. PSUP) THEN
                  ALZT = 1.
                ELSE
                  ALZT = 0.
                ENDIF
              ENDIF
            ENDIF
            ER = ALZT - ALZP
            IF (ABS(ER) .LT. 1.E-4) THEN
              SIG = 0.
            ELSE
              SIG = ABS(ER) / ER
            ENDIF
            ALZC = ALZP + SIG*DTINT/TCORSA
            IF (TCORSA .LT. DTINT) ALZC = ALZT
            IF (ALZC .LT. 0.) ALZC = 0.
            IF (ALZC .GT. TT) ALZC = TT
            RNI(1) = AEQV - ALZC
            DATI(IPD+1) = ALZC
            DATI(IPD+2) = ALZT
        ENDIF             
      ELSE IF (NC .EQ. 6) THEN
        AEQV = XYU(IXYU  )
        WPOM = XYU(IXYU+1)*W0
        WRIC = XYU(IXYU+2)*W0
        WMIN = XYU(IXYU+3)*W0
        OMPM = XYU(IXYU+4)*OM0
        OMNM = XYU(IXYU+5)*OM0
        GPRO = XYU(IXYU+6)
        TINT = XYU(IXYU+7)
        ALZB = XYU(IXYU+8)
C
        IF (KREGIM) THEN
          DATI(IPD+2) = AEQV
          DATI(IPD+4) = AEQV
          IF (OMPM .LT. OMNM) THEN
              DATI(IPD+1) = -WMIN / 10.
              DATI(IPD+3) = -WMIN / 10.
          ELSE
              DATI(IPD+1) = WMIN
              DATI(IPD+3) = WMIN
          ENDIF          
        ELSE
          IF (ITERT .LE. 0 .AND. IFUN .EQ. 2) THEN
            DATI(IPD+3) = DATI(IPD+1)
            DATI(IPD+4) = DATI(IPD+2)
          ENDIF
            YP = DATI(IPD+4)
            WMINP = DATI(IPD+3)
            IF (OMPM .LT. OMNM) THEN
              WMINS = -WMIN / 10.
            ELSE
              WMINS = WMIN
            ENDIF
            WMINF = WMINP*5./(5.+DTINT) + WMINS*DTINT/(5.+DTINT)
            ER = WMINF - WPOM - WRIC
            YC = YP + ER*DTINT/TINT
            IF (YC .LE. 0.) YC = 0.
            IF (YC .GE. 1.) YC = 1.
            DATI(IPD+1) = WMINF
            DATI(IPD+2) = YC
            RNI(1) = (AEQV-YC)
        ENDIF
      ELSE
        AEQV = XYU(IXYU   )
        WPOM = XYU(IXYU+1 )*W0
        WRIC = XYU(IXYU+2 )*W0
        WMIN = XYU(IXYU+3 )*W0
        WMAX = XYU(IXYU+4 )*W0
        OMPM = XYU(IXYU+5 )*OM0
        OMIN = XYU(IXYU+6 )*OM0
        OMAX = XYU(IXYU+7 )*OM0
        GPRO = XYU(IXYU+8 )
        TINT = XYU(IXYU+9 )
        ALZB = XYU(IXYU+10)
C
        IF (KREGIM) THEN
          DATI(IPD+2) = AEQV
          DATI(IPD+4) = AEQV
          DELTAOM = OMAX - OMIN
          DELTAWM = WMAX - WMIN
          RAPP = DELTAWM / DELTAOM
          IF (OMPM .LT. OMIN) THEN
              DATI(IPD+1) = -WMIN / 10.
              DATI(IPD+3) = -WMIN / 10.
          ELSE
              DATI(IPD+1) = WMIN + RAPP*(OMPM - OMIN)
              DATI(IPD+3) = WMIN + RAPP*(OMPM - OMIN)
          ENDIF          
        ELSE
          IF (ITERT .LE. 0 .AND. IFUN .EQ. 2) THEN
            DATI(IPD+3) = DATI(IPD+1)
            DATI(IPD+4) = DATI(IPD+2)
          ENDIF
            DELTAOM = OMAX - OMIN
            DELTAWM = WMAX - WMIN
            RAPP = DELTAWM / DELTAOM
            YP = DATI(IPD+4)
            WMINP = DATI(IPD+3)
            IF (OMPM .LT. OMIN) THEN
              WMINS = -WMIN / 10.
            ELSE
              WMINS = WMIN + RAPP*(OMPM - OMIN)
            ENDIF
            WMINF = WMINP*5./(5.+DTINT) + WMINS*DTINT/(5.+DTINT)
            ER = WMINF - WPOM - WRIC
            YC = YP + ER*DTINT/TINT
            IF (YC .LE. 0.) YC = 0.
            IF (YC .GE. 1.) YC = 1.
            DATI(IPD+1) = WMINF
            DATI(IPD+2) = YC
            RNI(1) = (AEQV-YC)
        ENDIF                 
      ENDIF
      RETURN
C
C---calcolo jacobiano
C
  300 CONTINUE
      IF (NC .EQ. 0) THEN
        AJAC(1,1) = -1.
        AJAC(1,3) = 1.
        IF (KREGIM) THEN   
          AJAC(2,2) = -1.
          AJAC(2,3) = 1.
        ENDIF          
      ELSE IF (NC .EQ. 1) THEN
        ALZA = XYU(IXYU+3)
        ALZB = XYU(IXYU+4)
        AJAC(1,1) = -1.
        AJAC(1,4) = ALZB
        AJAC(1,5) = ALZA
        IF (KREGIM) THEN 
          AJAC(2,2) = -1.
          AJAC(2,4) = 1.
          AJAC(3,3) = -1.
          AJAC(3,5) = 1.
        ENDIF  
      ELSE IF (NC .EQ. 2) THEN
        Y0=DATI(IPD+1)
        IF(Y0.LE.0.)THEN
          AJAC(1,1) = -1.
          AJAC(1,4) = 0.5
          AJAC(1,5) = 0.5
        ELSE
          AJAC(1,1) = -1.
          AJAC(1,4) = 1.-Y0*ALZB
          AJAC(1,5) = Y0*(1.-ALZA)
        ENDIF
       IF (KREGIM) THEN
          AJAC(2,2) = -1.
          AJAC(2,4) = 1.
          AJAC(3,3) = -1.
          AJAC(3,5) = 1.
        ENDIF  
      ELSE IF (NC. EQ. 3) THEN
        ALZ3 = XYU(IXYU+5)
        ALZA = XYU(IXYU+6)
        ALZB = XYU(IXYU+7)
        AJAC(1,1) = -1.
        AJAC(1,6) = ALZA
        AJAC(1,7) = ALZ3
        AJAC(2,2) = -1.
        AJAC(2,6) = -ALZB
        AJAC(2,8) = 1.-ALZ3
        IF (KREGIM) THEN
          AJAC(3,3) = -1.
          AJAC(3,6) = 1.
          AJAC(4,4) = -1.
          AJAC(4,7) = 1.
          AJAC(5,5) = -1.
          AJAC(5,8) = 1.
        ENDIF  
      ELSE IF (NC .EQ. 4) THEN
        AJAC(1,1) = -1.
        AJAC(1,7) = 1.
      ELSE
        AJAC(1,1) = -1.
      ENDIF
      RETURN
C
      END
C
C
C
      SUBROUTINE VACTD1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
