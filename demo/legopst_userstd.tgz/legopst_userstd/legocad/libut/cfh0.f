C modulo cfh0.f
C tipo
C release 0.0
C data 17/novembre/2011
C Mille600 project libut reserver @(#)cfh0.f	0.0
C**********************************************************************
C
C   Cross Flow Heater rel.0
C 
C
C**********************************************************************
C
      SUBROUTINE CFH0I3(IFO,IOB,DEBL)
      COMMON/CFH000/IBLOC,NE,NUS
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'CFH0'/
C
C
      CALL CFH0I4(IOB,MOD)
C
C----  Numero Zone Longitudinali (rispetto al fascio tubiero)
C
      NZL=3
C
C----  Numero Zone Trasversali (rispetto al fascio tubiero)
C
      NZT=5
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      WRITE(IFO,3000)IOB
 3000 FORMAT('PWSS',A4,2X,'--US-- SHELL SIDE WATER PRESSURE')
C
      DO I=1,NZL
        DO J=1,NZT
          WRITE(IFO,3001) I,J,IOB,I,J
 3001     FORMAT('HS',2I1,A4,2X
     $          ,'--US-- SHELL SIDE WATER ENTHALPY ZONE L ',I1,' T ',I1)
        END DO
      END DO
C
      WRITE(IFO,3002)IOB
 3002 FORMAT('TAMS',A4,2X,'--US-- SHELL METAL AVERAGE TEMPERATURE')
C
      DO I=1,NZL
        DO J=1,NZT
          WRITE(IFO,3003) I,J,IOB,I,J
 3003     FORMAT('TM',2I1,A4,2X,
     $           '--US-- TUBES WALL TEMPERATURE ZONE L ',I1,' T ',I1)
        END DO
      END DO
C
      DO I=1,NZL
        DO J=1,NZT
          WRITE(IFO,3004) I,J,IOB,I,J
 3004     FORMAT('HF',2I1,A4,2X,
     $           '--US-- TUBES SIDE WATER ENTHALPY ZONE L ',I1,' T ',I1)
        END DO
      END DO
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HSAO',A4,2X,'--UA-- SHELL SIDE WATER OUTLET ENTHALPY')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('WFDW',A4,2X,'--UA--  TUBES SIDE WATER MASS FLOW RATE')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('HTAO',A4,2X,'--UA-- TUBES SIDE WATER OUTLET ENTHALPY')
C
      DO J=1,NE
        WRITE(IFO,3020)J,IOB,J
        WRITE(IFO,3021)J,IOB,J
      ENDDO 
 3020 FORMAT('WS',I2,A4,2X,'--IN-- SHELL SIDE INLET FLOW RATE BR N.',I2)
 3021 FORMAT('HS',I2,A4,2X,'--IN-- SHELL SIDE INLET ENTHALPY  BR N.',I2)
C
      DO J=1,NUS
        WRITE(IFO,3022)J,IOB,J
        WRITE(IFO,3023)J,IOB,J
      ENDDO
 3022 FORMAT('WSO',I1,A4,2X,'--IN-- SHELL SIDE FLOW RATE OUTLET  N ',I1)
 3023 FORMAT('HSO',I1,A4,2X,'--IN-- SHELL SIDE ENTHALPY N',I1,'(W<0)')
C
      WRITE(IFO,3024)IOB
 3024 FORMAT('PFIN',A4,2X,'--IN-- TUBES SIDE WATER INLET PRESSURE')
C
      WRITE(IFO,3025)IOB
 3025 FORMAT('HFIN',A4,2X,'--IN-- TUBES SIDE WATER INLET ENTHALPY')
C
      WRITE(IFO,3026)IOB
 3026 FORMAT('PFOU',A4,2X,'--IN-- TUBES SIDE WATER OUTLET PRESSURE')
C
      WRITE(IFO,3027)IOB
 3027 FORMAT('HFOU',A4,2X
     $      ,'--IN-- TUBES SIDE REVERSE FLOW WATER ENTHALPY W<0')
C
      WRITE(IFO,3028)IOB
 3028 FORMAT('FTFF',A4,2X,'--IN-- TUBES SIDE FRICTION FACTOR')
C
      WRITE(IFO,3029)IOB
 3029 FORMAT('AHTR',A4,2X
     $      ,'--IN-- HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3030)IOB
 3030 FORMAT('GSIF',A4,2X
     $      ,'--IN-- SHELL-INNER FLUID HEAT TRANSFER COEFFICIENT')
C
      WRITE(IFO,3031)IOB
 3031 FORMAT('TEST',A4,2X,'--IN-- EXTERNAL ENVIRONMENT TEMPERATURE')
C
      WRITE(IFO,3032)IOB
 3032 FORMAT('GEST',A4,2X,'--IN-- EXTERNAL HEAT TRANSFER COEFFICIENT')
C
C
      RETURN
      END
C***********************************************************************
      SUBROUTINE CFH0I4(IOB,MOD)
      PARAMETER (MAXIO=5,MAXCI=15)
      COMMON/CFH000/IBLOC,NE,NUS
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
C
      WRITE(6,101) MAXIO
  101 FORMAT(10X,'***** Cross Flow Heater model - rel.0 *****',//,
     $       10X,'Shell Side Inlet Branches Number [01 -',I3,'] ?')
    9 CONTINUE
      READ(5,*) NE
      IF(NE.LE.0.OR.NE.GT.MAXIO) THEN
         WRITE(6,102) NE,MAXIO
         GOTO 9
      ENDIF
  102 FORMAT(/10X,'%% ERROR %% -> assigned inlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')
C
C
      WRITE(6,105) MAXIO
  105 FORMAT(10X,'Shell Side Outlet Branches Number [01 -',I3,'] ?')
   15 CONTINUE
      READ(5,*) NUS
      IF(NUS.LT.1.OR.NUS.GT.MAXIO) THEN
         WRITE(6,106) NUS,MAXIO
         GOTO 15
      ENDIF
  106 FORMAT(10X,'%% ERROR %% -> assigned outlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C***********************************************************************
        SUBROUTINE CFH0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
        DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
        PARAMETER (PI=3.14159)
        PARAMETER (MAXIO=5,MAXCI=15)
        PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
        COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
C
C   Cross Flow (Shell & Tubes) Heater model
C
        GO TO(100,200),IFUN
C
  100   WRITE(14,500)    'I.S.B.N.'
     1                  ,'O.S.B.N.'
     1                  ,'SH.O.D. '
     1                  ,'SH.THICK'
     1                  ,'SH.LENGH'
     1                  ,'SH.M.RO.'
     1                  ,'SH.CP.  '
     1                  ,'SH.COND.'
     1                  ,'D.C.I.  '
     1                  ,'TUB.NUMB'
     1                  ,'TUB.O.D.'
     1                  ,'TUB.THIC'
     1                  ,'TUB.LENG'
     1                  ,'TUB.T.P.'
     1                  ,'TUB.L.P.'
     1                  ,'TU.M.RO.'
     1                  ,'TUB. CP.'
     1                  ,'TUB. K. '
     1                  ,'HTR.SURF'
     1                  ,'U.SH.T.C'
     1                  ,'U.TH.T.C'
     1                  ,'Tub.Arr.'
        RETURN
C
C
C
C-----------'I.S.B.N.' - Inlet Steam Branch Number
C-----------'O.S.B.N.' - Outlet Steam Branch Number
C-----------'SH.O.D. ' - SHell Outside Diameter
C-----------'SH.THICK' - SHell THICKness
C-----------'SH.LENGH' - SHell LENGHT
C-----------'SH.M.RO.' - SHell Metal density
C-----------'SH.CP.  ' - SHell metal specific heat
C-----------'SH.COND.' - SHell metal CONDuctivity
C-----------'D.C.I.  ' - Diametro Cassa Interna
C-----------'TUB.NUMB' - TUBes NUMBer
C-----------'TUB.O.D.' - TUBes Outside Diameter
C-----------'TUB.THIC' - TUBes THICkness
C-----------'TUB.LENG' - TUBes LENGht
C-----------'TUB.T.P.' - TUBes Transverse Pitch
C-----------'TUB.L.P.' - TUBes Longitudinal Pitch
C-----------'TU.M.RO.' - TUbes Metal density
C-----------'TUB. CP.' - TUBes Metal specific heat
C-----------'TUB. K. ' - TUBes metal conductivity
C-----------'HTR.SURF' - DeSuperHeating SURFace
C-----------'U.SH.T.C' - User Shell Heat Transfer Coefficient
C-----------'U.TH.T.C' - User Tubes Heat Transfer Coefficient
C-----------'Tub.Arr.' - Tubes Arrangement 0 = staggered; 1 = aligned

C
C---lettura e memorizzazione dati
C
  200   READ(14,502)
        READ(14,502)     FNE
     1                  ,FNUS
     1                  ,SHOD
     1                  ,SHTHICK
     1                  ,SHLENGH
     1                  ,SHRO
     1                  ,SHCP
     1                  ,SHCOND
     1                  ,DCI
     1                  ,FNTUB
     1                  ,TUBOD
     1                  ,TTHICK
     1                  ,TUBLENGH
     1                  ,TUBTP
     1                  ,TUBLP
     1                  ,TUBRO
     1                  ,TUBCP
     1                  ,TUBK
     1                  ,HTRSUP
     1                  ,USHTC
     1                  ,UTHTC
     1                  ,TUBARR
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  502 FORMAT(3(14X,F10.2,1X))
C
C______________________________________________
C
      NE=FNE
      NUS=FNUS
      NZL=3
      NZT=5
      FNZL=FLOAT(NZL)
      FNZT=FLOAT(NZT)
      NTUB=FNTUB
      HTA=TUBARR
C
C--- Shell outside surface ---
C
      SHOS=PI*SHOD*SHLENGH
C
C--- Shell inside diameter ---
C
      SHID=SHOD-2.*SHTHICK
C
C--- Shell inside surface ---
C
      SHIS=PI*SHID*SHLENGH
C
C--- Volume beetwen shell and internal tank ---
C
      SHIV=PI*(SHID**2.-DCI**2.)*SHLENGH/4.
C
C--- Tank inner volume without tubes' volume ---
C
      TIVWT=PI*DCI**2.*SHLENGH/4.-FNTUB*PI*(TUBOD**2)*TUBLENGH/4.
C
C--- Number of longitudinal rows of tubes ---
C
      NLR=AINT(DCI/TUBLP)-1.
C
C--- Number of transverse rows of tubes ---
C
      NTR=NTUB/NLR
C
C--- Global volume among tubes ---
C
      VG=DCI*(NTR+1)*TUBTP*TUBLENGH
      VGAT=VG-FNTUB*PI*(TUBOD**2)*TUBLENGH/4.
      VGATZ=VGAT/(FNZT*FNZL)
C
C
C
      IF (VGATZ.LE.0) THEN
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^    ERROR!!  ERROR!  ERROR!  ERROR!  ERROR!!    ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^  Tubes volume can''t be bigger then enclosure  ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)' '
        STOP
      ENDIF
C
C--- Internal tank flow cross-sectional area ---
C
C     FCSA=PI*(DCI**2.)/4.-FNTUB*PI*(TUBOD**2.)/4.
      FCSA=0.5*(PI*(DCI**2.)/4.-2.*FNTUB*PI*(TUBOD**2.)/4.)
C
C--- Internal tank equivalent diameter ---
C
C     EQD=4.*FCSA/(PI*DCI+FNTUB*PI*TUBOD)
      EQD=4.*FCSA/(FNTUB*PI*TUBOD)
C
C--- Shell metal mass ---
C
      SHMASS=SHRO*PI*(SHOD**2.-SHID**2.)/4.*SHLENGH
C
C--- Shell thermal capacity ---
C
      SHELLTC=SHCP*SHMASS
C
C--- Internal tank heat exchange surface per zone ---
C
      SSCIZ=PI*DCI*SHLENGH/FNZL
C
C--- Tubes' heat exchange surface per zone ---
C
      IF (HTRSUP.EQ.0.) THEN
         HTRSUP=FNTUB*PI*TUBOD*TUBLENGH
         TUBZSURF=FNTUB*PI*TUBOD*TUBLENGH/(FNZL*FNZT)
      ELSE
         TUBZSURF=HTRSUP/(FNZL*FNZT)
C
C--- Average tubes' outside diameter ----
C
         TUBOD=HTRSUP/(PI*FNTUB*TUBLENGH)
      ENDIF
C
C
C--- Feedwater tubes flow cross-sectional area ---
C
      FTCSA=FNTUB*PI*((TUBOD-2.*TTHICK)**2.)/4.
C
C--- Feedwater tubes equivalent diameter ---
C
      FTEQD=4.*FTCSA/(FNTUB*PI*(TUBOD-2.*TTHICK))
C
C
      WRITE(6,11)
   11 FORMAT(/10X,24H----  Shell's Data  ----)
      WRITE(6,12)SHOD,SHTHICK,SHLENGH,SHID
   12 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Shell lenght',13X,'Inside diameter',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],23X,3H[m]//,10X,
     $       4(G15.6,10X))
      WRITE(6,13)SHOS,SHIS,(VGATZ+SHIV),SHMASS
   13 FORMAT(///10X,'Outside surface',10X,'Inside surface',
     $       11X,'Inside volume',12X,'Metal mass',/16X,
     $       4H[m2],19X,4H[m2],22X,4H[m3],20X,4H[kg]//,10X,
     $       4(G15.6,10X))
      WRITE(6,14)FCSA,EQD
   14 FORMAT(///10X,'Flow cross-sectional area',
     $       10X,'Equivalent diameter',/,20X,
     $       4H[m2],30X,3H[m]//,10X,
     $       2(G15.6,20X))
      WRITE(6,1)
    1 FORMAT(/////10X,23H----  Tubes' Data  ----)
      WRITE(6,*) ' '
      WRITE(6,2)TUBOD,TTHICK,TUBLENGH,NTUB
    2 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Tubes lenght',13X,'Tubes number',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],21X,3H[-],//,10X,
     $       3(G15.6,10X),1I5)
      WRITE(6,*) ' '
      WRITE(6,3)TUBZSURF*FNZL*FNZT,TUBZSURF,NZL,NZT
    3 FORMAT(/10X,'Heat Exchange Surface',9X,
     $       'Heat Exchange Surface per Zone',
     $       11X,'Longitudinal Zone number',/19X,
     $       11X,'Transverse Zone number',/19X,
     $       4H[m2],30X,4H[m2],28X,3H[-],//,12X,
     $       2(G15.6,20X),2I5)
C
C
      DATI(ID2  ) = NE
      DATI(ID2+1) = NUS
      DATI(ID2+2) = SHOS
      DATI(ID2+3) = SHIS
      DATI(ID2+4) = VGATZ
      DATI(ID2+5) = FCSA
      DATI(ID2+6) = EQD
      DATI(ID2+7) = SHELLTC
      DATI(ID2+8) = NZL
      DATI(ID2+9) = NTUB
      DATI(ID2+10)= TUBOD
      DATI(ID2+11)= TUBLENGH
      DATI(ID2+12)= HTRSUP
      DATI(ID2+13)= USHTC
      DATI(ID2+14)= SHID
      DATI(ID2+15)= SHLENGH
      DATI(ID2+16)= SHIV
      DATI(ID2+17)= SSCIZ
      DATI(ID2+18)= FTCSA
      DATI(ID2+19)= FTEQD
      DATI(ID2+20)= TTHICK
      DATI(ID2+21)= TUBRO
      DATI(ID2+22)= TUBCP
      DATI(ID2+23)= TUBK
      DATI(ID2+24)= HTA
      DATI(ID2+25)= UTHTC
      DATI(ID2+26)= NZT
      DATI(ID2+27)= TUBTP
      DATI(ID2+28)= TUBLP
      DATI(ID2+29)= NLR
      DATI(ID2+30)= NTR
C
C
      ID2 = ID2+30+1
C
C---costanti di normalizzazione
C
      CNXYU(IV1  ) = P0
C
      DO I=1,NZL*NZT
        CNXYU(IV1+I) = H0
      END DO
C
      NIND=NZL*NZT
C
      CNXYU(IV1+NIND+1) = T0
C
      NIND=NIND+1
C
      DO I=1,NZL*NZT
        CNXYU(IV1+NIND+I) = T0
      END DO
C
      NIND=NIND+NZL*NZT
C
      DO I=1,NZL*NZT
	CNXYU(IV1+NIND+I)=H0
      END DO
C
      NIND=NIND+NZL*NZT
C
      CNXYU(IV1+NIND+1) = H0
C
      CNXYU(IV1+NIND+2) = W0
C
      CNXYU(IV1+NIND+3) = H0
C
      NT=NE+NUS
C
      I0=IV1+NIND+3
C
      DO J = 1,NT
	JW=2*J-1
	JH=JW+1
	CNXYU(I0+JW) = W0
	CNXYU(I0+JH) = H0
      END DO
C
      CNXYU(I0+2*NT+1)=P0
      CNXYU(I0+2*NT+2)=H0
      CNXYU(I0+2*NT+3)=P0
      CNXYU(I0+2*NT+4)=H0
C
      CNXYU(I0+2*NT+5) = 1.
      CNXYU(I0+2*NT+6) = 1.
C
      CNXYU(I0+2*NT+7) = GAM0
      CNXYU(I0+2*NT+8) = T0
      CNXYU(I0+2*NT+9) = GAM0
C
      RETURN
      END
C************************************************************************
C
      SUBROUTINE CFH0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/REGIME/KRE10GIM
C
      COMMON/CFH0BLOC/IBL1X,IBL2X
C
      EXTERNAL CFH0
C
C
      IBL1X=IBL1
      IBL2X=IBL2
C
C   Cross Flow Heater model
C
C   CALCOLO RESIDUI
C
C
      NE  =DATI(IPD)
      NUS =DATI(IPD+1)
      NZL=DATI(IPD+8)
      NZT=DATI(IPD+26)
      NSTATI=2+3*NZL*NZT
      NUSCALG=3
      NUSCTOT=NSTATI+NUSCALG
      NINGRE=2*(NE+NUS)+9
      NVAR=NUSCTOT+NINGRE
C
        GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100   DO I=1,NUSCTOT
          DO J =1,NVAR
            AJAC(I,J) = 1.
          END DO
        END DO
        RETURN
C
C---calcolo residui
C
  200   CONTINUE
        CALL CFH0(IFUN,IXYU,XYU,IPD,DATI,RNI)
        RETURN
C
C---calcolo jacobiano 
C
 300    CONTINUE
C
      EPS   =1.E-3
      EPSLIM=1.E-4
C     CALL CFH0JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
C    $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,CFH0)
      CALL NAJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,CFH0)
C
       RETURN                
      END
C
C
      SUBROUTINE CFH0JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(100),CXYU(100),CCRN(100),CCXYU(100),VAR(100)
      EXTERNAL RESIDUI
C
      PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE

C
C--- se la variabile e` una pressione
C    non viene limitato il suo incremento
C
C
      NE   =DATI(IPD)
      NUS  =DATI(IPD+1)
      NZL  =DATI(IPD+8)
      NZT  =DATI(IPD+26)
      ILS  =3*NZL*NZT+5
      I1LS =ILS+2*(NE+NUS)
C
      PR=XYU(IXYU)*P0
C
      VAR(1)=10./P0
C
      DO J=1,NZL*NZT
        VAR(1+J)=100./H0
      END DO
C
      N0=NZL*NZT+1
C
      VAR(N0+1)=1./T0
C
      N1=N0+1
C
      DO J=1,NZL*NZT
        VAR(N1+J)=1./T0
      END DO
C
      N2=N1+NZL*NZT
C
      DO I=1,NZL*NZT
        VAR(N2+I)=100./H0
      END DO
C
      N3=N2+NZL*NZT
C
      VAR(N3+1)=100./H0
C
      VAR(N3+2)=0.1/W0
C
      VAR(N3+3)=100./H0
C
      DO I1=ILS+1,I1LS,2
        VAR(I1)=0.1/W0
        VAR(I1+1)=50./H0
      END DO
C
      VAR(I1LS+1)=10./P0
      VAR(I1LS+2)=100./H0
      VAR(I1LS+3)=10./P0
      VAR(I1LS+4)=100./H0
C
      VAR(I1LS+5)=0.0001
      VAR(I1LS+6)=0.01

      VAR(I1LS+7)=10./1000.
      VAR(I1LS+8)=1./T0
      VAR(I1LS+9)=10./1000.
C
      DO 30 J=1,NCOL
        DO 10 K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR(J)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR(J)
   10   CONTINUE
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
C
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
C
        DO 20 I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR(J))
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
   20   CONTINUE
C
   30 CONTINUE
C
      RETURN
      END
C
C
C
C*********************************************************************
C
C
C
C
C*********************************************************************
C
C
      SUBROUTINE CFH0(IFUN,IXYU,XYU,IPD,DATI,RNI)
      DIMENSION XYU(*),DATI(*),RNI(*)
C
C   Simplified Heat Exchanger Shell side model
C
      PARAMETER (MAXIO=5,MAXCI=15)
C     PARAMETER (GAM0=1000.)
      PARAMETER (ALMIN=0.5)
C
      PARAMETER (ALFA=3.3)
      PARAMETER (BETA=0.1)
      PARAMETER (HSUP=100.E3)
C
      DIMENSION WS(MAXIO),WSO(MAXIO)
      DIMENSION HS(MAXIO),HSO(MAXIO),HVTAV(MAXCI,MAXCI)
      DIMENSION TM(MAXCI,MAXCI),TFW(MAXCI,MAXCI)
      DIMENSION HSD(MAXCI,MAXCI),TVZ(MAXCI,MAXCI)
      DIMENSION HF(MAXCI,MAXCI),ROVZ(MAXCI,MAXCI)
      DIMENSION QHTR(MAXCI,MAXCI)
      DIMENSION THTC(MAXCI,MAXCI),SHTC(MAXCI,MAXCI)
      DIMENSION QFDW(MAXCI,MAXCI)
      DIMENSION SHHTR(MAXCI,MAXCI),SHFDW(MAXCI,MAXCI)
      DIMENSION ROFW(MAXCI,MAXCI)
      DIMENSION QSHIS(MAXCI,MAXCI)
      DIMENSION DRODH(MAXCI,MAXCI),DRODP(MAXCI,MAXCI)
C
      REAL MVZ(MAXCI,MAXCI),MLFW(MAXCI,MAXCI)
      REAL MFWTOT
C
      LOGICAL KREGIM,COUNTERFLOW
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
C
      COMMON/REGIME/KREGIM
C
      COMMON/CFH0VAR0/MVZ,MLFW,ROMFW
      COMMON/CFH0VAR1/PFIN,HFIN,PFOU,FTFF,WFDW
      COMMON/CFH0VAR2/SHHTR,SHFDW,SHV,SMV
      COMMON/CFH0VAR3/TBMHTRZ
      COMMON/CFH0_HT/THTC,SHTC,TBSHTRZ,HTRSUPZ,QHTR,QFDW,QSHE,QSHIST
C
      COMMON/CFH0_ENTH/HSAO,HMUM,HTAO,HMUT
      COMMON/CFH0_R0/ROVZ,DRODH,DRODP
C
      COMMON /CFH0_TUBES_DATA/NLR,NTR,HTA,TUBTP,TUBLP,TUBOD,TUBLENGH
C
C
      GAM0=1000.
C
C---decodifica dati
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      SHOS    = DATI(IPD+2)
      SHIS    = DATI(IPD+3)
      VGATZ   = DATI(IPD+4)
      FCSA    = DATI(IPD+5)
      EQD     = DATI(IPD+6)
      SHELLTC = DATI(IPD+7)
      NZL     = DATI(IPD+8)
      NTUB    = DATI(IPD+9)
      TUBOD   = DATI(IPD+10)
      TUBLENGH= DATI(IPD+11)
      HTRSUP  = DATI(IPD+12)
      USHTC   = DATI(IPD+13)
      SHID    = DATI(IPD+14)
      SHLENGH = DATI(IPD+15)
      SHIV    = DATI(IPD+16)
      SSCIZ   = DATI(IPD+17)
      FTCSA   = DATI(IPD+18)
      FTEQD   = DATI(IPD+19)
      TTHICK  = DATI(IPD+20)
      TUBRO   = DATI(IPD+21)
      TUBCP   = DATI(IPD+22)
      TUBK    = DATI(IPD+23)
      HTA     = DATI(IPD+24)
      UTHTC   = DATI(IPD+25)
      NZT     = DATI(IPD+26)
      TUBTP   = DATI(IPD+27)
      TUBLP   = DATI(IPD+28)
      NLR     = DATI(IPD+29)
      NTR     = DATI(IPD+30)
C
      FNZL=FLOAT(NZL)
      FNZT=FLOAT(NZT)
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C
C----- Massa di metallo complessiva del fascio tubiero
C
      TUBID=TUBOD-2.*TTHICK
      TUBMASS=TUBRO*FLOAT(NTUB)*TUBLENGH*3.1415*(TUBOD**2.-TUBID**2.)/4.
C
C
C----- Superficie esterna complessiva del fascio tubiero
C
      TUBSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBOD
C
C
C----- Superficie interna complessiva del fascio tubiero
C
      TUBINSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID
C
C
C----- Volume interno complessivo del fascio tubiero
C
      TUBINVOL=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID**2./4.
C
C
C
C----- Superficie esterna di scambio per cella nelle divere zone
C
      IF (HTRSUP.GT.0.) THEN
        HTRSUPZ=HTRSUP/(FNZL*FNZT)
      ELSE
        HTRSUPZ=TUBSURF/(FNZL*FNZT)
      END IF
C
C
C----- Superficie di scambio interno (lato acqua alimento) per cella nelle
C----- divere zone del fascio tubiero
C
      IF (HTRSUP.GT.0.) THEN
        TBSHTRZ=HTRSUPZ/TUBSURF*TUBINSURF
      ELSE
        TBSHTRZ=TUBINSURF/(FNZL*FNZT)
      END IF
C
C
C----- Massa di metallo per cella nelle divere zone del fascio tubiero
C      proporzionale al rapporto fra superficie di scambio della zona
C      e superficie esterna complesiva
C
      IF (TUBSURF.GT.0.) THEN
        TBMHTRZ=HTRSUPZ/TUBSURF*TUBMASS
      ELSE
        TBMHTRZ=TUBMASS/(FNZL*FNZT)
      END IF
C     write(6,*)' TBMHTRZ = ',TBMHTRZ,' HTRSUPZ = ',HTRSUPZ
C     write(6,*)' TUBSURF = ',TUBSURF,' TUBMASS = ',TUBMASS
C
C
C----- Volume interno (lato acqua alimento) nelle divere zone del fascio tubiero
C
      IF (TUBSURF.GT.0.) THEN
        TBVHTRZ=HTRSUPZ/TUBSURF*TUBINVOL
      ELSE
       TBVHTRZ=TUBINVOL/(FNZL*FNZT)
      END IF
C
C----- Volume lato shell nelle divere zone
C
      SHVHTRZ=HTRSUPZ/TUBSURF*VGATZ
C
C
C---decodifica variabili
C
C---- Pressione lato shell
C
      PWSS = XYU(IXYU  )*P0
C
C---- Entalpia zona longitudinale I, trasversale J - lato mantello
C
      DO I=1,NZL
        DO J=1,NZT
          HSD(I,J)=XYU(IXYU+(I-1)*NZT+J)*H0
        END DO
      END DO
C
      IDELTA=NZL*NZT
C
C---- Temperatura media metallo mantello
C
      TAMS = XYU(IXYU+IDELTA+1)*T0
C
      IDELTA=IDELTA+1
C
C---- Temperatura media metallo tubi zona longitudinale I, trasversale J
C
      DO I=1,NZL
        DO J=1,NZT
          TM(I,J) = XYU(IXYU+IDELTA+(I-1)*NZT+J)*T0
        END DO
      END DO
C
      IDELTA=IDELTA+NZL*NZT
C
C---- Entalpia zona longitudinale I, trasversale J - lato tubi
C
      DO I=1,NZL
        DO J=1,NZT
          HF(I,J)=XYU(IXYU+IDELTA+(I-1)*NZT+J)*H0
        END DO
      END DO
C
      IDELTA=IDELTA+NZL*NZT
C
C---- Entalpia media dell'acqua in uscita - lato mantello
C
      HSAO = XYU(IXYU+IDELTA+1)*H0
C
C
C---- Portata complessiva acqua - lato tubi
C
      WFDW = XYU(IXYU+IDELTA+2)*W0
C
C---- Entalpia media dell'acqua in uscita - lato tubi
C
      HTAO = XYU(IXYU+IDELTA+3)*H0
C
      I0=IXYU+IDELTA+3
C
C---- Portate ed Entalpie in ingresso - lato mantello
C
      DO J = 1,NE
        JW=2*J-1
        JH=JW+1
        WS(J) = XYU(I0+JW)*W0
        HS(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NE
C
C---- Portate in uscita e corrispondenti entalpie in caso di inversione del moto  - lato mantello
C
      DO J = 1,NUS
        JW=2*J-1
        JH=JW+1
        WSO(J) = XYU(I0+JW)*W0
        HSO(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NUS
C
C
      PFIN=XYU(I0+1)*P0
      HFIN=XYU(I0+2)*H0
      PFOU=XYU(I0+3)*P0
      HFOU=XYU(I0+4)*H0
C
      FTFF=XYU(I0+5)
      AHTR=XYU(I0+6)
C
      GSIF = XYU(I0+7)*GAM0
      TEST = XYU(I0+8)*T0
      GEST = XYU(I0+9)*GAM0
C
      IF(PWSS.LT.2.5E5) THEN
        PPTOL=10./P0
      ELSE IF(PWSS.LT.10.E5) THEN
        PPTOL=50./P0
      ELSE
        PPTOL=100./P0
      ENDIF
C
      TOLIN(1)=PPTOL
C
C---- Portate di fluido in igresso lato mantello
C
      SWS=0.
      SHS=0.
      SWSDHS=0.
      SWSINV=0.
C
      DO J= 1,NE
        IF(WS(J).GT.0.) THEN
          SWS=SWS+WS(J)
          SWSDHS=SWSDHS+WS(J)*HS(J)
        ELSE
          SWSINV=SWSINV-WS(J)
        ENDIF
        SHS=SHS+HS(J)
      END DO
C
C---- Portata media acqua in ingresso al canale logitudinale I - lato mantello
C
      WIZT=SWS/FNZL
C
C---- Entalpia media acqua in ingresso al canale longitudinale I - lato mantello
C
      IF (SWS.GT.0.) THEN
        HIZT=SWSDHS/SWS
      ELSE
        HIZT=SHS/FLOAT(NE)
      END IF
C
C
C---- Portate di fluido in uscita (ultima zona di scambio) - lato mantello
C
      SWSOINV=0.
      SWSODHSOINV=0.
      SWSO=0.
C
      DO J= 1,NUS
        IF(WSO(J).LT.0.) THEN
          SWSOINV=SWSOINV-WSO(J)
          SWSODHSOINV=SWSODHSOINV-WSO(J)*HSO(J)
        ELSE
          SWSO=SWSO+WSO(J)
        ENDIF
      END DO
C
C
C---- Entalpia media di fluido in uscita (ultima zona di scambio) - lato mantello
C
      HMUM=0.
      DO I=1,NZL
        HMUM=HMUM+HSD(I,NZT)/FNZL
      END DO
C
C
C---- Portata media acqua in ingresso al canale trasversale J - lato tubi
C
      WFZT=WFDW/FNZT
C
C
C---- Entalpia media di fluido in uscita lato tubi
C
      HMUT=0.
      DO J=1,NZT
        HMUT=HMUT+HF(NZL,J)/FNZT
      END DO
C
C
C-----  Protezione per pressioni ed entalpie fuori range
C
      PVTAV=PWSS
C
CC    IF(PVTAV.LE.810.8) THEN
CC      PVTAV=810.8
CC    ELSE IF(PVTAV.GE.400.E+05) THEN
CC      PVTAV=400.E+05
CC    ENDIF
C
      DO I=1,NZL
        DO J=1,NZT
          HVTAV(I,J)=HSD(I,J)
        END DO
      END DO
C
C
C---- Pressione media dell'acqua alimento nel fascio tubiero
C
      PMFDW=(PFIN+PFOU)/2.
C
C---- Stato termodinamico dell'acqua alimento, densit� media (Vi=cost.)
C
      MFWTOT=0.
C
      DO I=1,NZL
        DO J=1,NZT
          SFW=SHEV(PMFDW,HF(I,J),NFL)
          TFW(I,J)=TEV(PMFDW,SFW,NFL)
          ROFW(I,J)=ROEV(PMFDW,SFW,NFL)
        END DO
      END DO
C
C
C---- Massa di liquido nelle diverse zone del fascio tubiero
C
      DO I=1,NZL
        DO J=1,NZT
 	  MLFW(I,J)=ROFW(I,J)*TBVHTRZ
          MFWTOT=MFWTOT+MLFW(I,J)
        END DO
      END DO
C
      ROMFW=MFWTOT/TUBINVOL
C
C--- Tubes Side Heat Exchange Coefficient
C
      DO I=1,NZL
        DO J=1,NZT
          TMT=TM(I,J)
          HFT=HF(I,J)
          IF (UTHTC.LE.0.) THEN
            CALL CFH0_THTC(TMT,PMFDW,HFT,WFDW,FTCSA,FTEQD,THTC(I,J))
          ELSE
            IF (UTHTC.LE.10.) THEN
              CALL CFH0_USR_THTC(TMT,PMFDW,HFT,WFDW,FTCSA,FTEQD,HTC)
              THTC(I,J)=HTC
            ELSE
              THTC(I,J)=UTHTC
            END IF
          END IF
        END DO
      END DO
C
C
C----- Calcolo proprieta' lato shell
C
      DO I=1,NZL
        DO J=1,NZT
C
          SVZ=SHEV(PVTAV,HVTAV(I,J),NFL)
          TVZ(I,J)=TEV(PVTAV,SVZ,NFL)
          ROVZ(I,J)=ROEV(PVTAV,SVZ,NFL)
          MVZ(I,J)=VGATZ*ROVZ(I,J)
C
C--- derivata della densita` dell'acqua fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h - lato shell
C
          DRODP(I,J)=1./A2EV(PVTAV,SVZ,NFL)-
     &               1./(ROVZ(I,J)*TVZ(I,J))*BEV(PVTAV,SVZ,NFL)
C
C--- derivata della densita` dell'acqua fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p
C
	  DRODH(I,J)=BEV(PVTAV,SVZ,NFL)/TVZ(I,J)
C
C
C--- Shell Side Heat Exchange Coefficient
C
          IF (USHTC.LE.0.) THEN
            CALL CFH0_SHTC(PVTAV,HVTAV(I,J),SWS,FCSA,EQD,TM(I,J)
     $                     ,SHTC(I,J))
          ELSE
            IF (USHTC.LE.10.) THEN
              CALL CFH0_USR_SHTC(PVTAV,HVTAV(I,J),SWS,FCSA,EQD
     $                          ,TM(I,J),SHTC(I,J))
            ELSE
              SHTC(I,J)=USHTC
            END IF
          END IF
        END DO
      END DO
C
C
C     write(6,*)'Speed= ',SWS/(ROVZ*FCSA)
C
C
C
C---- Calcolo potenze termiche scambiate  ---------------------------------------
C
C---- Scambio lato mantello
C
          QSHIST=0.
      DO I=1,NZL
C         QSHIS(I,1)=0.5*GSIF*SHIS*ALFA*(TVZ(I,1)-TAMS)/FLOAT(NZL)
          QSHIS(I,1)=GSIF*SHIS*ALFA*(TVZ(I,1)-TAMS)/FLOAT(NZL)
          QSHIST= QSHIST+QSHIS(I,1)
C         QSHIS(I,1)=0.
C        write(6,*)' TVZ(',I,'1)',TVZ(I,1),'QSHIS(',I,'1)',QSHIS(I,1)
C     &           ,' QSHIST_1 ', QSHIST
        DO J=1,NZT
          QHTR(I,J)=AHTR*SHTC(I,J)*HTRSUPZ*(TVZ(I,J)-TM(I,J))
C         QHTR(I,J)=AHTR*SHTC(I,J)*14000.*(TVZ(I,J)-TM(I,J))
C       write(6,*)'AHTR ',AHTR,' SHTC ',SHTC(I,J),' HTRSUPZ ',HTRSUPZ
C    &           ,' TVZ(',I,J,')',TVZ(I,J),'TM(',I,J,')',TM(I,J)
C    &           ,'QHTR(',I,J,')',QHTR(I,J)
        END DO
C         QSHIS(I,2)=0.5*GSIF*SHIS/FLOAT(NZL)*ALFA*(TVZ(I,NZT)-TAMS)
C         QSHIS(I,2)=0.
C         QSHIST= QSHIST+0.5*GSIF*SHIS*ALFA*(TVZ(I,NZT)-TAMS)/FLOAT(NZL)
C       write(6,*)' TVZ(',I,'NZT)',TVZ(I,NZT),'QSHIS(',I,'2)',QSHIS(I,2)
C    &           ,' QSHIST_2 ', QSHIST
      END DO
C
C
C---- Scambio lato tubi
C
      DO I=1,NZL
        DO J=1,NZT
          QFDW(I,J)=THTC(I,J)*TBSHTRZ*(TM(I,J)-TFW(I,J))
C         QFDW(I,J)=THTC(I,J)*14000.*(TM(I,J)-TFW(I,J))
C        write(6,*)'THTC(',I,J,')',THTC(I,J),' TBSHTRZ',TBSHTRZ
C     &           ,' TM(',I,J,')',TM(I,J),'TFW(',I,J,')',TFW(I,J)
C     &           ,' QFDW(',I,J,')', QFDW(I,J)
        END DO
      END DO
C
C     write(6,*)' TBSHTRZ = ',TBSHTRZ,' HTRSUPZ = ',HTRSUPZ
C
C---- calore scambiato fra parete esterna shell e ambiente
C
      QSHE=GEST*SHOS*(TAMS-TEST)
C
C
C
C--- calcolo dei termini noti delle equazioni di conservazione dell'energia
C
C------------    Lato mantello ------------------------
C
      DO I=1,NZL
        SHHTR(I,1)=WIZT*(HIZT-HSD(I,1))-QHTR(I,1)-QSHIS(I,1)
C       SHHTR(I,1)=WIZT*(HIZT-HSD(I,1))-QHTR(I,1)
C        write(6,*)'HIZT ',HIZT
C       DO J=2,NZT-1
        DO J=2,NZT
          SHHTR(I,J)=WIZT*(HSD(I,J-1)-HSD(I,J))-QHTR(I,J)
        END DO
C       SHHTR(I,NZT)=WIZT*(HSD(I,NZT-1)-HSD(I,NZT))-QHTR(I,NZT)
C    $                                             -QSHIS(I,2)
C       SHHTR(I,NZT)=SHHTR(I,NZT)-QSHIS(I,2)
      END DO
C
      SMV=SWS+SWSOINV-SWSINV-SWSO
C
C------------    Lato tubi ------------------------
C
      DO J=1,NZT
        IF (WFZT.GE.0.) THEN
          SHFDW(1,J)=WFZT*(HFIN-HF(1,J))+QFDW(1,J)
	  DO I=2,NZL
            SHFDW(I,J)=WFZT*(HF(I-1,J)-HF(I,J))+QFDW(I,J)
	  END DO
        ELSE
          SHFDW(NZL,J)=ABS(WFZT)*(HFOU-HF(NZL,J))+QFDW(NZL,J)
          DO I=1,NZL-1
            SHFDW(NZL-I,J)=ABS(WFZT)*(HF(NZL,J)-HF(NZL-I,J))
     $                                         +QFDW(NZL-I,J)
          END DO
        END IF
      END DO
C
C
C--- Calcolo stazionario e transitorio
C
      CALL CFH0NF(IFUN,IPD,DATI,RNI)
C
C
      RETURN
      END
C
C
C
C---------------------------------------------------------------------------------
C
C      Calcolo stazionario e transitorio 
C
C---------------------------------------------------------------------------------
C
C
      SUBROUTINE CFH0NF(IFUN,IPD,DATI,RNI)
C
C
      DIMENSION DATI(*),RNI(*)
C
      PARAMETER (MAXIO=5,MAXCI=15)
C
      DIMENSION AIJ(MAXCI,MAXCI),DHVDT(MAXCI,MAXCI)
      DIMENSION DRODH(MAXCI,MAXCI),DRODP(MAXCI,MAXCI)
      DIMENSION ROVZ(MAXCI,MAXCI)
      DIMENSION AM(MAXCI,MAXCI)
      DIMENSION QHTR(MAXCI,MAXCI)
      DIMENSION QFDW(MAXCI,MAXCI)
      DIMENSION SHHTR(MAXCI,MAXCI),SHFDW(MAXCI,MAXCI)
      DIMENSION THTC(MAXCI,MAXCI),SHTC(MAXCI,MAXCI)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
      LOGICAL KREGIM,COUNTERFLOW
      COMMON/REGIME/KREGIM
C
      COMMON/CFH0VAR0/MVZ,MLFW,ROMFW
      COMMON/CFH0VAR1/PFIN,HFIN,PFOU,FTFF,WFDW
      COMMON/CFH0VAR2/SHHTR,SHFDW,SHV,SMV
      COMMON/CFH0VAR3/TBMHTRZ
      COMMON/CFH0_HT/THTC,SHTC,TBSHTRZ,HTRSUPZ,QHTR,QFDW,QSHE,QSHIST
C
      COMMON/CFH0_ENTH/HSAO,HMUM,HTAO,HMUT
      COMMON/CFH0_R0/ROVZ,DRODH,DRODP
C
      REAL MVZ(MAXCI,MAXCI),MLFW(MAXCI,MAXCI)
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      SHOS    = DATI(IPD+2)
      SHIS    = DATI(IPD+3)
      VGATZ   = DATI(IPD+4)
      FCSA    = DATI(IPD+5)
      EQD     = DATI(IPD+6)
      SHELLTC = DATI(IPD+7)
      NZL     = DATI(IPD+8)
      NTUB    = DATI(IPD+9)
      TUBOD   = DATI(IPD+10)
      TUBLENGH= DATI(IPD+11)
      HTRSUP  = DATI(IPD+12)
      USHTC   = DATI(IPD+13)
      SHID    = DATI(IPD+14)
      SHLENGH = DATI(IPD+15)
      SHIV    = DATI(IPD+16)
      SSCIZ   = DATI(IPD+17)
      FTCSA   = DATI(IPD+18)
      FTEQD   = DATI(IPD+19)
      TTHICK  = DATI(IPD+20)
      TUBRO   = DATI(IPD+21)
      TUBCP   = DATI(IPD+22)
      TUBK    = DATI(IPD+23)
      HTA     = DATI(IPD+24)
      UTHTC   = DATI(IPD+25)
      NZT     = DATI(IPD+26)
      TUBTP   = DATI(IPD+27)
      TUBLP   = DATI(IPD+28)
      NLR     = DATI(IPD+29)
      NTR     = DATI(IPD+30)
C
      NZON=NZL
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C
C--- Calcolo dei termini delle perdite di carico dell'acqua alimento
C
C     CALL CFH0_MOODY_FF(PFIN,HFIN,WFDW,FTEQD,FTCSA,FRICF)
C     FRICF=0.05
C     write(6,*)'Friction factor=',FRICF
C
C     XK = Form pressure loss coefficient default = 1.
C
      XK=1.
C     XK=0.
C
C     CDPFDW=0.5*(FRICF*TUBLENGH/FTEQD+XK)*(1./(FTCSA**2.*ROMFW))
      CDPFDW=0.5*(FTFF*(TUBLENGH/FTEQD+XK))*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=0.5*(FTFF*FRICF*TUBLENGH/FTEQD+XK)*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=0.5*FTFF*(1./(FTCSA**2.*ROMFW))
C     CDPFDW=FTFF*(1./(FTCSA**2.*ROMFW))
C     write(6,*)'FTCSA = ',FTCSA,' CDPFDW= ',CDPFDW,' ROMFW= ',ROMFW
C
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni lato mantello
C
      A0=0.
      B0=0.
      C0=0.
      DO I=1,NZL
        DO J=1,NZT
          AIJ(I,J)=VGATZ* DRODH(I,J)
          A0=AO+AIJ(I,J)/ROVZ(I,J)
          B0=B0+VGATZ*DRODP(I,J)
          C0=C0+AIJ(I,J)*SHHTR(I,J)/MVZ(I,J)
        END DO
      END DO
C
C
C--- Calcolo della derivata della pressione  dP/dt
C
      DPDT=(SMV-C0)/(B0+A0)
C
C
C--- Calcolo della derivata dell'entalpia del vapore  dHv/dt
C
      DO I=1,NZL
        DO J=1,NZT
          DHVDT(I,J)= SHHTR(I,J)/MVZ(I,J)+DPDT/ROVZ(I,J)
        END DO
      END DO
C
C
C
      IF (KREGIM) THEN
C
C___ Pressione nel riscaldatore
C
C       RNI(1)= DPDT/P0
        RNI(1)= SMV/W0
C
C
C___ Entalpia acqua lato mantello
C
        DO I=1,NZL
          DO J=1,NZT
C     	    RNI(1+(I-1)*NZT+J)= DHVDT(I,J)/H0
      	    RNI(1+(I-1)*NZT+J)= SHHTR(I,J)/(W0*H0)
          END DO
        END DO
C
        IDELTA=1+NZT*NZL
C
C___ Temperatura metallo parete shell
C
        RNI(IDELTA+1)= (QSHIST-QSHE)/(W0*H0)
C        write(6,*)' QSHIST ',QSHIST,' QSHE ',QSHE
C
C
        IDELTA=IDELTA+1
C
C
C___ Temperatura metallo fascio tubiero
C
C
        TUBTC=TUBCP*TBMHTRZ
C
        DO I=1,NZL
          DO J=1,NZT
            HST=THTC(I,J)*TBSHTRZ
            RNI(IDELTA+(I-1)*NZT+J)=(QHTR(I,J)-QFDW(I,J))/(HST*T0)
C       write(6,*)' QHTR(I,J)= ',QHTR(I,J),' QFDW(I,J)= ',QFDW(I,J)
C     $          ,' TUBTC ',TUBTC
          END DO
        END DO
C
C
        IDELTA=IDELTA+NZT*NZL
C
C
C___ Entalpia acqua alimento
C
        DO I=1,NZL
          DO J=1,NZT
            RNI(IDELTA+(I-1)*NZT+J)= SHFDW(I,J)/(W0*H0)
C       write(6,*)' SHFDW(I)= ',SHFDW(I),' I= ',I
          END DO
        END DO
C
C
        IDELTA=IDELTA+NZT*NZL
C
C
C___ Entalpia media fluido uscita lato mantello
C
        RNI(IDELTA+1)=(HSAO-HMUM)/H0
C
C___ Portata acqua alimento nel fascio tubiero
C
C       write(6,*)'FTCSA = ',FTCSA,' CDPFDW= ',CDPFDW,' ROMFW= ',ROMFW
C       RNI(3*NZL+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(P0)
C       RNI(3*NZL+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
C       RNI(IDELTA+2)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
        RNI(IDELTA+2)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/P0
C       RNI(IDELTA+2)=(PFIN-PFOU-FTFF*WFDW*ABS(WFDW))/P0
C       RNI(3*NZL+4)=((PFIN-PFOU)/CDPFDW-WFDW*ABS(WFDW))/(W0*W0)
C       RNI(3*NZL+4)=((PFIN-PFOU)/CDPFDW-FTFF*WFDW*ABS(WFDW))/(W0*W0)
C       RNI(3*NZL+4)=(PFIN-PFOU-FTFF*WFDW*ABS(WFDW))/(W0*W0)
C
C___ Entalpia media fluido uscita lato tubi
C
        RNI(IDELTA+3)=(HTAO-HMUT)/H0
C
C
      ELSE
C
C___ Pressione nel riscaldatore
C
        RNI(1)=DPDT/P0
C
C
C___ Entalpia acqua lato mantello
C
        DO I=1,NZL
          DO J=1,NZT
      	    RNI(1+(I-1)*NZT+J)= DHVDT(I,J)/H0
          END DO
        END DO
C
        IDELTA=1+NZT*NZL
C
C___ Temperatura metallo parete shell
C
        RNI(IDELTA+1)= (QSHIST-QSHE)/(SHELLTC*T0)
C
        IDELTA=IDELTA+1
C
C___ Temperatura metallo fascio tubiero
C
C
        TUBTC=TUBCP*TBMHTRZ
C
        DO I=1,NZL
          DO J=1,NZT
            RNI(IDELTA+(I-1)*NZT+J)=(QHTR(I,J)-QFDW(I,J))/(TUBTC*T0)
          END DO
        END DO
C
        IDELTA=IDELTA+NZT*NZL
C
C___ Entalpia acqua alimento
C
        DO I=1,NZL
          DO J=1,NZT
            RNI(IDELTA+(I-1)*NZT+J)= SHFDW(I,J)/(MLFW(I,J)*H0)
          END DO
        END DO
C
        IDELTA=IDELTA+NZT*NZL
C
C___ Entalpia media fluido uscita lato mantello
C
        RNI(IDELTA+1)=(HSAO-HMUM)/H0
C
C
C___ Portata acqua alimento nel fascio tubiero
C
C       RNI(3*NZL+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/P0
C       RNI(3*NZL+4)=(PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
C       RNI(IDELTA+2)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
        RNI(IDELTA+2)=(PFIN-PFOU-CDPFDW*WFDW*ABS(WFDW))/P0
C       RNI(IDELTA+2)=(PFIN-PFOU-FTFF*WFDW*ABS(WFDW))/P0
C
C
C___ Entalpia media fluido uscita lato tubi
C
      RNI(IDELTA+3)=(HTAO-HMUT)/H0
C
C
      END IF
C
C
      RETURN
      END
C---------------------------------------------------------------------------------
C************************************************************************
      SUBROUTINE CFH0D1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      RETURN
      END
C
C************************************************************************
      SUBROUTINE CFH0_THTC(TMT,P,H,W,SEZ,D,THTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Dittus-Boelter Heat transfert correlation
C
C
C
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL MU,LAM,Kl,MUl,MUg
C
      NFL=1
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      SFW=SHEV(P,H,NFL)
      TFW=TEV(P,SFW,NFL)
      RO=ROEV(P,SFW,NFL)
      TIT=YEV(P,SFW,NFL)
C
      CP=CPEV(P,SFW,TIT,0.5,NFL)
      MU=ETEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
      RE=ABS(W)*D/(SEZ*MU)
      PR=CP*MU/LAM
C
      IF (H.LE.HLS) THEN
C
C************** Dittus-Boelter Heat transfert correlation
C
C     write(6,*)'Dittus-Boelter '
        THTC=.023*LAM*RE**.8*PR**.4/D+HTSTAT
C
      ELSE
C
        IF (H.GE.HVS) THEN
C
C************** Hadaller Heat transfert correlation
C
C     write(6,*)'Hadaller '
          THTC=.008348*LAM*RE**.8774*PR**.6112/D+HTSTAT
C
        ELSE
C
          IF (TFW.GT.TMT) THEN
C
C************** Shah  Heat transfert correlation - film condensation inside vertical tubes
C
C     write(6,*)'Shah '
            Pred=P/221.2E+05
            Zeta=(1./TIT-1.)**0.8*Pred**0.4
            DB=.023*LAM*RE**.8*PR**.4/D
            Hsf=DB*(1-TIT)**0.8
            THTC=Hsf*(1.+3.8/Zeta**0.95)
C
          ELSE
C
C************** Chen  Heat transfert correlation - evaporation inside vertical tubes
C
C     write(6,*)'Chen '
            CPl=CPEV(P,SFW,0.,0.5,NFL)
            MUl=ETEV(P,TFW,RO,RWV,0.,0.5,NFL)
            MUl=AMAX1(9.216E-06,MUl)
            MUg=ETEV(P,TFW,RO,RWV,1.,0.5,NFL)
            Kl=ALEV(P,TFW,RO,RWV,0.,0.5,NFL)
            Kl=AMAX1(16.49E-03,Kl)
            Hlg=HVS-HLS
            PsTf=PSATEV(TFW,NFL)
            PsTm=PSATEV(TMT,NFL)
            TFr=TFW/647.15
            Sigma=0.2358*(1.-TFr)**1.256*(1.-0.625*(1.-TFr))
            A0=Kl**0.79*CPl**0.45*ROW**0.49
            B0=Sigma**0.5*MUl**0.29*Hlg**0.24*ROV**0.24
            DTsat=ABS(TMT-TFW)
            DPsat=ABS(PsTm-PsTf)
            AlfaFZ=0.00122*A0/B0*DTsat**0.24*DPsat**0.75
            REl=(1.-TIT)*ABS(W)*D/(SEZ*MUl)
            PRl=CPl*MUl/Kl
            AlfaL=.023*Kl*REl**.8*PRl**.4/D
            Xtt=(1./TIT-1.)**0.9*(ROV/ROW)**0.5*(MUl/MUg)**0.1
            F0=(1./Xtt+0.213)**0.736
            REtp=REl*F0**1.25
            S0=1./(1.+0.00000253*REtp**1.17)
            AlfaTP=AlfaFZ*S0+AlfaL*F0
            THTC=AlfaTP
          END IF
        END IF
      END IF
C
C      THTC=3000.
C     write(6,*)' THTC ',THTC
C
      RETURN
      END
C
C
C************************************************************************
      SUBROUTINE CFH0_SHTC(P,H,W,SEZ,D,TMT,SHTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Zhukauskas Heat transfert correlation - Flow across banks of tubes
C
C
C     TUBTP  = Tubes Transverse Pitch
C     TUBLP  = Tubes Longitudinal Pitch
C     DPITCH = Tubes Diagonal Pitch
C
      PARAMETER (HTSTAT=5.,NC2MAX=16) !GAMMA statico
      REAL MU,LAM, MUs,LAMs,NuD
C
      COMMON /CFH0_TUBES_DATA/NLR,NTR,HTA,TUBTP,TUBLP,TUBOD,TUBLENGH
C
      NFL=1
C
C--- Propriet� fisiche alla temperatura del fluido
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      S=SHEV(P,H,NFL)
      T=TEV(P,S,NFL)
      RO=ROEV(P,S,NFL)
      TIT=YEV(P,S,NFL)
C
      CP=CPEV(P,S,TIT,0.5,NFL)
      MU=ETEV(P,T,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,T,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
C
      PR=CP*MU/LAM
C
C
C--- Propriet� fisiche alla temperatura superficiale dei tubi
C
      IF (TMT.GT.TSAT) THEN
C
        STub=STEV(P,TMT,1.,NFL)
        CPs=CPEV(P,STub,1.,0.5,NFL)
        ROs=ROEV(P,STub,NFL)
        MUs=ETEV(P,TMT,ROs,RWV,1.,0.5,NFL)
        MUs=AMAX1(9.216E-06,MUs)
        LAMs=ALEV(P,TMT,ROs,RWV,1.,0.5,NFL)
        LAMs=AMAX1(16.49E-03,LAMs)
C
        PRs=CPs*MUs/LAMs
C
      ELSE
C
        STub=STEV(P,TMT,0.,NFL)
        CPs=CPEV(P,STub,0.,0.5,NFL)
        ROs=ROEV(P,STub,NFL)
        MUs=ETEV(P,TMT,ROs,RWV,0.,0.5,NFL)
        MUs=AMAX1(9.216E-06,MUs)
        LAMs=ALEV(P,TMT,ROs,RWV,0.,0.5,NFL)
        LAMs=AMAX1(16.49E-03,LAMs)
C
        PRs=CPs*MUs/LAMs
C
      END IF

      SELECT CASE (INT(HTA))
        CASE (0)
C
C---- Staggered arrangement
C
          DPITCH=SQRT(TUBLP**2.+(TUBTP/2.)**2.)
          CA1=2.*(DPITCH-TUBOD)
          CA2=TUBTP-TUBOD
C
          IF (CA1.LE.CA2) THEN
            FlowSec=FLOAT(NTR-1)*2.*(DPITCH-TUBOD)*TUBLENGH
            REmax=ABS(W)*TUBOD/(FlowSec*MU)
          ELSE
            FlowSec=FLOAT(NTR-1)*(TUBTP-TUBOD)*TUBLENGH
            REmax=ABS(W)*TUBOD/(FlowSec*MU)
          END IF
C
          IF (REmax.LT.10.) THEN
	    Ci=0.9
	    Emme=0.4
	  ELSE    
            IF (REmax.GE.10..AND.REmax.LE.100.) THEN
	      Ci=0.9
	      Emme=0.4
	    ELSE
	      IF (REmax.GT.100..AND.REmax.LE.1000.) THEN
	        Ci=Singolo tubo
	        Emme=Singolo tubo
	      ELSE
	        IF (REmax.GT.1000..AND.REmax.LE.2.E+05) THEN
	          IF (TUBTP/TUBLP.LE.2.) THEN
	            Ci=0.35*(TUBTP/TUBLP)**0.2
	            Emme=0.6
		  ELSE
	            Ci=0.4
	            Emme=0.6
		  END IF
	        ELSE
	          IF (REmax.GT.2.E+05.AND.REmax.LE.2.E+06) THEN
	            Ci=0.022
	            Emme=0.84
		  ELSE
	            Ci=0.022
	            Emme=0.84
	          END IF
	        END IF
	      END IF
	    END IF
	  END IF    
C
          IF (REmax.GT.1000.) THEN
            IF (NLR.GE.20) THEN
              C2=1.
            ELSE
              XNl=MAX(FLOAT(NLR),1.)
              C2=1.03578439-0.675550554/XNL + 0.278418227/XNL**2.
            END IF
          ELSE
            C2=1.
          END IF
C
          NuD=C2*Ci*REmax**Emme*PR**0.36*(PR/PRs)**0.25
C
        CASE (1)
C
C---- Aligned arrangement
C
          FlowSec=FLOAT(NTR-1)*(TUBTP-TUBOD)*TUBLENGH
          REmax=ABS(W)*TUBOD/(FlowSec*MU)
C
          IF (REmax.LT.10.) THEN
	    Ci=0.8
	    Emme=0.4
	  ELSE    
            IF (REmax.GE.10..AND.REmax.LE.100.) THEN
	      Ci=0.8
	      Emme=0.4
	    ELSE
	      IF (REmax.GT.100..AND.REmax.LE.1000.) THEN
	        Ci=Singolo tubo
	        Emme=Singolo tubo
	      ELSE
	        IF (REmax.GT.1000..AND.REmax.LE.2.E+05) THEN
	          IF (TUBTP/TUBLP.GE.0.7) THEN
	            Ci=0.27
	            Emme=0.63
		  ELSE
	            Ci=0.27
	            Emme=0.63
		  END IF
	        ELSE
	          IF (REmax.GT.2.E+05.AND.REmax.LE.2.E+06) THEN
	            Ci=0.021
	            Emme=0.84
		  ELSE
	            Ci=0.021
	            Emme=0.84
	          END IF
	        END IF
	      END IF
	    END IF
	  END IF    
C
          IF (REmax.GT.1000.) THEN
            IF (NLR.GE.20) THEN
              C2=1.
            ELSE
              XNl=MAX(FLOAT(NLR),1.)
              C2=1.03578439-0.675550554/XNL + 0.278418227/XNL**2.
            END IF
          ELSE
            C2=1.
          END IF
C
          NuD=C2*Ci*REmax**Emme*PR**0.36*(PR/PRs)**0.25
C
        CASE DEFAULT
C
C---- Staggered arrangement
C
      END SELECT
C
      SHTC=LAM/TUBOD*NuD+HTSTAT
C     write(6,*)' D= ',D,' Sez. = ',SEZ,'Speed= ',W/(RO*SEZ)
C     write(6,*)'HADHTC= ',HADHTC
C     SHTC=600.
C     write(6,*)'SHTC= ',SHTC
C
      RETURN
      END
C
C
C
      SUBROUTINE CFH0_MOODY_FF(P,H,W,DIA,SEZ,FRICF)
C
C  Friction factor according to Moody chart
C
C     ROUGHNESS     Tubes roughness - default = 0.0000023
C     DIA           Hydraulic diameter
C     P             Fluid pressure
C     H             Fluid enthalpy
C     FRICF         Friction factor  
C
C
      REAL MU
C
      COMMON/CFH0BLOCKS/IBL1X,IBL2X
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
      DATA ROUGHNESS/0.000023/
C
      SFW=SHEV(P,H,NFL)
      TFW=TEV(P,SFW,NFL)
      RO=ROEV(P,SFW,NFL)
      TIT=YEV(P,SFW,NFL)
C
      CALL SATUR(P,3,ROW,ROV,NFL)
      RWV=ROW/ROV
C
      MU=ETEV(P,TFW,RO,RWV,TIT,0.5,NFL)
C
      RE=ABS(W)*DIA/(SEZ*MU)
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
        FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
          FRICF=64./RE
        ELSE
          IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
          DO WHILE (I.LE.100)
            IT=IT+1
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
            END IF
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
              WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBL1X,IBL2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
              WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
          END DO
C
C   SOLUZIONE
C
          WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP1_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBL1X,IBL2X
        END IF
      END IF
      RETURN
      END
C
C
C
C~FORAUS_CFH0~C
C
C      SUBROUTINE CFH0_USR_THTC(PMFDW,HF,WFDW,FTCSA,FTEQD,THTC)
C      THTC=14000.
C      RETURN
C      END
C
C
C      SUBROUTINE CFH0_USR_SHTC(P,H,W,SEZ,D,HTA,SHTC)
C      HADHTC = 5000.
C      RETURN
C      END
C
C~FORAUS_CFH0~C
C
