C**********************************************************************
C modulo hmcp.f
C tipo 
C release 5.2
C data 4/12/95
C reserver @(#)hmcp.f	5.2
C**********************************************************************
C
C-------------------------------------------------------------------
C
C------ Heavy Metal Centrifugal Pump
C
C-------------------------------------------------------------------
C
      SUBROUTINE HMCPI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                 !DBLE
C
C------CENTRIFUGAL PUMP (PRIMARIA,TURBOPOMPA,MOTOPOMPA)
C
      PARAMETER (NV=6)
      CHARACTER*4 IOB, MOD, IBLOC*8, DEBL*80
      CHARACTER*4 NOME(NV), TIPO(NV)*2, DESC(NV)*50
      COMMON /HMCP01/ IBLOC
      COMMON /HMCP02/ IVEL,IOUT
C
      DATA MOD/'HMCP'/
      DATA (NOME(I),TIPO(I),DESC(I),I=1,NV) /
     $'HUPM','US','FLUID ENTHALPY AT THE PUMP OUTLET',
     $'WPOM','UA','FLUID FLOW RATE THROUGH THE PUMP',
     $'PUPM','IN','PRESSURE AT THE PUMP OUTLET',
     $'PIPM','IN','PRESSURE AT THE PUMP INLET',
     $'HIPM','IN','FLUID ENTHALPY AT THE PUMP INLET',
     $'OMPM','IN','ROTATIONAL SPEED OF THE PUMP'/
C
      CALL HMCPI4(IOB,MOD)
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
      WRITE(IFO,3000)NOME(1),IOB,TIPO(1),DESC(1)
      WRITE(IFO,3000)NOME(2),IOB,TIPO(2),DESC(2)
      WRITE(IFO,3000)NOME(3),IOB,TIPO(3),DESC(3)
      WRITE(IFO,3000)NOME(4),IOB,TIPO(4),DESC(4)
      WRITE(IFO,3000)NOME(5),IOB,TIPO(5),DESC(5)
      WRITE(IFO,3000)NOME(6),IOB,TIPO(6),DESC(6)
       RETURN
 2999 FORMAT(A8,'  BL.-',A4,'- **** MODULO ',A4,' - ',A)
 3000 FORMAT(2A4,'  --',A2,'-- ',A)
      END
C
C
C
      SUBROUTINE HMCPI4(IOB,MOD)
      CHARACTER*4 IOB, MOD, IBLOC*8
      COMMON /HMCP01/ IBLOC
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
      RETURN
      END
C
C
C
      SUBROUTINE HMCPI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $ IBLOC1,IBLOC2,IER,CNXYU,TOL)
C
C------CENTRIFUGAL PUMP
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER VAR,FluidType
      LOGICAL JPB,JPB1,JLEAD,JLBE,JNA,JNA1,JSODIUM
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
      CHARACTER*4 FLUID1,FLUID2,DPMX,DPMX1
      CHARACTER*4 WN1,WN2,OM1,OM2,DP1,DP2,PT1,PT2,ET1,ET2
      CHARACTER*4 RO1,RO2,GIR1,GIR2
      CHARACTER*8 Fluid
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
C
      DATA FLUID1/'Flui'/,FLUID2/'d'/,DPMX/'DP ('/,DPMX1/'W=0)'/
      DATA WN1/'W no'/,WN2/'m   '/,OM1/'OM n'/,OM2/'om'/
      DATA DP1/'DP n'/,DP2/'om'/,PT1/'POT '/,PT2/'nom '/
      DATA ET1/'ETA '/ET2/'nom '/,RO1/'Dens'/,RO2/'ity'/
      DATA GIR1/'N.GI'/,GIR2/'RAN.'/
      DATA PI/3.141592/,G/9.81/
C
      GO TO(1,10),IFUN
C
C------SCRITTURA SIMBOLI DATI
C
    1 WRITE(14,1000)FLUID1,FLUID2
      WRITE(14,1000)DPMX,DPMX1,WN1,WN2,OM1,OM2
      WRITE(14,1000)DP1,DP2,PT1,PT2,RO1,RO2
      WRITE(14,1000)GIR1,GIR2
 1000 FORMAT(3(4X,A4,A4,' =',10X,'*'),5X)
      RETURN
C
C------LETTURA DATI E MEMORIZZAZIONE
C
   10 READ(14,1002)
      READ(14,'(14X,A8)')Fluid
      READ(14,1002)DPMAX,QMNOM,OMNOM,DPNOM,PNOM,RO,GIRAN
 1002 FORMAT(3(14X,F10.0,1X),5X)
C
C------DECODIFICA TIPO DI POMPA
C
        IHI=1
C
        IWP=2
C
      WRITE(6,502)'*** Heavy Metal Centrifugal Pump ***'
  502 FORMAT(/,14X,A,/)
C
C--- SELECT CASE on CHARACTER type not supported by GNU FORTRAN ----
C
C      Select Case  (Fluid)
C        Case ('PB','Pb','pB','pb')
C          FluidType=1
C          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidType                                             
C        Case ('Lead','lead')
C          FluidType=1
C          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidType                                             
C        Case ('LBE','Lbe','lbe')
C          FluidType=2
C          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidType                                             
C        Case ('Sodium','sodium','NA','Na','nA','na')
C          FluidType=3.
C          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidType                                             
C        Case Default
C          FluidType=1
C          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
C          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
C          write(6,*)'WARNING!!! default case - FluidType=',FluidType                                             
C      End Select
C
       JPB=(Fluid.EQ.'PB'.OR.Fluid.EQ.'Pb')
       JPB1=(Fluid.EQ.'pB'.OR.Fluid.EQ.'pb')
       JLEAD=(Fluid.EQ.'Lead'.OR.Fluid.EQ.'lead')
       JLBE=(Fluid.EQ.'LBE'.OR.Fluid.EQ.'Lbe'.OR.Fluid.EQ.'lbe')
       JSODIUM=(Fluid.EQ.'Sodium'.OR.Fluid.EQ.'sodium')
       JNA=(Fluid.EQ.'NA'.OR.Fluid.EQ.'Na')
       JNA1=(Fluid.EQ.'nA'.OR.Fluid.EQ.'na')
C
       IF (JPB.OR.JPB1.OR.JLEAD) THEN
          FluidType=1
          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidType
       ELSE IF (JLBE) THEN
          FluidType=2
          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidType                                             
       ELSE IF (JNA.OR.JNA1.OR.JSODIUM) THEN
          FluidType=3.
          write(6,'(18x,2A,I1)')'Fluid : ',Fluid                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidType
       ELSE
          FluidType=1
          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
          write(6,*)'WARNING!!! default case - FluidType=',FluidType
       END IF                                             
CC                                           
C
C--- ---------------------------------------------------------------- ----
C
C
C------CALCOLO DATI DI LAVORO
C
      IF(RO.EQ.0.) RO=10000.
C
      QNOM=QMNOM/RO
C
      IF(GIRAN.LE.0.)GIRAN=1.
      ETANOM=0.85
      IF(PNOM.GT.0.)ETANOM=QNOM*DPNOM/PNOM
C
      DH=DPNOM/RO/G/GIRAN
C
C      ECINOM=HIN*OMNOM**2.*.5
      GIRI=OMNOM/2./PI*60.
      GCAR=3.65*GIRI*QNOM**.5/(DH**(3./4.))
      AMPMP=2000.*QNOM
      WRITE(6,1021) GCAR
 1021 FORMAT(/14X,'*** CHARACTERISTIC NUMBER OF ROUND: ',
     $       F8.2,' ***'/)
      CNOM=PNOM/OMNOM
      IF(PNOM.NE.0.)GO TO 167
      CNOM=QNOM*DPNOM/(OMNOM*ETANOM)
 167  CONTINUE
      write(6,*)
      write(6,*)
      Write (6,*) 'Nominal conditions'
      write(6,*)
      write(6,*)'efficiency : ',ETANOM,'[p.u.]'
      write(6,*)
C
C------MEMORIZZAZIONE DEI DATI
C
      DATI(ID2)=IHI
      DATI(ID2+1)=IWP
      DATI(ID2+2)=DPMAX
      DATI(ID2+3)=FluidType
      DATI(ID2+4)=QNOM
      DATI(ID2+5)=OMNOM
      DATI(ID2+6)=DPNOM
      DATI(ID2+7)=PNOM
      DATI(ID2+8)=ETANOM
C      DATI(ID2+9)=ECINOM
      DATI(ID2+10)=GCAR
      DATI(ID2+11)=AMPMP
      DATI(ID2+12)=CNOM
      DATI(ID2+16)=.004*CNOM
      ID2=ID2+16
C
C------NORMALIZZAZIONE
C
      OM0=PI*2.*50.
C
      CNXYU(IV1)=H0
      CNXYU(IV1+1)=W0
      CNXYU(IV1+2)=P0
      CNXYU(IV1+3)=P0
      CNXYU(IV1+4)=H0
      CNXYU(IV1+5)=OM0
C
C------TOLLERANZE STANDARD(1.E-4)
C
      RETURN
      END
C
      SUBROUTINE HMCPC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $                  IBLOC1,IBLOC2)
C
C------ Heavy Metal Centrifugal Pump
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/IFAN/IFAN
      EXTERNAL HMCP
C
      NSTATI=1
      NUSCIT=1
      NINGRE=4
      NEQ=NSTATI+NUSCIT
      NVARIABL=NEQ+NINGRE
C
      IFAN=IFUN
C
      GO TO (1,10,20),IFUN
C
C------TOPOLOGIA JACOBIANO
C
    1 CONTINUE
C
      DO  I=1,NEQ
        DO  J=1,NVARIABL
          AJAC(I,J)=1.
        END DO
      END DO
C
      RETURN
C
C------CALCOLO RESIDUI  E DERIVATE
C
  10  CONTINUE
C
      CALL HMCP(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      RETURN
C
C------CALCOLO DELLLO JACOBIANO
C
  20  CONTINUE
C
      CALL HMCPJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,HMCP)
      RETURN
      END
C
C
C
C------------------------------------------------------------------------------
C
C
C
C
C------------------------------------------------------------------------------
C
      SUBROUTINE HMCPJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      LOGICAL KREGIM
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
C
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
C------CALCOLO JACOBIANO NUMERICO
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      DO J=1,NCOL
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
        VARP=10./P0
C
        IF(J.EQ.3.OR.J.EQ.4.) THEN
          VAR=VARP
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
      CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
      CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C
      RETURN
      END
C
C
C
C
C------------------------------------------------------------------------------
C
C
C
C
C------------------------------------------------------------------------------
C
      SUBROUTINE HMCP(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      DIMENSION XYU(*),DATI(*),RNI(*)
      INTEGER FluidType
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/PARPAR/NUL(7),ITERT
C
      DATA NFL/1/,OM0/314.1592/
C
C
      IHI=DATI(IPD)
      IWP=DATI(IPD+1)
      DPMAX=DATI(IPD+2)
      FluidType=DATI(IPD+3)
      QNOM=DATI(IPD+4)
      OMNOM=DATI(IPD+5)
      DPNOM=DATI(IPD+6)
      PNOM=DATI(IPD+7)
      ETANOM=DATI(IPD+8)
C      ECINOM=DATI(IPD+9)
      GCAR  =DATI(IPD+10)
      CNOM  =DATI(IPD+12)
      PERD  =DATI(IPD+16)
C
      HV   =XYU(IXYU)*H0
      Q    =XYU(IXYU+1)*W0
      PV   =XYU(IXYU+2)*P0
      PM   =XYU(IXYU+3)*P0
      HM   =XYU(IXYU+4)*H0
      OM   =XYU(IXYU+5)*OM0
C
      VOL=QNOM/OMNOM
C
      CALL HMCP_FLUID_PROP(FluidType,HV,THM,RO,CP,BETAP,UQ)
C
      HMMASS=RO*VOL
      QV=Q/RO
      A0=(1.+BETAP*UQ/CP)/HMMASS
C
      IF (DPMAX.GT.0.) THEN
        CALL HMCP_DP(DPMAX,QNOM,OMNOM,DPNOM,CNOM,ETANOM,
     $                       QV,RO,OM,DP,CRES)
      ELSE
        CALL HMCPDPU(DPMAX,QNOM,OMNOM,DPNOM,CNOM,ETANOM,
     $                       QV,RO,OM,DP,CRES)
      END IF
C
      WR=CRES*OM
C
C------CALCOLO RESIDUI
C
      IF (KREGIM) THEN
        IF (Q.GT.1.E-3) THEN
          RNI(1)=(WR+Q*(HM-HV))/W0/H0
        ELSE
          RNI(1)=(HV-HM)/H0
        END IF
          RNI(2)=(PV-PM-DP)/P0
      ELSE
        WP=0.
        RNI(1)=A0*(Q*(HM-HV)+WR-WP)/H0
        RNI(2)=(PV-PM-DP)/P0
      END IF
C
      RETURN
      END
C
C
C
C------------------------------------------------------------------------------
C
C
C
C
C------------------------------------------------------------------------------
C
       SUBROUTINE HMCP_DP(DPMAX,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,
     $                    DP,CRES)
C
C  Parametri in ingresso: DPMAX,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM
C  Parametri in uscita  : DP,CRES
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI DP E CRES IN
C      FUNZIONE DELLE ALTRE VARIABILI.
C      SIGNIFICATO DELLE VARIABILI DI INGRESSO-USCITA:
C
C       DPMAX = DATO A DISPOSIZIONE DELL'UTENTE PER DISTINGUERE
C             DIVERSE CARATTERISTICHE CONTENUTE IN QUESTA SUBROUTINE
C       QVNOM = PORTATA NOMINALE (M**3/S)
C       OMNOM = NUMERO DI GIRI NOMINALE (RAD/S)
C       DPNOM = PREVALENZA NOMINALE (PA)
C       CNOM = COPPIA NOMINALE (N*M)
C       ETANOM=RENDIMENTO NOMINALE
C       Q = PORTATA EFFETTIVA (M**3/S)
C       RO = DENSITA' EFFETTIVA (KG/M**3)
C       OM = VELOCITA' EFFETTIVA (RAD/S)
C       DP = PREVALENZA EFFETTIVA (PA)
C       CRES = COPPIA RESISTENTE EFFETTIVA (KG*M)
C
C
C****************CARATTERISTICA POMPA*********************
C
C
          A=DPMAX/DPNOM
          OMS=OM/OMNOM
          QS=Q/QVNOM
          DP=DPNOM*(A*OMS**2-(A-1.)*QS*ABS(QS))
C
C       QUANDO LA POMPA FUNZIONA A BOCCA CHIUSA (Q=0) E A VELOCITA'
C       NOMINALE (OM=OMNOM), DP=DPNOM*A.
C       A DUNQUE DEFINISCE LA PREVALENZA A BOCCA CHIUSA
C
C****************FORMULA DEL RENDIMENTO*******************
          IF(OMS.LT.1.E-4)GO TO 125
          RID=QS/OMS
          ETA=ETANOM*(-RID**2+2.*RID)
C
C****************COPPIA RESISTENTE***********************
C
C
          IF(ETA.LT.1.E-4)GO TO 125
          OME=OM
          IF(OME.LE.1.E-3)OME=1.E-3
          CRES=Q*DP/OME/ETA
          GO TO 130
  125     CRES=0.5*DP/DPNOM*CNOM
  130     CONTINUE
         RETURN
         END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMCP_FLUID_PROP(FluidType,H,T,RO,CP,BETAP,UQ)
C
      INTEGER FluidType
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C
      Select Case  (FluidType)
        Case (1)
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LEAD(T)
          BETAP=1.
          UQ=1.
cx          write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
        Case (2)
C         Case ('LBE')
          T=T_H_LBE(H)
          RO=RO_T_LBE(T)
          MU=MU_T_LBE(T)
          CP=CP_T_LBE(T)
          BETAP=BETAP_T_LBE(T)
          UQ=UQ_T_LBE(T)
CX          write(6,*)'Case LBE ','T=',T,' MU=',MU                                        
C       Case (3)
C         Case ('Sodium')
        Case Default
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LBE(T)
          BETAP=1.
          UQ=1.
CX          write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
      RETURN
      END
C
C
C
C------------------------------------------------------------------------------
C
C
C
C
C------------------------------------------------------------------------------
C
      SUBROUTINE HMCPD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $   XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*8 IBLOC, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
      Q0 = H0*W0
      OM0 = 314.1592
C
      IHI = DATI(IPD)
      IWP = DATI(IPD+1)
C
C---IHI=1
C
       IQ = 2
        IV = 3
        IM = 4
      OM = XYU(IXYU+5)*OM0
      Q  = XYU(IXYU+IQ-1)*W0
C
C-----Equazione n. 1 (Algebrica):
C
      SIGNEQ(1) = 'COMPUTATION OF OUTLET ENTHALPY (ENERGY CONS. EQ.)'
      IF (Q .GT. 1.E-3) THEN
C---pompa flussata
        UNITEQ(1) = 'W'
        COSNOR(1) = H0*W0
        ITOPVA(1,1) = 1
        ITOPVA(1,5) = 1
        ITOPVA(1,6) = 1
        ITOPVA(1,7) = 1
        ITOPVA(1,IQ) = 1
        ITOPVA(1,IM) = 1
      ELSE
C---portata nulla
        UNITEQ(1) = 'J/kg'
        COSNOR(1) = H0
        ITOPVA(1,1) = 1
        ITOPVA(1,5) = 1
      ENDIF
C
C-----Equazione n.2 (Algebrica)
C
      SIGNEQ(2) = 'COMPUTATION OF PUMP INLET PRESSURE'
        UNITEQ(2) = 'Pa'
        COSNOR(2) = P0
        ITOPVA(2,5) = 1
        ITOPVA(2,6) = 1
        ITOPVA(2,7) = 1
        ITOPVA(2,IQ) = 1
        ITOPVA(2,IM) = 1
        ITOPVA(2,IV) = 1
C
      RETURN
      END
CC
C
C
C~FORAUS_HMCP~C
C
C FORTRAN AUSILIARIO DEL MODULO POMPA CENTRIFUGA
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  Parametri in ingresso: DPMAX,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM
C  Parametri in uscita  : DP,CRES
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI DP E CRES IN
C      FUNZIONE DELLE ALTRE VARIABILI.
C      SIGNIFICATO DELLE VARIABILI DI INGRESSO-USCITA:
C
C       DPMAX = DATO A DISPOSIZIONE DELL'UTENTE PER DISTINGUERE
C             DIVERSE CARATTERISTICHE CONTENUTE IN QUESTA SUBROUTINE
C       QVNOM = PORTATA NOMINALE (M**3/S)
C       OMNOM = NUMERO DI GIRI NOMINALE (RAD/S)
C       DPNOM = PREVALENZA NOMINALE (PA)
C       CNOM = COPPIA NOMINALE (N*M)
C       ETANOM=RENDIMENTO NOMINALE
C       Q = PORTATA EFFETTIVA (M**3/S)
C       RO = DENSITA' EFFETTIVA (KG/M**3)
C       OM = VELOCITA' EFFETTIVA (RAD/S)
C       DP = PREVALENZA EFFETTIVA (PA)
C       CRES = COPPIA RESISTENTE EFFETTIVA (KG*M)
C
C       ESEMPIO DI SUBROUTINE:
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C      SUBROUTINE HMCPDPU(DPMAX,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      RETURN
C      END
C
C~FORAUS_HMCP~C
