C**********************************************************************
C modulo kina.f
C tipo
C release  3.2
C data 9/6/94
C reserver @(#)kina.f	3.2
C**********************************************************************
C
      SUBROUTINE KINAI3(IFO,IOB,DEBL)
C
C     CINETICA NEUTRONICA ZERO-MONODIMENSIONALE 'STRIQS'
C
C      VERSIONE  APRILE 28 1987  (S.SPELTA,L.POLLACHINI)
C
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      COMMON/KINA01/IBLOC
      COMMON/KINA02/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'KINA'/
C
C
      CALL KINAI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      NCELR=3
C
C-----DEFINIZIONE NUMERO STATI,USCITE,INGRESSI
C
      NSTATI= 0
      NUSCIT= 4+NCEL
      NINGRE= 6+4*NCEL
C
C-----STAMPA SIGNIFICATO STATI,USCITE,INGRESSI
C
      WRITE(IFO,3001)IOB
 3001 FORMAT('QTRC',A4,2X,'--UA-- POTENZA TOTALE DEL REATTORE')
C
      WRITE(IFO,3002)IOB
 3002 FORMAT('QTNT',A4,2X,'--UA-- POTENZA NEUTRONICA DEL REATTORE')
C
      WRITE(IFO,3003)IOB
 3003 FORMAT('REAC',A4,2X,'--UA-- REATTIVITA',1H',' TOTALE ')
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('AXOS',A4,2X,'--UA-- AXIAL OFF-SET')
C
      DO I=1,NCEL
      WRITE(IFO,3005)I,IOB,I
 3005 FORMAT('QGC',I1,A4,2X,
     $'--UA-- POTENZA TOTALE GENERATA NELLA CELLA',I2)
      ENDDO
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('ABCC',A4,2X,
     $'--IN-- POS. BARRE CONTR. CARATTER.: < 0 -> ENEL; > 0 -> EDF')
CC
C

      WRITE(IFO,3007)IOB
 3007 FORMAT('ABCN',A4,2X,
     $'--IN-- POSIZIONE DELLE BARRE DI CONTROLLO NERE (BANCO R)')
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('CNBR',A4,2X,'--IN-- CONCENTRAZIONE MEDIA DI BORO')
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('PMIN',A4,2X,
     $'--IN-- PRESSIONE MODERATORE INGRESSO NOCCIOLO')
C
      WRITE(IFO,3010)IOB
 3010 FORMAT('PMUN',A4,2X,
     $'--IN-- PRESSIONE MODERATORE USCITA NOCCIOLO')
C
      WRITE(IFO,3011)IOB
 3011 FORMAT('HMIN',A4,2X,
     $'--IN-- ENTALPIA MODERATORE INGRESSO NOCCIOLO')
C
      DO I=1,NCEL
        WRITE(IFO,3012)I,IOB,I
 3012   FORMAT('HMN',I1,A4,2X,
     $  '--IN-- ENTALPIA MODERATORE NELLA CELLA',I2,' DEL NOCCIOLO')
      ENDDO
C
      DO I=1,NCEL
        DO J=1,NCELR
          WRITE(IFO,3013)I,J,IOB,I,J
 3013     FORMAT('TC',2I1,A4,2X,
     $    '--IN-- TEMP. COMBUSTIBILE CELLA ASS.',I1,' CELLA RAD. ',I1)
        ENDDO
      ENDDO
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINAI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/KINA01/IBLOC
      COMMON/KINA02/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      NCTMAX=8
C
    1 WRITE(6,4000) NCTMAX
 4000 FORMAT(//10X,'CINETICA NEUTRONICA ZERO-MONODIMENSIONALE '//
     & 10X,'NUMERO DI CELLE TERMOIDRAULICHE - (MAX=',I3,') ?')
      READ(5,*) NCEL
 4001 FORMAT(I2)
      IF(NCEL.LT.2.OR.NCEL.GT.NCTMAX) THEN
        WRITE(6,4002) NCEL
 4002   FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
        GO TO 1
      END IF
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINAI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBL1,
     &                  IBL2,IER,CNXYU,TOL)
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      LOGICAL KREGIM
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REAT,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/KINA05/JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &              DPOTNO,DBURM
C
      IFAN=IFUN
      NCEL=((IV2-IV1+1)-10)/5
C
      GO TO (1,10),IFUN
C
C-----SCRITTURA SIMBOLI DEI DATI
C
    1 WRITE(14,500) 'IND.KIN.'
     &          ,'N.CELTH.'
     &          ,'N.DIVKIN'
     &          ,'N.BANCHI'
     &          ,'N.ASSEM.'
     &          ,'N.EL/ASS'
     &          ,'R UO2   '
     &          ,'PAS.ASS.'
     &          ,'ALT.ATT.'
     &          ,'POT.NOM.'
     &          ,'BURN-UP '
      RETURN
C
C---LECTURE ET MEMORISATION DES DATI
C
C     FDKIN  = indice del tipo di cinetica neutronica utilizzata
C              [ IND.KIN. = 1  ===>  cinetica (1-D) ]
C              [ IND.KIN. = 0  ===>  cinetica (0-D) ]
C              (l'opzione di cinetica zerodimensionale non e' attualmente
C              disponibile in KINA).
C
C     FCELT  = numero di celle termoidrauliche per la cinetica assiale
C              (sottomultiplo, secondo il parametro FKIN seguente, del
C              numero totale NCLIB di celle neutroniche assiali attive per
C              il quale sono state generate le biblioteche di parametri
C              neutronici (1-D) e i profili assiali iniziali).
C
C     FKIN   = numero di sottocelle neutroniche considerate per ciascuna cella
C              termoidraulica assiale. Dunque deve risultare:
C              FCELT * FKIN = NCLIB.
C              Attualmente sono impiegati i valori FCELT=8 e FKIN=3,essendo NCLIB=24
C
C     FG     = numero di banchi di barre di controllo previsti per il modo di
C              funzionamento del reattore considerato.
C              Nel funzionamento in "Mode Gris" il numero totale di banchi di
C              barre (grigie + nere) presi in considerazione deve essere:
C              N.BANCHI = 5 (G1,G2,N1,N2;R), mentre in "Mode A" si deve porre:
C              N.BANCHI = 6, in quanto, oltre ai banchi neri (D,C,B,A), vengono
C              computati anche i banchi di "SCRAM" (SB,SA).
C
C     DCANN  = numero di assemblaggi del nocciolo
C
C     DELNUM = numero di barrette di combustibile per assemblaggio
C
C     DRC    = raggio della pastiglia di combustibile                    [ m ]
C
C     DASPA  = passo dell'assemblaggio                                   [ m ]
C
C     DALATT = altezza attiva del nocciolo                               [ m ]
C
C     DPOTNO = potenza termica nominale del reattore                    [ MW ]
C
C     DBURM  = bruciamento medio del nocciolo                        [ MWD/t ]
C
C
  10  READ(14,501)
      READ(14,501)FDKIN
     &          ,FCELT
     &          ,FKIN
     &          ,FG
     &          ,DCANN
     &          ,DELNUM
     &          ,DRC
     &          ,DASPA
     &          ,DALATT
     &          ,DPOTNO
     &          ,DBURM
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  501 FORMAT(3(14X,F10.0,1X))
C
      LREGIM=.TRUE.
      JDKIN=FDKIN
      JCELT=FCELT
      JKIN=FKIN
      JG=FG
      DATI(ID2  ) = FDKIN
      DATI(ID2+1) = FCELT
      DATI(ID2+2) = FKIN
      DATI(ID2+3) = FG
      DATI(ID2+4) = DCANN
      DATI(ID2+5) = DELNUM
      DATI(ID2+6) = DRC
      DATI(ID2+7) = DASPA
      DATI(ID2+8) = ALATT
      DATI(ID2+9) = DPOTNO
      DATI(ID2+10) = DBURM
      ID2 = ID2+10
C
      WTOTP=XYU(IV1)
      WTOT=WTOTP*DPOTNO/100.*1.E6
      PASSI1=XYU(IV1+NCEL+4)
      PASSI2=XYU(IV1+NCEL+5)
      CBORO =XYU(IV1+NCEL+6)
C
C---   CALCOLO DELLE DENSITA' MODERATORE E DELLE TEMPERATURE COMBUSTIBILE
C
      IP=IV1+7+NCEL
C
      CALL KMTH(XYU,IP,ROCEL,TCCEL,TMCEL,TCCELC,TCCELP,NCEL)
C
      CALL BARRE(PASSI1,PASSI2,DINSER,JG)
C
C
C----  CHIAMATA ALLA ROUTINE 'KIQSWR' PER IL PREDIMENSIONAMENTO DEI COMMON
C        L'unit� di lettura o scrittura IQSWR non � utilizzata e quindi
C        viene inizializzata a 999
C
      IQSWR=49
C
      CALL KIQSWR(0,IQSWR)
C
C---  CHIAMATA AL SOTTOPROGRAMMA 'KIQS01' CHE INIZIALIZZA LE POTENZE E
C     LE FORME DI FLUSSO DI OGNI CELLA TERMOIDRAULICA
C
      WRITE(6,*) '*****  INIZIALIZZAZIONE CALCOLO NEUTRONICO  *****'
C
      CALL KIQS01(JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &            DPOTNO,DBURM)
C
      WRITE(6,*) '****  FINE INIZIALIZZAZIONE CALCOLO NEUTRONICO  ****'
C
C
C*****MEMORIZZAZIONE DELLE POTENZE CALCOLATE DA KIQS01
C     SOLO SE L'UTENTE NON LE HA DEFINITE
C
      XYU(IV1+1)=WNEUT/DPOTNO*100./1.E6
C
      WRITE(6,3301)AXOFF
 3301 FORMAT(//10X,'AXIAL OFF-SET PER INIZIALIZZARE IL CALCOLO ',F10.2)
C
      IF (XYU(IV1+3).LT.1.E-5)XYU(IV1+3)=AXOFF
C
      WRITE(6,3000)
 3000 FORMAT(///10X,'POTENZE TOTALI DI CELLA '/10X,
     &       'PER INIZIALIZZARE IL CALCOLO'//)
C
      DO 35 I=1,NCEL
        IF (XYU(IV1+3+I).LT.1.E-5)XYU(IV1+3+I)=WCEL(I)
        WRITE(6,3001)WCEL(I)
 3001 FORMAT(15X,G12.5)
   35 CONTINUE
C
C---CONSTANTES DE NORMALISATION
C
      W0H0=W0*H0
C
      CNXYU(IV1  ) = 100.
      CNXYU(IV1+1) = 100.
      CNXYU(IV1+2) = 1.E5
      CNXYU(IV1+3) = 1.E6
C
      DO I=1,NCEL
        CNXYU(IV1+3+I) = W0H0
        CNXYU(IV1+9+NCEL+I) =H0
      END DO
C
      CNXYU(IV1+4+NCEL) =1.
      CNXYU(IV1+5+NCEL) =1.
      CNXYU(IV1+6+NCEL) =1000.
      CNXYU(IV1+7+NCEL) =P0
      CNXYU(IV1+8+NCEL) =P0
      CNXYU(IV1+9+NCEL) =H0
C
      IP=IV1+9+2*NCEL
      N3C=3*NCEL
C
      DO I=1,N3C
        K=IP+I
        CNXYU(K)=T0
      END DO
C
C     TOLLERANZE PER LA SOLUZIONE DEL SISTEMA DIFFERENZIALE ALGEBRICO
C     (PER LE GRANDEZZE CALCOLATE DAL MODULO STRIQS IN KINA02 VENGONO
C      AMMESSE TOLLERANZE SUI RESIDUI SUFFICIENTEMENTE ELEVATE ONDE
C      EVITARE INUTILI ITERAZIONI LEGO CHE NON MIGLIOREREBBERO LA
C      PRECISIONE DEI RISULTATI DEL CALCOLO NEUTRONICO IQS)
C
      TOL(1)=1.E-03
      TOL(2)=1.E-03
C
      DO I=1,NCEL
        TOL(4+I)=1.E-03
      END DO
C
      RETURN
      END
C
C**********************************************************************
C
C
C
C**********************************************************************
C
      SUBROUTINE KINAC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
       DATA SccsID/'@(#)kina.f	3.2\t 3.2\t 9/6/94'/
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
      DIMENSION EPS(100)
C
      LOGICAL KREGIM
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      LOGICAL PASFIX
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
      COMMON/PARPAR/NUL(7),ITERT
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REAT,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/PARINT/TITOLO(20),TFIN,TSTEP,FATOLL,INTERR,TINTER
Casam      COMMON/OROSCO/DTCORR,DTDOPO
      COMMON/FIXPAS/PASFIX
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ
Casam      COMMON/VATE$/DTJ,DTJNEW
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NNPAS
C
      EXTERNAL KINRES
C
      IF(.NOT.KREGIM)PASFIX=.TRUE.
      IFAN=IFUN
      NCEL=DATI(IPD+1)
      NEQ=NCEL+4
      NVAR=NEQ+6+4*NCEL
C
C     Definizione di corrispondenti parametri di 'STRIQS'
C
      LREGIM=KREGIM
C
Casam ------------------ DTCORR, DTDOPO e TFIN non sono definiti
C
Casam      DTJ=DTCORR
Casam      DTJNEW=DTDOPO
Casam      TEMFIN=TFIN
      IF(DTINT.LE.0.)THEN
        DTJ=1.
        DTJNEW=1.
      ELSE
        DTJ=DTINT
        DTJNEW=DTINT
Casam        DTJ=TSTEP
Casam        DTJNEW=TSTEP
      ENDIF
      TEMFIN=DTINT+999999.
Casam      TEMFIN=TFIN+999999.
C
Casam      write(6,*)'TSTOP,TEMPO,DTINT,NPAS,CDT',TSTOP,TEMPO,DTINT,NPAS,CDT
Casam      write(6,*)'TFIN',TFIN,' LEND ',LEND
Casam      write(6,*)'TFIN,TSTEP,FATOLL,INTERR,TINTER',TFIN,TSTEP,FATOLL
Casam     &                                           ,INTERR,TINTER
C
Casam ------------------ DTCORR e DTDOPO non sono definiti
C
C      PRINT 200 , TEMPO,DTJ,DTJNEW,WTOT
  200 FORMAT(1X,' TIME =',G12.5,'    DTJ =',G12.5,
     &          ' DTJNEW =',G12.5,'  WTOT =',G12.5)
C
      GO TO (10,30,60),IFUN
C
C
C       TOPOLOGIA JACOBIANO
C
C      SOLO TERMINI DIAGONALI
C
   10 DO I=1,NEQ
        DO J=1,NVAR
          AJAC(I,I)=1.
        END DO
      END DO
C
      RETURN
C
  30  CONTINUE
C
C
C-----CALCOLO DEI RESIDUI
C
      CALL KINRES(IFUN,IXYU,XYU,IPD,DATI,RNI)
      RETURN
C
C-----CALCOLO DELLO JACOBIANO
C
   60 CONTINUE
      CALL KINAJC(AJAC,MX5,NEQ)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINAJC(AJAC,MX5,NEQ)
C
C     JACOBIANO ANALITICO APPROSSIMATO
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      DIMENSION AJAC(MX5,*),BREC(4)
C
      LOGICAL KREGIM
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REAT,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
C
      DO 40 I=1,NEQ
        AJAC(I,I)=-1.
 40   CONTINUE
C
      IF(KREGIM)AJAC(3,3)=0.
C
      IF(.NOT.KREGIM) RETURN
C
      ALFAB=-.000096
C
C    EQUAZIONE DELLA REATTIVITA' TOTALE PER IL CALCOLO DELLO STAZIONARIO
C
      BREC(1)=AREC(1)
      BREC(2)=BREC(1)-AMPAS+AREC(2)
      BREC(3)=BREC(2)-AMPAS+AREC(3)
      HTP=-3.*AMPAS+AREC(1)+AREC(2)+AREC(3)
      WRITE(6,222) IFIX(HTP),IFIX(BREC(3)-AREC(3)),IFIX(BREC(3)),
     &             IFIX(BREC(2)-AREC(2)),IFIX(BREC(2)),IFIX(BREC(1)
     &             -AREC(1)),IFIX(BREC(1)),IFIX(AMPAS)
  222 FORMAT(/,10X,'PSEUDO-ESTRAZIONE DELLE BARRE DI CONTROLLO ',
     &       '(MODE GRIS)',//,1X,7(I4,' ____'),1X,I4,1X,'PASSI1')
C
      IF(PASSI2.GE.0.) THEN
C    MODE GRIS (E.D.F. SEPTEN)
        FAP=1.
        IF(PASSI1.GE.BREC(1)) THEN
C---- BANCO G1
          ALFAP1=0.000015*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.BREC(1)-AREC(1)) THEN
C---- BANCO G1+G2
          ALFAP1=0.000045*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.BREC(2)) THEN
C---- BANCO G2
          ALFAP1=0.000035*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.BREC(2)-AREC(2)) THEN
C---- BANCO G2+N1
          ALFAP1=0.000075*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.BREC(3)) THEN
C---- BANCO N1
          ALFAP1=0.000055*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.BREC(3)-AREC(3)) THEN
C---- BANCO N1+N2
          ALFAP1=0.000095*FAP
          ALFAP2=0.00007*FAP
        ELSE IF(PASSI1.GE.HTP) THEN
C---- BANCO N2
          ALFAP1=0.000055*FAP
          ALFAP2=0.00007*FAP
        ENDIF
        AJAC(3,NEQ+1)=ALFAP1
        AJAC(3,NEQ+2)=ALFAP2
      ELSE IF(PASSI2.LT.0.) THEN
C    MODE A (ENEL/CRA)
        IF(PASSI1.LT.AREC(1)) THEN
C---- BANCO D + C
          FAP=1.7
        ELSE IF(PASSI1.GT.AREC(1)) THEN
C---- BANCO D
          FAP=1.
        ENDIF
        ALFAP1=.00007*FAP
        AJAC(3,NEQ+1)=ALFAP1
        AJAC(3,NEQ+2)=ALFAP1
      ENDIF
      AJAC(3,NEQ+3)=ALFAB*1000.
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINRES(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      LOGICAL KREGIM
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/INTEGR/PSS(4),CDT
      COMMON/PARPAR/PS(7),ITERT
      COMMON/REGIME/KREGIM
C
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REAT,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/KINA05/JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &              DPOTNO,DBURM
C
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      DATA JIQSWR /0/
C
C
      NCEL=DATI(IPD+1)
C
      CALL KINDEC(NCEL,XYU,IXYU,DATI,IPD,IFUN)
C
C*****CHIAMATA DEL PROGRAMMA 'STRIQS' PER IL CALCOLO DI:
C           REATTIVITA'(REATC)
C           POTENZE DI CELLA TERMOIDRAULICHE (WCELC(I))
C           FORMA DI CELLA TERMOIDRAULICA (PHLC(I))
C
      IF(.NOT.KREGIM.AND.JIQSWR.EQ.0) THEN
        JIQSWR=1
        CALL KIQSWR(0,IQSWR)
      ENDIF
C
Casam      write(6,*)'KINRES - LEND ',LEND
      IF (LEND) THEN
C---- FINE DEL TRANSITORIO DECRETATA DAL MODULO DI CINETICA 'KINA'
        WRITE(6,100)
  100   FORMAT(///,80('*'),//,10X,'PROGRAMMA  LEGO/KINA  : FINE DEL ',
     &       'TRANSITORIO',//,80('*'),///)
      STOP ' *****  PROGRAMMA LEGO/KINA : FINE DEL TRANSITORIO  *****'
      ENDIF
C
      CALL KIQS02
C
C*****CALCOLO DEI RESIDUI
C
      W0H0=W0*H0
      WTOTPC=WTOTC/DPOTNO/1.E6
      WNEUPC=WNEUTC/DPOTNO/1.E6
C
      RNI(1)=(WTOTP-WTOTPC)
C
      RNI(2)=(WNEUTP-WNEUPC)
C
      IF (KREGIM) THEN
        RNI(3)=-REATC/1.E5
      ELSE
        RNI(3)=(REAT-REATC)/1.E5
      END IF
C
      RNI(4)=(AXOFF-AXOFFC/1.E6)
C
      DO I=1,NCEL
        RNI(4+I)=(WCEL(I)-WCELC(I))/W0H0
      END DO
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
C
      SUBROUTINE KINAD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINDEC(NCEL,XYU,IXYU,DATI,IPD,IFUN)
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      DIMENSION XYU(*),DATI(*)
      DIMENSION CXYU(100)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/INTEGR/PSS(4),CDT
      COMMON/PARPAR/PS(7),ITERT
      COMMON/REGIME/KREGIM
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REAT,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/KINA05/JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &              DPOTNO,DBURM
C
      LOGICAL KREGIM
C
C
       JDKIN  =DATI(IPD)
       JCELT  =DATI(IPD+1)
       JKIN   =DATI(IPD+2)
       JG     =DATI(IPD+3 )
       DCANN  =DATI(IPD+4)
       DELNUM =DATI(IPD+5)
       DRC    =DATI(IPD+6)
       DASPA  =DATI(IPD+7)
       DALATT =DATI(IPD+8)
       DPOTNO =DATI(IPD+9)
       DBURM  =DATI(IPD+10)
C
      W0H0=W0*H0
C
      NEQ=4+NCEL
      NN2=3*NCEL
      WTOTP    =XYU(IXYU      )
      WNEUTP   =XYU(IXYU +  1 )
      WTOTP  =XYU(IXYU)
      WTOT =WTOTP*DPOTNO*1.E6
      WNEUT=WNEUTP*DPOTNO*1.E6
      REAT     =XYU(IXYU +  2 )*1.E5
      AXOFF    =XYU(IXYU +  3 )
C
      DO I=1,NCEL
        WCEL(I)  =XYU(IXYU +I+3 )*W0H0
      END DO
C
      PASSI1   =XYU(IXYU+NEQ )
      PASSI2   =XYU(IXYU+NEQ +1)
      CBORO    =XYU(IXYU+NEQ +2)*1000.
C
C     DECODIFICA PRESSIONI ENTALPIE TEMPERATURE
C
      CXYU(1) =XYU(IXYU+7+NCEL)*P0
      CXYU(2) =XYU(IXYU+8+NCEL)*P0
      CXYU(3) =XYU(IXYU+9+NCEL)*H0
C
      IP1=IXYU+9+NCEL
C
      DO I=1,NCEL
        CXYU(3+I) =XYU(IP1+I)*H0
      END DO
C
      IP1=IXYU+9+2*NCEL
C
      N3C=3*NCEL
C
      DO I=1,N3C
        K=IP1+I
        CXYU(3+NCEL+I)=XYU(K)*T0
      END DO
C
      IP=1
C
      CALL KMTH(CXYU,IP,ROCEL,TCCEL,TMCEL,TCCELC,TCCELP,NCEL)
C
      CALL BARRE(PASSI1,PASSI2,DINSER,JG)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
C
      SUBROUTINE KMTH(XYU,IP,ROCEL,TCCEL,TMCEL,TCCELC,TCCELP,NCEL)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      DIMENSION ROCEL(*),TCCEL(*),XYU(*),TMCEL(*),TCCELC(*),TCCELP(*)
C
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &              ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
C
C       CALCOLO DELLE DENSITA' MODERATORE E DELLE TEMPERATURE COMBUST.
C
      PI=XYU(IP)
      PU=XYU(IP+1)
      HI=XYU(IP+2)
      DP=(PI-PU)/NCEL
      IP1=IP+2
      PIC=PI
      HIC=HI
      SIC=SHEV(PIC,HIC,1)
      RIC=ROEV(PIC,SIC,1)
      TIC=TEV(PIC,SIC,1)
      ROH2OI=RIC
C
      DO I=1,NCEL
C
C     DENSITA' MODERATORE
C
        PUC=PIC+DP
        HUC=XYU(IP1+I)
        SUC=SHEV(PUC,HUC,1)
        RUC=ROEV(PUC,SUC,1)
        TUC=TEV(PUC,SUC,1)
        ROCEL(I)=(RUC+RIC)*.5
        TMCEL(I)=(TUC+TIC)*.5
        PIC=PUC
        RIC=RUC
        TIC=TUC
C
C     TEMPERATURE DEL COMBUSTIBILE
C
        KC=(I-1)*3+1+IP1+NCEL
        KP=KC+2
C
C---- ESPRESSIONE ENEL/CRA
C      TCCEL(I)=(XYU(KC)+XYU(KP))*.5
C---- ESPRESSIONE EDF/SEPTEN
C
        TCCEL(I)=(4.*XYU(KC)+5.*XYU(KP))/9.
        TCCELC(I)=XYU(KC)
        TCCELP(I)=XYU(KP)
      END DO
C
      ROH2OU=RUC
C
      RETURN
      END
C
C
C**********************************************************************
C
C
C**********************************************************************
C
C
      SUBROUTINE BARRE(PASSI1,PASSI2,DINSER,JG)
C-----------------------------------------------------------------------
C     CALCOLA L' ESTRAZIONE IN PASSI DEI BANCHI DI BARRE IN FUNZIONE
C     DELLE VARIABILI 'PASSI1' E 'PASSI2' SECONDO LE CONFIGURAZIONI
C     DEFINITE COME SEGUE:
C     ------------------------------------------------------------------
C
C           MODE A ENEL/EDF(PASSI2 < 0)      MODE GRIS EDF (PASSI2 > 0)
C           (D=1,C=2,B=3,A=4;SB=5,SA=6)      (G1=1,G2=2,N1=3,N2=4;R=5)
C
C      0)    BARRE ESTRATTE                   BARRE ESTRATTE
C      1)    D                                G1
C      2)    D+C                              G1+G2
C      3)    D+C+B                            G1+G2+N1
C      4)    D+C+B+A                          G1+G2+N1+N2
C      5)    D+C+B+A+SB                       R
C      6)    D+C+B+A+SB+SA                    R+G1
C      7)                                     R+G1+G2
C      8)                                     R+G1+G2+N1
C      9)                                     R+G1+G2+N1+N2
C     10)    C                                G2
C     11)    B                                N1
C     12)    A                                N2
C     13)                                     R+G2
C     14)                                     R+N1
C     15)                                     R+N2
C-----------------------------------------------------------------------
C     L' INSERIMENTO DEI BANCHI D,C,B,A (MODE A) O G1,G2,N1,N2
C     (MODE GRIS) E' DESCRITTO TRAMITE UN BANCO FITTIZIO LA CUI
C     CORSA TOTALE E' QUELLA DEI BANCHI CONSIDERATI MESSI UNO DI
C     SEGUITO ALL'ALTRO DIMINUITA DEI RICOPRIMENTI FRA GLI STESSI.
C     LA POSIZIONE (IN PASSI ESTRATTI) DI TALE BANCO FITTIZIO E'
C     DESUNTA DAL PARAMETRO 'PASSI1' CHE ASSUME VALORI NEGATIVI
C     AL DI LA DELL'INSERIMENTO MASSIMO DEL PRIMO BANCO.
C
C     EX. MODE GRIS (900 MWE):
C                                      N2 ____________________
C
C                           N1 ____________________
C
C               G2 ____________________
C
C    G1 ____________________
C
C       I__________I_______I___I______I___I_______I___________I  PASSI1
C      225        100      0  -35   -125 -170   -260        -395
C
C
C-----------------------------------------------------------------------
C
C     JG     = numero di banchi di barre di controllo previsti per il modo di
C              funzionamento del reattore considerato.
C              Nel funzionamento in "Mode Gris" il numero totale di banchi di
C              barre (grigie + nere) presi in considerazione deve essere:
C              N.BANCHI = 5 (G1,G2,N1,N2;R), mentre in "Mode A" si deve porre:
C              N.BANCHI = 6, in quanto, oltre ai banchi neri (D,C,B,A), vengono
C              computati anche i banchi di "SCRAM" (SB,SA).
C
      DIMENSION DINSER(*),DREC(4)
C
      COMMON/KINA05/JDKIN,JCELT,JKIN,JJG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &              DPOTNO,DBURM
      IF (PASSI2.LT.0.) THEN
C  MODE A ENEL
        IF(JG.NE.6) STOP'NOMBRE DE GROUPES MODE A ENEL <> 6'
        PAST=228.
        DREC(1)=100.
        DREC(2)=100.
        DREC(3)=100.
        JGP=2
      ELSE IF(PASSI2.GE.0.) THEN
C   MODE GRIS E.D.F. SEPTEN
        IF(JG.NE.5) STOP 'NOMBRE DE GROUPES MODE GRIS E.D.F. <> 5'
        JGP=1
        IF(ABS(DPOTNO-2780.).LE.10.) THEN
C---- CASO EDF - REATTORE 900 MWE
          PAST=225.
          DREC(1)=100.
          DREC(2)=90.
          DREC(3)=90.
        ELSE IF(ABS(DPOTNO-3800.).LE.10.) THEN
C---- CASO EDF - REATTORE 1300 MWE
          PAST=260.
          DREC(1)=75.
          DREC(2)=85.
          DREC(3)=100.
        ENDIF
      ENDIF
C
C   CALCUL DES PAS D'EXTRACTION DE CHAQUE GROUPE EN FCT DE PASSI1
C
      HPT=0.
      DO 10 J=2,JG-JGP
   10 HPT=HPT+DREC(J-1)-PAST
      HP=PASSI1
      IF(HP.GT.PAST+1..OR.HP.LT.HPT-1.) THEN
      WRITE(6,21) PASSI1,PAST,HPT
   21 FORMAT(1X,'ATTENTION PASSI1 HORS LIMITES',/,1X,'PASSI1=',F7.2,3X,
     &       'INTERVAL DE VALIDITE = ',F7.2,',',F7.2)
      STOP'PASSI1 HORS LIMITE'
      ENDIF
      DINSER(1)=HP
      IF(DINSER(1).LT.0.) DINSER(1)=0.
      DO 20 J=2,JG-JGP
      HP=HP+PAST-DREC(J-1)
      DINSER(J)=HP
      IF (DINSER(J).GT.PAST) DINSER(J)=PAST
      IF(DINSER(J).LT.0.) DINSER(J)=0.
   20 CONTINUE
C
C  CALCUL DES PAS D'EXTRACTION DU GROUPE R OU DES GROUPES DE SCRAM SB,SA
C
      IF(PASSI2.LT.0.) THEN
C  GROUPES DE SCRAM (ENEL/CRA)
        DINSER(JG-1)=PAST
        DINSER(JG)=PAST
      ELSE IF(PASSI2.GE.0.) THEN
C  GROUPES NOIRES R E.D.F. SEPTEN
        DINSER(JG)=PASSI2
        IF (PASSI2.GT.PAST) THEN
          DINSER(JG)=PAST
          WRITE(6,22)PASSI2
   22 FORMAT(1X,'PASSI2 (MODE GRIS) HORS LIMITES (225-0)',/,1X,
     &      'PASSI2=',F7.2,/,1X,'LE PROG CONTINUE AVEC PASSI=225.')
          PASSI2=PAST
        ENDIF
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KIQS01(JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,
     &                  DALATT,DPOTNO,DBURM)
C-----------------------------------------------------------------------
C     ROUTINE D'INITIALISATION DU CALCUL NEUTRONIQUE (1-D) O (0-D)
C
C     VERSION ENEL/EDF : LAURO POLLACHINI - DIMITRI NICOLOPOULOS
C
C                     **********************************
C                     *                                *
C                     *  VERSION A 2 GROUPS D'ENERGIE  *
C                     *                                *
C                     *           12/01/1988           *
C                     **********************************
C
C-----------------------------------------------------------------------
C   - FISSA I VALORI MASSIMI DELLE DIMENSIONI DEL PROGRAMMA E
C     CONTROLLA CHE I VALORI CORRENTI NON SUPERINO QUELLI MASSIMI.
C   - DIMENSIONA IL COMMON /NEUT1$/S(MAXS) RELATIVO
C     AL VETTORE PRINCIPALE DI MEMORIA 'S' DI "STRIQS"
C     SULLA BASE DEI VALORI MASSIMI DEI PARAMETRI DI INPUT
C     (SALVATI NEL COMMON/INPAR$/.....).
C   - DIMENSIONA INOLTRE ALTRI COMMON DEL TIPO /NEUT.$/XXX(NXX)
C     PROPRI DI GRANDEZZE COMUNI SIA A 'STRIQS' CHE A 'LEGO'.
C   - ASSEGNA LE UNITA' DI INPUT-OUTPUT DI "STRIQS".
C   - EFFETUA L'ALLOCAZIONE DINAMICA DELLE VARIABILI NEL VETTORE
C     DI MEMORIA 'S' TRAMITE LA SUBROUTINE 'ALLOCA'.
C   - FISSA I VALORI CORRENTI DI ALCUNE GRANDEZZE UTILIZZATE DA 'STRIQS'
C   - GESTISCE LE STAMPE RELATIVE AL MODULO DI CINETICA ASSIALE 'STRIQS'
C   - LEGGE I PARAMETRI NUCLEARI GENERATI DA 'NOSTRI' O DA 'LIBELLULE'
C     PER IL TIPO DI CINETICA NEUTRONICA PRESCELTA DALL'UTENTE.
C   - SELEZIONA IL PROFILO DI FLUSSO INIZIALE DI TENTATIVO E CALCOLA
C     LA RELATIVA DISTRIBUZIONE DELLE POTENZE TOTALI DI CELLA.
C   - VALUTA SULLA BASE DEI PROFILI NEUTRONICI E TERMOIDRAULICI PASSATI
C     DA "NOSTRI" I "RESTI" PER L'AZZERAMENTO INIZIALE DELLA REATTIVITA'
C     CALCOLATA CON FORMULAZIONE A DUE GRUPPI ENERGETICI.
C-----------------------------------------------------------------------
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      INTEGER CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,H,RO,CSP,GIN,GINV,PHS,
     1        HAKF,EFB,WESTS,RES,XE,VIO,SM,PM,CALFA,CBETA,CALFA1,
     2        CBETA1,PHI,ROV,FCN,ALBA,BQ,PH,EEF,PHV,ENF,BE,AL,C,SG,
     3        HEL,AKF,CM,ALM,BEM,DEN,BQ1,BQV,BQV1,BQP,C2BQ,GISF,
     4        D,HBE,PHSV,PHP,C2,NBAR,ALBAS,WEST,PHT,TCNOS,RONOS,
     5        DBE,BEMI,HBEV,TIMP,AZ,BZ,ENFV,CV,ZDG,TN,SER,PHJ1,
     6        PROFLU,HBEK,TIMPT,ENFVV,CVV,TEMV,DV,ALMV,PROFTM,
     7        CMV,SERFI,SERFIV,HRO ,HTEM,WMED,WESTD,WESTV,CORD,
     8        WTILD,ATILD,WTRA,TREF,ALBASN,ALBASV,PHV1,ZW,PROFRM,
     9        RECOBA,PALBA,PRPR,EEFR,CLTH,HALBA,HBORO,AKFCEL,
     &        FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     $        VELOC,BINSTE,PROFF,PROFP,BEJ,ALJ,COEXE1,DSGXE,SIGXE,
     !        SIGXEL,GISFL,XEV,VIOV,PROFTC,TMNOS,XENOS,PROFXE
C
      CHARACTER TITOLO*80 , KETITO*80 , SELSTA*12
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
C
      DIMENSION RINSER(NBBC),ROR1(20),ROR2(20)
C
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/XEIOTM/XEVV(NCNT),VIOVV(NCNT),TREFV(NCNT),TEMCV(NCNT),
     &              TEMPV(NCNT)
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
C
      COMMON/NEUT1$/S( KAXS  ),DUMMI30(MAXSM-KAXS)
      COMMON/NAS$$/NAS( KUZOM ),DUMMI31(NW-KUZOM)
      COMMON/BARRE$/VBAR,BINSER( NBBC ),DUMMI32(NW-NBBC)
C      COMMON/SOS$/NSTEP(KSTRAM),INSER(KSTRAM,KSM,KGM),LIZO(KNYM,KNXM),
C     1       NUEL(KUZOM),LIBA(KSTRAM,KNYM,KNXM),JAP(KNYM,KNXM),
C     2       SOM(KUZOM),NGRU(KSTRAM),MAP(2,KNXM),
C     3       KAP(KNYM,KNXM),HELBT(KUZOM),INDEL(KNYM,KNXM)
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),LIZO(15,15),NUEL(5),
     &            LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),
     &            MAP(2,15),KAP(15,15),HELBT(5),INDEL(15,15)
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/COREA$/ERRE,TZER,HKXE,HKB,HKRI(KGM),DUMMI33(NW-4-KGM)
      COMMON/NUCL$/OM(2,KCM),DUMMI40(2,NW-KCM)
      COMMON/PRODE$/ADEC(KPDM,KPDM-1),GDEC(KPDM,KPDM-1),POTDEC
     &             ,DUMMI50(5*NW-2*KPDM*(KPDM-1)-1)
      COMMON/RIFLE$/SF(2),DF(2),ST(2),DT(2),RRIF(2)
     &             ,DUMMI34(NW-2*5)
C
      COMMON/INPAR$/NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,
     &              NNXM,NNYM,NTTJM,NITJM,NLIBM,NPROFM,
     &              NKINM,NCELM,MAXS,KDIM,NCM
      COMMON/INTER$/NCEL,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $              NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
C
      COMMON/PRINT$/SELSTA
      COMMON/TIIQS$/TITOLO
      COMMON/JSTAX$/JALBA,JEEF,JENF,JSG,JPROFL,JWW,JRO,JTEM,JXE,JSM,
     &              JRBA,JCM,JDUMMI(NW-12)
      COMMON/REG22$/TIMERG(NW),WTOTRG(NW),REATRG(NW),PDECRG(NW),
     &              AXOFRG(NW),AMINB1(NW),AMINB2(NW),ALFDRG(NW),
     &              ALFMRG(NW),ALFBRG(NW),DUMMI60(20*NW-10*NW)
C
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
C
      COMMON/INDIR$/PHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     &              TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,
     &              WESTV,WESTD,WESTS,H,RO,CSP,GIN,WTRA,DUMMI0(NW-31)
      COMMON/INDR1$/ALT,BEM,AL,WW,XE,VIO,PM,SM,HEL,
     &              PHT,WGAMC,WTILD,ATILD,GINV,XEV,VIOV,
     &              TREF,ALBAS,WMED,CORD,NBAR,HALBA,HBORO,ALBA
     &              ,DUMMI1(NW-24)
      COMMON/INDR2$/QCEL,CEFI,TEM,ALBASN,ALBASV,SERFI,HRO,
     1              EFB,RES,HTEM,TIMPT,
     2              PHI,ROV,FCN,BQ,PH,EEF,PHV,ENF,BE,C,SG,
     3              AKF,CM,ALM,DEN,WEST,
     4              DBE,BEMI,TIMP,AZ,BZ,ZDG,TN,SER,PHJ1,
     5              NBARRE,NBARN,PHV1,ZW,RECOBA,PALBA,PRPR,EEFR,CLTH
     &              ,DUMMI2(NW-45)
      COMMON/INDR3$/PROFLU,CL,DUMMI3(NW-2)
      COMMON/INDR5$/FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     $              VELOC,BINSTE,PROFF,PROFP,ILIB1,ILIB2,AKFCEL,BEJ,ALJ,
     &              COEXE1,DSGXE,PROFTM,PROFRM,TCNOS,RONOS,CALFA,CBETA,
     %              CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,PROFTC,TMNOS
     %              ,XENOS,PROFXE,DUMMI4(NW-35)
C
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/BOR$/BORVCT,DUMMI23(NW-1)
C
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1              VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,
     2              CSIFR,RELN,A,DG,TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPSBQ,RIAL,
     &              RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/REAL6$/BREAK1,BREAK2,DELM1,DELM2,DUMMI17(NW-4)
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
C
      COMMON/PADKR$/PPF,AAG,PPFV,AAGV,DTKIN,DUMMI15(NW-5)
      COMMON/PKIN$/DWANOM,SIGFEE,DUMMI14(NW-2)
      COMMON/DANU0$/GIO,GXE,SIGXEM,EFIS,SIGFTH,DUMMI13(NW-5)
      COMMON/DANUC$/VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $              FRAXE,FRASM,DUMMI12(NW-10)
      COMMON/ZEKIN$/PXE0,B0,REAT0,DHRD0,DRHM0,DHRIT0,DUMMI11(NW-6)
C
      COMMON/PROVV$/EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
C
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/TARGE$/TARAXO,POTF0,DUMMI7(NW-2)
      COMMON/RIFLA$/RRFI,RRTI,RRFS,RRTS,DUMMI6(NW-4)
C   COMMON 7N
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/CLAPLA/NBUL,BUCL(50),B2R1(50),B2R2(50),COEFB1,COEFB2
      COMMON/LIM/IM1,GM1,KM1
      COMMON/ZREF/IINF,ISUP,L1,PL1
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
C
C-----------------------------------------------------------------------
C
      NCELTM = KCELTM
      NUZOM = KUZOM
      NRITM = KRITM
      NPDM = KPDM
      NGM = KGM
      NSM = KSM
      NSTRAM = KSTRAM
      NNXM = KNXM
      NNYM = KNYM
      NTTJM = KTTJM
      NITJM = KITJM
      NLIBM = KLIBM
      NPROFM = KPROFM
      NKINM = KKINM
C
      NCOE = KCOE
      NCELM = KCELM
      NCM = KCM
      MAXS = KAXS
      KDIM = KLIB
C
      PRINT*,'MAXS=',MAXS,'   KDIM=',KDIM
C------------------------------------------------------------------
C     IDENTIFICATION DE LA VERSION KINA EMPLOYEE                       0
C      ILEGO=1  VERSION ENEL/CISE
C      ILEGO=2  VERSION EDF/SEPTEN
C------------------------------------------------------------------
      ILEGO=2
C------------------------------------------------------------------
C     IDENTIFICATION DU NOMBRE DE GROUPS D'ENERGIE EMPLOYEES
C------------------------------------------------------------------
      IDUEG=1
C------------------------------------------------------------------
C     IDENTIFICATORE DEL TIPO DI CALCOLO DELLO XENO
C      IXENO=0 --> XENO FISSATO AL VALORE NOMINALE
C      IXENO=1 --> XENO CALCOLATO (FUNZIONE DEL LIVELLO DI POTENZA)
C------------------------------------------------------------------
      IXENO=1
C
C     DEFINIZIONE DEI FILES DI INPUT-OUTPUT UTILIZZATI DA 'STRIQS'
C
      NREAD= 56
      NWRITE= 57
      IRLIB1= 55
      IRLIB2= 54
      IRLIB3= 53
      IALBE= 45
      IQSWR= 49
      IREST= 50
C
C     APERTURA DEI FILES DI INPUT/OUTPUT
C
C     OPEN(UNIT=NWRITE,FILE='KINOUT3',STATUS='NEW',FORM='FORMATTED')
C     OPEN(UNIT=IRLIB1,FILE='KINLIB',STATUS='OLD',FORM='FORMATTED')
C     OPEN(UNIT=IRLIB2,FILE='KINPROF',STATUS='OLD',FORM='FORMATTED')
C     OPEN(UNIT=IRLIB3,FILE='KINLIB0',STATUS='OLD',FORM='FORMATTED')
C
C     INIZIALIZZAZIONE DEI PARAMETRI DI INGRESSO
C
      IDKIN=JDKIN
      NKIN=JKIN
      NCELT=JCELT
      NG=JG
      CANN=DCANN
      ELNUM=DELNUM
      RC=DRC
      ASPA=DASPA*100.
      ALATT=DALATT
      WNOM=DPOTNO*1.E+06
      BURM=DBURM
C
      IF (ILEGO.EQ.1) THEN
C
C---- CASO ENEL - REATTORE PUN
C
        ZMIN=0.
        AMPAS=228.
        AREC(1)=100.
        AREC(2)=100.
        AREC(3)=100.
C
      ELSE IF(ILEGO.EQ.2) THEN
C
        IF(ABS(WNOM-2780.E+6).LE.10.E+6) THEN
C
C---- CASO EDF - REATTORE 900 MWE
C
          ZMIN=8.5705
          AMPAS=225.
          AREC(1)=100.
          AREC(2)=90.
          AREC(3)=90.
C
        ELSE IF(ABS(WNOM-3800.E+6).LE.10.E+6) THEN
C
C---- CASO EDF - REATTORE 1300 MWE
C
          ZMIN=13.950
          AMPAS=260.
          AREC(1)=75.
          AREC(2)=85.
          AREC(3)=100.
C
        ENDIF
      ENDIF
C
      IPPREP=1
      NDTJM=50
      LSTAZ=.TRUE.
      LEND=.FALSE.
C
C     DEFINIZIONE DEGLI INDICI PROPRI DEL CASO CORRENTE
C
      NUZO = 1
      NCEL = NKIN*NCELT
      NPD = NPDM
      NSTRA = NSTRAM
      NS = NSM
      NRIT = NRITM
      NNX = NNXM
      NNY = NNYM
C
      NAS(NUZO) = CANN
C
      CALL STAKIN(JSTAMP,SELSTA,KETITO,TITOLO)
C
      CALL FIQS01(DTKIN,IBWR,IDOIN,EPSR,EPSNOR,EPSKF,EPSBQ,
     &            CF,TPAS,BREAK1,BREAK2,DELM1,DELM2,NST,IVELBR,
     &            BQR,RGAM)
C
      CALL FIQS02(NPDM,NGM,ADEC,GDEC)
C
      CALL TESDIM(KETITO)
C
      CALL ALLOCA
C
      CALL SKEMA(ALATT,NCEL,NKIN,NCELT,NWRITE,S(ALT),S(CL),S(CLTH))
C
      IF (IDKIN.EQ.0) THEN
C
        CALL NOSTR0(NRIT,VELOX,SIGFNU,EFIS,VNUM,S(ALM),S(BEM))
        VEL=1./VELOX
        SIGFTH=SIGFNU/VNUM
        ALBIG=VEL/SIGFNU
        BEMTOT=0.
        ALUNO=0.
C
        DO J=1,NRIT
          IBEM=BEM+J-1
          IALM=ALM+J-1
          BEMTOT=BEMTOT+S(IBEM)
          ALUNO=ALUNO+S(IBEM)/S(IALM)
        END DO
C
        ALUNO=BEMTOT/ALUNO
C
      ELSE IF(IDKIN.EQ.1) THEN
C
        IF (ILEGO.EQ.1) THEN
          CALL NOSTR1(NLIBM,NPROFM,NCEL,NRIT,NG,S(COES1),S(COED1),
     &                S(COENF1),S(COEKFT),S(COEEF1),S(RLAM),S(RBETA),
     &                S(VELOC),S(BINSTE),S(PROFF),S(PROFP),NCM,
     &                S(COEXE1),NLIB,NPROF,NCOE,S(PROFTM),S(PROFRM),
     &                S(SIGXEL),S(GISFL),S(PROFTC),NCICLO,BURNUP,POTTOT,
     &                BORCRI,RINSER,BURM)
          IF (ABS(BURM-BURNUP).GT.1.) THEN
            WRITE(NWRITE,75) BURM,BURNUP
   75 FORMAT(/,' ATTENZIONE ! IL BRUCIAMENTO MEDIO DI REATTORE LETTO',
     &' IN INPUT E'' DIVERSO DA QUELLO DELLE LIBRERIE O DEI PROFILI ',
     &'DISPONIBILI',/,1X,'BRUCIAMENTO DI INPUT =',F6.2,'%',5X,
     &'ULTIMO BRUCIAMENTO DELLE LIBRERIE O DEI PROFILI =',F6.2,'%',/,
     &      1X,'IL PROGRAMMA SI BLOCCA',/)
            STOP ' BRUCIAMENTO LETTO DIVERSO DA QUELLO DI LIBRERIA '
          ENDIF
        ELSE IF (ILEGO.EQ.2) THEN
C
C    INITIALISATIONS GRANDEURS TYPIQUES DES CONTRE REACTIONS EDF
C
          NCELRF=2
          IINF=NCELRF/2+1
          ISUP=NCEL+NCELRF/2
          KM1=NCEL+NCELRF
          CALL TABLEKINA
          CALL PLIBEL(NPROFM,NCEL,NG,NPROF,NCM,NCELRF,S(BINSTE),
     %                S(PROFF),S(PROFP),S(PROFTM),S(PROFRM),S(CL),
     %                S(PROFXE),S(PROFTC),BURNUP,POTTOT,BORCRI,
     %                AKEFFL,RINSER,ROR1,ROR2,BURM,BUMCOR)
C
C---- INTERPOLAZIONI SUL BURN-UP PER IL CALCOLO DEI "RESTI"
C
          CALL EPUINT(BURNUP)
C
        ENDIF
C
C     PARAMETRI DELLA LIBRERIA DEI PROFILI 'KINPROF' SULLA BASE DEI
C     QUALI VENGONO CALCOLATI I "RESTI"
C
        BURM=BURNUP
        W=POTTOT*WNOM/100.
        BORVCT=BORCRI
C
        DO 381 K=1,NG
          BINSER(K)=RINSER(K)
  381   CONTINUE
C
C  DECODAGE DES PAS TOTAL D'EXTRACTION DES GRAPPES GRISES (EDF 7N)
C  OU NOIRES (ENEL/CRA)
C
        IF (PASSI2.LT.0.) THEN
C
C  MODE A (E.N.E.L. CRA)
C
          JGP=2
          PAS2=PASSI2
C
        ELSE IF(PASSI2.GE.0.) THEN
C
C  MODE GRIS (E.D.F. 7N)
C
          JGP=1
          PAS2=BINSER(NG)
C
        ENDIF
C
        IF (BINSER(1).LE.AMPAS.AND.BINSER(1).GE.0.) THEN
          PAS1=BINSER(1)
          GO TO 60
        ENDIF
C
        DO 50 J=2,NG-JGP
          IF (BINSER(J).LE.AMPAS.AND.BINSER(J).GE.0.) THEN
            JB=J
            PAS1=BINSER(JB)
            DO 51 I=2,JB
   51         PAS1=PAS1-AMPAS+AREC(I-1)
            GO TO 60
          ENDIF
   50   CONTINUE
   60   CONTINUE
C
        CALL PROFIN(BINSER,NG,S(BINSTE),NPROF,NPROFM,S(PROFF),
     &              S(PROFP),S(RES),S(PH),S(PROFLU),S(D),NCEL,
     &              RIAL,RIBA,IREST,IRLIB4,IDKIN,LREGIM,BORVCT,
     &              ALATT,CANN,S(WW),S(WGAMC),S(WESTD),S(WESTS),
     &              ADEC,GDEC,S(CORD),S(CL),RGAM,TPAS,NPDM,
     &              NPD,WTOT,ROCEL,TCCEL,NCELT,NKIN,ALCAN,WCEL,
     &              WNEUT,CBORO,DINSER,S(RO),S(TEM),S(TCNOS),
     &              S(RONOS),S(PROFTM),S(PROFRM),TARAXO,AXOFF,
     &              S(PROFTC),S(TMNOS),S(TREF),ILEGO,S(PROFXE),S(XENOS),
     &              S(XE),ROR1,ROR2,FLU1V,FLU2T,S(ALT),PHR1,PHR2,RFIS21)
C
        IF (IDKIN.EQ.1) THEN
C
          CALL RESTI(S(AKF),S(AL),S(BE),S(ALBA),S(ALT),S(CEFI),S(BQ),
     &               S(C),S(EEF),S(ENF),S(PHV),S(SG),S(TEM),S(RO),
     &               S(HEL),S(PALBA),S(BQV),S(D),S(RES),S(CM),S(HBE),
     &               S(BEM),S(ALM),S(PROFLU),S(PH),S(FCNZ),S(ILIB1),
     &               S(ILIB2),S(COES1),S(COED1),S(COENF1),S(COEKFT),
     &               S(COEEF1),S(RLAM),S(RBETA),S(VELOC),S(AKFCEL),
     &               S(ALJ),S(BEJ),ALFAD,ALFAM,ALFAB,S(TREF),S(COEXE1),
     &               S(DSGXE),WNEUT,NLIBM,NCM,NRITM,S(XE),S(VIO),
     &               S(SIGXE),S(GISF),S(XEV),S(VIOV),S(SIGXEL),S(GISFL),
     &               ILEGO,PAS1,PAS2,IDUEG,IXENO,S(XENOS))
C
        ENDIF
C
C---- UTILIZZO DEL BURN-UP MEDIO OTTENUTO DAL PROFILO ASSIALE LIBELLULE
C
        BURM=BUMCOR
C
        IF (ABS(DBURM-BURM).GT.10.) THEN
          WRITE(NWRITE,48) DBURM,BURM
   48   FORMAT(/,1X,'ATENTION ! L''EPUISEMENT MOYEN DES BIBLIOTHEQUES ',
     &       'EST DIFFERENT DE CELUI DU FICHIER 14',/,1X,
     &       'BURN UP MOYEN D''ENTREE =',F8.1,/,1X,
     &       'BURN UP DE LA LIBRAIRIE =',F8.1,/,1X,
     &       'LE PROGRAMME CONTINUE EN UTILISANT LE BURN UP MOYEN DE ',
     &       'LA LIBRAIRIE LIBELLULE ',/)
        ENDIF
C
C     TARATURA DELL'AXIAL OFFSET IN FUNZIONE DEL BRUCIAMENTO MEDIO
C
        IF (ILEGO.EQ.1) THEN
          PBURM=BURM
        ELSE IF(ILEGO.EQ.2) THEN
          PBURM=BURM*100./BUCL(NBUL)
        ENDIF
C
C---- INIZIO VITA (B.O.L.)
C
        IF(PBURM.GE.0.0)  TARAXO=-9.
C
C---- MEZZA VITA (M.O.L.)
C
        IF(PBURM.GE.50.)  TARAXO=-5.
C
C---- FINE VITA (E.O.L.)
C
        IF(PBURM.GE.100.) TARAXO=-2.
C
      ENDIF
C
C     CHIUSURA DEI FILES DI INPUT/OUTPUT
C
C     CLOSE (IRLIB1)
C     CLOSE (IRLIB2)
C     CLOSE (IRLIB3)
C
      WRITE(NWRITE,777)
  777 FORMAT(///,20X,'*****  FINE DEL CALCOLO DI INIZIALIZZAZIONE ',
     &       '(SUB. KIQS01)  *****',///,1H1)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KIQS02
C
C***********************************************************************
C
C    PROGRAMMA STRIQS-3 (SIMULATION TRANSITOIRE IMPROVED QUASI STATIC)
C    (MODULO NEUTRONICO DEL CODICE "LEGO" DELL'ENEL-CRA)
C
C  ---------------------------------------------------------------------
C
C       MAIN PROGRAM  (VAX-8600 ENEL-CRA E IBM EDF-SEPTEN)
C
C***********************************************************************
C
C         MODULO PER LA SIMULAZIONE DINAMICA DI PWR
C         CON CINETICA NEUTRONICA MONODIMENSIONALE (1-D)
C         O ZERODIMENSIONALE (0-D)
C                                                                       
C  ---------------------------------------------------------------------
C
C       AUTORI: L. POLLACHINI E G. VIMERCATI , CISE  MILANO (ITALIA)
C
C       VERSION EDF/7N (LYON) : DIMITRI NICOLOPOULOS - LAURO POLLACHINI
C
C                     **********************************
C                     *                                *
C                     *  VERSION A 2 GROUPS D'ENERGIE  *
C                     *                                *
C                     *           12/01/1988           *
C                     **********************************
C
C***********************************************************************
C
C      IL MODULO RICEVE DAL 'MAIN PROGRAM' (SUBROUTINE 'KIQS01') LE
C      DIMENSIONI MASSIME DELLE VARIE GRANDEZZE, I COMMON DEL TIPO
C      'NEUT1$', 'NEUT2$', NEUT.$ (MEDIANTE I QUALI VENGONO
C      PREDIMENSIONATI IL VETTORE DI MEMORIA 'S'  E ALTRE GRANDEZZE
C      COMUNI SIA A 'STRIQS' CHE A 'LEGO' SECONDO LA LOGICA DI
C      QUEST'ULTIMO CODICE) E I DATI NECESSARI ALLA CINETICA ASSIALE
C      (1-D) O ZERODIMENSIONALE (0-D) RELATIVAMENTE AL CASO CORRENTE.
C
C-----------------------------------------------------------------------
C
C   IL CODICE STRIQS-3 HA ATTUALMENTE LE SEGUENTI CARATTERISTICHE PRINCI
C
C    - ALLOCAZIONE DINAMICA DELLE VARIABILI NEL VETTORE DI MEMORIA 'S'.
C    - FINALIZZAZIONE DEL CODICE ALLO STUDIO DI REATTORI PWR
C    - VERSIONE SENZA RESTITUZIONE DI ENERGIA (ENER=0.)
C    - LA TERMOIDRAULICA VIENE RISOLTA ITERATIVAMENTE (CON LA NEUTRONICA
C      UNA SOLA VOLTA PER OGNI PASSO DI RICALCOLO DELLA FUNZIONE FORMA;
C      EVENTUALI RICALCOLI DI FORMA AVVENGONO MANTENENDO COSTANTE LA
C      TERMOIDRAULICA (AI VALORI DELLA PRIMA ITERAZIONE DI FORMA).
C    - VERSIONE CON AUTOMATIZZAZIONE DEGLI INTERVALLI DTPSI DI RICALCOLO
C      DELLA FUNZIONE FORMA DI FLUSSO SPAZIALE.
C    - INTRODUZIONE CONTATORE E SELEZIANATORE STAMPE.
C    - INTRODUZIONE POTENZA DI DECADIMENTO (NPD=2-11).
C    - IMPLEMENTAZIONE DELLA OPZIONE DI CINETICA NEUTRONICA PUNTIFORME
C      (0-D) PER PWR (CON VALUTAZIONE DELLA REATTIVITA' PER MEZZO DI
C      COEFFICIENTI DI CONTROREAZIONE TIPICI).
C      TALE OPZIONE DI CINETICA ZERODIMENSIONALE PUO' ESSERE IMPIEGATA
C      SOLAMENTE DOPO UNA REGIMAZIONE EFFETTUATA CON CINETICA ASSIALE.
C    - NUOVA GESTIONE DEL CALCOLO DELLE COSTANTI NUCLEARI COLLASSATE    
C      (1-D) PRODOTTE DAL CODICE DI INTERFACCIA "NOSTRI" (NORMA-STRIQS).
C    - CALCOLO DEL RAPPORTO DI 'ALBEDO' A PARTIRE DALLE COSTANTI NUCLEAR
C      DEI RIFLETTORI ASSIALI E DETERMINAZIONE DEI COEFFICIENTI DI      
C      RIFLESSIONE SUPERIORE ED INFERIORE DEL REATTORE SULLA BASE DI
C      TALE ALBEDO.                                                     
C    - INTRODUZIONE RICERCA DI CRITICITA' DA BORO (A BARRE FERME) O DA
C      BARRE (A BORO PREFISSATO) PER PWR.                               
C    - VALUTAZIONE PER PWR DELLA 'CONTROL FRACTION' DEI BANCHI DI BARRE
C      CON PESATURA SUI FLUSSI NEUTRONICI INTEGRATI DI CELLA.
C    - GENERAZIONE AUTOMATICA DELLE CELLE NEUTRONICHE E TERMOIDRAULICHE.
C    - DISACCOPPIAMENTO DELLA CELLIZZAZIONE ASSIALE NEUTRONICA DA QUELLA
C      TERMOIDRAULICA.
C    - EVOLUZIONE DINAMICA DELLO XENO IN TRANSITORI ANCHE DI LUNGA DURAT
C      (EVENTUALMENTE MEDIANTE PASSI DI TEMPO ADEGUATAMENTE AMPI)
C    - POSSIBILITA' DI RICERCA DI REGIMI STAZIONARI (STRIQS0) E DI ANALI
C      DI TRANSITORI A REGIMAZIONE (1-D) AVVENUTA (STRIQS0+STRIQS1+STRIQ
C
C    - TRATTAZIONE DELLA CINETICA NEUTRONICA A DUE GRUPPI ENERGETICI.   
C
C    - VERSIONE EDF/SEPTEN: CALCOLO COSTANTI NUCLEARI (1-D) A DUE GRUPPI
C      TRAMITE CONTROREAZIONI SEPTEN GENERATE DA "LIBELLULE".
C
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/PARPAR/PS(7),ITERT
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO          
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      DATA ITERL /0/
      DATA IQSWR /49/                                                   
      DATA IREST /50/
C                                                                       
      IF( LREGIM) THEN
C     CALCUL STATIONNAIRE DU REGIME                                     
C     OPEN(UNIT=IQSWR,FILE='KINCOM',STATUS='NEW',FORM='UNFORMATTED')
C      OPEN(UNIT=IREST,FILE='KINREG1',STATUS='NEW',FORM='FORMATTED')
C
        CALL STRIX0
        CALL KIQSWR(1,IQSWR)
C
      ELSE IF(.NOT.LREGIM.AND.ITERL.EQ.0) THEN
C
C     INITIALISATION DU CALCUL DYNAMIQUE DU TRANSITOIRE
C---- LETTURA DEI DATI SALVATI DA KIQSWR DOPO LO STAZIONARIO
C
C     OPEN(UNIT=IQSWR,FILE='KINCOM',STATUS='OLD',FORM='UNFORMATTED')    
        CALL KIQSWR(2,IQSWR)
        LREGIM=.FALSE.
        LIQS3=.FALSE.
C     OPEN(UNIT=NWRITE,FILE='KINOUT5',STATUS='NEW',FORM='FORMATTED')    
        WRITE(NWRITE,*) ' STRIX0 --> INIZIALIZZAZIONE DEL CALCOLO ',
     &                '(ITERL =',ITERL,')'                              
        CALL STRIX0
        ITERL=1
      ELSE IF(IDKIN.EQ.0.OR.(.NOT.LREGIM.AND.ITERT.EQ.0)) THEN
C     RECALCUL DE LA FCT FORME DE FLUX A LA FIN DE L'INTERVAL RELATIF   
C     DE TEMPS
        IF(LFORMA.AND.LIQS3) THEN
        WRITE(NWRITE,*) ' STRIX3 --> RICALCOLO DELLA FUNZIONE FORMA ',
     &                  '(ITERT =',ITERT,')'
         CALL STRIX3
        ENDIF
C
C     CALCUL DYNAMIQUE DE TYPE (IQS-1D) DE PREVISION OU 0D
C
      WRITE(NWRITE,*) ' STRIX1 --> CALCOLO DINAMICO IQS DI PREVISIONE'
     &                ,' (ITERT =',ITERT,')'
        CALL STRIX1
      ELSE
        WRITE(NWRITE,*) ' STRIX2 --> CALCOLO DINAMICO IQS EFFETTIVO ',
     &                '(ITERT =',ITERT,')'
        CALL STRIX2
      ENDIF
C
      RETURN
      END                                                               
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE STAKIN(JSTAMP,SELSTA,KETITO,TITOLO)
C-----------------------------------------------------------------------
C     SCELTA DEI PARAMETRI PER LA GESTIONE DELLE STAMPE NEL MODULO 'STRI
C
C
C      JSTAMP = INDICE DI STAMPA DELLE GRANDEZZE DI INTERESSE NEUTRONICO
C                 JSTAMP=N --> STAMPA LE GRANDEZZE SELEZIONATE IN 'SELST
C                              OGNI N PASSI DTJ DI RICALCOLO DEI PRECURS
C                 JSTAMP=0 --> NESSUNA STAMPA (SALVO QUELLE NON GESTITE
C                              'SELSTA' DI CARATTERE GENERALE)
C
C      SELSTA = STRINGA MEDIANTE LA QUALE VENGONO SELEZIONATE LE GRANDEZ
C               DA STAMPARE (OGNI JSTAMP PASSI DTJ) PONENDO UGUALE AD 1
C               L'INDICE CORRISPONDENTE (SE INVECE L' INDICE E' POSTO
C               UGUALE A 0 LA GRANDEZZA NON VIENE STAMPATA)
C
C-----------------------------------------------------------------------
C
      CHARACTER KETITO*80 , TITOLO*80 , SELSTA*12
C
C---- TITOLO DEI GRAFICI ASSIALI
C
      TITOLO=' MODULE DE NEUTRONIQUE AXIALE KINA-2G'
C
C---- TITOLO DELLA PROVA CORRENTE
C
      KETITO=
     &' LEGO - STRIQS (ESSAI PWR/EDF: NCELT=8,NKIN=3 , MILAN, 03/11/87)'
      JSTAMP=0
      SELSTA= '100010000000'
C  LEGENDA  :  ABCDEFGHILMN
C
C     A : JALBA  ( --> ALTEZZA DI INSERIMENTO DEI BANCHI DI BARRE )
C     B : JEEF   ( --> SIGMA DI FISSIONE * ENERGIA RILASCIATA PER FISSIO
C     C : JENF   ( --> SIGMA DI FISSIONE * NU (NEUTR. EMESSI PER FISSION
C     D : JSG    ( --> SIGMA DI ASSORBIMENTO )
C     E : JPROFL ( --> PROFILO DI POTENZA ASSIALE )
C     F : JWW    ( --> POTENZA LINEARE ASSIALE MEDIA )
C     G : JRO    ( --> DENSITA' DEL REFRIGERANTE O SUA TEMPERATURA PER 0
C     H : JTEM   ( --> TEMPERATURA DEL COMBUSTIBILE )
C     I : JXE    ( --> CONCENTRAZIONE MEDIA DI XENO )
C     L : JSM    ( --> CONCENTRAZIONE MEDIA DI SAMARIO )
C     M : JRBA   ( --> REATTIVITA' CONTROLLATA DAI BANCHI DI BARRE 0-D )
C     N : JCM    ( --> CONCENTRAZIONE MEDIA DEI PRECURSORI DI RITARDATI
C-----------------------------------------------------------------------
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE FIQS01(DTKIN,IBWR,IDOIN,EPSR,EPSNOR,EPSKF,EPSBQ,CF,
     &                  TPAS,BREAK1,BREAK2,DELM1,DELM2,NST,IVELBR,
     &                  BQR,RGAM)
C-----------------------------------------------------------------------
C     VENGONO FISSATI ALCUNI DATI RELATIVI AL MODULO 'STRIQS'
C     (TALI DATI IN GENERE NON SONO MODIFICATI DALL'UTENTE)
C-----------------------------------------------------------------------
      DTKIN=.01
      IBWR=0
      NST=1
      IVELBR=1
      IDOIN=2
      EPSR=  1.0E-04
      EPSNOR= .0001
      EPSKF= 0.5E-03
      EPSBQ= 1.000E-06
      CF= 1.00
      TPAS= 1.00E+09
      BREAK1= 1.E-04
      BREAK2= 1.E-04
      DELM1=.003
      DELM2=.015
      BQR=0.
      RGAM=.04
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE FIQS02(NPDM,NGM,ADEC,GDEC)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION ADEC(NPDM,NPDM-1),GDEC(NPDM,NPDM-1)
      DIMENSION AADEC(KPDM,KPDM-1),GGDEC(KPDM,KPDM-1),HHKRI(KGM)
C
      COMMON /DANUC$/VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $               FRAXE,FRASM,DUMMI12(NW-10)
      COMMON/COREA$/ERRE,TZER,HKXE,HKB,HKRI(KGM),DUMMI33(NW-4-KGM)
C
      DATA AADEC/1.5E-03,1.0E-06,9*0.0,0.067,0.007,3.437E-04,85*0.0,
     &           1.772,.5774,6.743E-02,6.214E-03,4.739E-04,4.810E-05,
     &           5.344E-06,5.726E-07,1.036E-07,2.959E-08,7.585E-10/
C
      DATA GGDEC/0.05,0.01,9*0.0,2.51E-02,1.654E-02,2.586E-02,85*0.0,
     &            .00299,.00825,.01550,.01935,.01165,
     &            .00645,.00231,.00164,.00085,.00043,.00057/
C
      DATA HLAMXE/2.114E-5/,HLAMIO/2.885E-5/,HLAMPM/3.56E-6/,
     &     HYXE/.059/,HYSM/.012/,HFRAIO/.9492/,HFRAPM/1.0/
C
      DATA HTZER/293./,HHKXE/-0.278E-01/,HHKB/-9.5/,
     &     HHKRI/1536.,1401.,2131.,1304.,1408.,2844./
C
      VLAMXE=HLAMXE
      VLAMIO=HLAMIO
      VLAMPM=HLAMPM
      YXE=HYXE
      YSM=HYSM
      FRAIO=HFRAIO
      FRAPM=HFRAPM
      TZER=HTZER
      HKXE=HHKXE
      HKB=HHKB
C
      DO J=1,NPDM
        DO K=1,NPDM-1
         ADEC(J,K)=AADEC(J,K)
         GDEC(J,K)=GGDEC(J,K)
        END DO
      END DO
C
      DO J=1,NGM
        HKRI(J)=HHKRI(J)
      END DO
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE TESDIM(KETITO)
C-----------------------------------------------------------------------
C     VERIFICA CHE LE DIMENSIONI REALI DEL CASO CORRENTE NON SUPERINO
C     QUELLE MASSIME DEFINITE IN PARAMETER
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      CHARACTER KETITO*80
      COMMON/INPAR$/NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,
     &              NNXM,NNYM,NTTJM,NITJM,NLIBM,NPROFM,
     &              NKINM,NCELM,MAXS,KDIM,NCM
      COMMON/INTER$/NCEL,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $              NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      IF(ILEGO.EQ.1) THEN
      WRITE(NWRITE,777)
      WRITE(99,777)
  777 FORMAT(1H1,///,1X,125('-'),///,18X,'>>>>>>>>>   MODULO  ',
     &      'K I N A  ( OPZIONE ENEL )   <<<<<<<<<',//)
      ELSE IF(ILEGO.EQ.2) THEN
      WRITE(NWRITE,677)
      WRITE(99,677)
  677 FORMAT(1H1,///,1X,125('-'),///,18X,'>>>>>>>>>   MODULE  ',
     &      'K I N A  ( OPTION EDF )   <<<<<<<<<',//)
      ENDIF
      WRITE(NWRITE,737) IDKIN,IDUEG
      WRITE(99,737) IDKIN,IDUEG
  737 FORMAT(18X,'*****  PROGRAMMA  S T R I Q S  : INIZIO DEL CASO ',
     &       ' *****',//,28X,'( CINETICA NEUTRONICA (',I1,'-D) A ',I1,
     &       '-G )',///,1X,125('-'),///)
C
      WRITE(NWRITE,'(1X,A,/)') KETITO
      WRITE(NWRITE,10)
   10 FORMAT(/,25X,'*****  INIZIO DEL CALCOLO NEUTRONICO  *****',//,
     &         25X,'*****         STAMPE IN KIQS01        *****',/)
      WRITE(NWRITE,655) MAXS,KDIM
  655 FORMAT(1X,'OCCUPAZIONE DI MEMORIA DEL VETTORE PRINCIPALE S(MAXS)',
     &       ':  MAXS = ',I7,//,1X,
     &          'OCCUPAZIONE DI MEMORIA DELLE LIBRERIE DI PARAMETRI ',
     &       'NUCLEARI :  KDIM = ',I7,/)
C
C     TEST DI CONGRUENZA DEI PARAMETRI REALI CON I RISPETTIVI VALORI
C     MASSIMI PREFISSATI NEI DIMENSIONAMENTI INIZIALI DEI VETTORI
C
      IF(NCEL.GT.NCELM) THEN
      WRITE(NWRITE,881) NCEL,NCELM
  881 FORMAT(//,5X,'NCEL = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NCEL MAGGIORE DI NCELM '
      ELSE IF(NCELT.GT.NCELTM) THEN
      WRITE(NWRITE,781) NCELT,NCELTM
  781 FORMAT(//,5X,'NCELT = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NCELT MAGGIORE DI NCELTM '
      ELSE IF(NKIN.GT.NKINM) THEN
      WRITE(NWRITE,782) NKIN,NKINM
  782 FORMAT(//,5X,'NKIN = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NKIN MAGGIORE DI NKINM '
      ELSE IF(NUZO.GT.NUZOM) THEN
      WRITE(NWRITE,882) NUZO,NUZOM
  882 FORMAT(//,5X,'NUZO = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NUZO MAGGIORE DI NUZOM '
      ELSE IF(NRIT.GT.NRITM) THEN
      WRITE(NWRITE,883) NRIT,NRITM
  883 FORMAT(//,5X,'NRIT = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NRIT MAGGIORE DI NRITM '
      ELSE IF(NPD.GT.NPDM) THEN
      WRITE(NWRITE,884) NPD,NPDM
  884 FORMAT(//,5X,'NPD = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NPD MAGGIORE DI NPDM '                  
      ELSE IF(NG.GT.NGM) THEN
      WRITE(NWRITE,885) NG,NGM
  885 FORMAT(//,5X,'NG = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NG MAGGIORE DI NGM '                    
      ELSE IF(NS.GT.NSM) THEN
      WRITE(NWRITE,886) NS,NSM
  886 FORMAT(//,5X,'NS = ',I4,' MAGGIORE DI ',I4,/)                     
      STOP  ' ERRORE DI INPUT : NS MAGGIORE DI NSM '
      ELSE IF(NSTRA.GT.NSTRAM) THEN                                     
      WRITE(NWRITE,887) NSTRA,NSTRAM
  887 FORMAT(//,5X,'NSTRA = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NSTRA MAGGIORE DI NSTRAM '              
      ELSE IF(NNX.GT.NNXM) THEN
      WRITE(NWRITE,888) NNX,NNXM
  888 FORMAT(//,5X,'NNX = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NNX MAGGIORE DI NNXM '                  
      ELSE IF(NNY.GT.NNYM) THEN
      WRITE(NWRITE,889) NNY,NNYM
  889 FORMAT(//,5X,'NNY = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NNY MAGGIORE DI NNYM '                  
      ELSE IF(NLIB.GT.NLIBM) THEN
      WRITE(NWRITE,890) NLIB,NLIBM
  890 FORMAT(//,5X,'NLIB = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NLIB MAGGIORE DI NLIBM '                
      ELSE IF(NPROF.GT.NPROFM) THEN
      WRITE(NWRITE,981) NPROF,NPROFM
  981 FORMAT(//,5X,'NPROF = ',I4,' MAGGIORE DI ',I4,/)
      STOP  ' ERRORE DI INPUT : NPROF MAGGIORE DI NPROFM '              
      ENDIF
C
      IF(NPD.GE.2) GO TO 895                                            
      WRITE(NWRITE,896) NPD
  896 FORMAT(//,5X,'NPD = ',I4,' MINORE DI 2 (NUMERO MINIMO DI ',       
     &    'PRODOTTI DI FISSIONE RESPONSABILI DELLA POTENZA RESIDUA',/)
      STOP  ' ERRORE DI INPUT : NPD  MINORE DI  2 '
C                                                                       
  895 CONTINUE
C
      IF(NCOE.NE.6) THEN
      WRITE(NWRITE,898) NCOE
  898 FORMAT(//,5X,'NCOE = ',I4,' DIVERSO DA 6 (NUMERO DI COEFFICIENTI',
     &  ' PER IL CALCOLO DELLE COSTANTI NUCLEARI ATTUALMENTE IN USO',/)
      STOP ' NUMERO COEFF. CALCOLO COSTANTI NCOE .NE. 6 '
      ENDIF
C
      IF(NDTJM.GT.NITJM) THEN
      WRITE(NWRITE,897) NDTJM,NITJM
  897 FORMAT(//,5X,'NDTJM = ',I4,' MAGGIORE DI NITJM = ',I4,/,5X,
     & 'IL PROGRAMMA PROSEGUE PONENDO AUTOMATICAMENTE NDTJM=NITJM',/)
      NDTJM=NITJM
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE ALLOCA
C-----------------------------------------------------------------------
C     EFFETUA L'ALLOCAZIONE DINAMICA DELLE PRINCIPALI GRANDEZZE DEL CODI
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
      INTEGER CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,H,RO,CSP,GIN,GINV,PHS,
     1        HAKF,EFB,WESTS,RES,XE,VIO,SM,PM,PROFTM,PROFRM,CALFA,
     2        PHI,ROV,FCN,ALBA,BQ,PH,EEF,PHV,ENF,BE,AL,C,SG,CBETA,
     3        HEL,AKF,CM,ALM,BEM,DEN,BQ1,BQV,BQV1,BQP,C2BQ,CALFA1,
     4        D,HBE,PHSV,PHP,C2,NBAR,ALBAS,WEST,PHT,CBETA1,TCNOS,
     5        DBE,BEMI,HBEV,TIMP,AZ,BZ,ENFV,CV,ZDG,TN,SER,PHJ1,
     6        PROFLU,HBEK,TIMPT,ENFVV,CVV,TEMV,DV,ALMV,RONOS,
     7        CMV,SERFI,SERFIV,HRO ,HTEM,WMED,WESTD,WESTV,CORD,
     8        WTILD,ATILD,WTRA,TREF,ALBASN,ALBASV,PHV1,ZW,SIGXE,
     9        RECOBA,PALBA,PRPR,EEFR,CLTH,HALBA,HBORO,AKFCEL,GISF,      
     &        FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     &        VELOC,BINSTE,PROFF,PROFP,BEJ,ALJ,COEXE1,DSGXE,XEV,
     &        VIOV,SIGXEL,GISFL,PROFTC,TMNOS,PROFXE,XENOS
C
      COMMON/NEUT1$/S(KAXS),DUMMI30(MAXSM-KAXS)
      COMMON/INPAR$/NC1M,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,NNXM,NNYM,
     &              NTTJM,NITJM,NLIBM,NPROFM,NKINM,NCELM,MAXS,KDIM,NCM
      COMMON/INTER$/NCEL,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     &              NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
C
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/INDIR$/PHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     &              TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,
     &              WESTV,WESTD,WESTS,H,RO,CSP,GIN,WTRA,DUMMI0(NW-31)
      COMMON/INDR1$/ALT,BEM,AL,WW,XE,VIO,PM,SM,HEL,PHT,WGAMC,WTILD,
     &              ATILD,GINV,XEV,VIOV,TREF,ALBAS,WMED,CORD,NBAR,
     &              HALBA,HBORO,ALBA
     &              ,DUMMI1(NW-24)
      COMMON/INDR2$/QCEL,CEFI,TEM,ALBASN,ALBASV,SERFI,HRO,EFB,RES,HTEM,
     &              TIMPT,PHI,ROV,FCN,BQ,PH,EEF,PHV,ENF,BE,C,SG,AKF,CM,
     &              ALM,DEN,WEST,DBE,BEMI,TIMP,AZ,BZ,ZDG,TN,SER,PHJ1,
     &              NBARRE,NBARN,PHV1,ZW,RECOBA,PALBA,PRPR,EEFR,CLTH
     &              ,DUMMI2(NW-45)
      COMMON/INDR3$/PROFLU,CL,DUMMI3(NW-2)
      COMMON/INDR5$/FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     &              VELOC,BINSTE,PROFF,PROFP,ILIB1,ILIB2,AKFCEL,BEJ,
     &              ALJ,COEXE1,DSGXE,PROFTM,PROFRM,TCNOS,RONOS,CALFA,
     &              CBETA,CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,PROFTC,
     &              TMNOS,XENOS,PROFXE,DUMMI4(NW-35)
C-----------------------------------------------------------------------
      PROFLU=1
      C2=PROFLU+NCM
      CL=C2+NCM
      ALT=CL+NCM
      CLTH=ALT+NCM
      WW=CLTH+NCM
      QCEL=WW+NCM
      WGAMC=QCEL+NCM
      CEFI=WGAMC+NCM
      TEMV=CEFI+NCM
      TEM=TEMV+NCM
      EFB=TEM+NCM
      RES=EFB+NGM*NUZOM
      FCNZ=RES+NCM                                                      
      FCN=FCNZ+NCM
      ALBA=FCN+NCM*NUZOM                                                
      BQ=ALBA+NGM
      BQV=BQ+NCM                                                        
      PH=BQV+NCM
      EEF=PH+NCM                                                        
      PHV=EEF+NCM
      PHI=PHV+NCM                                                       
      ENF=PHI+NCM
      ENFV=ENF+NCM
      ENFVV=ENFV+NCM
      BE=ENFVV+NCM
      AL=BE+NRITM*NCM
      C=AL+NRITM*NCM                                                    
      CV=C+NRITM*NCM
      CVV=CV+NRITM*NCM                                                  
      SG=CVV+NRITM*NCM
      AKF=SG+NCM                                                        
      CM=AKF+NCM
      CMV=CM+NRITM                                                      
      ALM=CMV+NRITM
      ALMV=ALM+NRITM                                                    
      BEM=ALMV+NRITM
      D=BEM+NRITM                                                       
      DV=D+NCM
      HBE=DV+NCM                                                        
      PHSV=HBE+NRITM
      PHS=PHSV+NCM                                                      
      PHP=PHS+NCM
      NBAR=PHP+NCM
      NBARRE=NBAR+NGM
      NBARN=NBARRE+NGM
      HBEV=NBARN+NGM
      HBEK=HBEV+NRITM                                                   
      MAXV1=HBEK+NRITM
      IF(MAXV1.GT.MAXS) GO TO 2                                         
      GO TO 3
    2 WRITE(NWRITE,100)MAXV1,MAXS                                       
  100 FORMAT(1X,'MAXV1=',I6,3X,'MAXS=',I6)
      STOP ' MAXV1 MAGGIRE DI MAXS (SUBROUTINE ALLOCA) '                
    3 CONTINUE
      ALBAS=MAXV1                                                       
      ALBASN=ALBAS+NGM
      ALBASV=ALBASN+NGM                                                 
      RECOBA=ALBASV+NGM
      PALBA=RECOBA+NGM                                                  
      ZW=PALBA+NGM
      WEST=ZW+NCM                                                       
      PHT=WEST+NCM
      DBE=PHT+NCM                                                       
      BEMI=DBE+NRITM
      TIMP=BEMI+NRITM                                                   
      TIMPT=TIMP+NTTJM
      AZ=TIMPT+NTTJM                                                    
      BZ=AZ+NRITM
      PHJ1=BZ+NRITM                                                     
      ZDG=PHJ1+NCM
      DEN=ZDG+NCM
      TN=DEN+NCM                                                        
      SER=TN+NCM
      SERFI=SER+NCM
      SERFIV=SERFI+NCM
      PHV1=SERFIV+NCM                                                   
      BQ1=PHV1+NCM
      BQV1=BQ1+NCM
      BQP=BQV1+NCM
      C2BQ=BQP+NCM
      HRO=C2BQ+NCM
      HTEM=HRO+NCM*NITJM
      HALBA=HTEM+NCM*NITJM
      HBORO=HALBA+NGM*NITJM
      HAKF=HBORO+NITJM
      CORD=HAKF+NCM
      WMED=CORD+NPDM
      WESTV=WMED+NCM
      WESTS=WESTV+NCM
      WESTD=WESTS+NCM
      H=WESTD+NCM*NPDM
      RO=H+NCM
      ROV=RO+NCM
      CSP=ROV+NCM
      GIN=CSP+NCM
      WTILD=GIN+NCM
      ATILD=WTILD+NCM
      WTRA=ATILD+NCM
      GINV=WTRA+NCM
      TREF=GINV+NCM
      HEL=TREF+NCM
      PRPR=HEL+NUZOM
      EEFR=PRPR+NUZOM
      XE=EEFR+NUZOM
      VIO=XE+NCM
      SM=VIO+NCM
      PM=SM+NCM
      XEV=PM+NCM
      VIOV=XEV+NCM
      AKFCEL=VIOV+NCM
      ALJ=AKFCEL+NCM
      BEJ=ALJ+NRITM
      ILIB1=BEJ+NRITM
      ILIB2=ILIB1+NCM
      DSGXE=ILIB2+NCM
      COEXE1=DSGXE+NCM
      COES1=COEXE1+NLIBM*NCM*NCOE
      COED1=COES1+NLIBM*NCM*NCOE
      COENF1=COED1+NLIBM*NCM*NCOE
      COEKFT=COENF1+NLIBM*NCM*NCOE
      COEEF1=COEKFT+NLIBM*NCM*NCOE
      RLAM=COEEF1+NLIBM*NCM*NCOE
      RBETA=RLAM+NLIBM*NCM*NRITM
      VELOC=RBETA+NLIBM*NCM*NRITM
      BINSTE=VELOC+NLIBM
      PROFF=BINSTE+NPROFM*NGM
      PROFP=PROFF+NPROFM*NCM
      PROFTM=PROFP+NPROFM*NCM
      PROFRM=PROFTM+NPROFM*NCM
C<<<
      PROFXE=PROFRM+NPROFM*NCM
      PROFTC=PROFXE+NPROFM*NCM
      TMNOS=PROFTC+NPROFM*NCM
      RONOS=TMNOS+NCM
      XENOS=RONOS+NCM
C<<<
      TCNOS=XENOS+NCM
      CALFA=TCNOS+NCM
      CBETA=CALFA+NCM
      CALFA1=CBETA+NCM
      CBETA1=CALFA1+NCM
      SIGXE=CBETA1+NCM
      GISF=SIGXE+NCM
      SIGXEL=GISF+NCM
      GISFL=SIGXEL+NLIBM*NCM
      MAXV2=GISFL+NLIBM*NCM
C-----------------------------------------------------------------------
C      WRITE(NWRITE,*) 'MAXS CALCOLATO = ', MAXV2
      IF(MAXV2.GT.MAXS) GO TO 4
      GO TO 5
    4 WRITE(NWRITE,101) MAXV2,MAXS
  101 FORMAT(1X,'MAXV2=',I6,3X,'MAXS=',I6)
      STOP ' MAXV2 MAGGIORE DI MAXS (SUBROUTINE ALLOCA) '
    5 RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE SKEMA(ALATT,NCEL,NKIN,NCELT,NWRITE,ALT,CL,CLTH)
C-----------------------------------------------------------------------
C     GENERA LE CELLE ASSIALI NEUTRONICHE E TERMOIDRAULICHE SULLA BASE
C     DEL NUMERO 'NCELT' PREVISTO IN INPUT PER QUESTE ULTIME E DEL NUMER
C     'NKIN' DI SOTTOCELLE NEUTRONICHE ATTIVE IN CUI SI VUOLE SUDDIVIDER
C     CIASCUNA CELLA TERMOIDRAULICA AL FINE DEL SOLO CALCOLO NEUTRONICO.
C-----------------------------------------------------------------------
C
      DIMENSION ALT(*),CL(*),CLTH(*)
C
C     CALCOLO DELLA ALTEZZA COSTANTE DELLE 'NCELT' CELLE TERMOIDRAULICHE
      ALCE=ALATT/FLOAT(NCELT)
C     CALCOLO DELLA ALTEZZA COSTANTE DELLE 'NKIN' CELLE NEUTRONICHE IN
C     CUI CIASCUNA CELLA TERMOIDRAULICA COMPLETAMENTE ATTIVA VIENE
C     SUDDIVISA PER L'EFFETUAZIONE DEL CALCOLO NEUTRONICO               
      ALCEN=ALCE/FLOAT(NKIN)
C     GENERAZIONE DELLE 'NCELT' CELLE TERMOIDRAULICHE DEL CANALE (IN CM)
      DO K=1,NCELT
        CLTH(K)=ALCE*100.
      END DO
C
C     GENERAZIONE DELLE 'NCEL' CELLE NEUTRONICHE ATTIVE DI ALTEZZA
C     COSTANTE PARI A 1/NKIN DI QUELLA DELLE CELLE TERMOIDRAULICHE
C
      DO J=1,NCEL
        CL(J)=ALCEN
      END DO
C
C     TEST SULLE CELLE NEUTRONICHE CHE COSTITUISCONO IL CANALE
C
      SOM=0.0
C
      DO J=1,NCEL
        SOM=SOM+CL(J)
      END DO
C
      IF(ABS(SOM-ALCE*NCELT).GT.1.E-03) STOP
     &  ' ERRORE NELLA GENERAZIONE DELLE CELLE ASSIALI IN "SKEMA" '
C
C     TRASFORMAZIONE DELLE ALTEZZE DELLE CELLE NEUTRONICHE ASSIALI DA M
      DO J=1,NCEL
        ALT(J)=CL(J)*100.
      END DO
C
      WRITE(NWRITE,50) NCELT,NCEL,NKIN,ALATT
      WRITE(NWRITE,51) (ALT(I),I=1,NCEL)
      WRITE(NWRITE,52) (CLTH(I),I=1,NCELT)                              
   50 FORMAT(/,2X,'NCELT = ',I4,3X,'NCEL = ',I4,3X,
     &       'NKIN = ',I4,3X,'ALATT = ',G12.5)                          
   51 FORMAT(/,40X,'ALT(K),(K=1,NCEL)',//,8(2X,G12.5) )
   52 FORMAT(/,40X,'CLTH(K),(K=1,NCELT)',//,8(2X,G12.5) )               
C
      RETURN                                                            
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE NOSTR0(NRIT,VELOX,SIGFNU,EFIS,VNUM,ALM,BEM)
C-----------------------------------------------------------------------
C     LEGGE IL FILE GENERATO DAL CODICE DI INTERFACCIA 'NOSTRI'
C     NEL CASO DI CINETICA PUNTIFORME (0-D) :
C
C     - IL FILE CONTIENE I PARAMETRI TIPICI DELLA CINETICA ZERODIMENSION
C       (OTTENUTI MEDIANTE OPPORTUNO COLLASSAMENTO DELLE GRANDEZZE ASSIA
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      DIMENSION ALM(*),BEM(*)
C
  101 FORMAT(6E12.5)
  100 FORMAT(I4)
C-----------------------------------------------------------------------
      REWIND IRLIB3
      READ(IRLIB3,101) VELOX,SIGFNU,EFIS,VNUM
      READ(IRLIB3,101) (ALM(J),J=1,NRIT)
      READ(IRLIB3,101) (BEM(J),J=1,NRIT)
C-----------------------------------------------------------------------
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE NOSTR1(NLIBM,NPROFM,NCEL,NRIT,NG,COES1,COED1,COENF1,
     %           COEKFT,COEEF1,RLAM,RBETA,VELOC,BINSTE,PROFF,PROFP,NCM,
     %           COEXE1,NLIB,NPROF,NCOE,PROFTM,PROFRM,SIGXEL,GISFL,
     %           PROFTC,NCICLO,BURNUP,POTTOT,BORCRI,RINSER,BURM)
C-----------------------------------------------------------------------
C     LEGGE I FILES GENERATI DAL CODICE DI INTERFACCIA 'NOSTRI' NEL
C     CASO DI CINETICA ASSIALE (1-D) :
C
C     - IL PRIMO FILE CONTIENE PER OGNI CELLA ASSIALE I VALORI DEI
C       PARAMETRI CINETICI, DELLE COSTANTI NECESSARIE AL CALCOLO DEI
C       VELENI E DEI COEFFICIENTI DELLE CORRELAZIONI PER LE SEZIONI
C       D'URTO MACROSCOPICHE AD UN GRUPPO ENERGETICO RELATIVI ALLE
C       NLIB LIBRERIE CONSIDERATE (PER CIASCUNA DELLE PREVISTE
C       CONDIZIONI DI BRUCIAMENTO DEL NOCCIOLO)
C
C     - IL SECONDO FILE CONTIENE PER OGNUNO DEGLI NPROF CASI CONSIDERATI
C       GLI STEP DI ESTRAZIONE DEI BANCHI DI BARRE E I RELATIVI PROFILI
C       DI POTENZA E DI FLUSSO NORMALIZZATI SULL'ALTEZZA ATTIVA DEL CANA
C       PER OGNI STEP DI ESTRAZIONE SONO DATI PURE I PROFILI TERMOIDRAUL
C       DI TEMPERATURA DEL COMBUSTIBILE E DI DENSITA' DEL MODERATORE.
C       CIASCUN GRUPPO DI NPROF PROFILI ASSIALI E' RELATIVO AD UNA DATA
C       SITUAZIONE DEL NOCCIOLO :
C
C       - NCICLO  =   INDICE DEL CICLO DI FUNZIONAMENTO DEL REATTORE
C       - BURNUP  =   BRUCIAMENTO MEDIO DI REATTORE (IN %)
C       - POTTOT  =   POTENZA TOTALE DI FUNZIONAMENTO (IN %)
C       - BORCRI  =   CONCENTRAZIONE CRITICA DI BORO (IN PPM)
C       - RINSER(K) = ESTRAZIONE DEI K BANCHI DI BARRE (IN PASSI)
C
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/RIFLE$/SF(2),DF(2),ST(2),DT(2),RRIF(2),DUMMI34(NW-2*5)
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION COES1(NLIBM,NCM,*),PROFP(NPROFM,*),COEXE1(NLIBM,NCM,*),
     &          COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),RINSER(*),
     %          COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),
     &          RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),GISFL(NLIBM,*),
     &          VELOC(NLIBM),BINSTE(NPROFM,*),PROFF(NPROFM,*),
     %          PROFTM(NPROFM,*),PROFRM(NPROFM,*),SIGXEL(NLIBM,*),
     $          PROFTC(NPROFM,*)
C
  101 FORMAT(6E12.5)
  100 FORMAT(I4)
      REWIND IRLIB1
C-----------------------------------------------------------------------
      NBURNL=0
      READ(IRLIB1,100) NBRUM
  601 READ(IRLIB1,101,END=701) CICLIB,BRULIB
      READ(IRLIB1,100) NLIB
      IF(NLIB.GT.NLIBM) STOP ' ***  NLIB .GT. NLIBM  *** '
      READ(IRLIB1,101) SF(1),DF(1),ST(1),DT(1)
      READ(IRLIB1,101) SF(2),DF(2),ST(2),DT(2)
      NCICLB=IFIX(CICLIB)
      NBURNL=NBURNL+1
      IF(NBURNL.GT.NBRUM) STOP ' ***  NBURNL .GT. NBRUM  *** '
      DO 10 NL=1,NLIB
      READ(IRLIB1,101) VELOC(NL)
      DO 20 KZ=1,NCEL
      READ(IRLIB1,101) (RLAM(NL,KZ,IR),IR=1,NRIT),
     &                 (RBETA(NL,KZ,IR),IR=1,NRIT)
   20 CONTINUE
      READ(IRLIB1,101) (SIGXEL(NL,KZ),KZ=1,NCEL)
      READ(IRLIB1,101) (GISFL(NL,KZ),KZ=1,NCEL)
      DO 50 KZ=1,NCEL
      READ(IRLIB1,101) (COES1(NL,KZ,IC),IC=1,NCOE)
      READ(IRLIB1,101) (COED1(NL,KZ,IC),IC=1,NCOE)
      READ(IRLIB1,101) (COENF1(NL,KZ,IC),IC=1,NCOE)
      READ(IRLIB1,101) (COEKFT(NL,KZ,IC),IC=1,NCOE)
      READ(IRLIB1,101) (COEEF1(NL,KZ,IC),IC=1,NCOE)
      READ(IRLIB1,101) (COEXE1(NL,KZ,IC),IC=1,NCOE)
   50 CONTINUE
   10 CONTINUE
C     VERIFICA DELLA CORRETTEZZA DELLE LIBRERIE LETTE RISPETTO AL
C     BRUCIAMENTO BURM FISSATO IN INPUT DALL'UTENTE
      IF(ABS(BURM-BRULIB).LE.1.) GO TO 501
      GO TO 601
  701 WRITE(NWRITE,47) NBURNL
   47 FORMAT(/,' FINE DEI VALORI DI BURNUP PER CUI SONO DISPONIBILI',
     &         ' LE LIBRERIE NUCLEARI ',/,
     &       1X,'NUMERO DI VALORI DI BRUCIAMENTO DISPONIBILI = ',I2,/)
      BURNUP=BRULIB
      RETURN
  501 CONTINUE
C-----------------------------------------------------------------------
C     DETERMINAZIONE DEL NUMERO DI RECORD PRESENTI SUL FILE DEI PROFILI
      REWIND IRLIB2
      NUREC2=0
  800 READ(IRLIB2,101,END=900)
      NUREC2=NUREC2+1
      GO TO 800
  900 CONTINUE
      REWIND IRLIB2
      NBURN=0
      READ(IRLIB2,100) NBURNM
      IF(NBURNM.NE.NBRUM) STOP ' ***  NBURNM .NE. NBRUM  *** '
C     LETTURA PROFILI RELATIVI AL BRUCIAMENTO 'BURNUP' NBURN-ESIMO
  600 READ(IRLIB2,101,END=700) CICLO,BURNUP,POTTOT,BORCRI
      NCICLO=IFIX(CICLO)
      NBURN=NBURN+1
      IF(NBURN.GT.NBURNM) STOP ' ***  NBURN .GT. NBURNM  **** '
      READ(IRLIB2,101) (RINSER(K),K=1,NG)
      READ(IRLIB2,100) NPROF
      IF(NPROF.GT.NPROFM) STOP ' ***  NPROF .GT. NPROFM  *** '
      DO 30 NP=1,NPROF
      READ(IRLIB2,101) (BINSTE(NP,KB),KB=1,NG)
      READ(IRLIB2,101) (PROFP(NP,NZ),NZ=1,NCEL)
      READ(IRLIB2,101) (PROFF(NP,NZ),NZ=1,NCEL)
      READ(IRLIB2,101) (PROFTC(NP,NZ),NZ=1,NCEL)
      READ(IRLIB2,101) (PROFRM(NP,NZ),NZ=1,NCEL)
   30 CONTINUE
C     VERIFICA DELLA CORRETTEZZA DEI PROFILI LETTI RISPETTO AL BRUCIAMEN
C     BURM FISSATO IN INPUT DALL'UTENTE
      IF(ABS(BURM-BURNUP).LE.1.) GO TO 500
      GO TO 600
  500 CONTINUE
C     CALCOLO DEL NUMERO DI RECORD PREVISTI DA "NOSTRI" SUL FILE DEI PRO
      ANG6=NG/6
      NG6=IFIX(ANG6)
      IF(ABS(ANG6-NG6).GT.1.E-05) NG6=NG6+1
      ANCEL6=NCEL/6
      NCEL6=IFIX(ANCEL6)
      IF(ABS(ANCEL6-NCEL6).GT.1.E-05) NCEL6=NCEL6+1
      NURECC= 1 + NBURNM*(1+NG6+1+NPROF*(NG6+4*NCEL6))
C     TEST SUI NUMERI DI RECORD LETTI E PREVISTI
      IF(NUREC2.GT.NURECC) THEN
      WRITE(NWRITE,66) NUREC2,NURECC
   66 FORMAT(1X,'ATTENZIONE ! NUMERO DI RECORD LETTI SUL FILE DEI ',
     &       'PROFILI MAGGIORE DI QUELLO PREVISTO DA "NOSTRI"',/,1X,
     &       'PROBABILMENTE SONO GIA'' STATI ACCODATI ALTRI DATI IN',
     &       ' FONDO AL FILE',/,1X,'NUMERO DI RECORD LETTI =',I6,/,
     &       1X,'NUMERO DI RECORD PREVISTI (DA "NOSTRI") =',I6,/,
     &       1X,'IL PROGRAMMA PROSEGUE PONENDO IL NUMERO DI RECORD',
     &       ' LETTI UGUALE A QUELLO PREVISTO ',/,1X,'IN MODO CHE ',
     &       'EVENTUALI NUOVI DATI SIANO ACCODATI SEMPRE A PARTIRE ',
     &       /,1X,'DALLA FINE DEI RECORD PREVISTI DA "NOSTRI"',/)
      NUREC2=NURECC
      ELSE IF(NUREC2.LT.NURECC) THEN
      WRITE(NWRITE,68) NUREC2,NURECC
   68 FORMAT(1X,'ATTENZIONE ! NUMERO DI RECORD LETTI SUL FILE DEI ',
     &       'PROFILI MINORE DI QUELLO PREVISTO DA "NOSTRI"',/,1X,
     &       'NUMERO DI RECORD LETTI =',I6,/,1X,
     &       'NUMERO DI RECORD PREVISTI (DA "NOSTRI") =',I6,/,1X,
     &       'IL PROGRAMMA SI BLOCCA',/)
      STOP ' NUMERO RECORD LETTI MINORE NUMERO RECORD PREVISTI '
      ENDIF
      IF(ABS(BURNUP-BRULIB).LE.1.E-05.AND.NCICLO.EQ.NCICLB
     &   .AND.NBURN.EQ.NBURNL) THEN
      WRITE(NWRITE,46) NBURN,BURNUP
   46 FORMAT(/,1X,'LIBRERIE NUCLEARI E PROFILI ASSIALI PRESCELTI ',
     &       'RELATIVI AL BRUCIAMENTO N.',I2,'  (BURNUP = ',F5.1,')',/)
      RETURN
      ELSE
      WRITE(NWRITE,48) NCICLO,NBURN,BURNUP,NCICLB,NBURNL,BRULIB
   48 FORMAT(/,1X,'ATTENZIONE ! LE LIBRERIE E I PROFILI SONO RELATIVI',
     &       ' A CICLI O A BRUCIAMENTI DIVERSI (O SONO ORDINATI ',
     &       'SCORRETTAMENTE)',/,1X,'PROFILI ASSIALI',
     &       ' : CICLO N.',I2,3X,'BRUCIAMENTO N.',I2,' =',F5.1,/,1X,
     &       'LIBRERIE NUCLEARI : CICLO N.',I2,3X,'BRUCIAMENTO N.',I2,
     &       ' =',F5.1,/,1X,'IL PROGRAMMA SI BLOCCA')
      STOP ' LIBRERIE E PROFILI RELATIVI A CICLI O BRUCIAMENTI DIVERSI'
      ENDIF
  700 CONTINUE
      WRITE(NWRITE,45) NBURN
   45 FORMAT(/,' FINE DEI VALORI DI BURNUP PER CUI SONO DISPONIBILI',
     &         ' I PROFILI ASSIALI',/,
     &       1X,'NUMERO DI VALORI DI BRUCIAMENTO DISPONIBILI = ',I2,/)
C-----------------------------------------------------------------------
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE TABLEKINA
C
C      VERSION ADAPTEE A KINA /LECTURE BETAI,LANDAI,VITESSES
C      A LA SUITE DES AUTRES DONNEES
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      CHARACTER*8 TEXT
      CHARACTER*4 TIT10(18),TITRE(18)
C
      DIMENSION D0(50,30),XIRN(30),ALAMDA(6,30),ABETA(6,30),VELOX(2,30)
C
      COMMON/APPEL/NENR(60)
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
      COMMON/CGRILL/DSGRI(60,3)
      COMMON/CLAPLA/NBUL,BUCL(50),B2R1(50),B2R2(50),COEFB1,COEFB2
      COMMON/DBARRE/NBU,BUC(50),DSAGB1(15,50),ALF2,ALFR,ALFF1,ALFF2
      COMMON/LIM/IM1,JM1,KM1
      COMMON/REFLEC/NREFL,IREFL(10)
      COMMON/RIDCOM/AFLOT,NFIXE,ITYP,IERR
      COMMON/RIDCOT/TEXT
      COMMON/TABLKINA/KE(60),IE(60),D(30,66,60),DREF(6,60),NACT(60)
      COMMON/ZREF/IINF,ISUP,L1,PL1
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/CSERVE/BIDO,SAXE1,SAXE2
C
      NREFL=0
C
      DO K=1,60
        IE(K)=0
        KE(K)=0
        NACT(K)=264
        DO J=1,6
          DREF(J,K)=0.
        END DO
      END DO
C
      DO I=1,30
        DO J=1,66
          DO K=1,60
            D(I,J,K)=0.
          END DO
        END DO
      END DO
C
C     LECTURE DE LA BIBLIOTHEQUE GENELIB
C
      REWIND IRLIB1
      READ(IRLIB1,1000) (TITRE(I),I=1,18),IDATE
      READ(IRLIB1,'(F5.1)') BIDO
      READ(IRLIB1,2000) PRLIB,TMLIB,TCREF
      READ(IRLIB1,3000) NBUL,(BUCL(N),B2R1(N),B2R2(N),N=1,NBUL)
      READ(IRLIB1,4000) COEFB1,COEFB2
      READ(IRLIB1,5000) NBU,(BUC(I),I=1,5)
      READ(IRLIB1,6000) ((DSAGB1(J,I),J=1,15),I=1,NBU)
      READ(IRLIB1,6000) ALF2,ALFR,ALFF1,ALFF2
C
      DO K=1,60
        DREF(1,K)=TCREF
        DREF(2,K)=TMLIB
      END DO
C
      DO 8  K=1,KM1
      READ(IRLIB1,8000) LL,NIR,(XIRN(M),D0(1,1),D0(2,1),
     &(D0(I,M),I=3,50),M=1,NIR),BID1,BID2,BID3
      NENR(K)=LL
      KE(K)=1
      IE(K)=NIR
      DSGRI(LL,1)=BID1
      DSGRI(LL,3)=BID2
      DSGRI(LL,2)=BID3
      DREF(3,K)=D0(2,1)
      DREF(4,K)=D0(1,1)
      DREF(5,K)=D0(24,1)
      IF(K.LT.IINF.OR.K.GT.ISUP) THEN
           NREFL=NREFL+1
           IREFL(NREFL)=K
           D(1,15,K)=XIRN(1)
           D(1,1,K)=D0(3,1)
           D(1,3,K)=D0(4,1)
           D(1,4,K)=D0(5,1)
           D(1,7,K)=D0(6,1)
           D(1,9,K)=D0(7,1)
           D(1,37,K)=D0(8,1)
           D(1,38,K)=D0(9,1)
           GOTO 8
           ENDIF
      DO 9 J=1,NIR
      D(J,15,K)=XIRN(J)
      D(J,30,K)=D0(19,J)
      D(J,31,K)=D0(20,J)
      DO 10 I=1,5
      D(J,I+1,K)=D0(I+2,J)
10    CONTINUE
      D(J,1,K)=D(J,2,K)
      IF(D0(8,J).NE.0.) D(J,2,K)=D0(7,J)/D0(8,J)
C     D(J,3,K)=D(J,3,K)+D0(24,J)*D0(14,J)
      D(J,8,K)=D0(9,J)
      D(J,7,K)=D(J,8,K)
      IF(D0(13,J).NE.0.) D(J,8,K)=D0(12,J)/D0(13,J)
      D(J,9,K)=D0(10,J)
C     D(J,9,K)=D(J,9,K)+D0(24,J)*D0(15,J)+D0(25,J)*D0(17,J)
      D(J,11,K)=D0(11,J)
      D(J,12,K)=D0(12,J)
      D(J,59,K)=D0(17,J)
      IF (K.EQ.IINF) SAXE1=D0(16,1)*1.E-24
C     13 ET 14 SONT LES SECTIONS MICRO DU DETECTEUR
      D(J,13,K)=D0(21,J)
      D(J,14,K)=D0(22,J)
      D(J,6,K)=D0(7,J)
      D(J,12,K)=D0(12,J)                                                
      D(J,32,K)=D0(23,J)
      D(J,33,K)=D0(25,J)                                                
      D(J,34,K)=D0(26,J)
      D(J,35,K)=D0(27,J)                                                
      D(J,36,K)=D0(28,J)
      DO 11 I=1,22
      D(J,I+36,K)=D0(28+I,J)
11    CONTINUE
9     CONTINUE
8     CONTINUE
C       LECTURE POUR CHAQUE TRANCHE AXIALE ET CHAQUE EPUISEMENT
C       DES PARAMETRES CINETIQUES (NEUTRONS RETARDES)
      DO 88 K=1,KM1
      IF (K.GE.IINF.AND.K.LE.ISUP) THEN
      READ(IRLIB1,9000) LL,NIR,(XIRN(M),(ALAMDA(I,M),I=1,6),
     1(ABETA(I,M),I=1,6),(VELOX(I,M),I=1,2),M=1,NIR)
       DO 75 J=1,NIR
       DO 21 I=1,6
       D(J,I+17,K)=ALAMDA(I,J)
       D(J,I+23,K)=ABETA(I,J)
   21  CONTINUE
       D(J,16,K)=VELOX(1,J)
       D(J,17,K)=VELOX(2,J)
   75  CONTINUE
       ENDIF
   88  CONTINUE
C
 1000 FORMAT(18A4,/,I8)
 2000 FORMAT(3X,2F10.2,5X,1P,E13.5)
 3000 FORMAT(3X,I4,(/,8X,F8.0,2E13.5))
 4000 FORMAT(/,3X,1P,2E13.5)
 5000 FORMAT(/,3X,I4,(5F8.0))
 6000 FORMAT(/,(1P,5E13.5))
 7000 FORMAT(/,(1P,4E13.5))
 8000 FORMAT(/,3X,2I4,/,(3X,1P,E13.5,/,11(1P,5E13.5,/)/))
 9000 FORMAT(2I4,/,(E12.5,/,2(6E12.5,/),2E12.5))
C
C    IMPRESSION DE LA MATRICE D
C
      WRITE(NWRITE,*) ' MATRICE DSEP'
      WRITE(NWRITE,9001)((D(1,I,K),I=1,66),K=1,KM1)
 9001 FORMAT(6(1X,E12.5))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PLIBEL(NPROFM,NCEL,NG,NPROF,NCM,NCELRF,
     %          BINSTE,PROFF,PROFP,
     %          PROFTM,PROFRM,CL,PROFXE,PROFTC,BURNUP,
     %          POTTOT,BORCRI,AKEFFL,RINSER,ROR1,ROR2,BURM,BUMCOR)
C-----------------------------------------------------------------------
C     LIT LES FICHIERS DE PROFILES AXIAUX GENERES PAR LIBELLULE
C     DANS LE CAS DE CINETIQUE AXIALE:
C
C     - LECTURE DES PARAMETRES GENERAUX DU CAS TRAITE
C       (B.U. PUISSANCE,BORE CRIT,K-EFF LIBELLULE,EXTACTION DES BARRES)
C
C     - POUR CHACUN DES NPROF CAS CONSIDERE:
C          EXTRACTION DES BARRES
C          PROFIL AXIAL DE PUISSANCE
C          PROFIL DE FLUX RAPIDE
C          PROFIL DE FLUX THERMIQUE
C          PROFIL DE TEMPERATURE COMBUSTIBLE
C          PROFIL DE DENSITE MODERATEUR
C          PROFIL DE TEMPERATURE MODERATEUR
C          PROFIL DE CONCENTRATION XENON                                
C
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/FLUX2G/FLUX1(20,60),FLUX2(20,60),BULAX(60)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      DIMENSION PROFP(NPROFM,*),CL(*),ROR1(*),ROR2(*),
     &          BINSTE(NPROFM,*),PROFF(NPROFM,*),
     %          PROFTM(NPROFM,*),PROFRM(NPROFM,*),
     %          PROFTC(NPROFM,*),RINSER(*),PROFXE(NPROFM,*)
C
  100 FORMAT(I4)
C-----------------------------------------------------------------------
C    DETERMINATION DU NOMBRE DE RECORD SUR LE FICHER DES PROFILS AXIAUX
      REWIND IRLIB2
      NUREC2=0
  800 READ(IRLIB2,101,END=900)
      NUREC2=NUREC2+1
      GO TO 800
  900 CONTINUE
C
      REWIND IRLIB2
      BURLIB=BURM
      READ(IRLIB2,101) BURNUP,POTTOT,BORCRI,AKEFFL
      READ(IRLIB2,101) (RINSER(K),K=1,NG)
C      IF(ABS(BURLIB-BURNUP).GT.1.) THEN
C      WRITE(NWRITE,81)BURLIB,BURNUP
C   81 FORMAT(//,' ATENTION BURN UP BIBL. DIFFERENT DU BURN UP PROF.
C     & AXIALE',/,1X,'BURN UP LIBRAIRIE=',F6.1,/,1X,'BURN UP PROF.AX.='
C     & ,F6.1,/,1X,'LE CODE ARRETE SON EXECUTION')
C      STOP'B.U. LIB. DIFFERENT B.U. PROF.AX.'
C      ENDIF
      READ(IRLIB2,100) NPROF
      IF(NPROF.GT.NPROFM) STOP ' ***  NPROF .GT. NPROFM  *** '          
      IF(NCELRF.NE.2) STOP'NOMBRE DE TRANCHES REFL DIFFERENT DE DEUX'
C     REMARQUE LES VARIABLES A ET B SERVENT A MASQUER LES VALEURS
C     CORRESPONDANT AUX REFLECTEURS                                     
  101 FORMAT(6E12.5)
  102 FORMAT(E12.5,5E12.5,/,3(6E12.5,/),E12.5,E12.5)
      DO 30 NP=1,NPROF                                                  
      READ(IRLIB2,101) (BINSTE(NP,KB),KB=1,NG)
      READ(IRLIB2,102) A,(PROFP(NP,NZ),NZ=1,NCEL),B
      READ(IRLIB2,102) FLUX1(NP,59),(FLUX1(NP,NZ),NZ=1,NCEL),
     &                 FLUX1(NP,60)                                     
      READ(IRLIB2,102) FLUX2(NP,59),(FLUX2(NP,NZ),NZ=1,NCEL),
     &                 FLUX2(NP,60)                                     
      READ(IRLIB2,102) A,(PROFTC(NP,NZ),NZ=1,NCEL),B
      READ(IRLIB2,102) ROR1(NP),(PROFRM(NP,NZ),NZ=1,NCEL),ROR2(NP)
      READ(IRLIB2,102) A,(PROFTM(NP,NZ),NZ=1,NCEL),B                    
      READ(IRLIB2,102) A,(PROFXE(NP,NZ),NZ=1,NCEL),B
      ROR1(NP)=ROR1(NP)*1000.                                           
      DO 54 NZ=1,NCEL
      PROFRM(NP,NZ)=PROFRM(NP,NZ)*1000.                                 
   54 PROFXE(NP,NZ)=PROFXE(NP,NZ)*1.E+24
      ROR2(NP)=ROR2(NP)*1000.
C  FLUX COLLAPSE A 1 GROUPE D'ENERGIE
      DO 31 K=1,NCEL
   31 PROFF(NP,K)=FLUX1(NP,K)+FLUX2(NP,K)
   30 CONTINUE
C---- LETTURA DEL PROFILO ASSIALE DI BRUCIAMENTO LIBELLULE
      READ(IRLIB2,102) (BULAX(K),K=1,NCEL+2)
C     VALUTAZIONE DEL BURN-UP MEDIO DI NOCCIOLO
      BUMCOR=0.
      DO 86 K=2,NCEL+1
   86 BUMCOR=BUMCOR+BULAX(K)
      BUMCOR=BUMCOR/FLOAT(NCEL)
      IF(ABS(BURM-BUMCOR).GT.10.) THEN
      WRITE(NWRITE,67) BURM,BUMCOR
   67 FORMAT(/,1X,'ATTENZIONE ! IL BURN-UP MEDIO DEL PROFILO LIBELLULE',
     &       ' E'' DIVERSO DA QUELLO DI INPUT',/,1X,'IL PROGRAMMA ',
     &       'PROSEGUE UTILIZZANDO IL BURN-UP MEDIO DI LIBELLULE',/,
     &       1X,'BURN-UP MEDIO DI INPUT  = ',F8.1,'  (MWD/T)',/,
     &       1X,'BURN-UP MEDIO LIBELLULE = ',F8.1,'  (MWD/T)',/)
      ENDIF
C-----------------------------------------------------------------------
C     CALCOLO NUMERO DI RECORD PREVISTI DA "LIBELLULE" SUL FILE PROFILI
      NBURNM=1
      NNG=NG
      IF(NNG.LT.6) NNG=NG+1
      ANG6=NNG/6
      NG6=IFIX(ANG6)
      IF(ABS(ANG6-NG6).GT.1.E-05) NG6=NG6+1
      ANCEL6=NCEL/6
      NCEL6=IFIX(ANCEL6)
      IF(ABS(ANCEL6-NCEL6).GT.1.E-05) NCEL6=NCEL6+1
      NURECC=   NBURNM*(1+NG6+1+NPROF*(NG6+7*(NCEL6+1)))
C---- AGGIUNTA DEL BRUCIAMENTO ASSIALE LIBELLULE
      NURECC=NURECC + NCEL6 + 1
C     TEST SUI NUMERI DI RECORD LETTI E PREVISTI
      IF(NUREC2.GT.NURECC) THEN
      WRITE(NWRITE,66) NUREC2,NURECC
   66 FORMAT(//,1X,120('*'),//,
     &      ' ATTENZIONE ! NUMERO DI RECORD LETTI SUL FILE DEI ',
     &     'PROFILI MAGGIORE DI QUELLO PREVISTO DA "LIBELLULE"',/,1X,
     &       'PROBABILMENTE SONO GIA'' STATI ACCODATI ALTRI DATI IN',
     &       ' FONDO AL FILE',/,1X,'NUMERO DI RECORD LETTI =',I6,/,
     &       1X,'NUMERO DI RECORD PREVISTI (DA "LIBELLULE") =',I6,/,
     &       1X,'IL PROGRAMMA PROSEGUE PONENDO IL NUMERO DI RECORD',
     &       ' LETTI UGUALE A QUELLO PREVISTO ',/,1X,'IN MODO CHE ',
     &       'EVENTUALI NUOVI DATI SIANO ACCODATI SEMPRE A PARTIRE ',
     &       /,1X,'DALLA FINE DEI RECORD PREVISTI DA "LIBELLULE"',
     &        //,1X,120('*'),/)
      NUREC2=NURECC
      ELSE IF(NUREC2.LT.NURECC) THEN
      WRITE(NWRITE,68) NUREC2,NURECC
   68 FORMAT(1X,'ATTENZIONE ! NUMERO DI RECORD LETTI SUL FILE DEI ',
     &      'PROFILI MINORE DI QUELLO PREVISTO DA "LIBELLULE"',/,1X,
     &       'NUMERO DI RECORD LETTI =',I6,/,1X,
     &       'NUMERO DI RECORD PREVISTI (DA "LIBELLULE") =',I6,/,1X,
     &       'IL PROGRAMMA SI BLOCCA',/)
      STOP ' NUMERO RECORD LETTI MINORE NUMERO RECORD PREVISTI '
      ENDIF
C----------------------------------------------------------------------
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE EPUINT(BURM)
C-----------------------------------------------------------------------
C
C      INTERPOLLATIONS SUR L'EPUISEMENT LOCAL
C      A PARTIR DES PROFILS GENERES PAR LIBELLULE
C
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/CLAPLA/NBUL,BUCL(50),B2R1(50),B2R2(50),COEFB1,COEFB2
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/TABLKINA/KE(60),IE(60),DSEP(30,66,60),DREF(6,60),NACT(60)
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
C     &              ,CEFB1,CEFB2
      COMMON/DBARRE/NBU,BUC(50),DSAGB1(15,50),ALF2,ALFR,ALFF1,ALFF2
      COMMON/INTER$/NCEL,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/FLUX2G/FLUX1(20,60),FLUX2(20,60),BULAX(60)
      DIMENSION BUZ(60)
C
      IF(BURM.LE.0.1) THEN
C---- CASO A BRUCIAMENTO MEDIO NULLO E PROFILO ASSIALE NULLO (BOL)
      DO 10 K=1,NCEL+NCELRF
   10 BUZ(K)=BURM
      ELSE IF(BURM.GT.0.1) THEN
C---- CASO A BRUCIAMENTO MEDIO NON NULLO E PROFILO ASSIALE LIBELLULE
      DO 11 K=1,NCEL+NCELRF
   11 BUZ(K)=BULAX(K)
      ENDIF
      DO 50 K=1,NCEL+NCELRF
      J1=KE(K)
      J2=IE(K)
       IF(BUZ(K).LE.DSEP(J1,15,K)) THEN
        DO 20 I=1,66
   20   DDS(I,K)=DSEP(J1,I,K)
        GOTO 50
       ENDIF
       IF(BUZ(K).GE.DSEP(J2,15,K)) THEN
        DO 30 I=1,66
   30   DDS(I,K)=DSEP(J2,I,K)
        GOTO 50
       ENDIF
       DO 40 J=J1,J2
       IF(DSEP(J,15,K).GT.BUZ(K)) THEN
       JS=J                                                             
       JI=J-1
       DLBS=DSEP(JS,15,K)-BUZ(K)
       DLBI=BUZ(K)-DSEP(JI,15,K)
       DLB=DSEP(JS,15,K)-DSEP(JI,15,K)
       DO 35 I=1,66                                                     
   35  DDS(I,K)=(DSEP(JS,I,K)*DLBI+DSEP(JI,I,K)*DLBS)/DLB
       GO TO 50
       ENDIF                                                            
   40  CONTINUE
   50  CONTINUE                                                         
       WRITE(NWRITE,1001) BURM
 1001  FORMAT(/,20X,'MATRICE DDS (BURN-UP MOYEN =',F7.1,' MWD/T)',/)    
       WRITE(NWRITE,1000)((DDS(I,K),I=1,66),K=1,NCEL+NCELRF)
 1000  FORMAT(6(1X,G12.5))                                              
C   RECHERCHE DES TERMES CORRECTIFS REPRESENTANT LES SECTIONS EFFICECES
C   MACROSCOPIQUES DE CAPTURE (RAPIDE ET THERMIQUE) POUR CHAQUE         
C   CONFIGURATION DE GRAPPES EN FONCTION DU B.U. MOYEN DU COEUR
       IF (BURM.LE.BUC(1)) THEN
         DO 63 J=1,15
   63    DSIGB1(J)=DSAGB1(J,1)
        GOTO 100
       ENDIF
       IF (BURM.GE.BUC(NBU)) THEN
         DO 64 J=1,15
   64    DSIGB1(J)=DSAGB1(J,NBU)
        GO TO 100
       ENDIF
       DO 65 I=1,NBU
        IF(BUC(I).GT.BURM) THEN
        IS=I
        II=I-1
        DIS=BUC(IS)-BURM
        DII=BURM-BUC(II)
        DIT=BUC(IS)-BUC(II)
         DO 66 J=1,15
   66    DSIGB1(J)=(DSAGB1(J,IS)*DII+DSAGB1(J,II)*DIS)/DIT
        GOTO 100
        ENDIF
   65  CONTINUE
  100  CONTINUE
       WRITE(NWRITE,*) ' DSIGB1 =',DSIGB1
C   RECHERCHE DES LAPLACIENS RADIAUX RAPIDES ET THERMIQUES
C   EN FONCTION DU B.U. MOYEN DU COEUR
       IF(BURM.LE.BUCL(1)) THEN
        BQR1=B2R1(1)
        BQR2=B2R2(1)
        GO TO 999
       ENDIF
       IF(BURM.GE.BUCL(NBUL)) THEN
        BQR1=B2R1(NBUL)
        BQR2=B2R2(NBUL)                                                 
        GO TO 999
       ENDIF
       DO 61 I=1,NBUL                                                   
       IF(BUCL(I).GT.BURM) THEN
       IS=I
       II=I-1                                                           
       DIS=BUCL(IS)-BURM
       DII=BURM-BUCL(II)                                                
       DIT=BUCL(IS)-BUCL(II)
       BQR1=(B2R1(IS)*DII+B2R1(II)*DIS)/DIT                             
       BQR2=(B2R2(IS)*DII+B2R2(II)*DIS)/DIT
       GOTO 999
       ENDIF
   61  CONTINUE
  999  RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PROFIN(BINSER,NG,BINSTE,NPROF,NPROFM,PROFF,PROFP,
     &           RES,PH,PROFLU,D,NCEL,RIAL,RIBA,IREST,IRLIB4,IDKIN,
     &           LREGIM,BORVCT,ALATT,CANN,WW,WGAMC,WESTD,WESTS,ADEC,
     &           GDEC,CORD,CL,RGAM,TPAS,NPDM,NPD,WTOT,ROCEL,TCCEL,
     $           NCELT,NKIN,ALCAN,WCEL,WNEUT,CBORO,DINSER,RO,TEM,
     $           TCNOS,RONOS,PROFTM,PROFRM,TARAXO,AXOFF,PROFTC,TMNOS,
     $           TREF,ILEGO,PROFXE,XENOS,XE,ROR1,ROR2,FLU1V,FLU2T,ALT,
     $           PHR1,PHR2,RFIS21)
C-----------------------------------------------------------------------
C     INDIVIDUAZIONE DEL PROFILO DI PARTENZA OTTENUTO PER INTERPOLAZIONE
C     DEI DUE PROFILI BASE RELATIVI ALLE CONDIZIONI PIU' VICINE A QUELLE
C     OPERATIVE (RICERCA REGIME STAZIONARIO INIZIALE --> LREGIM=.TRUE.).
C     (LA REGIMAZIONE DEVE SEMPRE ESSERE EFFETUATA CON CINETICA ASSIALE)
C     VALUTAZIONE DELLE POTENZE TOTALI DI CELLA (UTILIZZATE NEL CALCOLO
C     'LEGO') RELATIVE A TALE  PROFILO DI TENTATIVO INIZIALE.
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON/FLUX2G/ FLUX1(20,60),FLUX2(20,60),BULAX(60)
      DIMENSION BINSER(*),BINSTE(NPROFM,*),PROFLU(*),PH(*),RES(*),
     %          D(*),PROFF(NPROFM,*),PROFP(NPROFM,*),WW(*),WGAMC(*),
     $          WESTD(NPDM,*),WESTS(*),CL(*), ADEC(NPDM,NPDM-1),
     &          GDEC(NPDM,NPDM-1),CORD(*),WCEL(*),ROCEL(*),PHR2(*),
     *          TCCEL(*),DINSER(*),RO(*),TEM(*),TCNOS(*),RONOS(*),
     &          PROFTM(NPROFM,*),PROFRM(NPROFM,*),PROFTC(NPROFM,*),
     &          TMNOS(*),TREF(*),PROFXE(NPROFM,*),XENOS(*),XE(*),
     &          ROR1(*),ROR2(*),FLU1V(60),FLU2T(60),ALT(*),PHR1(*),
     &          RFIS21(*)
C
      IF(IDKIN.EQ.0) GO TO 100
      IF(LREGIM) THEN
C     INTERPOLAZIONE DEI PROFILI CALCOLATI DA 'NOSTRI'
      BINS=0.
      DO 319 KB=1,NG
  319 BINS=BINS+BINSER(KB)
      DO 318 KP=1,NPROF
      BINST=0.
      DO 317 KB=1,NG
  317 BINST=BINST+BINSTE(KP,KB)
      DIFINS=BINS-BINST
      IF(DIFINS.LT.0.) GO TO 318
      INPRO=KP
      INPRO1=KP-1
      IF(INPRO1.EQ.0) INPRO1=1
      GO TO 339
  318 CONTINUE
  339 BINST=0.
      DO 329 KB=1,NG
  329 BINST=BINST+BINSTE(INPRO,KB)
      BINST1=0.
      DO 320 KB=1,NG
  320 BINST1=BINST1+BINSTE(INPRO1,KB)
      PESO=ABS(BINS-BINST1)
      PESO1=ABS(BINS-BINST)
      IF(INPRO.EQ.INPRO1) THEN
      PESO=1.
      PESO1=0.
      ENDIF
      DENOM=PESO+PESO1
      PESO=PESO/DENOM
      PESO1=PESO1/DENOM
      WRITE(NWRITE,*) ' PRIMO PROFILO BASE : N. =',INPRO1,
     &                '  (PESO 1 =',PESO1,')'
      WRITE(NWRITE,*) ' SECONDO PROFILO BASE : N. =',INPRO,
     &                '  (PESO 2 =',PESO,')'
      DO 314 K=1,NCEL
      PROFLU(K)=PROFP(INPRO,K)*PESO+PROFP(INPRO1,K)*PESO1
      PH(K)=PROFF(INPRO,K)*PESO+PROFF(INPRO1,K)*PESO1
       IF(ILEGO.EQ.2) THEN
       FLU1V(K)=FLUX1(INPRO,K)*PESO+FLUX1(INPRO1,K)*PESO1
       FLU2T(K)=FLUX2(INPRO,K)*PESO+FLUX2(INPRO1,K)*PESO1
       XENOS(K)=PROFXE(INPRO,K)*PESO+PROFXE(INPRO1,K)*PESO1
       TMNOS(K)=PROFTM(INPRO,K)*PESO+PROFTM(INPRO1,K)*PESO1
       ENDIF
      TCNOS(K)=PROFTC(INPRO,K)*PESO+PROFTC(INPRO1,K)*PESO1
      RONOS(K)=PROFRM(INPRO,K)*PESO+PROFRM(INPRO1,K)*PESO1
  314 CONTINUE
      IF(ILEGO.EQ.2) THEN
      ROH2OI=ROR1(INPRO)*PESO+ROR1(INPRO1)*PESO1
      ROH2OU=ROR2(INPRO)*PESO+ROR2(INPRO1)*PESO1
      ROILIB=ROH2OI
      ROULIB=ROH2OU
      FLU1V(59)=FLUX1(INPRO,59)*PESO+FLUX1(INPRO1,59)*PESO1
      FLU2T(59)=FLUX2(INPRO,59)*PESO+FLUX2(INPRO1,59)*PESO1
      FLU1V(60)=FLUX1(INPRO,60)*PESO+FLUX1(INPRO1,60)*PESO1
      FLU2T(60)=FLUX2(INPRO,60)*PESO+FLUX2(INPRO1,60)*PESO1
      ALTRI=ALT(1)
      ALTRS=ALT(NCEL)
C---- CALCOLO FLUSSI DI INTERFACCIA CORE-RIFLETTORE
      PHR11=(ALTRI*FLU1V(1)+ALT(1)*FLU1V(59))/(ALT(1)+ALTRI)
      PHR21=(ALTRI*FLU2T(1)+ALT(1)*FLU2T(59))/(ALT(1)+ALTRI)
      PHR1N=(ALTRS*FLU1V(NCEL)+ALT(NCEL)*FLU1V(60))/(ALT(NCEL)+ALTRS)
      PHR2N=(ALTRS*FLU2T(NCEL)+ALT(NCEL)*FLU2T(60))/(ALT(NCEL)+ALTRS)
      WRITE(NWRITE,*) ' FLUSSI D''INTERFACCIA CORE-RIFLETTORE LIBELLULE'
      WRITE(NWRITE,*) ' PHR11 =',PHR11,' PHR1N =',PHR1N
      WRITE(NWRITE,*) ' PHR21 =',PHR21,' PHR2N =',PHR2N
      ENDIF
      IF (ILEGO.EQ.1) THEN
      WRITE(NWRITE,654) (PROFLU(K),K=1,NCEL)
      WRITE(NWRITE,546) (PH(K),K=1,NCEL)
  654 FORMAT(/10X,'PROFIL0 INIZIALE DI POTENZA ',
     &'(INTERPOLATO FRA QUELLI PREPARATI DA "NOSTRI")',/,8(1X,G12.5))
  546 FORMAT(/10X,'PROFIL0 INIZIALE DI FLUSSO ',
     &'(INTERPOLATO FRA QUELLI PREPARATI DA "NOSTRI")',/,8(1X,G12.5))
      WRITE(NWRITE,931) (TCNOS(K),K=1,NCEL)
  931 FORMAT(/10X,'PROFIL0 INIZIALE DI TEMPERATURA DEL COMBUSTIBILE ',
     & '(INTERPOLATO FRA QUELLI PASSATI DA "NOSTRI")',/,8(1X,G12.5))
      WRITE(NWRITE,458) (RONOS(K),K=1,NCEL)
  458 FORMAT(/10X,'PROFIL0 INIZIALE DI DENSITA'' DEL MODERATORE ',
     & '(INTERPOLATO FRA QUELLI PASSATI DA "NOSTRI")',/,8(1X,G12.5))
      ELSE IF(ILEGO.EQ.2) THEN
      WRITE(NWRITE,354) (PROFLU(K),K=1,NCEL)
      WRITE(NWRITE,346) (PH(K),K=1,NCEL)
  354 FORMAT(/10X,'PROFIL INITIAL DE PUISSANCE ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
  346 FORMAT(/10X,'PROFIL INITIAL DE FLUX TOTAL 1G ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
      WRITE(NWRITE,331) (TCNOS(K),K=1,NCEL)
  331 FORMAT(/10X,'PROFIL INITIAL DE TEMPERATURE DU COMBUSTIBLE ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
      WRITE(NWRITE,358) (RONOS(K),K=1,NCEL)
  358 FORMAT(/10X,'PROFIL INITIAL DE DENSITE'' DU MODERATEUR ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
      WRITE(NWRITE,368) (TMNOS(K),K=1,NCEL)
  368 FORMAT(/10X,'PROFIL INITIAL DE TEMPERATURE DU MODERATEUR ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
      WRITE(NWRITE,369) (XENOS(K),K=1,NCEL)
  369 FORMAT(/10X,'PROFIL INITIAL DE CONCENTRATION XENON ',
     &'(INTERPOLLE DES PROFILS "LIBELLULE")',/,8(1X,G12.5))
      WRITE(NWRITE,370) (BULAX(K),K=1,NCEL)
  370 FORMAT(/10X,'PROFIL DE BURN-UP DE REGIMATION',/,8(1X,G12.5))
      ENDIF
C     INIZIALIZZAZIONE DELLE VARIABILI TERMOIDRAULICHE UTILIZZATE
C     PER IL CALCOLO DEI "RESTI" NEL CASO DI CINETICA (1-D)
      DO 384 K=1,NCEL
      TEM(K)=TCNOS(K)
      RO(K)=RONOS(K)
      IF (ILEGO.EQ.2) THEN
      TREF(K)=TMNOS(K)
      XE(K)=XENOS(K)
      ENDIF
  384 CONTINUE
C
      ELSE IF(.NOT.LREGIM) THEN
      WRITE(NWRITE,299)
  299 FORMAT(1X,'ATTENZIONE ! LA RICERCA DEL REGIME STAZIONARIO ',
     &'INIZIALE (E IL CALCOLO DEI "RESTI") SI DEVE EFFETTUARE CON',
     &'LREGIM=.TRUE.',/,
     &'IL PROGRAMMA SI BLOCCA  (SUBR. "PROFIN" DI "KIQS01")')
      STOP ' RICERCA REGIME CON LREGIM=.FALSE. (SUB. PROFIN DI KIQS01)'
      ENDIF
C
      GO TO 222
C
  100 CONTINUE
      IF(LREGIM) STOP ' REGIMAZIONE (0-D) NON PREVISTA (SUBR. PROFIN)'
      REWIND IREST
      READ(IREST,199) (RES(K),K=1,NCEL)
      READ(IREST,199) (PROFLU(K),K=1,NCEL)
      READ(IREST,199) (PH(K),K=1,NCEL)
      READ(IREST,199) (D(K),K=1,NCEL)
      READ(IREST,199) RIAL,RIBA
      READ(IREST,199) (DINSER(K),K=1,NG),CBORO
  199 FORMAT(4E15.8)
      BORVCT=CBORO
      DO 385 K=1,NG
      BINSER(K)=DINSER(K)
  385 CONTINUE
      WRITE(NWRITE,645) (PROFLU(K),K=1,NCEL)
      WRITE(NWRITE,357) (BINSER(K),K=1,NG),BORVCT
  645 FORMAT(/10X,'PROFIL0 INIZIALE DI POTENZA (DOPO ',
     &       'REGIMAZIONE)',/,8(1X,G12.5))
  357 FORMAT(/10X,'ESTRAZIONE INIZIALE DELLE BARRE (IN PASSI) ',
     &       '(DOPO REGIMAZIONE)',/,6G12.5,//,10X,'CONCENTRAZIONE ',
     &       'INIZIALE DI BORO (DOPO REGIMAZIONE) =',G12.5)
C
  222 CONTINUE
C
C     NORMALIZZAZIONE DEL PROFILO DI POTENZA E DI FLUSSO INIZIALI
C
      CLTOT=0.
      ALCAN=0.
      ALCAN1=0.
      DO 7 K=1,NCEL
      ALCAN=PROFLU(K)*CL(K)+ALCAN
      ALCAN1=PH(K)*CL(K)+ALCAN1
    7 CLTOT=CLTOT+CL(K)
      DO 8 K=1,NCEL
      PH(K)=PH(K)*CLTOT/ALCAN1
    8 PROFLU(K)=PROFLU(K)*CLTOT/ALCAN
      WRITE(NWRITE,456) (PROFLU(K),K=1,NCEL)
      WRITE(NWRITE,465) (PH(K),K=1,NCEL)
  456 FORMAT(/,10X,'PROFIL0 INIZIALE DI POTENZA NORMALIZZATO',
     &       /,8(1X,G12.5))
  465 FORMAT(/,10X,'PROFIL0 INIZIALE DI FLUSSO 1G NORMALIZZATO',
     &       /,8(1X,G12.5))
C
C     NORMALIZZAZIONE DEI FLUSSI VELOCE E TERMICO (LA CUI SOMMA DA'
C     IL FLUSSO TOTALE A 1 GRUPPO NORMALIZZATO) E DEFINIZIONE DEL
C     LORO RAPPORTO DIRETTO (CHE VERRA' CAMBIATO SOLO NEL CASO DI
C     NUOVI RICALCOLI DEI FLUSSI A DUE GRUPPI STESSI)
C
      DO 86 K=1,NCEL
      PHR1(K)=FLU1V(K)*CLTOT/ALCAN1
      PHR2(K)=FLU2T(K)*CLTOT/ALCAN1
      RFIS21(K)=PHR2(K)/PHR1(K)
   86 CONTINUE
      WRITE(NWRITE,291) (PHR1(K),K=1,NCEL)
      WRITE(NWRITE,292) (PHR2(K),K=1,NCEL)
      WRITE(NWRITE,290) (PHR2(K)/PHR1(K),K=1,NCEL)
  290 FORMAT(/,10X,'RAPPORTO SPETTRALE DIRETTO',/,8(1X,G12.5))
  291 FORMAT(/,10X,'PROFIL0 INIZIALE DI FLUSSO VELOCE NORMALIZZATO',
     &       /,8(1X,G12.5))
  292 FORMAT(/,10X,'PROFIL0 INIZIALE DI FLUSSO TERMICO NORMALIZZATO',
     &       /,8(1X,G12.5))
C---- CALCOLO FLUSSI DI INTERFACCIA NORMALIZZATI CORE-RIFLETTORE
      PHR11=PHR11*CLTOT/ALCAN1
      PHR21=PHR21*CLTOT/ALCAN1
      PHR1N=PHR1N*CLTOT/ALCAN1
      PHR2N=PHR2N*CLTOT/ALCAN1
      WRITE(NWRITE,*) ' FLUSSI D''INTERFACCIA CORE-RIFLETTORE NORMALIZ.'
      WRITE(NWRITE,*) ' PHR11 =',PHR11,' PHR1N =',PHR1N
      WRITE(NWRITE,*) ' PHR21 =',PHR21,' PHR2N =',PHR2N
C
      ALCAN=CLTOT
      IF(ABS(ALCAN-ALATT).GT.1.E-04) STOP ' ERRORE : ALCAN.NE.ALATT '
      NCEL2=NCEL/2
      IF(ILEGO.EQ.1) THEN
C
C     CALCOLO DELL' "AXIAL OFFSET" (SQUILIBRIO ASSIALE DI FLUSSO NEUTRON
C
      NCEL4=NCEL/4 + 1.E-05
      RIV1=0.
      RIV2=0.
      RIV3=0.
      RIV4=0.
      DO 386 K=1,NCEL4
      RIV1=RIV1+PH(K)
      RIV2=RIV2+PH(K+NCEL4)
      RIV3=RIV3+PH(K+2*NCEL4)
      RIV4=RIV4+PH(K+3*NCEL4)
  386 CONTINUE
      FIMENO=RIV4+RIV3-RIV2-RIV1
      FIPIU =RIV4+RIV3+RIV2+RIV1
      AXOFF=100.*FIMENO/FIPIU
      WRITE(NWRITE,33) AXOFF
   33 FORMAT(' AXIAL-OFFSET = ',F6.2)
      ELSE IF(ILEGO.EQ.2) THEN
C CALCUL DE L'AXIAL OFFSET(DESEQUILIBRE AXIAL DE PUISSANCE NEUT)
      PHAUT=0.
      PBAS=0.
      DO 71 K=1,NCEL2
      PBAS=PBAS+PROFLU(K)*CL(K)*100.
      PHAUT=PHAUT+PROFLU(K+NCEL2)*CL(K+NCEL2)*100.
   71 CONTINUE
      AXOFFC=100.*(PHAUT-PBAS)/(PHAUT+PBAS)
C CALCUL AXIAL-OFFSET XENON
      XEHAUT=0.
      XEBAS=0.
      DO 72 K=1,NCEL2
      XEBAS=XEBAS+XE(K)*CL(K)*100.
      XEHAUT=XEHAUT+XE(K+NCEL2)*CL(K+NCEL2)*100.
   72 CONTINUE
      AOXE=100.*(XEHAUT-XEBAS)/(XEHAUT+XEBAS)
C
      WRITE(NWRITE,1039) AXOFFC,AOXE
 1039 FORMAT(/,1X,'AXIAL-OFFSET = ',F6.2,2X,'A.O. XENON=',F6.2)
      ENDIF
C     CALCUL DU FACTEUR DE PIC LOCAL FZ
      FZ=PH(1)
      KFZ=1
      DO 981 K=2,NCEL
      IF(PH(K).GT.FZ) THEN
      FZ=PH(K)
      KFZ=K
      ENDIF
  981 CONTINUE
      WRITE(NWRITE,215) FZ,KFZ
  215 FORMAT(/,1X,'FACTEUR DE PIC AXIAL FZ=',F6.3,2X,'DANS LA MAILLE K='
     &,I3)
C
C
      WLIN1=WTOT/(ALCAN*CANN)
      DO 9 K=1,NCEL
      WW(K)=WLIN1*PROFLU(K)
      WWWK=1.
      DO 300 J=1,NPD
      WWWK=WWWK+ADEC(J,NPD-1)*GDEC(J,NPD-1)*ABS(TPAS)/(1.+ADEC(J,NPD-1)*
     $          ABS(TPAS))
  300 CONTINUE
C ********  POTENZA LINEARE DI FISSIONE  *******************************
      WW(K)=WW(K)/WWWK
C ********  POTENZA DI RISCALDAMENTO GAMMA  ****************************
      WGAMC(K)=RGAM*WW(K)*CL(K)
C ********  POTENZA DI DECADIMENTO  ************************************
      DO 200 J=1,NPD
      CORD(J)=1.
      WESTD(J,K)=CORD(J)*(ADEC(J,NPD-1)*GDEC(J,NPD-1)*WW(K)*ABS(TPAS))/
     &         (1.+ADEC(J,NPD-1)*ABS(TPAS))
  200 CONTINUE
    9 CONTINUE
      PFIS=0.
      PDEC=0.
      DO 16 K=1,NCEL
      WESTS(K)=0.
      DO 17 J=1,NPD
   17 WESTS(K)=WESTS(K)+WESTD(J,K)
      PDEC=PDEC+WESTS(K)*CL(K)
      PFIS=PFIS+WW(K)*CL(K)
   16 CONTINUE
      POTDEC=PDEC*CANN
      WRITE(NWRITE,30) POTDEC
   30 FORMAT(5(/),1X,'POTENZA MEDIA TOTALE DI DECADIMENTO WDEC =',E12.5)
      POTFIS=PFIS*CANN
      WNEUT=POTFIS
      WRITE(NWRITE,44) POTFIS
   44 FORMAT(1X,'POTENZA TOTALE DI FISSIONE WFIS =',E12.5)
      WRITE(NWRITE,40) WTOT
   40 FORMAT(1X,'POTENZA TOTALE DI REATTORE WTOT =',E12.5)
C ***  POTENZA TOTALE DI CELLA TERMOIDRAULICA PER CALCOLO 'LEGO'  ***
      KN=0
      DO 388 KT=1,NCELT
      WCTH=0.
      FLUL=0.
      CLTHH=0.
      DO 387 JN=1,NKIN
      KN=KN+1
      CLTHH=CLTHH+CL(KN)
      FLUL=FLUL+PH(KN)*CL(KN)
      WCTH=WCTH+(WW(KN)+WESTS(KN))*CL(KN)*CANN
  387 CONTINUE
      WCEL(KT)=WCTH
  388 CONTINUE
      WRITE(NWRITE,45) (WCEL(KT),KT=1,NCELT)
   45 FORMAT(1X,'POTENZA TOTALE DI CELLA (LEGO)',/,6(1X,G12.5))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE RESTI(AKF,AL,BE,ALBA,ALT,CEFI,BQ,C,EEF,ENF,PHV,
     &                 SG,TEM,RO,HEL,PALBA,BQV,D,RES,CM,HBE,BEM,ALM,    
     &                 PROFLU,PH,FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,
     &                 COEKFT,COEEF1,RLAM,RBETA,VELOC,AKFCEL,ALJ,BEJ,
     &                 ALFAD,ALFAM,ALFAB,TREF,COEXE1,DSGXE,POTFIS,
     &                 NLIBM,NCM,NRITM,XE,VIO,SIGXE,GISF,XEV,VIOV,      
     &                 SIGXEL,GISFL,ILEGO,PAS1,PAS2,IDUEG,IXENO,XENOS)  
C-----------------------------------------------------------------------
C     VALUTA SULLA BASE DEI PROFILI INIZIALI I COEFFICIENTI CORRETTIVI  
C     DELLE SEZIONI D'URTO DI ASSORBIMENTO PER L'AZZERAMENTO DELLA      
C     REATTIVITA' ("RESTI") NEL CASO DI CINETICA ASSIALE .
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),        
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),       
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)      
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,    
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)       
      COMMON/TUSEPT/TEMC(24),TEMP(24)                                   
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N                    
     &              ,DUMMI61(NW-16)
      COMMON /MATRIF/FT$(8),AP$(8),GT$(8),FT1$(8),F01$(8),G01$(8),
     &               GT1$(8),AP4$(8),AP5$(8),SS$(8),DD$(8),RM$(8),QQ(8),
     &               TTINF(4),TTSUP(4),PM1$(8),RG$(8),VG$(8),OMR$(8),   
     &               DC$(8),RN$(8)                                      
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)                         
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS                           
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT    
     &              ,NDUMMI(NW-21)
      COMMON/NAS$$/NAS(KUZOM),DUMMI31(NW-KUZOM)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/BOR$/BORVCT,DUMMI23(NW-1)
      COMMON/RIFLA$/RRFI,RRTI,RRFS,RRTS,DUMMI6(NW-4)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,  
     2TFIX,DC,ASPA,RSUP                                                 
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU ,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP            
     &             ,DUMMI20(NW-18)
      COMMON /DANUC$/ VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $               FRAXE,FRASM,DUMMI12(NW-10)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      DIMENSION ALT( * ),CEFI( * ),TEM( * ),RO( * ),RES(*),PROFLU(*),
     &          HEL(*),ALBA( * ),BQ( * ),PH( * ),EEF( * ),PHV( * ),
     *          ENF( * ),BE(NRITM, * ),AL(NRITM, * ),C(NRITM, * ),
     $          SG( * ), DSGXE(*),AKF( * ),TREF(*),D(*),BEM(*),HBE(*),
     %          BQV(*),PALBA(*),AKFCEL(*),ALJ(*),BEJ(*),CM(*),ALM(*),
     !          VIOV(*),XEV(*),XENOS(*)
      DIMENSION FCNZ(*),ILIB1(*),ILIB2(*),COES1(NLIBM,NCM,*),
     &          COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),
     %          COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),
     &          RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),XE(*),VIO(*),
     &          VELOC(NLIBM),COEXE1(NLIBM,NCM,*),SIGXE(*),GISF(*),
     &          SIGXEL(NLIBM,*),GISFL(NLIBM,*)
      DIMENSION RMAT1(4),RMAT2(4)                                       
C                                                                       
      IF(ILEGO.EQ.1) THEN                                               
      NOCPWR=228                                                        
      ELSE IF(ILEGO.EQ.2) THEN                                          
      IF(ABS(WNOM-2780.E+6).LE.10.E+6) THEN                             
      NOCPWR=225                                                        
      ELSE IF(ABS(WNOM-3800.E+6).LE.10.E+6) THEN                        
      NOCPWR=260                                                        
      ENDIF                                                             
      ENDIF                                                             
C                                                                       
      NCEL=NC1                                                          
      TIMEV=0.                                                          
      VC=3.14159*RC*RC                                                  
      DEPZ=VC*ELNUM                                                     
      ANOCP=(ALATT*100.-ZMIN)/FLOAT(NOCPWR)                             
      CEFI(1)=ALT(1)                                                    
      DO 25  K=2,NCEL                                                   
   25 CEFI(K)=CEFI(K-1)+ALT(K)                                          
      NNN=0                                                             
      DO 536 KR=1,NUZO                                                  
  536 NNN=NNN+NAS(KR)                                                   
      DO 62 KR=1,NUZO                                                   
   62 HEL(KR)=FLOAT(NAS(KR))/FLOAT(NNN)                                 
      DO 5 K=1,NCEL                                                     
      BQ(K)=0.                                                          
      BQZ1(K)=0.                                                        
      BQZ2(K)=0.                                                        
    5 CONTINUE                                                          
C-----------------------------------------------------------------------
C     CALCOLO DEL LIVELLO DI ESTRAZIONE DEGLI NG BANCHI DI BARRE        
C     (SIA IN PASSI CHE IN CM.) PER UN PWR.                             
C                                                                       
C - BINSER(K),(K=1,NG)    : LIVELLO DI ESTRAZIONE DEI BANCHI IN CM      
C - ALBA(K),(K=1,NG)      : COMPLEMENTO ALL'ALTEZZA ATTIVA DEL CANALE   
C                           DELL'INSERIMENTO (IN CM.) DI OGNI BANCO     
C                           (--> ESTRAZIONE DEI BANCHI DI BARRE IN CM)  
C                                                                       
C       ( 228/225 PASSI DI ESTRAZIONE --> BARRE TUTTE FUORI             
C               0 PASSI DI ESTRAZIONE --> BARRE TUTTE DENTRO )          
C-----------------------------------------------------------------------
      DO 382 K=1,NG                                                     
      ALBA(K)=BINSER(K)*ANOCP+ZMIN                                      
      IF(ALBA(K).LE.ZMIN) ALBA(K)=ZMIN                                  
      IF(ALBA(K).GE.ALATT*100.) ALBA(K)=ALATT*100.                      
  382 CONTINUE                                                          
C     INDIVIDUAZIONE DELLA CONCENTRAZIONE DI BORO NEL CIRCUITO PRIMARIO 
      BO=BORVCT                                                         
      POTTOT=W*100./WNOM                                                
      WRITE(NWRITE,653) BURM,POTTOT,BO,(BINSER(K),K=1,NG)               
  653 FORMAT(/,20X,'PARAMETRI RELATIVI AL CALCOLO DEI "RESTI" ',//,     
     &       1X,'BRUCIAMENTO MEDIO DI REATTORE  (MWD/T) = ',F7.1,/,     
     &       1X,'POTENZA TOTALE PERCENTUALE    (% WNOM) = ',F5.1,/,     
     &       1X,'CONCENTRAZIONE CRITICA DI BORO   (PPM) = ',F7.2,/,     
     &    1X,'ESTRAZIONE BARRE DI CONTROLLO  (PASSI) = ',6(F5.1,1X),//) 
C                                                                       
C-----------------------------------------------------------------------
C    GENERAZIONE DELLE COSTANTI NUCLEARI SULLA BASE DEI PROFILI INIZIALI
C-----------------------------------------------------------------------
C                                                                       
      IF(ILEGO.EQ.1) THEN                                               
      CALL CONUC(ALBA,BO,TEM,RO,ALT,CEFI,PH,D,SG,ENF,EEF,AKF,
     &           AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,                        
     &           FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %           COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,                     
     %           ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,             
     %           SIGXEL,GISFL)                                          
      WRITE(NWRITE,*) 'GISF 1=',(GISF(K),K=1,NCEL)                      
      WRITE(NWRITE,*) 'SIGXE 1=',(SIGXE(K),K=1,NCEL)                    
C                                                                       
C     CALCOLO DEL RAPPORTO COSTANTE DURANTE IL TRANSITORIO :            
C     (TASSO DI PRODUZIONE DELLO IODIO)/(ENERGIA RILASCIATA PER FISSIONE
      DO 383 K=1,NCEL                                                   
      GISF(K)=GISF(K)/EEF(K)                                            
  383 CONTINUE                                                          
      WRITE(NWRITE,*) 'GI/E 1=',(GISF(K),K=1,NCEL)                      
C                                                                       
C     CALCOLO DELLE CONCENTRAZIONI DI XENO E DI IODIO                   
C                                                                       
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)                
C     VALUTAZIONE DEL CONTRIBUTO ALLA SEZIONE MACROSCOPICA DI ASSORBIMEN
C     DOVUTO ALL'AVVELENAMENTO DA XENO                                  
      DO 50 KK=1,NCEL
C                                                                       
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB1
C                                                                       
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB1(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      DSGX11=DSGXE(KK)                                                  
C                                                                       
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB2                   
C                                                                       
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB2(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      IF(LSTAZ) DSGXE(KK)=DSGX11*(1.-FCNZ(KK))+DSGXE(KK)*FCNZ(KK)       
   50 CONTINUE                                                          
      WRITE(NWRITE,*) 'DSGXE 1=',(DSGXE(K),K=1,NCEL)                    
      ELSE IF (ILEGO.EQ.2) THEN                                         
      JRESTI=1                                                          
      CALL CONUS(JRESTI,NCEL,NRIT,TEM,TEMC,TEMP,TREF,RO,                
     &           BO,XE,SG,DSGXE,ENF,EEF,D,AKF,AKFCEL,PH,GISF,
     &           SIGXE,AL,BE,VEL,NRITM,PAS1,PAS2,ALT)                   
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)                
      IF(IXENO.EQ.0) THEN                                               
C---- CALCOLO A XENO FISSATO AL VALORE NOMINALE DI LIBELLULE            
      DO 977 K=1,NCEL                                                   
  977 XE(K)=XENOS(K)                                                    
      ENDIF                                                             
      WRITE(NWRITE,766) (XE(K),K=1,NCEL)                                
  766 FORMAT(/,20X,'CONCENTRAZIONE DI XENO '/(6E16.7))                  
      ENDIF                                                             
C                                                                       
C     CALCOLO DELLA SEZIONE DI ASSORBIMENTO TOTALE                      
      DO 71 K=1,NCEL                                                    
   71 SG(K)=SG(K)+DSGXE(K)                                              
C                                                                       
C-----------------------------------------------------------------------
C     CALCOLO DEI BUCKLINGS DI CELLA A 2 GRUPPI ENERGETICI.             
C     SE IND=0 I BUCLINGS SONO IN CONVERGENZA, SE IND=1 NO.             
C-----------------------------------------------------------------------
C                                                                       
      NITEBM=200                                                        
      CALL CALRIF                                                       
      NITERB=0                                                          
    1 NITERB=NITERB+1                                                   
C      WRITE(NWRITE,500) NITERB                                         
  500 FORMAT(///,5X,'ITERAZIONE DA BUCKLING N. ',I3,///)                
      IF(NITERB.EQ.1) GO TO 2                                           
      CALL BUCK2G(IND,ALT,EPS1,NCEL)                                    
      IF(NITERB.LT.30) GO TO 2                                          
      IF(IND.EQ.0) GO TO 3                                              
      IF(NITERB.GT.NITEBM) THEN                                         
      WRITE(NWRITE,602) NITERB,NITEBM                                   
  602 FORMAT(1X,'NUMERO ITERAZIONI DA BUCKLING NITERB=',I5,             
     &       3X,'(NITEBM = ',I5,' )')                                   
      STOP ' NITERB .GT. NITEBM (SUBROUTINE RESTI)'                     
      ENDIF                                                             
C                                                                       
C-----------------------------------------------------------------------
C     CALCOLO DELLA MATRICE DI RIFLESSIONE T PER LA RELAZIONE TRA LE    
C     CORRENTI DI INTERFACCIA CORE-RIFLETTORE E I FLUSSI MEDI NEI       
C     NODI MOLTIPLICANTI ADIACENTI AL RIFLETTORE                        
C-----------------------------------------------------------------------
C                                                                       
    2 CALL MATT(ALT,NCEL)                                               
C                                                                       
C-----------------------------------------------------------------------
C     CALCOLO DEI PARAMETRI G E W DEL METODO COARSE-MESH                
C-----------------------------------------------------------------------
C                                                                       
      CALL GWCOEF(ALT,NCEL)                                             
C                                                                       
C-----------------------------------------------------------------------
C     CALCOLO DEI COEFFICIENTI OMEGA CHE METTONO IN RELAZIONE CORRENTI  
C     D'INTERFACCIA E FLUSSI MEDI                                       
C-----------------------------------------------------------------------
C                                                                       
      CALL OMEGA2(ALT,NCEL)                                             
      GO TO 1                                                           
    3 CONTINUE                                                          
C      WRITE(NWRITE,*) ' N. ITERAZ. BUCKLING =',NITERB                  
      WRITE(NWRITE,1107) (BQZ1(K),K=1,NCEL)                             
      WRITE(NWRITE,2107) (BQZ2(K),K=1,NCEL)                             
 1107 FORMAT(/20X,'BUCKLING VELOCI'/(6G16.7))                           
 2107 FORMAT(/20X,'BUCKLING TERMICI'/(6G16.7))                          
C---- CALCOLO DEI FLUSSI AI CONFINI SUPERIORE ED INFERIORE DEL NOCCIOLO 
      CALL PERMA1(QQ(1),TTINF,RMAT1)                                    
      CALL PERMA1(QQ(5),TTSUP,RMAT2)                                    
      PHR11=RMAT1(1)*PHR1(1)+RMAT1(3)*PHR2(1)                           
      PHR21=RMAT1(2)*PHR1(1)+RMAT1(4)*PHR2(1)                           
      PHR1N=RMAT2(1)*PHR1(NCEL)+RMAT2(3)*PHR2(NCEL)                     
      PHR2N=RMAT2(2)*PHR1(NCEL)+RMAT2(4)*PHR2(NCEL)                     
      WRITE(NWRITE,751) PHR11,PHR1N,PHR21,PHR2N                         
  751 FORMAT(/,20X,'FLUSSI DI INTERFACCIA CORE-RIFLETTORE',/,           
     &      'PHR11 =',G12.5,2X,'PHR1N =',G12.5,2X,'PHR21 =',G12.5,2X,   
     &      'PHR2N =',G12.5)                                            
C---- CALCOLO DELLE FUGHE ASSIALI A 2 GRUPPI                            
      FUITZ1=0.                                                         
      FUITZ2=0.                                                         
      SOMF=0.                                                           
      SOMR=0.                                                           
      DMED1=0.                                                          
      DMED2=0.                                                          
      DO 219 K=1,NCEL                                                   
      SOMF=SOMF+(ENFIS1(K)*PHR1(K)+ENFIS2(K)*PHR2(K))*ALT(K)
      SOMR=SOMR+RIM1(K)**PHR1(K)*ALT(K)
      FUITZ1=FUITZ1+DIF1(K)*BQZ1(K)*PHR1(K)*ALT(K)                      
      FUITZ2=FUITZ2+DIF2(K)*BQZ2(K)*PHR2(K)*ALT(K)                      
      DMED1=DMED1+DIF1(K)*PHR1(K)*ALT(K)                                
  219 DMED2=DMED2+DIF2(K)*PHR2(K)*ALT(K)                                
      BQZ1MM=FUITZ1/DMED1                                               
      BQZ2MM=FUITZ2/DMED2                                               
      FUITZ1=FUITZ1/SOMF                                                
      FUITZ2=FUITZ2/SOMR                                                
      WRITE(NWRITE,*) ' FUGHE AX. VELOCI =',FUITZ1,                     
     &                '  FUGHE AX. TERMICHE =',FUITZ2                   
      WRITE(NWRITE,*) ' BUCKLING ASSIALE VELOCE MEDIO =',BQZ1MM         
      WRITE(NWRITE,*) ' BUCKLING ASSIALE TERMICO MEDIO =',BQZ2MM        
C                                                                       
      DO 93 K=1,NCEL                                                    
      PHR1(K)=PH(K)/(1.+RFIS21(K))                                      
      PHR2(K)=PHR1(K)*RFIS21(K)                                         
   93 CONTINUE                                                          
      WRITE(NWRITE,290) (RFIS21(K),K=1,NCEL)                            
      WRITE(NWRITE,291) (PHR1(K),K=1,NCEL)                              
      WRITE(NWRITE,292) (PHR2(K),K=1,NCEL)                              
  290 FORMAT(/,10X,'RAPPORTO SPETTRALE DIRETTO ',/,8(1X,G12.5))         
  291 FORMAT(/,10X,'PROFIL0 INIZIALE DI FLUSSO VELOCE SPLITTATO',       
     &       /,8(1X,G12.5))                                             
  292 FORMAT(/,10X,'PROFIL0 INIZIALE DI FLUSSO TERMICO SPLITTATO',      
     &       /,8(1X,G12.5))                                             
C                                                                       
C     CALCOLO DELLA REATTIVITA' SULLA BASE DEI PARAMETRI DI RIFERIMENTO 
      CALL REA2G(NCM,FSOT,ALT)
      WRITE(NWRITE,1124) REAT                                           
C                                                                       
C      WRITE(NWRITE,*) 'AKINF =',(AKINF(K),K=1,NCEL)                    
C      WRITE(NWRITE,*) 'ASS1  =',(ASS1(K),K=1,NCEL)                     
C      WRITE(NWRITE,*) 'ASS2  =',(ASS2(K),K=1,NCEL)                     
C      WRITE(NWRITE,*) 'BQR1Z(K) =',(BQR1Z(K),K=1,NCEL)                 
C      WRITE(NWRITE,*) 'BQR2Z(K) =',(BQR2Z(K),K=1,NCEL)                 
      WRITE(NWRITE,125) (AKF(K),K=1,NCEL)                               
C      WRITE(NWRITE,121) (ENF(K),K=1,NCEL)
C      WRITE(NWRITE,120) (EEF(K),K=1,NCEL)                              
C      WRITE(NWRITE,126) (SG(K),K=1,NCEL)                               
C      WRITE(NWRITE,118) (DSGXE(K),K=1,NCEL)                            
C      WRITE(NWRITE,122) (D(K),K=1,NCEL)                                
C      WRITE(NWRITE,141) (SIGXE(K),K=1,NCEL)                            
C      WRITE(NWRITE,128) (AKFCEL(K),K=1,NCEL)                           
      IF(REAT.GE..5) STOP ' REATTIVITA'' MAGGIORE DI 0.5 (SUBR. RESTI)' 
C                                                                       
C     CALCOLO DELLA 'FUNZIONE AMPIEZZA' INIZIALE                        
      TT=0.                                                             
      DO 88 K=1,NCEL                                                    
      PHEFIS=PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K)                        
   88 TT=TT+PHEFIS*ALT(K)*DEPZ*1.E+04                                   
      T=POTFIS/(TT*CANN)
      DO 89 J=1,NCEL
      PHV(J)=PH(J)
      XEV(J)=XE(J)
   89 BQV(J)=BQ(J)
      DO 8093 K=1,NG
      PALBA(K)=ALCAN*100.-ALBA(K)
      IF(PALBA(K).LE.0.0) PALBA(K)=0.0
 8093 CONTINUE
      WRITE(NWRITE,700) (PALBA(K),K=1,NG)
      WRITE(NWRITE,755) (BINSER(K),K=1,NG)
      WRITE(NWRITE,621) BO
C-----------------------------------------------------------------------
C     CALCOLO DEI RESTI (COEFFICIENTI CORRETTIVI DELLE SEZIONI D'URTO
C     DI ASSORBIMENTO TALI DA RENDERE IL REATTORE ESATTAMENTE CRITICO)
C     SULLA BASE DEI PROFILI NEUTRONICI E TERMOIDRAULICI INIZIALI DI
C     TENTATIVO NEL CASO DI DI REGIMAZIONE.
C-----------------------------------------------------------------------
      DO 11 K=1,NCEL
      NCERR=K
      RES1(K)=(ENFIS1(K)+ENFIS2(K)*PHR2(K)/PHR1(K)-RIM1(K)-DIF1(K)*
     &         BQZ1(K))/ASS1(K)
C     &         BQZ1M)/ASS1(K)
      IF(RES1(K).LT.0.5.OR.RES1(K).GT.2.5) GO TO 1001
      RES2(K)=(RIM1(K)*PHR1(K)/PHR2(K)-DIF2(K)*BQZ2(K))/ASS2(K)
C      RES2(K)=(RIM1(K)*PHR1(K)/PHR2(K)-DIF2(K)*BQZ2M)/ASS2(K)
      IF(RES2(K).LT.0.5.OR.RES2(K).GT.2.5) GO TO 1002
   11 CONTINUE
      WRITE(NWRITE,1106) (RES1(K),K=1,NCEL)
      WRITE(NWRITE,2106) (RES2(K),K=1,NCEL)
C-----------------------------------------------------------------------
      DO 31 K=1,NCEL
      ASS1(K)=ASS1(K)*RES1(K)
      ASS2(K)=ASS2(K)*RES2(K)
   31 SG(K)=SG(K)*RES(K)
C-----------------------------------------------------------------------
C      WRITE(NWRITE,125)(AKF(K),K=1,NCEL)
C      WRITE(NWRITE,127)(SG(K),K=1,NCEL)
      WRITE(NWRITE,1127)(ASS1(K),K=1,NCEL)
      WRITE(NWRITE,2127)(ASS2(K),K=1,NCEL)
C      WRITE(NWRITE,120)(EEF(K),K=1,NCEL)
C      WRITE(NWRITE,121)(ENF(K),K=1,NCEL)
C      WRITE(NWRITE,122)(D(K),K=1,NCEL)
C      WRITE(NWRITE,101)(PH(K),K=1,NCEL)
C      WRITE(NWRITE,107)(BQ(K),K=1,NCEL)
      WRITE(NWRITE,158) 1./VEL
      WRITE(NWRITE,159) ((AL(J,K),J=1,NRIT),K=1,NCEL)
      WRITE(NWRITE,160) ((BE(J,K),J=1,NRIT),K=1,NCEL)
  118 FORMAT(/20X,'DELTA SIGMA ASSORBIMENTO DA XENO'/(6G16.7))
  120 FORMAT(/20X,'E * SIGMA FISSIONE'/(6E16.7))
  121 FORMAT(/20X,'NU * SIGMA FISSIONE'/(6G16.7))
 1121 FORMAT(/20X,'NU * SIGMA FISSIONE VELOCE'/(6G16.7))
 2121 FORMAT(/20X,'NU * SIGMA FISSIONE TERMICA'/(6G16.7))
  122 FORMAT(/20X,'COEFFICIENTI DIFFUSIONE'/(6G16.7))
 1122 FORMAT(/20X,'COEFFICIENTI DIFFUSIONE VELOCI'/(6G16.7))
 2122 FORMAT(/20X,'COEFFICIENTI DIFFUSIONE TERMICI'/(6G16.7))
  106 FORMAT(/20X,'RESTI'/(6G16.7))
  124 FORMAT(/5X,'REATTIVITA'' CALCOLATA =',F10.5)
 1124 FORMAT(/5X,'REATTIVITA'' CALCOLATA A 2G =',F10.5)
  116 FORMAT(/5X,'REATTIVITA'' CORRETTA CON RESTI =',F10.5)
 1116 FORMAT(/5X,'REATTIVITA'' A 2G CORRETTA CON RESTI =',F10.5)
  100 FORMAT(/20X,'CONCENTRAZIONI DI RITARDATI'/(6E16.7))
  101 FORMAT(/20X,'FLUSSI MEDI DI CELLA'/(6E16.7))
  107 FORMAT(/20X,'BUCKLING'/(6G16.7))
  702 FORMAT(/20X,'EFFICIENZA DI CELLA PER ZONE'/)
  703 FORMAT(/10X,'CELLA',2X,I2,5X,5G12.5)
  708 FORMAT(/20X,'FORMA DI FLUSSO'/(8G12.5))
 1708 FORMAT(/20X,'FORMA DI FLUSSO VELOCE'/(8G12.5))
 2708 FORMAT(/20X,'FORMA DI FLUSSO TERMICO'/(8G12.5))
 3107 FORMAT(/20X,'SIGMA RIMOZIONE VELOCE'/6(G16.7))
  709 FORMAT(/5X,'FUNZIONE AMPIEZZA =',G12.5)
  700 FORMAT(/20X,'ALTEZZA BARRE'/(8G12.5))
  755 FORMAT(/20X,'ESTRAZIONE BARRE (IN PASSI)'/(8G12.5))
  621 FORMAT(/5X,'CONCENTRAZIONE DI BORO (PPM) =',G12.5)
  126 FORMAT(/20X,'SIGMA ASSORBIMENTO TOTALE'/(6G16.7))
 1126 FORMAT(/20X,'SIGM*A ASSORBIMENTO VELOCE'/(6G16.7))
 2126 FORMAT(/20X,'SIGMA ASSORBIMENTO TERMICA'/(6G16.7))
  127 FORMAT(/20X,'SIGMA ASSORBIMENTO MODIFICATE CON RESTI'/(6G16.7))
 1127 FORMAT(/20X,'SIGMA ASSORBIMENTO VELOCI MODIFICATE CON RESTI',
     $       /(6G16.7))
 2127 FORMAT(/20X,'SIGMA ASSORBIMENTO TERMICHE MODIFICATE CON RESTI',
     &       /(6G16.7))
  128 FORMAT(/20X,'COST. MOLTIPLIC. INFINITA TERMICA'/(6G16.7))
  125 FORMAT(/20X,'COST. MOLTIPLIC. INFINITA'/(6G16.7))
  141 FORMAT(/20X,'SIGMA ASSORBIMENTO XENO'/(6G16.7))
  158 FORMAT(/5X,'VELOCITA'' NEUTRONICA MEDIA =',G12.5)
  159 FORMAT(/20X,'COSTANTI DI DECADIMENTO',/,(6G12.5))
  160 FORMAT(/20X,'FRAZIONI DI RITARDATI',/,(6G12.5))
C
C     CALCOLO DELLA REATTIVITA' CORRETTA CON I "RESTI"
      CALL REA2G(NCM,FSOT,ALT)
C
      WRITE(NWRITE,1116) REAT
      WRITE(NWRITE,709) T
      WRITE(NWRITE,708) (PH(K),K=1,NCEL)
      WRITE(99,4454) TIMEV,T,REAT
 4454 FORMAT(/,1X,'TIME =',G12.5,3X,'AMPIEZZA  T =',G12.5,3X,
     &       'REAT =',G13.7)
C     CALCOLO CONCENTRAZIONI DI PRECURSORI DI NEUTRONI RITARDATI A 2G
      DO 3433 K=1,NCEL
      DO 3433 J=1,NRIT
      PHENFK=PHR1(K)*ENFIS1(K)+PHR2(K)*ENFIS2(K)
      C(J,K)=BE(J,K)*PHENFK*T/AL(J,K)
 3433 CONTINUE
      WRITE(NWRITE,100) ((C(J,K),J=1,NRIT),K=1,NCEL)
C
C     CALCOLO DEI PARAMETRI CINETICI MEDI DEL CANALE REATTORE
      CALL MED2G(NRITM,FSOT,CM,HBE,BEM,ALT,C,BE,AL,ALM)
C
      GO TO 902
C
 1001 WRITE(NWRITE,412)
  412 FORMAT(1X,'ATTENZIONE, ERRORE NELLA VALUTAZIONE DEI RESTI ',
     &       'VELOCI ',/,1X,'IL PROGRAMMA SI BLOCCA',/)
      WRITE(NWRITE,1106) (RES1(K),K=1,NCERR)
      WRITE(NWRITE,1126) (ASS1(K),K=1,NCEL)
      WRITE(NWRITE,1121) (ENFIS1(K),K=1,NCEL)
      WRITE(NWRITE,2121) (ENFIS2(K),K=1,NCEL)
      WRITE(NWRITE,1122) (DIF1(K),K=1,NCEL)
      WRITE(NWRITE,1107) (BQZ1(K),K=1,NCEL)
      WRITE(NWRITE,3107) (RIM1(K),K=1,NCEL)
      WRITE(NWRITE,1708) (PHR1(K),K=1,NCEL)
      WRITE(NWRITE,2708) (PHR2(K),K=1,NCEL)
 1106 FORMAT(/20X,'RESTI VELOCI'/(6G16.7))
      STOP ' ERRORE NELLA VALUTAZIONE DEI "RESTI VELOCI" (SUB. RESTI)'
 1002 WRITE(NWRITE,413)
  413 FORMAT(1X,'ATTENZIONE, ERRORE NELLA VALUTAZIONE DEI RESTI ',
     &       'TERMICI ',/,1X,'IL PROGRAMMA SI BLOCCA',/)
      WRITE(NWRITE,2106)(RES2(K),K=1,NCERR)
      WRITE(NWRITE,2126) (ASS2(K),K=1,NCEL)
      WRITE(NWRITE,2122) (DIF2(K),K=1,NCEL)
      WRITE(NWRITE,2107) (BQZ2(K),K=1,NCEL)
      WRITE(NWRITE,3107) (RIM1(K),K=1,NCEL)
      WRITE(NWRITE,1708) (PHR1(K),K=1,NCEL)
      WRITE(NWRITE,2708) (PHR2(K),K=1,NCEL)
 2106 FORMAT(/20X,'RESTI TERMICI'/(6G16.7))
      STOP ' ERRORE NELLA VALUTAZIONE DEI "RESTI TERMICI" (SUB. RESTI)'
C
  902 RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)
C-----------------------------------------------------------------------
C     VALUTA CELLA PER CELLA LE CONCENTRAZIONI DI XENO E DI IODIO
C-----------------------------------------------------------------------
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LSTAZ,LFORMA,LIQS3,LDUMMI
C
      DIMENSION PROFLU(*),EEF(*),XE(*),VIO(*),GISF(*),SIGXE(*),
     &          XEV(*),VIOV(*)
C
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &             ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,
     &             DINSER(NBBC),IFAN,TMCEL(NCNT),TCCELC(NCNT),
     &             TCCELP(NCNT)
C
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPSBQ,RIAL,
     &       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON /DANUC$/ VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $               FRAXE,FRASM,DUMMI12(NW-10)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
C
      NCEL=NC1
      HHCM=ALCAN*100.
C     DPMED=WNEUT/(CANN*HHCM*DEPZ*1.E+4)
      DPMED=WTOT/(CANN*HHCM*ASPA*ASPA)
      DO 390 K=1,NCEL
      DPMEDK=DPMED*PROFLU(K)
      ALXEFK=VLAMXE+SIGXE(K)*DPMEDK/EEF(K)
      GISFPK=GISF(K)*EEF(K)*DPMEDK
      IF(LSTAZ) THEN
      ESP=VLAMIO*ABS(TPAS)
      ESQ=ALXEFK*ABS(TPAS)
      EVAT=0.
      IF(ESP.LT.150.) EVAT=1./EXP(ESP)
      EAAT=0.
      IF(ESQ.LT.150.) EAAT=1./EXP(ESQ)
       VIO(K)=GISFPK*(1.-EVAT)/(VLAMIO*EEF(K))
       XE(K)=GISFPK*(1.-EAAT)/(ALXEFK*EEF(K))-
     &       GISFPK*(EVAT-EAAT)/
     &       ((ALXEFK-VLAMIO)*EEF(K))
      ELSE
C         VIOV(K)=VIO(K)
C         XEV(K)=XE(K)
       EXPIO=EXP(-VLAMIO*DTJ)
       EXPXE=EXP(-ALXEFK*DTJ)
       VIO(K)=VIOV(K)*EXPIO+GISFPK*(1.-EXPIO)/(VLAMIO*EEF(K))
       XE(K)=XEV(K)*EXPXE+GISFPK*(1.-EXPXE)/(ALXEFK*EEF(K))+
     &       (VIOV(K)-GISFPK/(VLAMIO*EEF(K)))*
     &       (VLAMIO/(ALXEFK-VLAMIO))*(EXPIO-EXPXE)
      ENDIF
  390 CONTINUE
      IF(LSTAZ) THEN
       WRITE(NWRITE,*) 'CONC. IO',(VIO(K),K=1,NCEL)
       WRITE(NWRITE,*) 'CONC. XE',(XE(K),K=1,NCEL)
       WRITE(NWRITE,*) 'DENSITE P FISSION=',DPMED
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE SIGMAZ(RO,TEM,BO,ILIBX,KAX,SG,D,EEF,ENF,AKF,AL,BE,
     &                  VEL,AKFCEL,NRITM,COES1,COED1,COENF1,COEKFT,
     $                  COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     *                  ALFDOP,ALFMOD,ALFBOR,COEXE1,DSGXE,SIGXEL,
     !                  GISFL,SIGXE,GISF)
C-----------------------------------------------------------------------
C     CALCOLA LE COSTANTI NUCLEARI ED I PARAMETRI CINETICI ASSIALI
C     MEDI AD 1 GRUPPO ENERGETICO
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LSTAZ,LFORMA,LIQS3,LDUMMI
C
      DIMENSION D(*),SG(*),ENF(*),EEF(*),AKF(*),AKFCEL(*),
     &          BE(NRITM,*),AL(NRITM,*),DSGXE(*),SIGXE(*),GISF(*)
      DIMENSION COES1(NLIBM,NCM,*),VELOC(NLIBM),COEXE1(NLIBM,NCM,*),
     &          COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),GISFL(NLIBM,*),
     %          COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),
     $          RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),SIGXEL(NLIBM,*)
C
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
C
      RO1=RO*1.E-03
C
C     COSTANTI MEDIE DI DECADIMENTO E FRAZIONI MEDIE DI NEUTRONI RITARDA
C
      DO 10 JJ=1,NRIT
      AL(JJ,KAX)=RLAM(ILIBX,KAX,JJ)
      BE(JJ,KAX)=RBETA(ILIBX,KAX,JJ)
   10 CONTINUE
C
C     SEZIONE D'URTO MICROSCOPICA DI CATTURA DELLO XENO E TASSO DI
C     PRODUZIONE DELLO IODIO PER FISSIONE
C
      SIGXE(KAX)=SIGXEL(ILIBX,KAX)
      IF(LSTAZ) GISF(KAX)=GISFL(ILIBX,KAX)                              
C
C     COEFFICIENTE DI DIFFUSIONE MEDIO
C                                                                       
      D(KAX)=COED1(ILIBX,KAX,1)*TEM*TEM+COED1(ILIBX,KAX,2)*TEM+
     &       COED1(ILIBX,KAX,3)*RO1*RO1+COED1(ILIBX,KAX,4)*RO1+
     &       COED1(ILIBX,KAX,5)*BO+COED1(ILIBX,KAX,6)
C
C     SEZIONE D'URTO MACROSCOPICA DI ASSORBIMENTO (A MENO DELLO XENO)
C
      SG(KAX)=COES1(ILIBX,KAX,1)*TEM*TEM+COES1(ILIBX,KAX,2)*TEM+
     &        COES1(ILIBX,KAX,3)*RO1*RO1+COES1(ILIBX,KAX,4)*RO1+
     &        COES1(ILIBX,KAX,5)*BO+COES1(ILIBX,KAX,6)
C                                                                       
C     SEZIONE D'URTO MACROSCOPICA DI FISSIONE MOLTIPLICATA PER
C     L'ENERGIA MEDIA LIBERATA PER FISSIONE
C
      EEF(KAX)=COEEF1(ILIBX,KAX,1)*TEM*TEM+COEEF1(ILIBX,KAX,2)*TEM+     
     &         COEEF1(ILIBX,KAX,3)*RO1*RO1+COEEF1(ILIBX,KAX,4)*RO1+
     &         COEEF1(ILIBX,KAX,5)*BO+COEEF1(ILIBX,KAX,6)
C                                                                       
C     SEZIONE D'URTO MACROSCOPICA DI FISSIONE MOLTIPLICATA PER
C     IL NUMERO MEDIO DI NEUTRONI LIBERATI PER FISSIONE                 
C
      ENF(KAX)=COENF1(ILIBX,KAX,1)*TEM*TEM+COENF1(ILIBX,KAX,2)*TEM+
     &         COENF1(ILIBX,KAX,3)*RO1*RO1+COENF1(ILIBX,KAX,4)*RO1+
     &         COENF1(ILIBX,KAX,5)*BO+COENF1(ILIBX,KAX,6)
C
C     COSTANTE DI MOLTIPLICAZIONE INFINITA TERMICA                      
C
      AKFCEL(KAX)=COEKFT(ILIBX,KAX,1)*TEM*TEM+COEKFT(ILIBX,KAX,2)*TEM+  
     &            COEKFT(ILIBX,KAX,3)*RO1*RO1+COEKFT(ILIBX,KAX,4)*RO1+
     &            COEKFT(ILIBX,KAX,5)*BO+COEKFT(ILIBX,KAX,6)            
C
C     COSTANTE DI MOLTIPLICAZIONE INFINITA                              
C
      AKF(KAX)=ENF(KAX)/SG(KAX)
C
C     COEFFICIENTE DI CONTROREAZIONE 'DOPPLER'                          
C
      ALFDOP=((2.*COENF1(ILIBX,KAX,1)*TEM+COENF1(ILIBX,KAX,2))*SG(KAX)
     &      -(2.*COES1(ILIBX,KAX,1) *TEM+COES1(ILIBX,KAX,2))*ENF(KAX))
     *      /(SG(KAX)*SG(KAX))                                          
C
C     COEFFICIENTE DI CONTROREAZIONE DEL MODERATORE                     
C
      ALFMOD=((2.*COENF1(ILIBX,KAX,3)*RO1+COENF1(ILIBX,KAX,4))*SG(KAX)
     &      -(2.*COES1(ILIBX,KAX,3) *RO1+COES1(ILIBX,KAX,4))*ENF(KAX))
     *      /(SG(KAX)*SG(KAX))
C                                                                       
C     COEFFICIENTE DI CONTROREAZIONE DEL BORO
C                                                                       
      ALFBOR=(COENF1(ILIBX,KAX,5)*SG(KAX)-COES1(ILIBX,KAX,5)*ENF(KAX))
     &       /(SG(KAX)*SG(KAX))
      RETURN
C
      ENTRY SIGXEZ(RO,TEM,BO,ILIBX,KAX,NLIBM,NCM,COEXE1,DSGXE)
C
C     DELTA SIGMA DI ASSORBIMENTO DOVUTO ALLO XENO INIZIALE
C     (TALE CONTRIBUTO RESTA COSTANTE NEL CORSO DI UN TRANSITORIO)
C
      IF(LSTAZ) THEN
      RO1=RO*1.E-03
      DSGXE(KAX)=COEXE1(ILIBX,KAX,1)*TEM*TEM+COEXE1(ILIBX,KAX,2)*TEM+
     &           COEXE1(ILIBX,KAX,3)*RO1*RO1+COEXE1(ILIBX,KAX,4)*RO1+
     &           COEXE1(ILIBX,KAX,5)*BO+COEXE1(ILIBX,KAX,6)
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CONUC(ALBA,BO,TEM,RO,ALT,CEFI,PH,D,SG,ENF,EEF,AKF,
     &                 AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,
     &                 FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %                 COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     &                 ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,
     !                 SIGXEL,GISFL)
C-----------------------------------------------------------------------
C     INDIVIDUA LE DUE LIBRERIE DI BASE DA UTILIZZARE NODO PER NODO
C     PER IL CALCOLO DELLE COSTANTI NUCLEARI MEDIE ASSIALI
C-----------------------------------------------------------------------
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LSTAZ,LFORMA,LIQS3,LDUMMI
C
      DIMENSION ALBA(*),CEFI(*),TEM(*),RO(*),PH(*),ALT(*),D(*),SG(*),
     $          ENF(*),EEF(*),AKF(*),AKFCEL(*),BE(NRITM,*),AL(NRITM,*),
     &          DSGXE(*),SIGXE(*),GISF(*)
      DIMENSION FCNZ(*),ILIB1(NCNT),ILIB2(NCNT),COES1(NLIBM,NCM,*),
     &          COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),
     %          COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),GISFL(NLIBM,*),
     &          RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),SIGXEL(NLIBM,*),
     &          VELOC(NLIBM),ALJ(*),BEJ(*),COEXE1(NLIBM,NCM,*)
C
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      NCEL=NC1
      JALF=0
      IF(LSTAZ) THEN
      IF(.NOT.LREGIM) GO TO 4
C     INIZIALIZZAZIONE DEL COEFFICIENTE DI DIFFUSIONE IN REGIMAZIONE
      DO 3 K=1,NCEL
      RO1=RO(K)*1.E-03
      D(K)=COED1(1,K,1)*TEM(K)*TEM(K)+COED1(1,K,2)*TEM(K)+
     &     COED1(1,K,3)*RO1*RO1+COED1(1,K,4)*RO1+
     &     COED1(1,K,5)*BO+COED1(1,K,6)
    3 CONTINUE
    4 CONTINUE
C     VELOCITA' NEUTRONICA MEDIA
      VEL1=0.
      DO 389 KL=1,NLIB
      VEL1=VEL1+VELOC(KL)
  389 CONTINUE
      VEL1=VEL1/FLOAT(NLIB)
      VEL=1./VEL1
      ENDIF
      DO 5 K=1,NCEL
      KK=NCEL-K+1
      KK1=KK-1
      FCNZ(KK)=0.
      ILIB1(KK)=1
      ILIB2(KK)=2
      DO 10 J=1,NG
      INDEX=0
      IF(ALBA(J).GE.ALCAN*100.) GO TO 100
      CEFIJ1=0.0
      IF(KK1.GT.0) CEFIJ1=CEFI(KK1)
      IF(ALBA(J).LE.CEFIJ1) THEN
      ILIB1(KK)=ILIB1(KK)+1
      ILIB2(KK)=ILIB2(KK)+1
      IF(ILIB2(KK).GT.NLIB) ILIB2(KK)=NLIB
      INDEX=1
      ELSE IF(ALBA(J).LE.CEFI(KK)) THEN
      HINS=CEFI(KK)-ALBA(J)
      CALL CALCON(ALT,HINS,KK,PH,D,AINS)
      FCNZ(KK)=AINS
      ENDIF
      IF(INDEX.EQ.0) GO TO 100
   10 CONTINUE
  100 CONTINUE
      FCNZ(KK)=FCNZ(KK)*CF
    5 CONTINUE
C      WRITE(NWRITE,111) (ILIB1(K),K=1,NCEL)
C      WRITE(NWRITE,101) (ILIB2(K),K=1,NCEL)
  111 FORMAT(1X,'ILIB1(K),K=1,NCEL)  ',30I3)
  101 FORMAT(1X,'ILIB2(K),K=1,NCEL)  ',30I3)
  222 FORMAT(8(1X,G12.5))
C
      ENTRY CONUC1(ALBA,BO,TEM,RO,ALT,CEFI,PH,D,SG,ENF,EEF,AKF,
     &             AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,
     &             FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %             COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     &             ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,
     !             SIGXEL,GISFL)
C
      ALFAD=0.0
      ALFAM=0.0
      ALFAB=0.0
      PHALT=0.0
C
C     CALCOLO COSTANTI RELATIVE ALLA LIBRERIA DI BASE ILIB1
C
C      WRITE(NWRITE,222) (FCNZ(K),K=1,NCEL)
      DO 50 KK=1,NC1
      CALL SIGMAZ(RO(KK),TEM(KK),BO,ILIB1(KK),KK,SG,D,EEF,ENF,
     &            AKF,AL,BE,VEL,AKFCEL,NRITM,COES1,COED1,COENF1,
     $            COEKFT,COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     *            ALFD1,ALFM1,ALFB1,COEXE1,DSGXE,SIGXEL,GISFL,
     !            SIGXE,GISF)
      D11=D(KK)
      SG11=SG(KK)
C      DSGX11=DSGXE(KK)
      EEF11=EEF(KK)
      ENF11=ENF(KK)
      AKFT1=AKFCEL(KK)
      AKF11=AKF(KK)
      DO 278 J=1,NRIT
      ALJ(J)=AL(J,KK)
  278 BEJ(J)=BE(J,KK)
      SIGX11=SIGXE(KK)
      GISF11=GISF(KK)
C
C     CALCOLO COSTANTI RELATIVE ALLA LIBRERIA DI BASE ILIB2
C
      CALL SIGMAZ(RO(KK),TEM(KK),BO,ILIB2(KK),KK,SG,D,EEF,ENF,
     &            AKF,AL,BE,VEL,AKFCEL,NRITM,COES1,COED1,COENF1,
     $            COEKFT,COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     *            ALFD2,ALFM2,ALFB2,COEXE1,DSGXE,SIGXEL,GISFL,
     !            SIGXE,GISF)
      SG(KK)=SG11*(1.-FCNZ(KK))+SG(KK)*FCNZ(KK)
C      IF(LSTAZ) DSGXE(KK)=DSGX11*(1.-FCNZ(KK))+DSGXE(KK)*FCNZ(KK)
      D(KK)=D11*(1.-FCNZ(KK))+D(KK)*FCNZ(KK)
      EEF(KK)=EEF11*(1.-FCNZ(KK))+EEF(KK)*FCNZ(KK)
      ENF(KK)=ENF11*(1.-FCNZ(KK))+ENF(KK)*FCNZ(KK)
      AKFCEL(KK)=AKFT1*(1.-FCNZ(KK))+AKFCEL(KK)*FCNZ(KK)
      AKF(KK)=AKF11*(1.-FCNZ(KK))+AKF(KK)*FCNZ(KK)
      DO 277 J=1,NRIT
      AL(J,KK)=ALJ(J)*(1.-FCNZ(KK))+AL(J,KK)*FCNZ(KK)
  277 BE(J,KK)=BEJ(J)*(1.-FCNZ(KK))+BE(J,KK)*FCNZ(KK)
      SIGXE(KK)=SIGX11*(1.-FCNZ(KK))+SIGXE(KK)*FCNZ(KK)
      IF(LSTAZ) GISF(KK)=GISF11*(1.-FCNZ(KK))+GISF(KK)*FCNZ(KK)
C
      IF(LSTAZ.OR.JALF.EQ.1) THEN
C
C     CALCOLO DEI COEFFICIENTI DI CONTROREAZIONE DOPPLER , MODERATORE E
C
      ALFDKK=ALFD1*(1.-FCNZ(KK))+ALFD2*FCNZ(KK)
      ALFAD=ALFAD+ALFDKK*PH(KK)*ALT(KK)
      ALFMKK=ALFM1*(1.-FCNZ(KK))+ALFM2*FCNZ(KK)
      ALFAM=ALFAM+ALFMKK*PH(KK)*ALT(KK)
      ALFBKK=ALFB1*(1.-FCNZ(KK))+ALFB2*FCNZ(KK)
      ALFAB=ALFAB+ALFBKK*PH(KK)*ALT(KK)
C      WRITE(NWRITE,*) KK,' ALFDOP=',ALFDKK,' ALFMOD=',ALFMKK,
C     &                   ' ALFBOR=',ALFBKK
C      WRITE(NWRITE,*) 'ALFM1=',ALFM1,'ALFM2=',ALFM2,'FCNZ(K)=',FCNZ(KK)
      PHALT=PHALT+PH(KK)*ALT(KK)
      ENDIF
C
   50 CONTINUE
C
      IF(LSTAZ.OR.JALF.EQ.1) THEN
      ALFAD=ALFAD*1.E+05/PHALT
      ALFAM=ALFAM*1.E+05/PHALT
      ALFAB=ALFAB*1.E+05/PHALT
C      WRITE(NWRITE,*) 'DSGXE 1 =',(DSGXE(K),K=1,NCEL)
C      WRITE(NWRITE,67) ALFAD,ALFAM,ALFAB
C      WRITE(30,67) ALFAD,ALFAM,ALFAB
   67 FORMAT(1X,'ALFD=',G12.5,1X,'ALFM=',G12.5,1X,'ALFB=',G12.5)
      ENDIF
C
      JALF=1
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CONUS(JRESTI,NCEL,NRIT,TEM,TEMC,TEMP,TREF,RO,
     &                 BOR,XE,SG,DSGXE,ENF,EEF,D,AKF,AKFCEL,PHS,GISF,
     &                 SIGXE,AL,BE,VEL,NRITM,PAS1,PAS2,ALT)
C-----------------------------------------------------------------------
C     GESTION DU CALCUL DES CONSTANTES NUCLEAIRES A DEUX GROUPES
C     UTILISANT LES BIB DE CONTREREACTIONS DE L'EDF/SEPTEN.
C     COLLAPSATION A 1 GROUPE D'ENERGIE.
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
C
      DIMENSION TEM(*),TEMC(*),TEMP(*),TREF(*),RO(*),XE(*),SG(*),D(*),
     &          DSGXE(*),ENF(*),EEF(*),AKF(*),AKFCEL(*),PHS(*),GISF(*),
     &          SIGXE(*),AL(NRITM,*),BE(NRITM,*),ALT(*)
C
      DIMENSION SIG(66),REF(10),FON(7),PAR(22),SCR(14)
C
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/PROXE/ALFA2(24),BETA2(24),ALFA3(24),BETA3(24)
      COMMON/TABLKINA/KE(60),IE(60),DSEP(30,66,60),DREF(6,60),NACT(60)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/CLAPLA/NBUC,BUCL(50),B2R1(50),B2R2(50),COEFB1,COEFB2
      COMMON/CHGAP/IHGAP,HGAPI,DPL,XR,ZEIT,TUO2,DELTU,WXY
      COMMON/RIFLE$/SF(2),DF(2),ST(2),DT(2),RRIF(2),DUMMI34(NW-2*5)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON/CROA/CORBO
      COMMON/CGRAPP/NGRA,NOG(15),AR(15,15),ALF2,ALFR,ALFF1,ALFF2
      COMMON/CFIC10/IFIC10,I10
      COMMON/CPPAL/PIN(5),P(5),C(2),TMOM
      COMMON/CSERVE/BIDO,SAXE1,SAXE2
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
C     *,CEFB1,CEFB2
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
C
C
C-----------------------------------------------------------------------
C     NCELRF = NUMERO DE CELLULE DU REFLECTEUR AXIAL (ACTUELLMENT = 2)
C     SCHEMATISATION AXIALE :
C     K = 1  --->  REFLECTEUR AXIAL INFERIEUR
C     K = 2,NCEL+1  --->  CELLULE ACTIVE DU COEUR
C     K = NCEL+2  --->  REFLECTEUR AXIAL SUPERIEUR
C-----------------------------------------------------------------------
C
C INITIALISATION PARAMETRES DELTU ET CORBO POUR NEWCRN
      WRITE(NWRITE,*)' PAS D''INSERTION DES BARRES G/N=',PAS1,PAS2
      IF(JRESTI.EQ.1) THEN
      CALL INICRN
      CALL INIBAR
      ENDIF
      IF(LSTAZ) THEN
      DELTU=1.
      CORBO=1.03
      IRF1=NCELRF/2
      IRF2=NCEL+IRF1+1
      IF(NCELRF.NE.2) THEN
      WRITE(NWRITE,66) NCELRF
   66 FORMAT(1X,'ATTENTION! NOMBRE DE CELLULES DU REFLECTEUR AXIAL ',
     &          'DIFFERENT DE 2',/,1X,'NOMBRE DE CELLULES =',I2,/,
     &          1X,'OPTION ACTUELLEMENT NON PREVUE',/,1X,
     &          'LE PROGRAME S''ARRETE')
      STOP ' NUMERO CELLE RIFLETTORE ASSIALE DIVERSO DA 2 (SUB. CONUS)'
      ENDIF
      ENDIF
C
C-----------------------------------------------------------------------
C     SCHEMATISATION ENERGETIQUE:
C     G = 1  --->  GROUPE RAPIDE
C     G = 2  --->  GROUPE THERMIQUE
C
C     SIG(14) = SEZIONI D'URTO EFFICACI DI RIFERIMENTO
C     PAR(22) = COEFFICIENTI DELLE CONTROREAZIONI "SEPTEN"
C     REF(10) = PARAMETRI DI FUNZIONAMENTO DI RIFERIMENTO
C     FON(7)  = PARAMETRI DI FUNZIONAMENTO CORRENTI DEL CASO CONSIDERATO
C
C     SCR(14) = SEZIONI D'URTO EFFICACI DOPO LE CONTROREAZIONI
C-----------------------------------------------------------------------
C
C     CARICAMENTO COSTANTI DI LIBRERIA PER IL RIFLETTORE INFERIORE
      DO 10 I=1,66
   10 SIG(I)=DDS(I,IRF1)
      DO 11 I=1,5
   11 REF(I)=DREF(I,IRF1)
      FON(5)=ROH2OI*1.E-03
      FON(6)=BOR
C     CALCOLO COSTANTI DEL RIFLETTORE ASSIALE INFERIORE
      CALL CRNRF(SIG,REF,FON)
C     CARICAMENTO COSTANTI DI RIFL. PER CALCOLO ALBEDO VELOCE E TERMICA
      SF(1)=SIG(3)+SIG(4)
      DF(1)=SIG(1)
      ST(1)=SIG(9)
      DT(1)=SIG(7)
      RRIF(1)=SIG(4)
      IF(LSTAZ) THEN
      WRITE(NWRITE,*) 'FON(5)=ROH2OI=',FON(5)
      WRITE(NWRITE,*) 'RIFL. INF ',SF(1),DF(1),ST(1),DT(1)
      ENDIF
C     CARICAMENTO COSTANTI DI LIBRERIA PER LE NCEL CELLE ASSIALI ATTIVE
      IF (JRESTI.EQ.1) THEN
         DO 625 K=1,NCEL
  625    RFIS21(K)=FLU2T(K)/FLU1V(K)
         D11=DDS(1,IRF1+1)
         D21=DDS(7,IRF1+1)
         D1N=DDS(1,NCEL+IRF1)                                           
         D2N=DDS(7,NCEL+IRF1)
      ENDIF                                                             
C---- EFFICACITE` DES BARRES SUR LA COSTANTE D'ABSORBSION TERMIQUE
         IF(I10.EQ.1) THEN                                              
         DO 487 I=1,15
  487    DSIGB2(I)=DSIGB1(I)*ALF2
         ENDIF
C   PAS D'EXTRACTION COURANT DES GRAPPES GRISES G1,G2,N1,N2
C   (P(1)=225 GRAPPES TOUTES EXTRAITES  / P(1)=-395 TOUTES INSEREES)
      P(1)=PAS1
C   PAS D'EXTRACTION COURANT DES GRAPPES R
C   (P(2)=225 GRAPPES TOUTES EXTRAITES  / P(2)=0 TOUTES INSEREES)
      P(2)=PAS2
      IF(P(2).LT.0.) STOP'VALEUR DE P(2) NON PREVUE EN MODE GRIS'
C   DECOUPAGE DU COEUR EN REGION COMPTE TENU DES CONFIG DE BARRES
      CALL REGION
C
      NCALCO=0
 1000 CONTINUE
      NCALCO=NCALCO+1
C
C    EXPANSION DU FLUX A 2 GROUPES ET CALCUL DU FLUX D' INTERFACE
      CALL SPLITF(PHS,PHR11,PHR1N,PHR21,PHR2N,RFIS21,PHR1,PHR2,ALT,NCEL)
C
      PHTOT=0.
      VEL1GM=0.
      IF(JRESTI.EQ.1) THEN
      WRITE(NWRITE,*) ' CALCOLO COSTANTI A 2G  N. =',NCALCO
       FI1M=0.
       FI2M=0.
       D1MINV=0.
       D2MINV=0.
       SF1M=0.
       SF2M=0.
       SA1M=0.
       SA2M=0.
       R1M=0.
      ENDIF
C >>>  DEBUT BOUCLE SUR LES MAILLES ACTIVES  <<<
      DO 20 K=IRF1+1,NCEL+IRF1
      IF(K.EQ.IRF1+1.AND.LSTAZ) WRITE(NWRITE,100)
C     COSTANTI NUCLEARI A 2 GRUPPI ENERGETICI
      K1=K-1
      DO 21 I=1,14
   21 SIG(I)=DDS(I,K)
C     COEFFICIENTI DELLE CONTROREAZIONI
      DO 22 I=1,22
   22 PAR(I)=DDS(36+I,K)
C     PARAMETRI DI RIFERIMENTO
      DO 23 I=1,5
   23 REF(I)=DREF(I,K)
      REF(6)=DDS(33,K)
      REF(7)=DDS(35,K)
      REF(8)=DDS(34,K)
      REF(9)=DDS(36,K)
      REF(10)=DDS(32,K)
C     PARAMETRI DI FUNZIONAMENTO CORRENTE (NEL CALCOLO DEI RESTI
C     SI UTILIZZANO I VALORI DI RIFERIMENTO)
      IF(JRESTI.EQ.1) THEN
      REF1=TEM(K1)
      REF2=TREF(K1)
      FON(1)=(REF1-REF2)/DELTU+REF2
      FON(2)=FON(1)
      ELSE IF(JRESTI.EQ.0) THEN
      FON(1)=TEMC(K1)
      FON(2)=TEMP(K1)
      ENDIF
      FON(3)=TREF(K1)
      FON(4)=DREF(3,K)
      FON(5)=RO(K1)*1.E-03
      FON(6)=BOR
      FON(7)=XE(K1)*1.E-24
      IF (.NOT.LSTAZ) FON(7)=(ALFA3(K1)+BETA3(K1)*XE(K1))*1.E-24
      IF(LSTAZ) THEN
      WRITE(NWRITE,*) 'K',K ,'  SCR SANS BARRES ET AVEC BARRES '
      WRITE(NWRITE,222) (FON(J),J=1,7)
  222 FORMAT(7(1X,G12.5))
C     WRITE(NWRITE,*) 'REF=',(REF(J),J=1,10)
C     WRITE(NWRITE,*) 'PAR=',(PAR(J),J=1,22)
C     WRITE(NWRITE,*) 'SIG=',(SIG(J),J=1,14)
      ENDIF
C
C     CALCUL CONSTANTES NUCLEAIRES DES TRANCHES ACTIVES AXIALES
      CALL NEWCRN(SIG,PAR,REF,FON,SCR)
C     SIGMA FISSION RAPIDE ET THERMIQUE SCR(2),SCR(8)
      SCR(2)=SCR(5)*SIG(2)/SIG(5)
      SCR(8)=SCR(11)*SIG(8)/SIG(11)
C     CALCUL DES TERMES CORRECTIFS DES SECTIONS EFFICACES MACROSC.
C     (RAPIDES ET THERMIQUES) POUR LES DIVERSES CONFIG. DE BARRES
      CALL DSABAR(K1,DSA1G,DSA2G,DSIRG,DSF1G,DSF2G)
      IF(LSTAZ) WRITE(NWRITE,101)(SCR(I),I=1,14)
      SCR(3)=SCR(3)+DSA1G
      SCR(9)=SCR(9)+DSA2G
      SCR(4)=SCR(4)+DSIRG
      SCR(5)=SCR(5)+DSF1G
      SCR(11)=SCR(11)+DSF2G
      SCR(10)=SCR(5)/(SCR(3)+SCR(4))+(SCR(4)/(SCR(3)+SCR(4)))*SCR(11)/
     &     SCR(9)
      IF(LSTAZ) WRITE(NWRITE,101) (SCR(J),J=1,14)
      IF(K.EQ.IRF1) THEN
      D11=SCR(1)
      D21=SCR(7)
      ELSE IF(K.EQ.NCEL+IRF1) THEN
      D1N=SCR(1)
      D2N=SCR(7)
      ENDIF
C     BQR1 E BQR2 SONO SELEZIONATI IN 'EPUINT' IN FUNZIONE DEL BURN-UP
      BQR1Z(K1)=BQR1*(1.+COEFB1*(FON(5)-REF(4))/REF(4))
      BQR2Z(K1)=BQR2*(1.+COEFB2*(FON(5)-REF(4))/REF(4))
      SAXE2=DDS(59,K)*1.E-24
      IF(JRESTI.EQ.1) THEN
C CALCUL DES CONSTANTS MOYENNES AVEC LA FORMULATION LIBELLULE
       FI1M=FI1M+FLU1V(K1)
       D1MINV=D1MINV+FLU1V(K1)/SCR(1)
       SF1M=SF1M+SCR(5)*FLU1V(K1)
       SA1M=SA1M+SCR(3)*FLU1V(K1)
       R1M=R1M+SCR(4)*FLU1V(K1)
       FI2M=FI2M+FLU2T(K1)
       D2MINV=D2MINV+FLU2T(K1)/SCR(7)
       SF2M=SF2M+SCR(11)*FLU2T(K1)
       SA2M=SA2M+SCR(9)*FLU2T(K1)
      ENDIF
      AVEL1=DDS(16,K)
      AVEL2=DDS(17,K)
      BQZ1K=BQZ1(K1)
      BQZ2K=BQZ2(K1)
      BQR1K=BQR1Z(K1)
      BQR2K=BQR2Z(K1)
C
C     MEMORIZZAZIONE DELLE COSTANTI 'SCR' DI CELLA A DUE GRUPPI CALCOLAT
C     (LE SEZIONI DI ASSORBIMENTO SONO COMPRENSIVE DELLE FUGHE RADIALI)
C
      VEL1=1./AVEL1
      VEL2=1./AVEL2
      DIF1(K1)=SCR(1)
      FIS1(K1)=SCR(2)
      ASS1(K1)=SCR(3)+SCR(1)*BQR1K
      RIM1(K1)=SCR(4)
      ENFIS1(K1)=SCR(5)
      EEFIS1(K1)=SCR(6)*1.6021E-13
      DIF2(K1)=SCR(7)
      FIS2(K1)=SCR(8)
      ASS2(K1)=SCR(9)+SCR(7)*BQR2K
      AKINF(K1)=SCR(10)
      ENFIS2(K1)=SCR(11)
      EEFIS2(K1)=SCR(12)*1.6021E-13
C
C     COLLASSAMENTO DELLE COSTANTI 'SCR' AD 1 GRUPPO ENERGETICO
C
      CALL COLLAX(SCR,AVEL1,AVEL2,SG1,DSGXE1,ENF1,EEF1,D1,AKF1,AKFTH1,
     &            PHS1,EF1,VELO1,BQR1K,BQR2K,K,BQZ1K,BQZ2K,BQE2,JRESTI,
     &            FLU1V,FLU2T,RFIS21,SAXE1,SAXE2,SAX1G,PHR1,PHR2)
      SG(K1)=SG1
      DSGXE(K1)=DSGXE1
      ENF(K1)=ENF1
      EEF(K1)=EEF1*1.6021E-13
      EF(K1)=EF1
      D(K1)=D1
      AKF(K1)=AKF1
      AKFCEL(K1)=AKFTH1
      SIGXE(K1)=SAX1G
      PHTOT=PHTOT+PHS(K1)
      VEL1GM=VEL1GM+VELO1*PHS(K1)
   20 CONTINUE
      IF(JRESTI.EQ.1) THEN
      D1M=FI1M/D1MINV
      SF1M=SF1M/FI1M
      SA1M=SA1M/FI1M
      R1M=R1M/FI1M
      D2M=FI2M/D2MINV
      SF2M=SF2M/FI2M
      SA2M=SA2M/FI2M
C CALCUL LAPLACIENS AXIAUX LIBELLULE
      BQZ1M=(SF1M/AKEFFL+SF2M*FI2M/(FI1M*AKEFFL)-SA1M-R1M-D1M*BQR1)/D1M
      BQZ2M=(R1M*FI1M/FI2M-SA2M-D2M*BQR2)/D2M
      WRITE(NWRITE,*) ' K-EFF LIBELLULE =',AKEFFL
      WRITE(NWRITE,*) ' LAPLACIEN AXIAL RAPIDE =',BQZ1M
      WRITE(NWRITE,*) ' LAPLACIEN AXIAL THERMIQUE =',BQZ2M
      DO 227 K=IRF1+1,NCEL+IRF1
      K1=K-1
      BQZ1(K1)=BQZ1M
      BQZ2(K1)=BQZ2M
  227 CONTINUE
      ENDIF
C
      IF(JRESTI.EQ.1.AND.NCALCO.EQ.1) GOTO 1000
C
C   CALCOLO DELLA VELOCITA' NEUTRONICA AD 1 GRUPPO MEDIA DI NOCCIOLO
       VEL1GM=VEL1GM/PHTOT
       VEL=1./VEL1GM
C   CARICAMENTO COSTANTI RELATIVE AI VELENI (XE,I) E PARAMETRI CINETICI
       DO 25 K=IRF1+1,NCEL+IRF1
        K1=K-1
        GISF(K1)=DDS(31,K)
        GISF(K1)=GISF(K1)*EF(K1)/EEF(K1)
         DO 26 I=1,NRIT
         AL(I,K1)=DDS(I+17,K)
         BE(I,K1)=DDS(I+23,K)
   26    CONTINUE
   25   CONTINUE
C     CARICAMENTO COSTANTI DI LIBRERIA PER IL RIFLETTORE SUPERIORE
      DO 30 I=1,66
   30 SIG(I)=DDS(I,IRF2)
      DO 31 I=1,5
   31 REF(I)=DREF(I,IRF2)
      FON(5)=ROH2OU*1.E-03
      FON(6)=BOR
C     CALCOLO COSTANTI DEL RIFLETTORE ASSIALE SUPERIORE
      CALL CRNRF(SIG,REF,FON)
C     CARICAMENTO COSTANTI DI RIFL. PER CALCOLO ALBEDO VELOCE E TERMICA
      SF(2)=SIG(3)+SIG(4)
      DF(2)=SIG(1)
      ST(2)=SIG(9)
      DT(2)=SIG(7)
      RRIF(2)=SIG(4)
      IF(LSTAZ) THEN
      WRITE(NWRITE,*) 'RIFL. SUP ',SF(2),DF(2),ST(2),DT(2)
      WRITE(NWRITE,*) 'FON(5)=ROH2OU=',FON(5)
      ENDIF
C
  100 FORMAT(15X,'COSTANTI NUCLEARI A 2 GRUPPI CALCOLATE',/,15X,
     &    ' 1) D1    2) F1    3) S1    4) R    5) NU*F1    6) E1*F1',/,
     &15X,' 7) D2    8) F2    9) S2   10) K-& 11) NU*F2   12) E2*F2',/,
     &15X,'13) *    14) * ',/)
  101 FORMAT(6(1X,G13.6))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CALRIF
C
C-----------------------------------------------------------------------
C     QUESTA SUBROUTINE CALCOLA  LA RELAZIONE TRA LA CORRENTE ALLA
C     INTERFACCIA CORE-RIFLETTORE E IL FLUSSO IN TALE INTERFACCIA.
C     TALE RELAZIONE E' DATA DALLA MATRICE 2X2 Q.
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/RIFLE$/SRIF1(2),DRIF1(2),SRIF2(2),DRIF2(2),RRIF(2)
     &             ,DUMMI34(NW-2*5)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON /MATRIF/FT(8),AP(8),GT(8),FT1(8),F01(8),G01(8),GT1(8),
     &               AP4(8),AP5(8),S(8),D(8),RM(8),Q(8),TTINF(4),
     &               TTSUP(4),PM1(8),RG(8),VG(8),OMR(8),DC(8),RN(8)
C
C---- ALTEZZE DEI RIFLETTORI ASSIALI SUPERIORI ED INFERIORI
      TT(1)=20.
      TT(2)=20.
C
      QK1(1)=SRIF1(1)/DRIF1(1)
      QK1(2)=SRIF1(2)/DRIF1(2)
      QK2(1)=SRIF2(1)/DRIF2(1)
      QK2(2)=SRIF2(2)/DRIF2(2)
C     COSTS=1.
C      WRITE(6,654)QK1,QK2
  654 FORMAT(1X,'QK1 QK2',4E12.5)
      DO 1 I=1,4
      FT(I)=0.
      AP(I)=0.
      GT(I)=0.
      FT1(I)=0.
      F01(I)=0.
      G01(I)=0.
      GT1(I)=0.
      AP4(I)=0.
      AP5(I)=0.
      S(I)=0.
      D(I)=0.
    1 CONTINUE
C     MATRICE S
      S(1)=1.
      S(2)=-RRIF(1)/(DRIF2(1)*(QK1(1)-QK2(1)))
      S(4)=1.
      S(5)=1.
      S(6)=-RRIF(2)/(DRIF2(2)*(QK1(2)-QK2(2)))
      S(8)=1.
C     MATRICE D
      D(1)=DRIF1(1)
      D(4)=DRIF2(1)
      D(5)=DRIF1(2)
      D(8)=DRIF2(2)
      RK11=SQRT(QK1(1))
      RK1T1=RK11*TT(1)
      RK21=SQRT(QK2(1))
      RK2T1=RK21*TT(1)
      RK12=SQRT(QK1(2))
      RK1T2=RK12*TT(2)
      RK22=SQRT(QK2(2))
      RK2T2=RK22*TT(2)
C     MATRICE F CALCOLATA PER UNO SPSSORE T
      FT(1)=EXP(-RK1T1)
      FT(4)=EXP(-RK2T1)
      FT(5)=EXP(-RK1T2)
      FT(8)=EXP(-RK2T2)
C     MATRICE G CALCOLATA PER UNO SPESSORE T
      GT(1)=COSH(RK1T1)
      GT(4)=COSH(RK2T1)
      GT(5)=COSH(RK1T2)
      GT(8)=COSH(RK2T2)
C     DERIVATA DELLA MATRICE F CALCOLATA PER UNO SPESSORE T
      FT1(1)=-RK11*FT(1)
      FT1(4)=-RK21*FT(4)
      FT1(5)=-RK12*FT(5)
      FT1(8)=-RK22*FT(8)
C     DERIVATA DELLA MATRICE G CALCOLATA PER UNO SPESSORE T
      GT1(1)=RK11*SINH(RK1T1)
      GT1(4)=RK21*SINH(RK2T1)
      GT1(5)=RK12*SINH(RK1T2)
      GT1(8)=RK22*SINH(RK2T2)
      AP(1)=2.
      AP(4)=2.
      AP(5)=2.
      AP(8)=2.
C     WRITE(6,243)S,D,FT,GT,FT1,GT1,AP
  243 FORMAT(/,1X,6E12.5)
      CALL PERMAT(S,GT1,AP4)
C     WRITE(6,243)AP4
      CALL PERMAT(D,AP4,AP5)
C     WRITE(6,243)AP5
      CALL PERMAT(AP,AP5,AP4)
C     WRITE(6,243)AP4
      CALL PERMAT(S,GT,AP5)
C     WRITE(6,243)AP5
      CALL ADDMAT(AP4,AP5,RM,1.)
C     WRITE(6,243)RM
      CALL INVMAT(RM)
C     WRITE(6,243)RM
      CALL PERMAT(S,FT1,AP4)
C     WRITE(6,243)AP4
      CALL PERMAT(D,AP4,AP5)
C     WRITE(6,243)AP5
      CALL PERMAT(AP,AP5,AP4)
C     WRITE(6,243)AP4
      CALL PERMAT(S,FT,AP5)
C     WRITE(6,243)AP5
      CALL ADDMAT(AP4,AP5,RN,1.)
C     WRITE(6,243)RN
      CALL PERMAT(RM,RN,AP)
C     WRITE(6,243)AP
      DO 2 I=1,8
    2 AP5(I)=0.
      AP5(1)=1.
      AP5(4)=1.
      AP5(5)=1.
      AP5(8)=1.
      CALL ADDMAT(AP5,AP,AP4,-1.)
C     WRITE(6,243)AP4
      CALL PERMAT(S,AP4,PM1)
C     WRITE(6,243)PM1
      CALL INVMAT(PM1)
C     WRITE(6,243)PM1
      F01(1)=-RK11
      F01(4)=-RK21
      F01(5)=-RK12
      F01(8)=-RK22
      CALL PERMAT(F01,PM1,AP4)
C     WRITE(6,243)AP4
      CALL PERMAT(S,AP4,AP5)
C     WRITE(6,243)AP5
      CALL PERMAT(D,AP5,Q)
C     WRITE(6,243)Q
      DO 3 I=1,8
    3 Q(I)=-Q(I)
      CALL INVMAT(Q)
C      WRITE(6,900)Q
  900 FORMAT(1X,'MATRICE Q ',4E12.5,/11X,4E12.5)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE MATT(HZ,NCEL)
C
C-----------------------------------------------------------------------
C
C     QUESTA SUBROUTINE CALCOLA LA RELAZIONE TRA CORRENTE ALLA
C     INTERFACCIA CORE-RIFLETTORE E IL FLUSSO MEDIO NELLA CELLA
C     ADIACENTE AL RIFLETTORE; TALE RELAZIONE E' ESPRESSA DALLA
C     MATRICE TTINF PER IL RIFLETTORE ASSIALE INFERIORE E DALLA
C     MATRICE TTSUP PER IL RIFLETTORE ASSIALE SUPERIORE
C
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DUEG/VEL1,VEL2,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/RIFLE$/SRIF1(2),DRIF1(2),SRIF2(2),DRIF2(2),RRIF(2)
     &             ,DUMMI34(NW-2*5)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON /MATRIF/FT(8),AP(8),GT(8),FT1(8),F01(8),G01(8),GT1(8),
     &               AP4(8),AP5(8),S(8),D(8),RM(8),Q(8),TTINF(4),
     &               TTSUP(4),PM1(8),RG(8),VG(8),OMR(8),DC(8),RN(8)
      DIMENSION HZ(1)
C
      IF(ABS(BUCK1(1)).GT.1.E-8)GO TO 1
      BG1=0.
      RG(1)=1.
      VG(1)=0.
      GO TO 2
    1 IF(BUCK1(1).GT.0.)GO TO 3
      BG1=SQRT(-BUCK1(1))
      UG=BG1*HZ(1)
      RG(1)=SINH(UG)/UG
      VG(1)=(1.-COSH(UG))/UG
      GO TO 2
    3 BG1=SQRT(BUCK1(1))
      UG=BG1*HZ(1)
      RG(1)=SIN(UG)/UG
      VG(1)=(COS(UG)-1.)/UG
    2 IF(ABS(BUCK2(1)).GT.1.E-8)GO TO 4
      BG2=0.
      RG(4)=1.
      VG(4)=0.
      GO TO 5
    4 IF(BUCK2(1).GT.0.)GO TO 6
      BG2=SQRT(-BUCK2(1))
      UG=BG2*HZ(1)
      RG(4)=SINH(UG)/UG
      VG(4)=(1.-COSH(UG))/UG
      GO TO 5
    6 BG2=SQRT(BUCK2(1))
      UG=BG2*HZ(1)
      RG(4)=SIN(UG)/UG
      VG(4)=(COS(UG)-1.)/UG
    5 IF(ABS(BUCK1(NCEL)).GT.1.E-8)GO TO 7
      BG3=0.
      RG(5)=1.
      VG(5)=0.
      GO TO 8
    7 IF(BUCK1(NCEL).GT.0.)GO TO 9
      BG3=SQRT(-BUCK1(NCEL))
      UG=BG3*HZ(NCEL)
      RG(5)=SINH(UG)/UG
      VG(5)=(1.-COSH(UG))/UG
      GO TO 8
    9 BG3=SQRT(BUCK1(NCEL))
      UG=BG3*HZ(NCEL)
      RG(5)=SIN(UG)/UG
      VG(5)=(COS(UG)-1.)/UG
    8 IF(ABS(BUCK2(NCEL)).GT.1.E-8)GO TO 10
      BG4=0.
      RG(8)=1.
      VG(8)=0.
      GO TO 11
   10 IF(BUCK2(NCEL).GT.0.)GO TO 12
      BG4=SQRT(-BUCK2(NCEL))
      UG=BG4*HZ(NCEL)
      RG(8)=SINH(UG)/UG
      VG(8)=(1.-COSH(UG))/UG
      GO TO 11
   12 BG4=SQRT(BUCK2(NCEL))
      UG=BG4*HZ(NCEL)
      RG(8)=SIN(UG)/UG
      VG(8)=(COS(UG)-1.)/UG
C      MATRICE OMEGA
   11 OMR(1)=BG1
      OMR(4)=BG2
      OMR(5)=BG3
      OMR(8)=BG4                                                        
C     MATRICE D
      DC(1)=D1(1)                                                       
      DC(4)=D2(1)
      DC(5)=D1(NCEL)                                                    
      DC(8)=D2(NCEL)
C     WRITE(6,100)                                                      
  100 FORMAT(/1X,'SUBROUTINE MATT')
  101 FORMAT(/1X,6E12.5)
      CALL PERMAT(RG,Q,AP4)
C     WRITE(6,101)AP4
      CALL INVMAT(OMR)
C     WRITE(6,101)OMR
      CALL INVMAT(DC)
C     WRITE(6,101)DC
      CALL PERMAT(OMR,DC,AP5)
C     WRITE(6,101)AP5
      CALL PERMAT(VG,AP5,AP)
C     WRITE(6,101)AP
      CALL ADDMAT(AP4,AP,AP5,-1.)
C     WRITE(6,101)AP5
      CALL INVMAT(AP5)
C     WRITE(6,101)AP5
      DO 13 I=1,4
      TTINF(I)=AP5(I)
      TTSUP(I)=AP5(I+4)
   13 CONTINUE
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE BUCK2G(IND,HZ,EPSB,NCEL)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DUEG/V1K,V2K,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON /MATRIF/FT(8),AP(8),GT(8),FT1(8),F01(8),G01(8),GT1(8),
     &               AP4(8),AP5(8),S(8),D(8),RM(8),Q(8),TTINF(4),
     &               TTSUP(4),PM1(8),RG(8),VG(8),OMR(8),DC(8),RN(8)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION HZ(*)
C                                                                       
C-----------------------------------------------------------------------
C
C     CALCOLO DEI BUCKLINGS VELOCI E TERMICI
C
C-----------------------------------------------------------------------
C
      IND=0
      DO 1 I=1,NCEL
      IF(I.NE.1.AND.I.NE.NCEL)GO TO 2
      IF(I.NE.1)GO TO 3
      CX1=OMED1(1)*FLU1(1)-OMES1(2)*FLU1(2)+TTINF(1)*FLU1(1)+TTINF(3)*
     &    FLU2(1)
      CX2=OMED2(1)*FLU2(1)-OMES2(2)*FLU2(2)+TTINF(2)*FLU1(1)+TTINF(4)*
     &    FLU2(1)
      GO TO 4
    3 CX1=OMES1(NCEL)*FLU1(NCEL)-OMED1(NCEL-1)*FLU1(NCEL-1)+
     &    TTSUP(1)*FLU1(NCEL)+TTSUP(3)*FLU2(NCEL)
      CX2=OMES2(NCEL)*FLU2(NCEL)-OMED2(NCEL-1)*FLU2(NCEL-1)+
     &    TTSUP(2)*FLU1(NCEL)+TTSUP(4)*FLU2(NCEL)
      GO TO 4
    2 CX1=(OMED1(I)+OMES1(I))*FLU1(I)-OMES1(I+1)*FLU1(I+1)-
     &    OMED1(I-1)*FLU1(I-1)
      CX2=(OMED2(I)+OMES2(I))*FLU2(I)-OMES2(I+1)*FLU2(I+1)-
     &    OMED2(I-1)*FLU2(I-1)
    4 CONTINUE
      DEN1=D1(I)*FLU1(I)*HZ(I)
      DEN2=D2(I)*FLU2(I)*HZ(I)
      B1=BUCK1(I)
      B2=BUCK2(I)
      BUCK1(I)=CX1/DEN1
      BUCK2(I)=CX2/DEN2
      B1=ABS(B1-BUCK1(I))
      B2=ABS(B2-BUCK2(I))
      IF(B1.GT.EPSB.OR.B2.GT.EPSB) IND=1
    1 CONTINUE
      IF(IND.EQ.0) THEN
C      WRITE(NWRITE,250) (BUCK1(I),I=1,NCEL)
C      WRITE(NWRITE,260) (BUCK2(I),I=1,NCEL)
  250 FORMAT(20X,'BUCKLING VELOCI',/,6(1X,G12.5))
  260 FORMAT(20X,'BUCKLING TERMICI',/,6(1X,G12.5))
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE SPLITF(PH,PHR11,PHR1N,PHR21,PHR2N,RFIS21,PHR1,PHR2,
     &                  ALT,NCEL)
C----------------------------------------------------------------------
C    SPLITTING DU FLUX TOTAL CALCULE PAR STRIQS EN FLUX RAPIDE ET
C    THERMIQUE ET CALCUL DES FLUX D'INTERFACE
C----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION PH(*),ALT(*),RFIS21(*),PHR1(*),PHR2(*)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/CFLUXP/PHI1(60),PHI2(60),PHIA1(60),PHIA2(60),PR(60),PA(60)
C
C     LO SPLITTING ATTUALMENTE VIENE EFFETTUATO NELLA ROUTINE 'PREVIS'
C
C      DO 10 K=1,NCEL
C      PHR1(K)=PH(K)/(1.+RFIS21(K))
C      PHR2(K)=PHR1(K)*RFIS21(K)
C   10 CONTINUE
C
C    CALCUL DES NCEL+1 FLUX (RAPIDES ET THERMIQUES) D'INTERFACE
C   ( FLUSSI ALL'INTERFACCIA CORE-RIFLETTORE CALCOLATI COERENTEMENTE
C     COL METODO COARSE-MESH A 2G )
C
C      PHI1(1)=PHR1(1)*ALEX11/(ALT(1)*.5+ALEX11)
C      PHI2(1)=PHR2(1)*ALEX21/(ALT(1)*.5+ALEX21)
      PHI1(1)=PHR11
      PHI2(1)=PHR21
      DO 20 K=2,NCEL
      PHI1(K)=(PHR1(K)-PHR1(K-1))*ALT(K-1)/(ALT(K)+ALT(K-1))+PHR1(K-1)
      PHI2(K)=(PHR2(K)-PHR2(K-1))*ALT(K-1)/(ALT(K)+ALT(K-1))+PHR2(K-1)
   20 CONTINUE
C      PHI1(NCEL+1)=PHR1(NCEL)*ALEX1N/(ALT(NCEL)*.5+ALEX1N)
C      PHI2(NCEL+1)=PHR2(NCEL)*ALEX2N/(ALT(NCEL)*.5+ALEX2N)
      PHI1(NCEL+1)=PHR1N
      PHI2(NCEL+1)=PHR2N
C   NORMALISATION DU FLUX TOTAL ET DES FLUX RAPIDE ET THERMIQUE
C   D'INTERFACE
      CNOR1=0.
      CNOR2=0.
      DO 30 K=1,NCEL
      CNOR1=CNOR1+PHR1(K)*ALT(K)
      CNOR2=CNOR2+PHR2(K)*ALT(K)
   30 CONTINUE
      DNOR1=0.
      DNOR2=0.
      DO 40 K=2,NCEL+1
      DNOR1=DNOR1+(PHI1(K)+PHI1(K-1))*.5*ALT(K-1)
      DNOR2=DNOR2+(PHI2(K)+PHI2(K-1))*.5*ALT(K-1)
   40 CONTINUE
      DO 50 K=1,NCEL+1
      PHI1(K)=PHI1(K)*CNOR1/DNOR1
      PHI2(K)=PHI2(K)*CNOR2/DNOR2
   50 CONTINUE
  100 FORMAT((1X,6G12.5))
C      WRITE(NWRITE,100)(PHI1(K),K=1,NCEL+1)                            
C      WRITE(NWRITE,100)(PHI2(K),K=1,NCEL+1)
C     FNOR=0.
C     DO 60 K=1,NCEL
C     FLTK=PHI1(K)+PHI2(K)                                              
C     FLTK1=PHI1(K+1)+PHI2(K+1)
C     FNOR=FNOR+(FLTK+FLTK1)*.5*ALT(K)                                  
C  60 CONTINUE
C                                                                       
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE OMEGA2(HZ,NCEL)
C
C-----------------------------------------------------------------------
C
C     CALCOLO DEI COEFFICIENTI OMEGA DEL METODO 'COARSE MESH'
C
C-----------------------------------------------------------------------
C
      COMMON/DUEG/VEL1,VEL2,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      DIMENSION HZ(*)
C
      OMES1(1)=0.
      OMES2(1)=0.
      OMED1(NCEL)=0.
      OMED2(NCEL)=0.
      DO 1 I=1,NCEL
      IF(I.EQ.1)GO TO 2
      OMES1(I)=W1(I)/(G1(I)+G1(I-1))
      OMES2(I)=W2(I)/(G2(I)+G2(I-1))
    2 IF(I.EQ.NCEL)GO TO 1
      OMED1(I)=W1(I)/(G1(I)+G1(I+1))
      OMED2(I)=W2(I)/(G2(I)+G2(I+1))
    1 CONTINUE
C     WRITE(6,100)(OMED1(I),I=1,NCEL),(OMES1(I),I=1,NCEL)
C     WRITE(6,101)(OMED2(I),I=1,NCEL),(OMES2(I),I=1,NCEL)
  100 FORMAT(/1X,'OMD1 OMS1 ',6E12.5)
  101 FORMAT(/1X,'OMD2 OMS2 ',6E12.5)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PERMA1(A,B,C)
C
C-----------------------------------------------------------------------
C
C     QUESTA SUBROUTINE ESEGUE IL PRODOTTO DI DUE MATRICI
C
C-----------------------------------------------------------------------
C
      DIMENSION A(*),B(*),C(*)
C
      C(1)=A(1)*B(1)+A(3)*B(2)
      C(2)=A(2)*B(1)+A(4)*B(2)
      C(3)=A(1)*B(3)+A(3)*B(4)
      C(4)=A(2)*B(3)+A(4)*B(4)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PERMAT(A,B,C)
C
C-----------------------------------------------------------------------
C
C     QUESTA SUBROUTINE ESEGUE IL PRODOTTO DI DUE MATRICI SIA PER IL
C     RIFLETTORE ASSIALE INFERIORE CHE PER QUELLO SUPERIORE
C
C-----------------------------------------------------------------------
C
      DIMENSION A(*),B(*),C(*)
C
      C(1)=A(1)*B(1)+A(3)*B(2)
      C(2)=A(2)*B(1)+A(4)*B(2)
      C(3)=A(1)*B(3)+A(3)*B(4)
      C(4)=A(2)*B(3)+A(4)*B(4)
      C(5)=A(5)*B(5)+A(7)*B(6)
      C(6)=A(6)*B(5)+A(8)*B(6)
      C(7)=A(5)*B(7)+A(7)*B(8)
      C(8)=A(6)*B(7)+A(8)*B(8)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE ADDMAT(A,B,C,FATT)
C
C-----------------------------------------------------------------------
C
C     QUESTA SUBROUTINE ESEGUE LA SEGUUENTE OPERAZIONE TRA MATRICI:
C
C                            C = A + B * FATT
C
C     SIA PER IL RIFLETTORE ASSIALE INFERIORE CHE PER QUELLO SUPERIORE
C
C-----------------------------------------------------------------------
C
C
      DIMENSION A(*),B(*),C(*)
      DO 1 I=1,8
      C(I)=A(I)+B(I)*FATT
    1 CONTINUE
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE INVMAT(A)
C
C-----------------------------------------------------------------------
C
C     QUESTA SUBROUTINE CALCOLA L'INVERSA DI UNA MATRICE SIA PER IL
C     RIFLETTORE ASSIALE INFERIORE CHE PER QUELLO SUPERIORE
C
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION A(*)
      DET1=A(1)*A(4)-A(2)*A(3)
      DET2=A(5)*A(8)-A(6)*A(7)                                          
      AV1=A(1)
      AV2=A(5)
      IF(ABS(DET1).LE.1.E-15)GO TO 1                                    
      A(1)=A(4)/DET1
      A(2)=-A(2)/DET1
      A(3)=-A(3)/DET1                                                   
      A(4)=AV1/DET1
    1 IF(ABS(DET2).LE.1.E-15)GO TO 2                                    
      A(5)=A(8)/DET2
      A(6)=-A(6)/DET2                                                   
      A(7)=-A(7)/DET2
      A(8)=AV2/DET2                                                     
    2 CONTINUE
      RETURN                                                            
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE GWCOEF(HZ,NCEL)
C
C-----------------------------------------------------------------------
C
C     CALCOLO DEI COEFFICIENTI G  E W DEL METODO COMETA
C
C-----------------------------------------------------------------------
C
      COMMON/DUEG/VEL1,VEL2,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      DIMENSION HZ(*)
C
      DO 1 I=1,NCEL
      W1(I)=1.
      W2(I)=1.
      G1(I)=0.5*HZ(I)/D1(I)
      G2(I)=0.5*HZ(I)/D2(I)
      IF(ABS(BUCK1(I)).LT.1.E-8)GO TO 2
      IF(BUCK1(I).GT.0.)GO TO 3
      UG=SQRT(-BUCK1(I))*HZ(I)
      W1(I)=UG/SINH(UG)
      G1(I)=HZ(I)*(COSH(UG)-1.)/(D1(I)*UG*SINH(UG))
      GO TO 2
    3 UG=SQRT(BUCK1(I))*HZ(I)
      W1(I)=UG/SIN(UG)
      G1(I)=HZ(I)*(1.-COS(UG))/(D1(I)*UG*SIN(UG))
    2 CONTINUE
      IF(ABS(BUCK2(I)).LT.1.E-8)GO TO 1
      IF(BUCK2(I).GT.0.)GO TO 4
      UG=SQRT(-BUCK2(I))*HZ(I)
      W2(I)=UG/SINH(UG)
      G2(I)=HZ(I)*(COSH(UG)-1.)/(D2(I)*UG*SINH(UG))
      GO TO 1
    4 UG=SQRT(BUCK2(I))*HZ(I)
      W2(I)=UG/SIN(UG)
      G2(I)=HZ(I)*(1.-COS(UG))/(D2(I)*UG*SIN(UG))
    1 CONTINUE
C     WRITE(6,120)(W1(I),I=1,NCEL),(G1(I),I=1,NCEL)
C     WRITE(6,121)(W2(I),I=1,NCEL),(G2(I),I=1,NCEL)
  120 FORMAT(/1X,'W1 G1 ',6E12.5)
  121 FORMAT(/1X,'W2 G2 ',6E12.5)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE REA2G(NCM,FSOT,ALT)
C-----------------------------------------------------------------------
C     CALCOLA LA REATTIVITA' TOTALE DEL NOCCIOLO NEL CASO DI CINETICA
C     ASSIALE CON FORMALISMO A DUE GRUPPI ENERGETICI
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     &       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION ALT(*)
C---- FORMALISMO LIBELLULE
      FI1M=0.
      D1MINV=0.
      SF1M=0.
      SA1M=0.
      FI2M=0.
      D2MINV=0.
      SF2M=0.
      SA2M=0.
      R1M=0.
      DB1M=0.
      DB2M=0.
      DO 30 K=1,NC1
      FI1M=FI1M+PHR1(K)*ALT(K)
      D1MINV=D1MINV+PHR1(K)*ALT(K)/DIF1(K)
      SF1M=SF1M+ENFIS1(K)*PHR1(K)*ALT(K)
      SA1M=SA1M+ASS1(K)*PHR1(K)*ALT(K)
      R1M=R1M+RIM1(K)*PHR1(K)*ALT(K)
      DB1M=DB1M+DIF1(K)*BQZ1(K)*PHR1(K)*ALT(K)
      DB2M=DB2M+DIF2(K)*BQZ2(K)*PHR2(K)*ALT(K)
      FI2M=FI2M+PHR2(K)*ALT(K)
      D2MINV=D2MINV+PHR2(K)/DIF2(K)*ALT(K)
      SF2M=SF2M+ENFIS2(K)*PHR2(K)*ALT(K)
      SA2M=SA2M+ASS2(K)*PHR2(K)*ALT(K)
   30 CONTINUE
      D1M=FI1M/D1MINV
      SF1M=SF1M/FI1M
      SA1M=SA1M/FI1M
      R1M=R1M/FI1M
      D2M=FI2M/D2MINV
      SF2M=SF2M/FI2M
      SA2M=SA2M/FI2M
      DB1M=DB1M/FI1M
      DB2M=DB2M/FI2M
      ADEN=1./(DB1M+SA1M+R1M)
      AKEFFK=SF1M*ADEN+SF2M*R1M*ADEN/(SA2M+DB2M)
      REAT=(AKEFFK-1.)/AKEFFK
C      WRITE(NWRITE,*) 'K-EFFETTIVO A 2G (KINA)=',AKEFFK,' REAT2=',REAT2
C---- FORMALISMO KINA/STRIQS
      FSOT=0.
      FSOP=0.
      DO 10 K=1,NC1
      ENFPH=ENFIS1(K)*PHR1(K)+ENFIS2(K)*PHR2(K)
      FSOP=FSOP+(ENFPH-(DIF1(K)*BQZ1(K)+ASS1(K))*PHR1(K)-
     &                 (DIF2(K)*BQZ2(K)+ASS2(K))*PHR2(K))*ALT(K)
C>>>  FSOP=FSOP+(ENFPH-(DIF1(K)*BQZ1(K)+ASS1(K)+RIM1(K))*PHR1(K))*ALT(K)
      FSOT=FSOT+ENFPH*ALT(K)
   10 CONTINUE
      FSOT=1./FSOT
      REAT2=FSOP*FSOT
C      WRITE(NWRITE,*) '2G: FSOP =',FSOP,' FSOT =',FSOT,' REAT2 =',REAT2
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE FORMA2(BE,ZDG,ALT,TN1,TN2,AL,C,DERT,NRITM,EPSR,
     &                  NCM,FNORMN,DEN,EPSNOR,IMOT)
C-----------------------------------------------------------------------
C
C     MODULO NEUTRONICO PER IL CALCOLO DELLA DISTRIBUZIONE DI FLUSSO
C     MONODIMENSIONALE IN TEORIA DI DIFFUSIONE A DUE GRUPPI DI ENERGIA
C     CON METODO DI TIPO "COARSE MESH".
C
C     I FLUSSI VENGONO CALCOLATI PER I SOLI NODI MOLTIPLICANTI,
C     MENTRE SI TIENE CONTO DELLE PROPRIETA' DEI RIFLETTORI ASSIALI
C     INFERIORE E SUPERIORE CALCOLANDO LE CORRENTI ALL'INTERFACCIA
C     CORE-RIFLETTORE IN FUNZIONE DEI FLUSSI MEDI DEI NODI
C     MOLTIPLICANTI ADIACENTI AI RIFLETTORI.
C
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/DUEG/VEL1,VEL2,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/RIFLE$/SRIF1(2),DRIF1(2),SRIF2(2),DRIF2(2),RRIF(2)
     &             ,DUMMI34(NW-2*5)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON /MATRIF/FT(8),AP(8),GT(8),FT1(8),F01(8),G01(8),GT1(8),
     &               AP4(8),AP5(8),S(8),D(8),RM(8),Q(8),TTINF(4),
     &               TTSUP(4),PM1(8),RG(8),VG(8),OMR(8),DC(8),RN(8)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1             RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      DIMENSION BE(NRITM,*),ZDG(*),ALT(*),TN1(*),TN2(*),AL(NRITM,*),
     &          C(NRITM,*),DEN(*)
C
      IF(LSTAZ) THEN
      WRITE(NWRITE,200)
C
      EPSFN=AMIN1(EPSNOR,1.E-05)
      EPSF=AMIN1(EPSR,1.E-05)
      EPSB=AMIN1(EPS1,1.E-07)
      NITEBM=200
      MAXVOL=50
      NITEFM=1000
      NCEL=NC1
      FNORM=ALCAN*100.
      DO 50 I=1,NCEL
      CHI1(I)=1.
      CHI2(I)=0.
   50 CONTINUE
C
      ELSE
      EPSB=AMIN1(EPS1,1.E-06)
      WRITE(NWRITE,100) IMOT
      ENDIF
  200 FORMAT(1H0/1X,'FORMA DEI FLUSSI ASSIALI VELOCE E TERMICO ',
     &       'CALCOLATA IN STAZIONARIO')
  100 FORMAT(1H0/1X,'*****  FINE DELL''INTERVALLO DTPSI DI RICALCOLO ',
     &       'DELLA FUNZIONE FORMA  ( --> ',I1,' )  *****',/,
     $       7X,'( 1 --> VARIAZ. K-INFINITO , 2 --> DTPSI > DTPSI ',
     %       'PREVISTO , 3 --> VARIAZ. DTJ )')
C
C---- CALCOLO DELLA SEZIONE D'URTO DI ASSORBIMENTO TOTALE VELOCE
      DO 20 K=1,NCEL
   20 S1(K)=ASS1(K)+R(K)
C
C-----------------------------------------------------------------------
C     CALCOLO DELLA MATRICE Q CHE DA' LE RELAZIONI TRA CORRENTI E
C     FLUSSI ALL'INTERFACCIA COL RIFLETTORE
C-----------------------------------------------------------------------
C
      CALL CALRIF
C
      FNORMN=1.
      NITERB=0
    1 NITERB=NITERB+1
C      WRITE(NWRITE,500) NITERB
  500 FORMAT(/,5X,'ITERAZIONE DA BUCKLING N. ',I3,/)
      IF(NITERB.EQ.1) GO TO 2
C
C-----------------------------------------------------------------------
C     CALCOLO DEI BUCKLINGS DI CELLA. SE IND=0 I BUCLINGS SONO IN
C     CONVERGENZA, SE IND=1 NO.
C-----------------------------------------------------------------------
C
      CALL BUCK2G(IND,ALT,EPSB,NCEL)
      IF(NITERB.LT.30) GO TO 2
      IF(IND.EQ.0) GO TO 3
      IF(NITERB.GT.NITEBM) THEN
      WRITE(NWRITE,602) NITERB,NITEBM                                  0
  602 FORMAT(1X,'NUMERO ITERAZIONI DA BUCKLING NITERB=',I5,
     &       3X,'(NITEBM = ',I5,' )')
      STOP ' NITERB .GT. NITEBM (SUBROUTINE FORMA2)'
      ENDIF
C
C-----------------------------------------------------------------------
C     CALCOLO DELLA MATRICE DI RIFLESSIONE T PER LA RELAZIONE TRA LE
C     CORRENTI DI INTERFACCIA CORE-RIFLETTORE E I FLUSSI MEDI NEI
C     NODI MOLTIPLICANTI ADIACENTI AL RIFLETTORE
C-----------------------------------------------------------------------
C
    2 CALL MATT(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI PARAMETRI G E W DEL METODO COARSE-MESH
C-----------------------------------------------------------------------
C
      CALL GWCOEF(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI COEFFICIENTI OMEGA CHE METTONO IN RELAZIONE CORRENTI
C     D'INTERFACCIA E FLUSSI MEDI
C-----------------------------------------------------------------------
C
      CALL OMEGA2(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     RISOLUZIONE DEL SISTEMA E CALCOLO DEL FATTORE DI NORMALIZZAZIONE
C----------------------------------------------------------------------
C
      CALL SOLVE(ALT,EPSF,EPSFN,NITEFM,MAXVOL,TN1,TN2,DERT,AL,BE,C,
     &           NCEL,NRIT,NRITM,FNORM,FNORMN,NITERB)
      GO TO 1
    3 CONTINUE
C      WRITE(NWRITE,809) (FLU1(I),I=1,NCEL)
C      WRITE(NWRITE,709) (FLU2(I),I=1,NCEL)
  809 FORMAT(/5X,'FORMA FLUSSO VELOCE'//,8(1X,G12.5))
  709 FORMAT(/5X,'FORMA FLUSSO TERMICO '//,8(1X,G12.5))
      WRITE(NWRITE,601) T,NITERB,NITEBM,FNORMN
  601 FORMAT(1X,'AMPIEZZA T =',G12.5,2X,
     &    'NITERB =',I5,2X,'(NITEBM =',I5,')',2X,'GAMMA NORM. =',G12.5)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE SOLVE(HZ,EPSF,EPSFN,NITEFM,MAXVOL,TN1,TN2,DETSUT,AL,
     &                 BE,C,NCEL,NRIT,NRITM,FNORM,FNORMN,NITERB)
C----------------------------------------------------------------------
C     RISOLVE IL SISTEMA DISCRETIZZATO CALCOLANDO I FLUSSI VELOCE E
C     TERMICO E LA COSTANTE DI NORMALIZZAZIONE (PER DATI BUCLINGS)
C----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON /MATRIF/FT(8),AP(8),GT(8),FT1(8),F01(8),G01(8),GT1(8),
     &               AP4(8),AP5(8),S(8),D(8),RM(8),Q(8),TTINF(4),
     &               TTSUP(4),PM1(8),RG(8),VG(8),OMR(8),DC(8),RN(8)
      COMMON/DUEG/V1K,V2K,D1(60),D2(60),FIS1(60),FIS2(60),
     &            ASS1(60),S2(60),R(60),AKINF(60),SNUSF1(60),
     &            SNUSF2(60),EEFIS1(60),EEFIS2(60),BUCK1(60),BUCK2(60),
     &            BQR1Z(60),BQR2Z(60),FLU1(60),FLU2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION HZ(*),TN1(*),TN2(*),AL(NRITM,*),BE(NRITM,*),C(NRITM,*)
C----------------------------------------------------------------------
      IF(LSTAZ) THEN
      UDTPSI=0.
      DETSUT=0.
      ELSE
      UDTPSI=1./DTPSI
      ENDIF
C---- CALCOLO DEI 'TERMINI NOTI'
      DO 31 I=1,NCEL
      TN1(I)=-UDTPSI*HZ(I)*PHR1V(I)*V1K
      SOMC=0.
      DO 32 J=1,NRIT
   32 SOMC=SOMC+AL(J,I)*C(J,I)
      TN1(I)=TN1(I)-SOMC*HZ(I)/T
      TN2(I)=-UDTPSI*HZ(I)*PHR2V(I)*V2K
   31 CONTINUE
C-----------------------------------------------------------------------
C      WRITE(NWRITE,753)TTINF,TTSUP
C  753 FORMAT(1X,'TTINF',5X,4E12.5,/1X,'TTSUP',5X,4E12.5)
      IESP=MIN0(NITERB,10)
      EPSAA=.01/10.**FLOAT(IESP-1)
      IF(EPSAA.LT.EPSFN) EPSAA=EPSFN
      EPSFF=.1/10.**FLOAT(IESP-1)
      IF(EPSFF.LT.EPSF) EPSFF=EPSF
C      EPSAA=EPSFN
C      EPSFF=EPSF
C      WRITE(NWRITE,800) EPSAA,EPSFF
C  800 FORMAT(/1X,'EPSAA = ',E12.5,3X,' EPSFF = ',E12.5)
      ITERAU=0
      NITER=0
    1 NITER=NITER+1
      DO 11 I=1,NCEL
      FLUV1(I)=FLU1(I)
      FLUV2(I)=FLU2(I)
   11 CONTINUE
      STOT=0.
      STOT1=0.
      STOT2=0.
      DO 2 I=1,NCEL
      IF(I.NE.1.AND.I.NE.NCEL) GO TO 3
      IF(I.NE.1) GO TO 4
      VARP1=-OMED1(1)-TTINF(1)
      VARS1=-OMES1(2)*FLU1(2)+TTINF(3)*FLU2(1)
      VARP2=-OMED2(1)-TTINF(4)
      VARS2=-OMES2(2)*FLU2(2)+TTINF(2)*FLU1(1)
      GO TO 5
    4 VARP1=-OMES1(NCEL)-TTSUP(1)
      VARS1=-OMED1(NCEL-1)*FLU1(NCEL-1)+TTSUP(3)*FLU2(NCEL)
      VARP2=-OMES2(NCEL)-TTSUP(4)
      VARS2=-OMED2(NCEL-1)*FLU2(NCEL-1)+TTSUP(2)*FLU1(NCEL)
      GO TO 5
    3 VARP1=-OMES1(I)-OMED1(I)
      VARS1=-OMES1(I+1)*FLU1(I+1)-OMED1(I-1)*FLU1(I-1)
      VARP2=-OMES2(I)-OMED2(I)
      VARS2=-OMES2(I+1)*FLU2(I+1)-OMED2(I-1)*FLU2(I-1)
    5 CONTINUE
      TERDIN=HZ(I)*(DETSUT/T+UDTPSI)
      VARP1=VARP1-HZ(I)*S1(I)-TERDIN*V1K
      BETAK=0.
      DO 30 J=1,NRIT
   30 BETAK=BETAK+BE(J,I)
      TERFIS=HZ(I)*(1.-BETAK)*(SNUSF1(I)*FLU1(I)+SNUSF2(I)*FLU2(I))
      TERFIS=TERFIS/FNORMN
      VARS1=VARS1-CHI1(I)*TERFIS+TN1(I)
      FLU1(I)=VARS1/VARP1
      TERFIS=HZ(I)*(1.-BETAK)*(SNUSF1(I)*FLU1(I)+SNUSF2(I)*FLU2(I))
      TERFIS=TERFIS/FNORMN
      VARP2=VARP2-HZ(I)*S2(I)-TERDIN*V2K
      VARS2=VARS2-CHI2(I)*TERFIS+TN2(I)-HZ(I)*R(I)*FLU1(I)
      FLU2(I)=VARS2/VARP2
C     WRITE(NWRITE,5656)I,VARS1,VARP1,VARS2,VARP2
 5656 FORMAT(1X,'I VARS1 VARP1 VARS2 VARP2',I3,4E12.5)
      STOT=STOT+(FLU1(I)+FLU2(I))*HZ(I)
    2 CONTINUE
      FNORMV=FNORMN
      FNORMN=STOT/FNORM
C      WRITE(NWRITE,100)FNORMN
  100 FORMAT(1X,'FNORMN = ',E15.6)
C      WRITE(NWRITE,101)
  101 FORMAT(/,1X,'DISTRIBUZIONE FLUSSI VELOCI E TERMICI')
C      WRITE(6,102)(FLU1(I),I=1,NCEL)
C      WRITE(6,102)(FLU2(I),I=1,NCEL)
  102 FORMAT(/,1X,6E12.5)
      EPSA=ABS((FNORMN-FNORMV)/FNORMN)
      IF(EPSA.LT.EPSAA)GO TO 124
      ITERAU=ITERAU+1
      IF(ITERAU.GT.MAXVOL) THEN
      WRITE(NWRITE,400) ITERAU,MAXVOL
  400 FORMAT(1X,'ITERAZIONI DA FATTORE DI NORMALIZZAZIONE =',I5,/,
     &       1X,'NUMERO MASSIMO =',I5)
      STOP ' ITERAU .GT. MAXVOL (SUBROUTINE SOLVE) '
      ENDIF
      GO TO 1
  124 RAPF=0.
      ITERAU=0
      DO 13 I=1,NCEL
      RAP=ABS(FLU1(I)-FLUV1(I))/FLUV1(I)
      IF(RAP.GT.RAPF)RAPF=RAP
      RAP=ABS(FLU2(I)-FLUV2(I))/FLUV2(I)
      IF(RAP.GT.RAPF) RAPF=RAP
   13 CONTINUE
C      WRITE(NWRITE,700) RAPF,EPSFF
  700 FORMAT(1X,'RAPF = ',E12.5,3X,' EPSFF = ',E12.5)
      IF(RAPF.LT.EPSFF) GO TO 15
      IF(NITER.GT.NITEFM) THEN
      WRITE(NWRITE,401) NITER,NITEFM
  401 FORMAT(1X,'ITERAZIONI DA FLUSSO =',I5,5X,'NUMERO MASSIMO =',I5)
      STOP ' NITER .GT. NITEFM (SUBROUTINE SOLVE) '
      ENDIF
      GO TO 1
   15 CONTINUE
C      WRITE(NWRITE,200)
  200 FORMAT(///,1X,'CONVERGENZA RAGGIUNTA SU FLUSSI E FATT. DI NORM.')
C
C---- NORMALIZZAZIONE DEI FLUSSI VELOCE E TERMICO
C     (PER OTTENERE UN FLUSSO TOTALE NORMALIZZATO ALL'UNITA')
C      PMOLT=1./FNORMN
C      DO 12 I=1,NCEL
C      FLU1(I)=FLU1(I)*PMOLT
C      FLU2(I)=FLU2(I)*PMOLT
C   12 CONTINUE
C----------------------------------------------------------------------
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE MED2G(NRITM,FSOT,CM,HBE,BEM,ALT,C,BE,AL,ALM)
C-----------------------------------------------------------------------
C     CALCOLA I PARAMETRI MEDI RICHIESTI PER IL CALCOLO DI TIPO
C     ZERODIMENSIONALE PREVISTO DAL METODO IQS
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     &              RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION CM(*),ALM(*),BEM(*),ALT(*),C(NRITM,*),
     &          HBE(*),AL(NRITM,*),BE(NRITM,*)
C
      ALBIG=0.
      BEMTOT=0.
      ALUNO=0.
      VELMED=0.
      DO 2 K=1,NRIT
      CM(K)=0.
      ALM(K)=0.
    2 BEM(K)=0.
      DO 1 K=1,NC1
C      AVEL1=1./VEL1
C      AVEL2=1./VEL2
C      VELMED=VELMED+(AVEL1*PHR1(K)+AVEL2*PHR2(K))*ALT(K)
      ALBIG=ALBIG+(PHR1(K)+PHR2(K))*ALT(K)
      ENPHH=(ENFIS1(K)*PHR1(K)+ENFIS2(K)*PHR2(K))*ALT(K)
      DO 4 J=1,NRIT
      CCJ=C(J,K)*ALT(K)
      ALM(J)=ALM(J)+AL(J,K)*CCJ
      BEM(J)=BEM(J)+BE(J,K)*ENPHH
    4 CM(J)=CM(J)+CCJ
    1 CONTINUE
C      VEL=ALBIG/VELMED
      ALBIG=VEL*ALBIG*FSOT
      HALB=1./ALBIG
      HREAT=REAT*HALB
      DO 5 K=1,NRIT
      BEM(K)=BEM(K)*FSOT
      HBE(K)=BEM(K)*HALB
      BEMTOT=BEMTOT+BEM(K)
      ALM(K)=ALM(K)/CM(K)
      CM(K)=CM(K)/(ALCAN*100.*VEL)
    5 ALUNO=ALUNO+BEM(K)/ALM(K)
      HBEM=BEMTOT*HALB
      ALUNO=BEMTOT/ALUNO
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CALCON(ALT,HINS,JJ,PHS,D,AINS)
C-----------------------------------------------------------------------
C     CALCOLA IL FATTORE DI PESO DA ATTRIBUIRE ALL'INSERIMENTO DEI BANCH
C     IN UNA CELLA DI UNA DATA ZONA RADIALE NELLA VALUTAZIONE DELLA
C     FRAZIONE DI CONTROLLO (PESATURA SUI FLUSSI DI CELLA INTEGRATI).
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION ALT(*),PHS(*),D(*)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1          RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
C
      FIMEN(H,HHI,HI1,FFI,FI1)=(FI1*HHI+FFI*HI1+2.*H*(FFI-FI1))/
     &                         (HHI+HI1)
      FIPIU(H,HHI,HI1,FFI,FI1)=(2.*H*(FI1-FFI)+2.*FFI*HHI+FFI*HI1
     &                         -FI1*HHI)/(HHI+HI1)
      HI=ALT(JJ)
      HM1=2.*D(JJ)*RIAL
      HP1=2.*D(JJ)*RIBA
      FI=PHS(JJ)
      FIM1=0.
      FIP1=0.
      IF(JJ.EQ.NC1) GO TO 1
      HM1=ALT(JJ+1)
      FIM1=PHS(JJ+1)
    1 IF(JJ.EQ.1) GO TO 2
      HP1=ALT(JJ-1)
      FIP1=PHS(JJ-1)
    2 FINTS=(FIM1*HI+FI*HM1)/(HI+HM1)
      FINTD=(FI*HP1+FIP1*HI)/(HI+HP1)
      DEN=.25*HI*(FINTS+2.*FI+FINTD)
      HIMEZ=HI*.5
      IF(HINS.GT.HIMEZ) GO TO 3
      ANUM=.5*HINS*(FIMEN(HINS,HI,HM1,FI,FM1)+FINTS)
      GO TO 4
    3 TRAP=.25*HI*(FINTS+FI)
      ANUM=TRAP+.5*(HINS-HIMEZ)*(FI+FIPIU(HINS,HI,HP1,FI,FIP1))
    4 AINS=ANUM/DEN
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE INICRN
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/ACSOIR/ZKELV,BOLTZM,TCK,T0K,XEMOY,XM,DUMMI62(NW-6)
      COMMON/DONNEE/PROB,AB10,AH20,AVOGAD,DUMMI61(NW-4)
C
      ELECTR=1.6E-19
      ZKELV=273.15
      BOLTZM=1.38E-23
      EC=0.625
      T0K=20.+ZKELV
      TCK=EC*ELECTR/BOLTZM
      XM=1.128
      AVOGAD=0.6023
      PROB=1.
      AB10=10.82
      AH20=18.015
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE INTPOL(A,B,C,D,NMAX,IND)
C-----------------------------------------------------------------------
C     ESEGUE INTERPOLAZIONI LINEARI
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      PARAMETER ( NNMM=49 )
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION A(NNMM+1),B(NNMM)
C
      IF(NMAX.GT.NNMM) STOP ' NMAX MAGGIORE DEL MASSIMO IN "INTPOL" '
      NMAX1=NMAX-1
      NMAXP1=NMAX+1
      IF(C.LT.A(1)) GO TO 10
      IF(C.GT.A(NMAX)) GO TO 20
      GO TO(1,2,3),IND
    1 IC=C/A(NMAXP1)+1
      GO TO 4
    2 IC=(C-A(1))/A(NMAXP1)+1
      GO TO 4
    3 IF(C.LT.A(2)) GO TO 5
      IF(C.GT.A(NMAX1)) GO TO 6
      IC=(C-A(2))/A(NMAXP1)+2
    4 IC1=IC+1
      D=B(IC)+(C-A(IC))*(B(IC1)-B(IC))/A(NMAXP1)
      GO TO 7
    5 D=B(1)+(C-A(1))*(B(2)-B(1))/A(NMAXP1)
      GO TO 7
    6 D=B(NMAX1)+(C-A(NMAX1))*(B(NMAX)-B(NMAX1))/A(NMAXP1)
      GO TO 7
   10 WRITE(NWRITE,11) C,A(1)
   11 FORMAT(1X,'ATTENZIONE, C = ',G12.5,' MINORE DI A(1) = ',G12.5/1X,
     $'IL PROGRAMMA SI BLOCCA'/)
      STOP ' C MINORE DI A(1) IN SUBROUTINE INTPOL '
   20 WRITE(NWRITE,12) C,A(NMAX)
   12 FORMAT(1X,'ATTENZIONE, C = ',G12.5,' MAGGIORE DI A(NMAX) = ',G12.5
     $/1X,'IL PROGRAMMA SI BLOCCA'/)
      STOP ' C MAGGIORE DI A(NMAX) IN SUBROUTINE INTPOL '
C
    7 RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE INIBAR
C INITIALISATION DES GRANDEURS UTILISEES POUR LE CALCUL DE L'EFFICACITE
C DES GRAPPES DE CONTROLE SUR LES SECTIONS MACROSCOPIQUES DE TRANCHES
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
C     *,COEFB1,COEFB2
      COMMON/CFIC10/IFIC10,I10
      COMMON/CEFGRA/IGRAP,IM,COTB(155),IP,CG0,ROIA,KINI,PPA,SKIN
      COMMON/CGEOME/NT,HZ(60),EZ(60),HMINC,HMAXC,IMIN,IMAX,L1,PL1
      COMMON/DBARRE/NBU,BUC(50),DSAGB1(15,50),ALF2,ALFR,ALFF1,ALFF2
      COMMON/CGRAPP/NGRA,NOG(15),AR(15,15),AALF2,AALFR,AALFF1,AALFF2
      COMMON/ZREF/IINF,ISUP,LL1,PLL1
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/NEUT1$/S(  KAXS  ),DUMMI30(MAXSM-KAXS)
      COMMON/INDR1$/ IALT,BEM,AL,     WW,XE,VIO,PM,SM,HEL,
     $               PHT,IWGAMC,WTILD,ATILD,GINV,XEV,VIOV,
     *               TREF,ALBAS,WMED,ICORD,INBAR,HALBA,HBORO,IALBA
     &              ,DUMMI1(NW-24)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1             RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/CSERVE/BIDO,SAXE1,SAXE2
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      NCEL=NC1
C COEFFICIENTS CORRECTEURS DES SECTIONS MACROSCOPIQUES D 'ABSORPTION
C TRANSFERT ET FISSION RAPIDE ET THERMIQUES DUS AUX BARRES
      AALF2=ALF2
      AALFR=ALFR
      AALFF1=ALFF1
      AALFF2=ALFF2
C
C   INDEXATION DES PREMIERE ET DERNIERE TRANCHE ACTIVE DU COEUR
C   ET NOMBRE DE TRANCHES TOTAL NT
      IINF=NCELRF/2+1
      ISUP=NCEL+IINF-1
      IMIN=IINF-1
      IMAX=ISUP
      NT=NCEL
C INDEXATION DES CONFIGURATION DE BARRES PARTICULIERES
      IGRAP=9
      IF(ABS(BIDO-3.1).LE.1.E-5) THEN
      I10=1
      ELSE IF(ABS(BIDO-3.0).LE.1.E-5) THEN
      I10=0
      ELSE
      STOP'VALEUR NON,PREVUE BIBLIOTHEQUE INCOMPATIBLE'
      ENDIF
C LES COTES Z SONT MESUREES A PARTIR DU BAS DE LA ZONE ACTIVE DU COEUR
      HMINC=0.
      HMAXC=HMINC+ALATT*100.
      HZ(1)=HMINC
      EZ(1)=S(IALT)
      DO 10 K=2,NCEL+1
      IF (K.LE.NCEL) EZ(K)=S(IALT+K-1)
      HZ(K)=HZ(K-1)+EZ(K-1)
   10 CONTINUE
C  NOMBRE DE GRAPPES DE BARRES (MODE GRIS)
C   GRAPPE 1 ---> G1   (GRISES)
C   GRAPPE 2 ---> G2   (GRISES)
C   GRAPPE 3 ---> N1   (GRISES)
C   GRAPPE 4 ---> N2   (GRISES)
C   GRAPPE 5 ---> R    (NOIRE)
      NGB=NG-1
C  VALEUR D'UN PAS D'EXTRACTION DE BARRES EN CENTIMETRES
      APAS=ANOCP
C
C      WRITE(NWRITE,*)'APAS=',APAS,'AMPAS=',AMPAS,'HMAXC=',HMAXC
C      WRITE(NWRITE,*)'IMIN=',IMIN,'IMAX=',IMAX,'NT=',NT,'NGB=',NGB
C      WRITE(NWRITE,100) (EZ(K),K=1,NT)
C      WRITE(NWRITE,100) (HZ(K),K=1,NT)
  100 FORMAT(6E12.5)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CRNRF(SIG,DREF,FON)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      COMMON/CALC/IOPT,PREAC,PPMBOR
      COMMON/CROA/CORBO
      COMMON/DONNEE/PROB,AB10,AH20,AVOGAD,DUMMI61(NW-4)
      COMMON/TRANSD/TABTPE(100),TABTT(100),TABTD(100),TABTPS(100),
     1TABPE(100),TABTE(100),TABDEB(100),TABPS(100),
     2ITRANS,JTRANS,KTRANS,LTRANS,TEM,TEMOY,PE
      DIMENSION SIG(66),DREF(6),FON(7)
C
C     CONTRE-REACTIONS DANS LE REFLECTEUR
C
      ROH2O=FON(5)
C     WRITE(57,*)'CRNRF VALEUR DE RO=',ROH2O
      PPMBOR=FON(6)
      BORE=(AVOGAD*ROH2O*DREF(3)*PROB*PPMBOR*1.E-6)*CORBO/AB10
      DSA1=BORE*SIG(37)
      DSA2=BORE*SIG(38)
      SIG(3)=SIG(3)+DSA1
      SIG(4)=SIG(4)-DSA1
      SIG(9)=SIG(9)+DSA2
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE REGION
C
C     DERNIERE MODIFICATION LE 23/09/86
C
C     DECOUPAGE DU COEUR EN REGIONS,COMPTE TENU DE LA CONFIGURATION
C     DE BARRES
C
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      COMMON/CEFGRA/IGRAP,IM,COTB(155),IP,CG0,ROIA,KINI,PPA,SKIN
      COMMON/CGEOME/NT,HZ(60),EZ(60),HMINC,HMAXC,IMIN,IMAX,L1,PL1
      COMMON/CPPAL/PIN(5),P(5),C(2),TMOM
      COMMON/CREGIO/NREG(60),INDR(60,4),PROPR(60,4)
      DIMENSION COT1(5),IN(6),PRO(6)
C
C
C     DECODAGE DE LA COTE DES BARRES P(1) ET P(2)
C
      H=P(2)
      COT2=HMINC+ZMIN+H*APAS
      H2=AMPAS-0.5
      IF(H.GE.H2) COT2=HMAXC
      H=P(1)
      DO 10 I=1,NGB
      COT1(I)=HMINC+ZMIN+H*APAS
      H1=HMAXC-0.1
      IF(COT1(I).GE.H1) COT1(I)=HMAXC
      COTMIN=HMINC+ZMIN
      IF(COT1(I).LE.COTMIN) COT1(I)=HMINC+ZMIN
      H=H+AMPAS-AREC(I)
   10 CONTINUE
C
C     DECOUPAGE EN REGIONS
C
      DO 20 J=1,NT
      NREG(J)=1
      INDR(J,1)=1
      PROPR(J,1)=1.
   20 CONTINUE
      IMAX1=IMAX-1
      DO 30 J=IMIN,IMAX1
C
C     DECOUPAGE RESULTANT DE LA COTE DU PREMIER ENSEMBLE DE BARRES P(1)
C
      CINF=HZ(J)
      CSUP=HZ(J+1)
      K=1
      PROPT=0.
      DO 32 I=1,NGB
      IF(COT1(I).GE.CSUP)  GO TO 32
      IF(COT1(I).LT.CINF)  GO TO 31
      PROPR(J,K)=(COT1(I)-CINF)/EZ(J)-PROPT                             
      IF(PROPR(J,K).LT.0.00001)  GO TO 31
      PROPT=PROPT+PROPR(J,K)
      K=K+1
      NREG(J)=K                                                         
   31 INDR(J,K)=I+1
      IF(IGRAP.GE.10) THEN                                              
            INDR(J,K)=IGRAP+1
            END IF                                                      
      PROPR(J,K)=1.-PROPT
   32 CONTINUE
C
C     SUPERPOSITION AU DECOUPAGE PRECEDENT DU DECOUPAGE RESULTANT DE LA
C     POSITION DU DEUXIEME ENSEMBLE DE BARRES P(2)
C
      IF((AMPAS-P(2)).LT.0.01) GO TO 30
      M=0
      CI=CINF
      DO 35 L=1,K
      PROPS=PROPR(J,L)
      PROPT=0.
      M=M+1
      CS=CI+EZ(J)*PROPR(J,L)
      IN(M)=INDR(J,L)
      IF(COT2.LE.CS)GO TO 33
      PRO(M)=PROPR(J,L)
      CI=CS
      GO TO 35
   33 IF(COT2.LE.CI) GO TO 34
      PRO(M)=(COT2-CI)/EZ(J)
      PROPT=PRO(M)
      M=M+1
   34 IN(M)=INDR(J,L)+5
      IF(IGRAP.GE.10.AND.IN(M).GE.15) THEN
            IN(M)=IN(M)-2
            END IF
      PRO(M)=PROPS-PROPT
      CI=CS
   35 CONTINUE
      NREG(J)=M
      DO 36 L=1,M
      INDR(J,L)=IN(L)
      PROPR(J,L)=PRO(L)
   36 CONTINUE
   30 CONTINUE
C
C      WRITE(57,*) 'REGION : NREG INDR PROPR'
C      WRITE(57,'(12I4)') (NREG(K),K=1,NT)
C      WRITE(57,'(12I4)') ((INDR(K,I),I=1,NREG(K)),K=1,NT)
C      WRITE(57,'(6G12.5)')((PROPR(K,I),I=1,NREG(K)),K=1,NT)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE NEWCRN(SIG,PAR,REF,FON,SCR)
C
C     TABLEAU SIG : D1R,D1Z,SA1,SIR,SF1,KF1,
C                   D2R,D2Z,SA2,KIN,SF2,KF2,DT1,DT2
C     TABLEAU PAR : 22 PARAMETRES CRN
C     TABLEAU REF : TU,TM,VOLIQ,ROM,NB(NOY),XE +
C                   FI1V,FIC,VMV0,B2M
C     TABLEAU FON : TC,TS,TM,VOLIQ,ROM,CB(PPM),XE
C     TABLEAU SCR : SIG CORRIGEES
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/CCRN/EQ(22)
      COMMON/CHGAP/IHGAP,HGAPI,DPL,XR,ZEIT,TUO2,DELTU,WXY
      COMMON/CROA/CORBO
      COMMON/CRNEUT/D1CRN,SA1CRN,SRCRN,SF1CRN,D2CRN,SA2CRN,SF2CRN,
     *XISCRN,UNICRN,B2MAT
      COMMON/DONNEE/PROB,AB10,AH20,AVOGAD,DUMMI61(NW-4)
      COMMON/PARCRN/TU,TH2O,XENON,BORE,CW
      COMMON/REFBIB/TUREF,TH2ORF,CWREF,BREF,XENREF,SACHP,SFCHP,
     *STR2,XIS,B2MREF,UNITA,AKREF,SN2N
      DIMENSION SIG(14),PAR(22),REF(10),FON(7),SCR(14)
C
      SN2N=0.
      TUREF=REF(1)
      TH2ORF=REF(2)
      VOLIR=REF(3)
      ROREF=REF(4)
      BREF=REF(5)
      XENREF=REF(6)
      CWREF=AVOGAD*ROREF*VOLIR/AH20
      FC=REF(8)
      F1=REF(7)
      UNITA=REF(9)
      SACHP=SIG(9)/UNITA
      SFCHP=SIG(11)/UNITA
      STR2=1./(3.*SIG(7))
      Q=SIG(4)*F1
      XIS=Q/FC
      B2MREF=REF(10)
      TH2O=FON(3)
      TU=(4.*FON(1)+5.*FON(2))/9.
      TU=DELTU*(TU-TH2O)+TH2O
      VOLIQ=FON(4)
      ROH2O=FON(5)
      CW=AVOGAD*ROH2O*VOLIQ/AH20
      CB=FON(6)
      BORE=(AVOGAD*ROH2O*VOLIQ*PROB*CB*1.E-6)*CORBO/AB10
      XENON=FON(7)
      AKREF=SIG(4)/(SIG(3)+SIG(4))*(SIG(5)/SIG(4)+SIG(11)/SIG(9))
      SIG(10)=AKREF                                                     
      DO 1 I = 1,22
1     EQ(I) = PAR(I)
      CALL FIDBAK(SIG)
      SCR(1)= D1CRN                                                     
      SCR(2)= D1CRN
      SCR(3)=SA1CRN
      SCR(4)= SRCRN
      SCR(5)=SF1CRN                                                     
      SCR(6)=SF1CRN*SIG(6)/SIG(5)
      SCR(7)= D2CRN
      SCR(8)= D2CRN
      SCR(9)=SA2CRN                                                     
      SCR(10)=(SF1CRN/SRCRN+SF2CRN/SA2CRN)*SRCRN/(SA1CRN+SRCRN-SN2N)
      SCR(11)=SF2CRN                                                    
      SCR(12)=SF2CRN*SIG(12)/SIG(11)
      SCR(13)=SF1CRN*SIG(13)/SIG(5)                                     
      SCR(14)=SF2CRN*SIG(14)/SIG(11)
      RETURN                                                            
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE DSABAR(L,DSA1G,DSA2G,DSIRG,DSF1G,DSF2G)
C
C     DERNIERE MODIFICATION LE 17/02/86
C
C     CALCUL DES CORRECTIONS SUR LES "DELTA-SIGMA"
C     DUES A LA PRESENCE DES BARRES DANS LA TRANCHE L
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
C     *,COEFB1,COEFB2
      COMMON/CFIC10/IFIC10,I10
      COMMON/CFLUXP/PHI1(60),PHI2(60),PHIA1(60),PHIA2(60),PR(60),PA(60)
      COMMON/CGRAPP/NGRA,NOG(15),AR(15,15),ALF2,ALFR,ALFF1,ALFF2
      COMMON/CREGIO/NREG(60),INDR(60,4),PROPR(60,4)
      DIMENSION DSAG(2),PHI(60,2),DSIGB(15,2)
      EQUIVALENCE (PHI1(1),PHI(1,1)),(PHI2(1),PHI(1,2))
      EQUIVALENCE (DSIGB(1,1),DSIGB1(1)),(DSIGB(1,2),DSIGB2(1))
C
      NRG=NREG(L)
      IF(I10.EQ.0) THEN
            DSIRG=0.
            DSF1G=0.
            DSF2G=0.
            END IF
      DO 20 I=1,2
      DSAG(I)=0.
      DPHI=PHI(L+1,I)-PHI(L,I)
      PHIM=0.5*(PHI(L,I)+PHI(L+1,I))
      PHII=PHI(L,I)
      DO 20 K=1,NRG
      IND=INDR(L,K)-1
      PHIS=PHII+PROPR(L,K)*DPHI
      PHIMK=0.5*(PHII+PHIS)/PHIM
      PHII=PHIS
      IF(IND.EQ.0)GO TO 20
      DSAG(I)=DSAG(I)+DSIGB(IND,I)*PROPR(L,K)*PHIMK
   20 CONTINUE
      DSA1G=DSAG(1)
      DSA2G=DSAG(2)
      IF(I10.NE.0) THEN
            DSIRG=ALFR*DSA1G
            DSF1G=ALFF1*DSA1G
            DSF2G=ALFF2*DSA1G
            END IF
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE FIDBAK(SIG)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/ACSOIR/ZKELV,BOLTZM,TCK,T0K,XEMOY,XM,DUMMI62(NW-6)
      COMMON/CCRN/AD1,AD2,AD3,
     1            AB1,AB2,AB3,AB4,AB5,AB6,
     2            AX1,AX2,AX3,
     3            AW1,AW2,AW3,AW4,AXI,AW5,AW6,AW7,
     4            AT1,AT2
      COMMON/CRNEUT/D1CRN,SA1CRN,SRCRN,SF1CRN,D2CRN,SA2CRN,SF2CRN,
     *XISCRN,UNICRN,B2MAT
      COMMON/CRN0/F1M0,D1M0,SF1M0,QM0,SACHM0,SFCHM0,SRM0,SA1M0,STR1M0,
     *STR2M0
      COMMON/PARABO/X1,X2,Y1X1,Y1Y2,ALFASR,BETA,GAMA
      COMMON/PARCRN/TU,TH2O,XENON,BORE,CW
      COMMON/REFBIB/TUREF,TH2ORF,CWREF,BREF,XENREF,SACHP,SFCHP,
     *STR2,XIS,B2MREF,UNITA,AKREF,SN2N
      COMMON/REF0/Q0,XIS0
      DIMENSION SIG(14)
C
      AGE=SIG(1)/(SIG(3)+SIG(4))
      ALFASR=0.245
      BETA=4.03
      GAMA=3.942
      X1=261.E-05
      X2=619.E-05
      Y1=-74.
      Y2=-269.
      Y1Y2=(Y2-Y1)/(X2-X1)
      Y1X1=Y1/X1
      SOM=B2MREF*Y1X1+B2MREF*(B2MREF-X1)*(Y1Y2-Y1X1)/X2
      AK0=AKREF/(1.+SOM*1.E-5)
      D10=SIG(1)/(1.-GAMA*B2MREF)
      SF10=SIG(5)/(1.-BETA*B2MREF)
      SR0=SIG(4)*EXP(ALFASR*AGE*B2MREF)
      SA10=SN2N-SR0+(SF10/SR0+SIG(11)/SIG(9))*SR0/AK0
      F10=1./(SA10+SR0-SN2N)
      Q0=F10*SR0
      STR10=1./(3.*D10)
      XIS0=XIS
C
C     CALCUL DES CONTRE-REACTIONS A PARTIR DES SECTIONS DE LA REF
C     ET APRES PASSAGE DE B2 MATIERE A B2 NUL
C
      TKREF=TH2ORF+ZKELV
      A=SQRT(T0K/TKREF)
      R=A/(XIS0/SACHP+2.*SQRT(T0K/TCK))
      EMOY=-SQRT(TKREF/TCK)
      A1=(1.+2.*R*EMOY)*A/(2.*R*UNITA)
      XEMOY=A1-XM/(2.*R)
C
C     DOPPLER RAPIDE
C
      TUK=TU+ZKELV
      TUREFK=TUREF+ZKELV
      X=SQRT(TUK)-SQRT(TUREFK)
      DQUD=AD1*X
      DFI1VD=AD2*X
      DSF1D=AD3*X
C
C     FIN DU DOPPLER
C     BORE RAPIDE CORRECTION 84 EN CWREF/CW
C
      X=BORE-BREF
      DQUB=AB1*X*CWREF/CW
      DFI1VB=AB2*X
      DSF1B=AB3*X
C
C     BORE THERMIQUE
C
      DSTR2B=AB4*X
      DSACHB=AB5*X
      DSFCHB=AB6*X
C
C     FIN DU BORE
C     XENON THERMIQUE
C
      X=XENON-XENREF
      DSTR2X=AX1*X
      DSACHX=AX2*X
      DSFCHX=AX3*X
C
C     FIN DU XENON
C     DENSITE EAU RAPIDE
C
      X=CW-CWREF
      DQUW=AW1*X/(CW*CWREF)
      QLOG=ALOG(Q0)-DQUW
      QH2O=EXP(QLOG)
      DFI1VW=AW2*X/(CW*CWREF)
      DSF1W=AW3*(QH2O-Q0)
      DSTR1W=AW4*X
      DXIW=AXI*XIS0*X/CWREF
C
C     DENSITE EAU THERMIQUE
C
      DSTR2W=AW5*X
      DSACHW=AW6*SACHP*X/CWREF
      ETARF=SFCHP/SACHP
      DETAW=AW7*X*ETARF/CWREF
      ETAW=ETARF+DETAW
      DSFCHW=ETAW*(DSACHW+SACHP)-SFCHP
C
C     FIN DE LA DENSITE
C     TEMPERATURE MODERATEUR THERMIQUE
C
      RACT=SQRT(TH2O+ZKELV)
      RACTR=SQRT(TH2ORF+ZKELV)
      X=(RACT-RACTR)/RACTR
      DSACHT=AT1*SACHP*X
      DSFCHT=AT2*SFCHP*X
C
C     FIN DE LA TEMPERATURE
C     FIN DES EFFETS INDIVIDUELS
C                                 CUMUL
C
      DQUTOT=DQUD+DQUB+DQUW
      DFITOT=DFI1VD+DFI1VB+DFI1VW
      DSF1TO=DSF1D+DSF1B+DSF1W
      DTR1TO=DSTR1W
      DTR2TO=DSTR2B+DSTR2X+DSTR2W
      DACHTO=DSACHB+DSACHX+DSACHW+DSACHT
      DFCHTO=DSFCHB+DSFCHX+DSFCHW+DSFCHT
C
C     CALCUL DES SECTIONS APRES CONTRE-REACTIONS AVEC B2 NUL
C
      ZX=ALOG(Q0)-DQUTOT
      QM0=EXP(ZX)
      F1M0=F10+DFITOT
      SRM0=QM0/F1M0
      SA1M0=(1.-QM0+SN2N*F1M0)/F1M0
      SF1M0=SF10+DSF1TO
      STR1M0=STR10+DTR1TO
      D1M0=1./(3.*STR1M0)
      XISM0=XIS0+DXIW
      STR2M0=STR2+DTR2TO
      D2M0=1./(3.*STR2M0)
      D2CRN=D2M0
      SACHM0=SACHP+DACHTO
      SFCHM0=SFCHP+DFCHTO
      XISCRN=XISM0
      TH2OK=TH2O+ZKELV
      X=SQRT(T0K/TH2OK)
      Y=SQRT(T0K/TCK)
      Z=XISCRN/SACHM0
      R=X/(Z+2.*Y)
      TSURTR=TH2OK/(TH2ORF+ZKELV)
      XECRN=XEMOY-0.5*ALOG(TSURTR)
      ECRN=-Y/X
      UNICRN=X*(1.+2.*R*ECRN)/(XM+2.*R*XECRN)
      SA2CRN=UNICRN*SACHM0
      SF2CRN=UNICRN*SFCHM0
      EPS=5.
      ITMAX=100
      ITER=0
      AGE=D1M0/(SA1M0+SRM0)
      AKM0=((SF1M0/SRM0+SF2CRN/SA2CRN)*SRM0)/(SA1M0+SRM0-SN2N)
      B2INIT=ALOG(AKM0)
      B2INIT=B2INIT/AGE
      B2MAT=B2INIT
   50 SOM=B2MAT*Y1X1+B2MAT*(B2MAT-X1)*(Y1Y2-Y1X1)/X2
      AKCRN=(1.+SOM*1.E-5)*AKM0
      ITER=ITER+1
      IF(ITER.GT.ITMAX) GOTO 51
      SF1CRN=SF1M0*(1.-BETA*B2MAT)
      D1CRN=D1M0*(1.-GAMA*B2MAT)
      SRCRN=SRM0*EXP(-ALFASR*AGE*B2MAT)
      SA1CRN=SN2N-SRCRN+(SF1CRN/SRCRN+SF2CRN/SA2CRN)*SRCRN/AKCRN
C
C     ARRET DES ITERATIONS SI DELTA REACTIVITE INF A EPS
C
      AKEFF= (SF1CRN/SRCRN+SF2CRN/(SA2CRN+D2CRN*B2MAT))
      AKEFF=AKEFF*SRCRN/(SA1CRN+D1CRN*B2MAT+SRCRN-SN2N)
      ROEFF=100000.*(AKEFF-1.)/AKEFF
      IF (ABS(ROEFF).LT.EPS) GO TO 100
C
C     RECHERCHE DE B2MAT POUR KEFF=1
C
      A=D1CRN*D2CRN
      B=D2CRN*(SA1CRN-SN2N+SRCRN)+SA2CRN*D1CRN-SF1CRN*D2CRN
      C=SA2CRN*(SA1CRN+SRCRN-SN2N)-SF2CRN*SRCRN-SF1CRN*SA2CRN
      DISCRI=B*B-4.*A*C
      IF (DISCRI.LT.0.) GO TO 52
      RACDIS=SQRT(DISCRI)
      B2M1=(-B-RACDIS)/(2.*A)
      B2MAT=C/A/B2M1
      GO TO 50
  100 RETURN
   52 WRITE(6,1052) ITER,B2MAT,D1CRN,SA1CRN,SRCRN,SF1CRN,D2CRN,SA2CRN,
     1   SF2CRN
 1052 FORMAT(1X,'DISCRI NEGATIF',I4,1P,8E13.5)
      STOP
   51 WRITE(6,1051) ITER,B2MAT,D1CRN,SA1CRN,SRCRN,SF1CRN,D2CRN,SA2CRN,
     1   SF2CRN
 1051 FORMAT(1X,'B2MAT NE CONVERGE PAS',I4,1P,8E13.5)
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE COLLAX(SCR,VEL1,VEL2,SG1,DSGXE1,ENF1,EEF1,D1,AKF1,
     &                 AKFTH1,PHS1,EF1,VELO1,BQR1,BQR2,KCEL,BQZ1,BQZ2,
     &                 BQE2,JRESTI,FLU1V,FLU2T,RFIS21,SAXE1,SAXE2,
     &                 SAX1G,PHR1,PHR2)
C-----------------------------------------------------------------------
C     ESEGUE IL COLLASSAMENTO AD 1 GRUPPO ENERGETICO DELLE COSTANTI
C     A DUE GRUPPI CALCOLATE IN 'NEWCRN' E CONTENUTE IN 'SCR'.
C-----------------------------------------------------------------------
C
C     SCR(1) = D1              SCR(7)  = D2         SCR(13) = *
C     SCR(2) = F1              SCR(8)  = F2         SCR(14) = *         
C     SCR(3) = S1              SCR(9)  = S2
C     SCR(4) = R               SCR(10) = K-INF
C     SCR(5) = NU*F1           SCR(11) = NU*F2
C     SCR(6) = E1*F1           SCR(12) = E2*F2
C
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION SCR(14),RFIS21(*),FLU1V(*),FLU2T(*),PHR1(*),PHR2(*),
     &          BQE2(*)
C
C     RAPPORT SPECTRAL DIRECT (RFI=PHR2/PHR1)
C
      KCEL1=KCEL-1
      IF(JRESTI.EQ.1) THEN
      BQE2(KCEL1)=0.
C      BQE2(KCEL1)=(SCR(4)/(FLU2T(KCEL1)/FLU1V(KCEL1))
C     &                            -SCR(9)-SCR(7)*(BQR2+BQZ2))/SCR(7)
      ENDIF
      RFIAS=SCR(4)/(SCR(9)+SCR(7)*(BQR2+BQZ2+BQE2(KCEL1)))
      RFI=RFIS21(KCEL1)
      IF(LSTAZ) THEN
C      WRITE(NWRITE,*) 'BQZ1=',BQZ1,'BQE2=',BQE2(KCEL1)
      RFI1D=FLU2T(KCEL1)/FLU1V(KCEL1)
      WRITE(NWRITE,111) RFI,RFIAS,RFI1D
  111 FORMAT(1X,'RAPP. SPECTRAL DIRECT=',F9.6,2X,
     &          'RAPP. SPECTRAL ASINT.=',F9.6,2X,
     &          'RAPP. SPECTRAL LIBELLULE (DIRECT)=',F9.6)
      ENDIF
      RFI1=RFI+1.
C                                                                       
C     VELOCITA' NEUTRONICA MEDIA AD 1 GRUPPO
C
      VELO1=(VEL1+RFI*VEL2)/RFI1                                        
C
C     COEFFICIENTE DI DIFFUSIONE
C
      D1=(SCR(1)+SCR(7)*RFI)/RFI1                                       
C
C     NU*SIGMA FISSIONE                                                 
C
      ENF1=(SCR(5)+SCR(11)*RFI)/RFI1                                    
C
C     K-INFINITO (CON SIGMA ASSORBIMENTO COMPRENSIVE FUGHE RADIALI)     
C
      SAS1=SCR(3)+SCR(1)*BQR1                                           
      SAS2=SCR(9)+SCR(7)*BQR2
      AKF1=SCR(5)/(SAS1+SCR(4))+(SCR(4)/(SAS1+SCR(4)))*SCR(11)/SAS2     
C
C     SIGMA ASSORBIMENTO (COMPRENSIVA FUGHE RADIALI)                    
C
      SG1=ENF1/AKF1                                                     
C
C     E*SIGMA FISSIONE                                                  
C
      EEF1=(SCR(6)+SCR(12)*RFI)/RFI1                                    
C
C     SIGMA FISSIONE                                                    
C
      EF1=(SCR(2)+SCR(8)*RFI)/RFI1                                      
C
C     K-INFINITO TERMICO (PER CALCOLO ALBEDO)
C
      AKFTH1=SCR(11)/SAS2
C
C     SECTION MACROSCOPIQUE D'ABSORBTION DU XENON
C
      SAX1G=(SAXE1+RFI*SAXE2)/RFI1
C
C     DELTA SIGMA ASSORBIMENTO DA XENO (NULLA IN QUANTO TALE CONTRIBUTO
C     E' GIA' PRESENTE IN SG1)
C
      DSGXE1=0.
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE STRIX0
C-----------------------------------------------------------------------
C
C     COSTITUISCE IL 'MAIN PROGRAM' DI 'STRIQS-3' CONTROLLANDO LE CHIAMA
C     ALLE VARIE SUBROUTINES DI QUEST'ULTIMO.
C     TRAMITE TRE 'ENTRY' ('STRIX1','STRIX2' E 'STRIX3')
C     VENGONO INDIVIDUATE COMPLESSIVAMENTE IN 'STRIX0' QUATTRO PARTI
C     PRINCIPALI DI 'STRIQS-3' :                                        
C
C     1)  'STRIX0'  STESSA CHE GESTISCE DINAMICAMENTE LA MEMORIA ED EFF
C                    IL CALCOLO STAZIONARIO INIZIALE. VIENE CHIAMATA DA
C                    'KIQS02', CIOE' IN PRATICA DALLA ROUTINE 'KINAC1' D
C                    'LEGO', AD OGNI ITERAZIONE DEL CALCOLO STAZIONARIO
C                    DI REGIMAZIONE E PER LA INIZIALIZZAZIONE DEL CALCOL
C                    DINAMICO (SIA NELL'OPZIONE DI CINETICA 1-D CHE 0-D)
C
C     2)  'STRIX1'  CHE ESEGUE LA VALUTAZIONE DELLE POTENZE DI PREVISIO
C                    SECONDO LE MODALITA' DEL METODO 'IQS'. VIENE CHIAMA
C                    SEMPRE DALLA ROUTINE 'KINAC1' DI 'LEGO' AD OGNI PAS
C                    TEMPORALE DI RICALCOLO TERMOIDRAULICO, ESCLUSIVAMEN
C                    NEL CASO DEL PRIMO ESAME DI UN GENERICO INTERVALLO
C                    DI RICALCOLO DELLA FORMA DI FLUSSO NEUTRONICO (IT=1
C
C     3)  'STRIX2'  CHE ESEGUE PER L'ITERAZIONE CORRENTE IL CALCOLO DEL
C                    POTENZE EFFETTIVE UTILIZZANDO I VALORI DELLE VARIAB
C                    TERMOIDRAULICHE PRODOTTI DA 'LEGO' SULLA BASE DELLE
C                    POTENZE CALCOLATE NEL CORSO DELLA ITERAZIONE PRECED
C                    ANCH'ESSA VIENE CHIAMATA DALLA 'KINAC1' AD OGNI PAS
C                    TEMPORALE DI RICALCOLO TERMOIDRAULICO, ESCLUSIVAMEN
C                    NEL CASO DEL PRIMO ESAME DI UN GENERICO INTERVALLO
C                    DI RICALCOLO DELLA FORMA DI FLUSSO NEUTRONICO (IT=1
C
C     4)  'STRIX3'  CHE,ALLA FINE DI UN PASSO TEMPORALE DI RICALCOLO
C                    DELLA FUNZIONE FORMA (E PRIMA DELL' ESAME DEL
C                    SUCCESIVO),NE EFFETTUA IL RICALCOLO CHIAMATA
C                    SIEMPRE DA 'KINAC1'.
C
C     NEL CASO DI ITERAZIONI SULLA FUNZIONE FORMA DI FLUSSO SUCCESSIVE A
C     PRIMA (IT>1) IL CONTROLLO DEL PROGRAMMA NON VIENE RESTITUITO ALLA
C     'KINAC1' DI 'LEGO' (PER CUI NON SONO PIU' RICHIAMATE LE SUBROUTINE
C     'STRIX1' E 'STRIX2') E IL RICALCOLO DELLA FORMA (GESTITO DEL TUT
C     ALL'INTERNO DI 'STRIX0') E' SOLO DI TIPO NEUTRONICO, RESTANDO I
C     VALORI DEI PARAMETRI TERMOIDRAULICI QUELLI VALUTATI NEL CORSO DELL
C     PRIMA ITERAZIONE (IT=1).
C
C     QUALORA INVECE SI FACCIA USO DELLA OPZIONE DI CINETICA ZERODIMENSI
C     IL CALCOLO NEUTRONICO NELL'AMBITO DI UNA DATA ITERAZIONE TERMOIDRA
C     VIENE INTERAMENTE GESTITO DALLA 'STRIX1'.
C
C-----------------------------------------------------------------------
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      INTEGER CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,H,RO,CSP,GIN,GINV,PHS,
     1        HAKF,EFB,WESTS,RES,XE,VIO,SM,PM,PROFTM,PROFRM,CALFA,
     2        PHI,ROV,FCN,ALBA,BQ,PH,EEF,PHV,ENF,BE,AL,C,SG,CBETA,
     3        HEL,AKF,CM,ALM,BEM,DEN,BQ1,BQV,BQV1,BQP,C2BQ,CALFA1,
     4        D,HBE,PHSV,PHP,C2,NBAR,ALBAS,WEST,PHT,CBETA1,RONOS,
     5        DBE,BEMI,HBEV,TIMP,AZ,BZ,ENFV,CV,ZDG,TN,SER,PHJ1,
     6        PROFLU,HBEK,TIMPT,ENFVV,CVV,TEMV,DV,ALMV,TCNOS,XEV,
     7        CMV,SERFI,SERFIV,HRO ,HTEM,WMED,WESTD,WESTV,CORD,
     8        WTILD,ATILD,WTRA,TREF,ALBASN,ALBASV,PHV1,ZW,VIOV,
     9        RECOBA,PALBA,PRPR,EEFR,CLTH,HALBA,HBORO,AKFCEL,GISF,
     &        FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     $        VELOC,BINSTE,PROFF,PROFP,BEJ,ALJ,COEXE1,DSGXE,GISFL,
     !        SIGXEL,SIGXE,PROFTC,TMNOS,PROFXE,XENOS
C
      INTEGER TCPU1,TCPU2
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/NEUT1$/S(  KAXS  ),DUMMI30(MAXSM-KAXS)
      COMMON/INPAR$/NC1M,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,NNXM,NNYM,
     &              NTTJM,NITJM,NLIBM,NPROFM,NKINM,NCELM,MAXS,KDIM,NCM
C
      COMMON/REG22$/TIMERG(NW),WTOTRG(NW),REATRG(NW),PDECRG(NW),
     &              AXOFRG(NW),AMINB1(NW),AMINB2(NW),ALFDRG(NW),
     &              ALFMRG(NW),ALFBRG(NW),DUMMI60(20*NW-10*NW)
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/PARPAR/PS$$(7),ITERT
      COMMON/XEIOTM/XEVV(NCNT),VIOVV(NCNT),TREFV(NCNT),TEMCV(NCNT),
     &              TEMPV(NCNT)
C
      CHARACTER SELSTA*12,STASEL*1,YES*1
      DIMENSION STASEL(12),JSELXX(12)
C
      COMMON/PRINT$/SELSTA
      COMMON/JSTAX$/JALBA,JEEF,JENF,JSG,JPROFL,JWW,JRO,JTEM,JXE,JSM,
     &              JRBA,JCM,JDUMMI(NW-12)
C
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
C
      COMMON/COREA$/ERRE,TZER,HKXE,HKB,HKRI(KGM),DUMMI33(NW-4-KGM)
      COMMON/PROVV$/EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
C
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),LIZO(15,15),N(5),
     &       LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),MAP(2,15),
     &       KAP(15,15),HELBT(5),INDEL(15,15)
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/INDIR$/ PHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     $        TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,WESTV,
     *        WESTD,WESTS,H,RO,CSP,GIN,WTRA,DUMMI0(NW-31)
      COMMON/INDR1$/ ALT,BEM,AL,     WW,XE,VIO,PM,SM,HEL,
     $               PHT,WGAMC,WTILD,ATILD,GINV,XEV,VIOV,
     *               TREF,ALBAS,WMED,CORD,NBAR,HALBA,HBORO,ALBA
     &              ,DUMMI1(NW-24)
      COMMON/INDR2$/ QCEL,CEFI,TEM,ALBASN,ALBASV,SERFI,HRO,
     1        EFB,RES,HTEM,TIMPT,
     2        PHI,ROV,FCN,BQ,PH,EEF,PHV,ENF,BE,C,SG,
     3        AKF,CM,ALM,DEN,WEST,
     4        DBE,BEMI,TIMP,AZ,BZ,ZDG,TN,SER,PHJ1,
     5        NBARRE,NBARN,PHV1,ZW,RECOBA,PALBA,PRPR,EEFR,CLTH
     &              ,DUMMI2(NW-45)
      COMMON/INDR3$/PROFLU,CL,DUMMI3(NW-2)
      COMMON/INDR5$/FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     $           VELOC,BINSTE,PROFF,PROFP,ILIB1,ILIB2,AKFCEL,BEJ,ALJ,
     &           COEXE1,DSGXE,PROFTM,PROFRM,TCNOS,RONOS,CALFA,CBETA,
     %           CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,PROFTC,TMNOS
     %           ,XENOS,PROFXE,DUMMI4(NW-35)
C
      EQUIVALENCE (STASEL(1),SELSTA) , (JSELXX(1),JALBA)
      DATA YES /'1'/
C
C-----------------------------------------------------------------------
C     ASSEGNAZIONE DELLE UNITA' DI LETTURA DEI DATI UTENTE (NREAD) E
C     DI SCRITTURA DEI PRINCIPALI DATI DI INPUT, DELLE SEGNALAZIONI
C     VARIE E DELL'OUTPUT DI STRIQS (NWRITE).
C
C      NREAD=56
C      NWRITE=57
C-----------------------------------------------------------------------
C     IL PROGRAMMA FA USO ANCHE DELLE UNITA' LOGICHE SEGUENTI :
C
C   UNITA' "55"  ( --> LETTURA DATI DELLE LIBRERIE DI COSTANTI NUCLEARI)
C   UNITA' "54"  ( --> LETTURA LIBRERIE DI PROFILI ASSIALI INIZIALI )
C   UNITA' "53"  ( --> LETTURA PARAMETRI RELATIVI ALLA CINETICA (0-D) )
C   UNITA' "50"  ( --> LETTURA O SCRITTURA PROFILI ASSIALI DI REGIMAZ.)
C   UNITA' "49"  ( --> SCRITTURA O LETTURA DELLE VARIABILI IN COMMON )
C   UNITA' "33"  ( --> REGISTRAZIONE GRANDEZZE DA PLOTTARE NELLO SPAZIO)
C   UNITA' "34"  ( --> REGISTRAZIONE GRANDEZZE DA PLOTTARE NELLO SPAZIO)
C   UNITA' "99"  ( --> SCRITTURA DI MESSAGGI ED INFORMAZIONI VARIE )
C                                                                       
C   ( L' UNITA' LOGICA "99" PUO' COINCIDERE COL TERMINALE VIDEO )
C-----------------------------------------------------------------------
C      IRLIB1=55
C      IRLIB2=54                                                        
C      IRLIB3=53
C      IREST =50                                                        
C      IQSWR =49
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C     SIGNIFICATO DEGLI INDICI PRINCIPALI RELATIVI AL DIMENSIONAMENTO
C     DELLE VARIABILI DI 'STRIQS' ALLOCATE NEL VETTORE DI MEMORIA 'S' : 
C
C     MAXS   = DIMENSIONE MASSIMA DEL VETTORE 'S' DI ALLOCAZIONE        
C              DINAMICA DELLA MEMORIA
C     NC1M   = NUMERO MAX DI CELLE ASSIALI TERMOIDRAULICHE IDENTICHE    
C     NRITM  = NUMERO MAX DI GRUPPI DI NEUTRONI RITARDATI (1-9)
C     NUZOM  = NUMERO MAX DI ZONE RADIALI CONCENTRICHE DEL NOCCIOLO (1-5
C     NNXM   = NUMERO MAX DI ELEMENTI DI COMBUSTIBILE (PWR)
C              O DI QUARTINE (BWR) LUNGO L'ASSE X (<16)                 
C     NNYM   = NUMERO MAX DI ELEMENTI DI COMBUSTIBILE (PWR)
C              O DI QUARTINE (BWR) LUNGO L'ASSE Y (<16)                 
C     NSTRAM = NUMERO MAX DI STRATEGIE PREVISTE PER IL MOVIMENTO
C              DELLE BARRE DI CONTROLLO (1-5)                           
C     NGM    = NUMERO MAX DI BANCHI DI BARRE DI CONTROLLO (<23)
C     NSM    = NUMERO MAX DI STEP DI INSERIMENTO DEI BANCHI DI BARRE (<3
C     NPDM   = NUMERO MAX DI PRODOTTI DI FISSIONE RESPONSABILI
C              DELLA POTENZA DI DECADIMENTO RESIDUA (2-11)              
C     NITJM  = NUMERO MAX DI PASSI TERMOIDRAULICI (O DI RICALCOLO DEI
C              RITARDATI) IN UN PASSO TEMPORALE DI RICALCOLO DELLA FORMA
C              DEL FLUSSO NEUTRONICO
C     NTTJM  = NUMERO MAX DI SOTTOPASSI DI TEMPO PER L'INTEGRAZIONE     
C              DELLE EQUAZIONI DELLA CINETICA PUNTIFORME IN UN PASSO
C              TERMOIDRAULICO (O DI RICALCOLO DEI RITARDATI)
C     NKINM  = NUMERO MASSIMO DI SOTTOCELLE UGUALI IN CUI CIASCUNA      
C              CELLA TERMOIDRAULICA VIENE SUDDIVISA AL FINE DEL SOLO
C              CALCOLO NEUTRONICO
C     NCELM  = NUMERO MASSIMO DI CELLE NEUTRONICHE ATTIVE (CALCOLATO    
C              DAL CODICE SULLA BASE DI NC1M E DI NKINM)
C     NLIBM  = NUMERO MASSIMO DI LIBRERIE DI BASE PRODOTTE DAL CODICE
C              DI INTERFACCIA 'NOSTRI'
C     NPROFM = NUMERO MASSIMO DI PROFILI ASSIALI INIZIALI PRODOTTI
C              DAL CODICE DI INTERFACCIA 'NOSTRI'
C     NCOE   = NUMERO DI COEFFICIENTI DELLE CORRELAZIONI PER IL CALCOLO
C              DELLE COSTANTI NUCLEARI GENERATI DA 'NOSTRI'
C
C-----------------------------------------------------------------------
      IF(IBWR.EQ.1.AND.IDKIN.EQ.0) GO TO 315
C-----------------------------------------------------------------------
C     SELEZIONAMENTO DEGLI INDICI DI STAMPA DEL COMMON 'JSTAXX' SULLA BA
C     DELLA STRINGA 'SELSTA' DEL COMMON 'PRINT$' INIZIALIZZATA IN 'STRIP
C
C     JXXXXX = 1 --> STAMPA DELLA GRANDEZZA XXXXX
C     JXXXXX = 0 --> LA GRANDEZZA XXXXX NON E' STAMPATA
C-----------------------------------------------------------------------
      DO 100 JX=1,12
  100 JSELXX(JX)=0
      DO 150 JX=1,12
      IF(STASEL(JX).EQ.YES) JSELXX(JX)=1                                
  150 CONTINUE
C---- CALCOLO STAZIONARIO ----------------------------------------------
C                                                                       
      LSTAZ=.TRUE.
      IPS=0                                                             
      IPL=1
      ITPS=1                                                            
      IEPS=1
      TPART=0.                                                          
      TPARTX=0.
      DELTIM=TEMFIN
      DTPSIM=5.
      DTPSI2=0.5*DTPSIM
      JPLOT=IPPREP
      TST=0.
      TST1=0.
      NTRAN=1
      IEND1=1
      IEND2=0
      IBORO=0
      IF(IDKIN.EQ.0) CALL STAZ0D(S(PROFLU),S(CL),S(ALT),S(WW),S(QCEL),
     &            S(WGAMC),S(TEM),
     &            S(ALBA),S(CM),S(ALM),S(BEM),S(HBE),S(HBEK),NCM,NGM,
     &            NRITM,NUZOM,S(WESTV),S(WESTD),NPDM,S(CORD),S(WESTS)
     &            ,S(H),S(RO),S(CSP),S(GIN),S(WTRA),JMAPP,JPLOT,
     &            JSTAMP,S(NBAR),EPSR,IPS,S(HEL),IVELBR,
     &            S(TREF),PXE,PIO,S(EFB),BPPM,S(WEST),NNYM,NSTRAM,
     &            NSM,S(RECOBA),S(PALBA),S(CLTH),S(PRPR),NC1M,
     &            S(D),S(PH),S(RES),S(TCNOS),S(RONOS),S(CALFA),
     &            S(CBETA),S(CALFA1),S(CBETA1),S(TMNOS),S(XENOS),S(XE))
      IF(IDKIN.EQ.1) CALL PRESTA(S(PROFLU),S(CL),S(ALT),S(WW),S(QCEL),
     2 S(WGAMC),S(CEFI),S(TEM),S(EFB),S(RES),S(NBAR),
     4 S(CORD),S(FCN),S(ALBA),S(BQ),S(PH),S(EEF),S(PHV),S(ENF),
     5 S(BE),S(AL),S(C),S(SG),S(PHI),
     6 S(AKF),S(CM),S(ALM),S(BEM),NCM,NGM,NCOSM,NRITM,NUZOM,JMAPP,
     7 NPDM, S ,JPLOT,JSTAMP,EPSR,IPS,S(ROV),
     9 S(HEL),S(XE),S(VIO),S(PM),S(SM),IVELBR,
     & IBORO,S(TREF),NNYM,NSTRAM,NSM,S(PRPR),S(EEFR),S(PALBA),
     $ S(ZW),S(CLTH),BO,NC1M,NLIBM,NPROFM,S(ZDG),S(TN),S(SER),S(DEN),
     * S(PHV1),EPSNOR,S(XEV),S(VIOV))
      CPUTOT=0.0
C      WRITE(NWRITE,1954) TIMEV,TCPU,CPUSTA
1954  FORMAT(/,1X,'TEMPO CORRENTE = ',G13.6,5X,'TCPU = ',G13.6,5X,
     $'CPUTOT = ',G13.6)
C
C     MEMORIZZAZIONI (PROFILI ASSIALI DI POTENZA, DI FLUSSO, ...)
C     NEL CASO DI REGIMAZIONE (CON CINETICA ASSIALE)
C
C      IF(LREGIM.AND.IDKIN.EQ.1) THEN
C      REWIND IREST
C      WRITE(IREST,199) (S(IS),IS=RES,RES+NC1-1)
C      WRITE(IREST,199) (S(IS),IS=PROFLU,PROFLU+NC1-1)
C      WRITE(IREST,199) (S(IS),IS=PHS,PHS+NC1-1)
C      WRITE(IREST,199) (S(IS),IS=D,D+NC1-1)
C      WRITE(IREST,199) RIAL,RIBA
C      WRITE(IREST,199) (BINSER(J),J=1,NG),BO
C      ENDIF
  199 FORMAT(4E15.8)
C      WRITE(NWRITE,745)
  745 FORMAT(///,1X,125('-'),///)
      IF(JSTAMP.NE.0.AND..NOT.LREGIM) THEN
      WRITE(NWRITE,*) '    RESTI DEL TRANSITORIO (1-D) DI REGIMAZIONE '
      WRITE(NWRITE,'(8G12.5)') (S(IS),IS=RES,RES+NC1-1)
      WRITE(NWRITE,*) '    PROFILO DI POTENZA (1-D) DI FINE REGIMAZIONE'
      WRITE(NWRITE,'(8G12.5)') (S(IS),IS=PROFLU,PROFLU+NC1-1)
      WRITE(NWRITE,*) '     PROFILO DI FLUSSO (1-D) DI FINE REGIMAZIONE'
      WRITE(NWRITE,'(8G12.5)') (S(IS),IS=PHS,PHS+NC1-1)
      WRITE(NWRITE,*) '     ESTRAZIONE DELLE BARRE DI FINE REGIMAZIONE'
      WRITE(NWRITE,'(8G12.5)') (BINSER(J),J=1,NG)
      WRITE(NWRITE,*) '   CONCENTRAZ. DI BORO DI FINE REGIMAZIONE =',BO
      WRITE(NWRITE,'(//)')
      ENDIF
C
      IDTJ=0
      ITST1=0
      ITST2=0
      NSCRAM=0
      RETURN
C
C     CALCOLO DI PREVISIONE (1-D)
C
      ENTRY STRIX1
C
C---- CALCOLO DINAMICO DI TIPO 'IQS' -----------------------------------
C
      IF(LSTAZ) THEN
      LSTAZ=.FALSE.
      WRITE(NWRITE,450) NTRAN
  450 FORMAT(//1X,125('-')//1X,' INIZIO DELLA FASE NUMERO ',I2,
     &       1X,'DEL TRANSITORIO'//,1X,125('-')/)
      ENDIF
      IF(IDKIN.EQ.0.AND.IDTJ.NE.0) GO TO 1103
C
      IF(ITPS.EQ.0.AND.IT.EQ.1)  GO TO 1103
      IF(ITPS.NE.1.OR.IEPS.NE.1) GO TO 3000
C
      ITMAX=30
C     INCREMENTO INDICE INTERVALLO DI RICALCOLO FUNZIONE FORMA ASSIALE
 1100 IPS=IPS+1
      ICALL=0
      IT=0
C      IF(IDKIN.EQ.1) WRITE(NWRITE,2121)
 2121 FORMAT(//' INIZIO DI UN NUOVO PASSO DTPSI DI RICALCOLO DELLA FORMA
     & DI FLUSSO ')
C     INCREMENTO INDICE DI RICALCOLO FUNZ. FORMA (NEL CASO DI NON-CONVER
 1102 IT=IT+1
      ITCALC=IT
      IF(IT.GT.ITMAX) GO TO 1000
      ITJ=0
      IPL=0
      IF(IT.EQ.1) IDTJV=IDTJ
 1103 NSTAMP=0
C      CALL CPUTIME(TCPU1)
      IF(ABS(TEMFIN-TIMEV).LE.0.10*DTJ) GO TO 2000
Casam      write(6,*)'TEMFIN, TIMEV, TEMFIN-TIMEV',TEMFIN, TIMEV,TEMFIN-TIMEV
Casam      write(6,*)'DTJ, 0.10*DTJ',DTJ, 0.10*DTJ
Casam      write(6,*)'LEND',LEND
C     INCREMENTO INDICE INTERVALLO DI AVANZAMENTO TEMPORALE TERMOIDRAULI
      ITJ=ITJ+1
      IDTJ=IDTJV+ITJ
      JPLOT=IPPREP
      IF(JSTAMP.GT.0) GO TO 23
      NSTAMP=2
      GO TO 24
   23 HJ=FLOAT(ITJ)/FLOAT(JSTAMP)
      JJH=HJ
      IF(ABS(FLOAT(JJH)-HJ).LT.1.E-6) NSTAMP=1
   24 CONTINUE
      IF(IDKIN.EQ.1) GO TO 600
C     CALCOLO ZERODIMENSIONALE
      CALL DINA0D(S(PHS),S(SERFIV),S(C2),S(TEM),S(FCN),
     $            S(EEF),S(ENF),S(SG),S(D),S(RES),S(AKF),S(BQ),S(CM),
     $            S(HBE),S(C),S(BE),S(DBE),S(ALM),S(BEMI),S(HBEV),
     $            S(HBEK),S(TIMP),S(TIMPT),NCM,NRITM,DERT,ITJ,NTTJM,
     $            ISCRAM,NSCRAM,IT,EPSKF,ITPS,NSTAMP,JPLOT,IDTJ,IPL,
     $            IVELBR,IPS,IBORO,S,NPDM,BPPM,S(WESTS),S(RO),S(H),
     $            S(GIN),S(CSP),S(PHSV),S(WESTD),S(WTRA),S(NBAR),TPARTX,
     $            S(BQV1),S(C2BQ),S(BQ1),S(HAKF),S(PHP),S(WESTV),JSTAMP,
     $            NGM,ITST1,ITST2,TST1,DELTAT,PXE,PIO,S(WEST),S(RECOBA),
     $            S(PALBA),S(ALT),S(WGAMC),S(QCEL),S(CLTH),S(ALBA),
     $            NUZOM,S(TCNOS),S(RONOS),S(CALFA),S(CBETA),S(CALFA1),
     $            S(CBETA1),S(TMNOS),S(XENOS))
      CALL PROLEG(REAT,S(WEST),S(WESTS),S(ALT),CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
C      CALL CPUTIME(TCPU2)
      TCPU=FLOAT(TCPU2-TCPU1)/100.
      CPUTOT=CPUTOT+TCPU
C      WRITE(NWRITE,1954) TIMEV,TCPU,CPUTOT
      RETURN
  600 CONTINUE
      CALL PREVIS ( S(FCN),S(ALBA),S(CEFI),S(ALT),S(EFB),S(ENF),
     2 S(EEF),S(SG),S(D),S(RES),S(AKF),S(PHS),S(BQ),S(NBAR),S(ALBAS),
     3 S(C2),S(SERFIV),NCM,NGM,ITJ,S(CM),S(ALM),S(CL),S(PHT),S(WEST),
     4 IPS,IT,S(TREF),S(TEM),S(BQV),NRITM,S(HBE),S(BEM),
     5 S(C),S(BE),S(AL),NSCRAM,S(BQV1),S(C2BQ),TPARTX,NTEMZ,ICALL,
     6 S(NBARRE),TPARTV,TPARTN,S(NBARN),S(ALBASN),S(ALBASV),S(RO),
     8 S(XE),S(VIO),S(PM),S(SM),S(HEL),IVELBR,BO,IBORO,NITJM,
     9 JPLOT,DERT,PHPRJ1,S(PROFLU),S(WESTS),S(WGAMC),S(QCEL),TIMEY,
     & WREAT,S(HALBA),S(HBORO),NUZOM,DERTVS,
     & S(FCNZ),S(ILIB1),S(ILIB2),S(COES1),S(COED1),S(COENF1),S(COEKFT),
     % S(COEEF1),S(RLAM),S(RBETA),S(VELOC),NLIBM,S(AKFCEL),S(ALJ),
     * S(BEJ),S(COEXE1),S(DSGXE),IREINP,S(CV),TTVP,DTPSI1,S(SIGXE),
     ! S(GISF),S(SIGXEL),S(GISFL),S(XEV),S(VIOV) )
      IBORO=0
      IF(IT.GE.2) GO TO 500
      D1=S(D)
      DNCEL=S(D+NC1-1)
      CALL PROLEG(REAT,S(WEST),S(WESTS),S(ALT),CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
C      CALL CPUTIME(TCPU2)
      TCPU=FLOAT(TCPU2-TCPU1)/100.
      CPUTOT=CPUTOT+TCPU
C      WRITE(NWRITE,1954) TIMEV,TCPU,CPUTOT
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,*) 'TIMEV=',TIMEV,'  DTJ=',DTJ,'  DTPSI=',DTPSI
      WRITE(NWRITE,*) ' WTOTL=',WTOT,'  WNEUTL=',WNEUT,'  REATL=',REATL
      WRITE(NWRITE,'(8G12.5)') (WCEL(K),K=1,NCELT)
      ENDIF
C      RETURN
C
C     CALCOLO EFFETTIVO (1-D)
C
      ENTRY STRIX2
C
C      CALL CPUTIME(TCPU1)
      CALL PREME(S(TEM),S(RO),S(HEL),S(TREF),S(PROFLU),S(TCNOS),
     &           S(RONOS),S(CALFA),S(CBETA),S(CALFA1),S(CBETA1),
     &           S(TMNOS),S(XENOS),S(XE))
      IF(NSTAMP.EQ.0.OR.NSTAMP.EQ.2) GO TO 500
C      CALL OUTP(TIMEY,NCM,S(ALBA),S(FCN),S(EEF),S(ENF),S(SG),S(PROFLU),
C     &          S(WEST),S(TEM),S(RO),S(H),S(GIN),WREAT,BO,S(XE),S(SM),
C     &          S(PALBA))
  500 CALL THERMO(S(TEM),S(RO),S(HRO),S(HTEM),S(TREF),NCM,IT,ITJ)
      IF(IT.EQ.1) ISCRAM=0
      ITPS=0
      CALL REINPA( S(PHS),S(SERFIV),S(C2),S(TEM),S(FCN),
     3S(EEF),S(ENF),S(SG),S(D),S(RES),S(AKF),S(BQ),S(CM),S(HBE),
     4S(C),S(BE),S(DBE),S(ALM),S(BEMI),S(HBEV),S(HBEK),S(TIMP),S(TIMPT),
     6NCM,NRITM,DERT,ITJ,NTTJM,S(ALT),S(BEM),S(AL),S(WEST),
     7ISCRAM,S(PHP),NSCRAM,S(BQV1),S(C2BQ),S(BQ1),IT,S(HAKF),EPSKF,ITPS,
     8NSTAMP,S(ALBA),S(PROFLU),S(WW),S(WESTS),S(RO),S(H),S(GIN),JPLOT,
     9IDTJ,IPL,S(XE),S(VIO),S(PM),S(SM),S(HEL),IVELBR,IPS,
     &IBORO,S(PALBA),PHPRJ1,BO,NUZOM,S(TREF),
     &S(FCNZ),S(ILIB1),S(ILIB2),S(COES1),S(COED1),S(COENF1),S(COEKFT),
     %S(COEEF1),S(RLAM),S(RBETA),S(VELOC),NLIBM,S(AKFCEL),S(ALJ),S(BEJ),
     *S(COEXE1),S(DSGXE),IREINP,WREAT,S(CV),TTVP,IMOT,S(SIGXE),S(GISF),
     !S(SIGXEL),S(GISFL),S(XEV),S(VIOV),AXOFFC,AOXE,AOIO,PASSI1,PASSI2)
      IF(ITERT.EQ.0.OR.IT.GT.1.OR.NSTAMP.EQ.0.OR.NSTAMP.EQ.2) GO TO 555
      CALL OUTP(TIMEY,NCM,S(ALBA),S(FCN),S(EEF),S(ENF),S(SG),S(PROFLU),
     &          S(WEST),S(TEM),S(RO),S(H),S(GIN),WREAT,BO,S(XE),S(SM),
     &          S(PALBA))
  555 CONTINUE
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,*) 'TIMEV=',TIMEV,'  DTJ=',DTJ,'  DTPSI=',DTPSI
      WRITE(NWRITE,*) ' WTOTL=',WTOT,'  WNEUTL=',WNEUT,'  REATL=',REATL
      WRITE(NWRITE,'(8G12.5)') (WCEL(K),K=1,NCELT)
      ENDIF
      IBORO=1
      CALL REENER(S(ALM),S(CM),S(PHS),S(CL),S(PHT),S(SERFIV),S(C2),
     1 S(WEST),S(EEF),S(ALT),S(PH))
      CALL RIT(S(TIMP),S(TIMPT),S(CM),S(AL),S(AZ),S(BZ),S(ALT),S(BE),
     1 S(ENF),S(PHS),S(SERFIV),S(ENFV),S(C),S(CV),NRITM,S(HBE),S(HBEK),
     2 S(C2),S(PHJ1),S(ENFVV),S(CVV),ITJ)
      CALL PROLEG(REAT,S(WEST),S(WESTS),S(ALT),CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
C      CALL CPUTIME(TCPU2)
      TCPU=FLOAT(TCPU2-TCPU1)/100.
      CPUTOT=CPUTOT+TCPU
C      WRITE(NWRITE,1954) TIMEV,TCPU,CPUTOT
      IF(ITPS.EQ.0.AND.IT.EQ.1) RETURN
      IF(ITPS.EQ.0.AND.IT.GE.2) GO TO 1103
C      CALL CPUTIME(TCPU1)
      IF(IT.GE.2) GO TO 700
      LIQS3=.TRUE.
      DTJOLD=DTJ
      DTJNUO=DTJNEW
      RETURN
C
      ENTRY STRIX3
C
C     RICALCOLO DELLA FUNZIONE FORMA ASSIALE DEI FLUSSI NEUTRONICI
C     VELOCE E TERMICO SECONDO IL FORMALISMO COARSE-MESH
C
      DTJ=DTJOLD
  700 CALL FORMA2(S(BE),S(ZDG),S(ALT),S(TN),S(SER),S(AL),S(C),DERT,
     &            NRITM,EPSR,NCM,FNORM1,S(DEN),EPSNOR,IMOT)
      IEPS=0
      CALL TSTPH(IEPS,EPSR,S(PHS),S(PHP),S(PHSV),S(C2),S(HBEV),S(HBEK),
     $S(ALT),S(D),NCM,S(BQ),S(HRO),S(RO),S(TEM),S(ROV),
     *S(TEMV),S(DV),S(ALMV),S(CMV),S(ALM),S(CM),S(BQV),S(EEF),
     $S(WEST),ITJ,ISCRAM,NSCRAM,S(ALBAS),S(ALBA),S(NBAR),NGM,FNORM1,
     &IDOIN,EPSNOR,IT,S(SERFI),S(SERFIV),S(C2BQ),S(BQP),S(BQV1),S(BQ1),
     +S(HTEM),ITST1,ITST2,NPDM,S(WMED),
     *S(WESTD),S(WESTV),S(WESTS),TST1,IEND1,IEND2,DELTAT,TPARTX,
     /JPLOT,IPL,JSTAMP,NITJM,S(C),S(CVV),NRITM,
     %IPS,S(PROFLU),S(CLTH),N,S(PRPR),DTJNUO,DTPSI1,AOXE,AOIO,S(XE),
     $S(VIO),XEVV,VIOVV,S(TREF),TREFV,TEMCV,TEMPV)
C      WRITE(NWRITE,2222) TEMFIN,TIMEVS,DTPSI,DTJ
 2222 FORMAT(/,1X,'TEMFIN =',G12.5,3X,'TIMEVS =',G12.5,3X,'DTPSI =',
     &G12.5,3X,'DTJ =',G12.5)
C      CALL CPUTIME(TCPU2)
      TCPU=FLOAT(TCPU2-TCPU1)/100.
      CPUTOT=CPUTOT+TCPU
C      WRITE(NWRITE,1954) TIMEV,TCPU,CPUTOT
      IF(IEPS.EQ.0)  GO TO 1102
      LIQS3=.FALSE.
      DTJ=DTJNUO
      CALL CHANGE(S(HBE),S(HBEV),S(ENFVV),S(ENF),S(CVV),S(C),
     $            NRITM,S(RO),S(ROV),S(TEM),S(TEMV),S(D),S(DV),
     *            S(ALMV),S(CMV),S(ALM),S(CM),DERT,DERTVS,S(XE),
     &            S(VIO),XEVV,VIOVV,S(TREF),TREFV,TEMCV,TEMPV)
C     TEST SULLA DURATA DEL TRANSITORIO
Casam      write(6,*)'strix3 - TEMFIN-TIMEV ',TEMFIN-TIMEV
Casam      write(6,*)'strix3 - DTPSI ',DTPSI
      IF((TEMFIN-TIMEV).GE.DTPSI) RETURN
C
 2000 CONTINUE
      WRITE(NWRITE,777)                                                 
  777 FORMAT(/////1X,125('-')//15X,'***** PROGRAMMA STRIQS : ',
     &       'FINE DEL TRANSITORIO *****',//,1X,125('-'),/)             
      LEND=.TRUE.
Casam      write(6,*)'STRIX3 - LEND=.TRUE. ',LEND
      WRITE(99,777)
      RETURN
C                                                                       
 1000 WRITE(NWRITE,50) IT
   50 FORMAT(1X,100('*')/1X,'ATTENZIONE, NUMERO DI ITERAZIONI SULLA FUNZ
     $IONE FORMA SUPERIORE AL MASSIMO (IT=',I3,')',/,1X,'IL PROGRAMMA SI
     * BLOCCA',/,1X,100('*'),/)
      GO TO 888
 3000 WRITE(NWRITE,65) ITPS,IEPS
   65 FORMAT(1X,'INIZIO DI UN NUOVO PASSO DI FORMA DTPSI CON GLI INDICI'
     &      ,' ITPS E IEPS NON ENTRAMBI UNITARI',/,1X,'ITPS =',I2,3X,
     &       'IEPS =',I2,/,1X,'SITUAZIONE DI ERRORE ; IL PROGRAMMA SI ',
     &       'BLOCCA ',/)
      GO TO 888
  315 WRITE(NWRITE,316)
  316 FORMAT(1X,100('*')/1X,'TENTATIVO DI ANALISI DI UN TRANSITORIO RELA
     &TIVO AD UN BWR CON UN MODELLO DI CINETICA NEUTRONICA ZERODIMENSION
     *ALE'/1X,'TALE OPZIONE ZERODIMENSIONALE E''ATTUALMENTE DISPONIBILE
     $SOLO PER PWR'/1X,'IL PROGRAMMA SI BLOCCA'/1X,100('*')/)
  888 WRITE(NWRITE,666)
  666 FORMAT(1H1)
      STOP ' *** FINE ANOMALA DEL MODULO STRIQS *** '
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE STAZ0D( PROFLU , CL , ALT , WW , QCEL , WGAMC , TEM ,
     &                 ALBA ,  CM ,  ALM ,  BEM ,  HBE ,  HBEK ,NCM,NGM,
     &               NRITM,NUZOM,  WESTV ,  WESTD ,NPDM,  CORD ,  WESTS,
     &               H ,  RO ,  CSP ,  GIN ,  WTRA ,JMAPP,JPLOT,JSTAMP,
     &               NBAR,EPSR,IPS,HEL,IVELBR,TREF,PXE,PIO,EFB,
     &               BPPM,WEST,NNYM,NSTRAM,NSM,RECOBA,PALBA,CLTH,PRPR,
     &               NC1M,D,PH,RES,TCNOS,RONOS,CALFA,CBETA,CALFA1,
     &               CBETA1,TMNOS,XENOS,XE)
C-----------------------------------------------------------------------
C     GESTISCE IL CALCOLO STAZIONARIO IN CINETICA ZERODIMENSIONALE (PWR)
C     (ATTUALMENTE VENGONO UTILIZZATI I COEFFICIENTI DI CONTROREAZIONE
C     DELLA REATTIVITA' PROPRI DEL 'LEGO')
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),IFUN
     &       ,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
C
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/BOR$/BORVCT,DUMMI23(NW-1)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/PKIN$/DWANOM,SIGFEE,DUMMI14(NW-2)
      COMMON/DANU0$/GIO,GXE,SIGXEM,EFIS,SIGFTH,DUMMI13(NW-5)
      COMMON /DANUC$/ VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $               FRAXE,FRASM,DUMMI12(NW-10)
      COMMON /ZEKIN$/ PXE0,B0,REAT0,DHRD0,DRHM0,DHRIT0,DUMMI11(NW-6)
      COMMON/PADKR$/PPF,AAG,PPFV,AAGV,DTKIN,DUMMI15(NW-5)
      COMMON/COREA$/ERRE,TZER,HKXE,HKB,HKRI(KGM),DUMMI33(NW-4-KGM)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),               LIZO(15,15),
     1N(5),LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),MAP(2,15),KAP(15,15),
     2HELBT(5),INDEL(15,15)                                             
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1             RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/PRODE$/ADEC(KPDM,KPDM-1),GDEC(KPDM,KPDM-1),POTDEC
     &             ,DUMMI50(5*NW-2*KPDM*(KPDM-1)-1)
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
C
      DIMENSION PROFLU( * ),CL( * ),ALT( 1 ),WW( * ),QCEL( * ),
     1 WGAMC( * ),TREF(*),CORD(*),TEM( * ),PALBA(*),PRPR(*),
     2 WESTV(*),HBE(*),HBEK(*), HEL(*), ALBA(*), D(*),PH(*),RES(*),
     3 WESTD(NPDM,*),GIN(*), CM(  *  ),ALM(  *  ),BEM(  *  ),WTRA(*),
     4 H(*),RO(*),CSP(*),WESTS(*),RECOBA(*),EFB(NGM,*),WEST(*),CLTH(*),
     5 TCNOS(*),RONOS(*),CALFA(*),CBETA(*),CALFA1(*),CBETA1(*),
     6 TMNOS(*),XENOS(*),XE(*)
C
      WRITE(NWRITE,230)
  230 FORMAT(1H0,/,30X,'*****  STAMPE IN KIQS02  *****',//,
     &             30X,'***** INIZIO DELLO STAZIONARIO *****'/)
C
      TIMEV=0.0
      DWANOM=WNOM/(CANN*ASPA*ASPA*ALATT*100.)
      VC=RC*RC
      DEPZ=3.14159*VC*ELNUM
      NOC=48
      IF (ILEGO.EQ.1) THEN
      NOCPWR=228
      ELSE IF(ILEGO.EQ.2) THEN
      IF(ABS(WNOM-2780.E+6).LE.10.E+6) THEN
      NOCPWR=225
      ELSE IF(ABS(WNOM-3800.E+6).LE.10.E+6) THEN
      NOCPWR=260
      ENDIF
      ENDIF
      IS=1
      ANOCP=(ALATT*100.-ZMIN)/FLOAT(NOCPWR)
      ANOC=(ALCAN*100.-ZMIN)/FLOAT(NOC)
      DO 67 J=1,NPD
   67 CORD(J)=1.0
      NCEL=NC1
      NC=NC1+1
C-----------------------------------------------------------------------
C     CALCOLO DEL LIVELLO DI ESTRAZIONE DEGLI NG BANCHI DI BARRE
C     (SIA IN PASSI CHE IN CM.) PER UN PWR.
C
C     - INSER(IS,NST,K),(K=1,NG) : LIVELLO DI ESTRAZIONE DEI BANCHI IN P
C     - BINSER(K),(K=1,NG)       : LIVELLO DI ESTRAZIONE DEI BANCHI IN C
C     - ALBA(K),(K=1,NG)         : COMPLEMENTO ALL'ALTEZZA ATTIVA DEL CA
C                                  DELL'INSERIMENTO (IN CM.) DI OGNI BAN
C                                  (--> ESTRAZIONE DEI BANCHI DI BARRE I
C
C       ( 228 PASSI DI ESTRAZIONE --> BARRE TUTTE FUORI
C           0 PASSI DI ESTRAZIONE --> BARRE TUTTE DENTRO )
C-----------------------------------------------------------------------
      BORVCT=CBORO
      DO 399 K=1,NG
      BINSER(K)=DINSER(K)
      INSER(IS,NST,K)=IFIX(BINSER(K))
C      ALBA(K)=INSER(IS,NST,K)*ANOCP+ZMIN
      ALBA(K)=BINSER(K)*ANOCP+ZMIN
      IF(ALBA(K).LE.ZMIN) ALBA(K)=ZMIN
      IF(ALBA(K).GE.ALATT*100.) ALBA(K)=ALATT*100.
  399 CONTINUE
C     INDIVIDUAZIONE DELLA CONCENTRAZIONE DI BORO NEL CIRCUITO PRIMARIO
      BPPM=BORVCT
C-----------------------------------------------------------------------
      IF(ABS(ALCAN-ALATT).GT.1.E-04) STOP ' ERRORE : ALCAN.NE.ALATT '
      ALCA=W/(ALCAN*CANN)
      DO 10 K=1,NG
      PALBA(K)=ALCAN*100.-ALBA(K)
      IF(PALBA(K).LE.0.0) PALBA(K)=0.0
   10 CONTINUE
C---- POTENZA LINEARE TOTALE DI REATTORE ------------------------------
      DO 9  K=1,NCEL
      WW(K)=ALCA*PROFLU(K)
      WWWK=1.
      DO 300 J=1,NPD
      WWWK=WWWK+ADEC(J,NPD-1)*GDEC(J,NPD-1)*ABS(TPAS)/(1.+ADEC(J,NPD-1)*
     $          ABS(TPAS))
  300 CONTINUE
C---- POTENZA LINEARE DI FISSIONE -------------------------------------
      WW(K)=WW(K)/WWWK
C---- POTENZA GENERATA NEL REFRIGERANTE PER RISCALDAMENTO GAMMA -------
      WGAMC(K)=RGAM*WW(K)*CL(K)
C---- POTENZA DI DECADIMENTO ------------------------------------------
      DO 200 J=1,NPD
      WESTD(J,K)=CORD(J)*(ADEC(J,NPD-1)*GDEC(J,NPD-1)*WW(K)*ABS(TPAS))/
     &         (1.+ADEC(J,NPD-1)*ABS(TPAS))
  200 CONTINUE
C     WRITE(NWRITE,20)(WESTD(J,K),J=1,NPD)
    9 CONTINUE
   20 FORMAT(1X,6(E12.5,2X))
      PDEC=0.
      PFIS=0.
      DO 16 K=1,NC1
      WESTS(K)=0.
      DO 17 J=1,NPD
   17 WESTS(K)=WESTS(K)+WESTD(J,K)
      PDEC=PDEC+WESTS(K)*CL(K)
      PFIS=PFIS+WW(K)*CL(K)
   16 CONTINUE
C---- POTENZA MEDIA TOTALE DI DECADIMENTO (W) --------------------------
      POTDEC=PDEC*CANN
      WRITE(NWRITE,30) POTDEC
   30 FORMAT(5(/),1X,'POTENZA MEDIA TOTALE DI DECADIMENTO WDEC =',E12.5)
C---- POTENZA MEDIA TOTALE DI FISSIONE (W) -----------------------------
      POTFIS=PFIS*CANN
      WRITE(NWRITE,44) POTFIS
   44 FORMAT(1X,'POTENZA TOTALE DI FISSIONE WFIS =',E12.5)
      RADEC=POTDEC/W
C---- DENSITA' DI POTENZA DI ASSEMBLAGGIO GENERATA PER FISSIONE -------
      DWANOM=DWANOM*(1.-RADEC)
C---- POTENZA TOTALE DI REATTORE (W) ----------------------------------
      WRITE(NWRITE,40) W
   40 FORMAT(1X,'POTENZA TOTALE DI REATTORE W =',E12.5)
C      WRITE(NWRITE,134)(PROFLU(K),K=1,NCEL)
  134 FORMAT(//1X,'PROFILO DI POTENZA ASSIALE (CINETICA ZERODIMENSIONALE
     $)'/8(2X,G12.5))
C
      CALL PREME(TEM,RO,HEL,TREF,PROFLU,TCNOS,RONOS,CALFA,CBETA,
     &           CALFA1,CBETA1,TMNOS,XENOS,XE)
C
      DO 4113 K=1,NC
      WEST(K)=WW(K)/100.
      WESTV(K)=WEST(K)
 4113 CONTINUE
      DO 8192 K=1,NCEL
      DO 18 J=1,NPD
   18 WESTD(J,K)=WESTD(J,K)/100.
      WESTS(K)=WESTS(K)/100.
 8192 CONTINUE
      ZWREAF=0.
      DO 1 K=1,NCEL
    1 ZWREAF= WW(K) /100.*ALT(K)+ZWREAF
      ZWREAF=ZWREAF*CANN
C     CALCOLO DELLA REATTIVITA' CONTROLLATA DA OGNI BANCO DI BARRE
      DHRIT=0.
      DO 25 K=1,NG
      HBA=ALCAN*100.-ALBA(K)
      ER=HBA/(ALCAN*100.)*100.
      HRIM=-0.5*COS(3.14159*ER/100.)+0.5
      RECOBA(K)=-HRIM*HKRI(K)*1.E-05
      DHRIT=DHRIT+RECOBA(K)
   25 CONTINUE
      DHRIT0=DHRIT
C     CALCOLO DELLE CONCENTRAZIONI DI XENO E DI IODIO (ATOMI/(CM**3))
      FRAXE=1.-FRAIO
      HKXE=HKXE*1.E-15
      SIGAXE=9.6981E-19
      GIO=YXE*FRAIO/EFIS
      GXE=YXE*FRAXE/EFIS
      SIGXEM=SIGAXE/(EFIS*SIGFTH)
      DENWA=ZWREAF/(ASPA*ASPA*CANN*ALCAN*100.)
      DWAPER=DENWA*100./DWANOM
      GIO=GIO*DWANOM/100.
      GXE=GXE*DWANOM/100.
      SIGXEM=SIGXEM*DWANOM/100.
      VLAMXS=VLAMXE+SIGXEM*DWAPER
      PIO=GIO*DWAPER*ABS(TPAS)/(1.+VLAMIO*ABS(TPAS))
      PXE=(VLAMIO*PIO+GXE*DWAPER)*ABS(TPAS)/(1.+VLAMXS*ABS(TPAS))
      PIO0=PIO
      PXE0=PXE
C     CONDIZIONE DI CRITICITA' IMPOSTA
      REAT=0.0
      REAT0=REAT
      HREAT=REAT/ALBIG
C     DETERMINAZIONE DEL FLUSSO NEUTRONICO T
      RSUP=ASPA*ASPA/(DEPZ*1.E+04)
      DENWF=DENWA*RSUP
      WRITE(NWRITE,*) 'DENWF=',DENWF
      SIGFEE=EFIS*SIGFTH
      T=DENWF/SIGFEE
      TVS=T
      TIMEVS=TIMEV
C
C      WRITE(NWRITE,812)
  812 FORMAT(/,5X,'VALORI DI CONVERGENZA :',/)
C      WRITE(NWRITE,803) NST
  803 FORMAT(5X,'STEP NUMERO',2X,I2/)
      WRITE(NWRITE,700) (PALBA(K),K=1,NG)
  700 FORMAT(20X,'ALTEZZA BARRE'/(8G12.5))
      WRITE(NWRITE,755) (BINSER(K),K=1,NG)
  755 FORMAT(/,20X,'ESTRAZIONE BARRE (IN PASSI)'/(8G12.5))
C      WRITE(NWRITE,701)(RECOBA(K),K=1,NG)
  701 FORMAT(/5X,'REATTIVITA'' CONTROLLATA DAI BANCHI DI BARRE'/
     $(8G14.7))
      WRITE(NWRITE,809)REAT
  809 FORMAT(/5X,'REATTIVITA'' =',2X,G14.7)
      WRITE(NWRITE,120)DENWA,T
  120 FORMAT(/5X,'DENSITA'' DI POTENZA DI ASSEMBLY',2X,G12.5//5X,'FLUSSO
     & NEUTRONICO',2X,G12.5)
      WRITE(NWRITE,158) 1./VEL
  158 FORMAT(/5X,'VELOCITA'' NEUTRONICA =',G12.5)
      WRITE(NWRITE,159) SIGFNU
  159 FORMAT(/5X,'NU * SIGMA FISSIONE =',G14.7)
      WRITE(NWRITE,161) EFIS
  161 FORMAT(/5X,'ENERGIA MEDIA DI FISSIONE =',G12.5)
      WRITE(NWRITE,162) VNUM
  162 FORMAT(/5X,'NUMERO MEDIO NU DI NEUTRONI RILASCIATI PER FISSIONE',
     &       ' =',F6.3)
      WRITE(NWRITE,163) (ALM(J),J=1,NRIT)
  163 FORMAT(/5X,'COSTANTI MEDIE DI DECADIMENTO',/,(6G12.5))
      WRITE(NWRITE,164) (BEM(J),J=1,NRIT)
  164 FORMAT(/5X,'FRAZIONI MEDIE DI RITARDATI',/,(6G12.5))
C     CALCOLO DELLE CONTROREAZIONI DI REATTIVITA' DOPPLER E DEL MODERATO
      TEMTOT=0.
      TRFTOT=0.
      ROTOT=0.
      DO 1984 K=1,NCEL
      TEMTOT=TEMTOT+(TEM(K)+273.)*ALT(K)
      TRFTOT=TRFTOT+(TREF(K)+273.)*ALT(K)
      ROTOT=ROTOT+RO(K)*ALT(K)
 1984 CONTINUE
      TEMTOT=TEMTOT/(ALCAN*100.)
      TRFTOT=TRFTOT/(ALCAN*100.)
      ROTOT=ROTOT/(ALCAN*100.)
      DHRD0=-4066.*ALOG((TEMTOT     +429.)/(TZER+429.))
      DHRD0=DHRD0*1.E-05
      AB=-0.003402+1.4029E-06*B0
      BB=3.2421-0.00132*B0
      GB=-787.+0.3248*B0
      DRHM0=AB*TRFTOT**3./3.+BB*TRFTOT**2./2.+GB*TRFTOT
      DRHM0=DRHM0*1.E-05
      ASM=ROTOT
C     CALCOLO DELLA CONCENTRAZIONE DEI PRECURSORI DI NEUTRONI RITARDATI
      DO 5433 J=1,NRIT
 5433 CM(J)=BEM(J)*VEL*T/(ALM(J)*ALBIG)
      WRITE(NWRITE,124)(CM(J),J=1,NRIT)
  124 FORMAT(/10X,'CONCENTRAZIONE MEDIA DI RITARDATI',/(6G16.7))
      DO 5434 J=1,NRIT
 5434 CM(J)=CM(J)/VEL
      BEMTOT=0.
      ALUNO=0.
      DO 5 J=1,NRIT
      HBE(J)=BEM(J)/ALBIG
      BEMTOT=BEMTOT+BEM(J)
      ALUNO=ALUNO+BEM(J)/ALM(J)
    5 CONTINUE
      HBEM=BEMTOT/ALBIG
      ALUNO=BEMTOT/ALUNO
      ALUNOV=ALUNO
      DO 881 J=1,NRIT
  881 HBEK(J)=HBE(J)
      HREATK=HREAT
      HBEMK=HBEM
C     INIZIALIZZAZIONI RELATIVE ALLA MATRICE DELLA CINETICA PUNTO (PADE1
      AAG=(BEMTOT-REAT0)/ALBIG
      PPF=1./ALBIG
C     CONTROREAZIONI DI REATTIVITA' STAZIONARIE (SECONDO I MODELLI DI
C     CONTROREAZIONE DELLA SUBROUTINE CRLOC DI 'STRIP')
      CDOP=0.
      CMOD=0.
      CBOR=0.
      CXEN=0.
      CBAR=0.
C     UTILIZZO DEI COEFFICIENTI DI RIPARTIZIONE RADIALE DELLA POTENZA
C     FISSATI IN 'STRIP' (TRAMITE LA FUNCTION 'ETAR')
      DO 347 KR=1,NUZO
  347 PRPR(KR)=ETAR(KR)
C
      D1=RES(1)
      DNCEL=RES(NCEL)
      CALL PROLEG(REAT,WEST,WESTS,ALT,CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
C
      IF(JSTAMP.NE.0) THEN
      WRITE(99,31) TIMEV,T,REAT
   31 FORMAT(/1X,'TIME = ',G12.5,2X,'AMPIEZZA  T = ',G12.5,2X,
     &       'REATTIVITA'' = ',G14.7)
      WRITE(NWRITE,'(1H1)')
      CALL OUTP0D(TIMEV,ALBA,PROFLU,WEST,TEM,TREF,H,GIN,W,BPPM,PXE,CM,
     &            T,RECOBA,PALBA)
      ENDIF
C
      WRITE(NWRITE,150)
  150 FORMAT(/////30X,'***** FINE DELLO STAZIONARIO *****'/)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PRESTA(PROFLU,CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,
     1 EFB,RES,NBAR,CORD,FCN,ALBA,BQ,PH,EEF,PHV,ENF,
     2 BE,AL,C,SG,PHI,AKF,CM,ALM,BEM,NCM,NGM,NCOSM,
     3 NRITM,NUZOM,JMAPP,NPDM, S ,JPLOT,JSTAMP,EPSR,
     4 IPS,ROV,HEL,XE,VIO,PM,SM,IVELBR,IBORO,TREF,NNYM,NSTRAM,
     5 NSM,PRPR,EEFR,PALBA,ZW,CLTH,BO,NC1M,NLIBM,NPROFM,ZDG,TN,
     6 SER,DEN,PHV1,EPSNOR,XEV,VIOV)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      INTEGER PHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     $        TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,WESTV,
     *        WESTD,CORD,WESTS,H,RO,CSP,GIN,WTRA,PROFTM,PROFRM,TCNOS,
     &        FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,RONOS,
     $        VELOC,BINSTE,PROFF,PROFP,AKFCEL,BEJ,ALJ,COEXE1,DSGXE,
     &        CALFA,CBETA,CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,
     &        PROFTC,TMNOS,PROFXE,XENOS
      COMMON/INDIR$/ PHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     $        TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,WESTV,
     *        WESTD,WESTS,H,RO,CSP,GIN,WTRA,DUMMI0(NW-31)
      COMMON/INDR5$/FCNZ,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     $           VELOC,BINSTE,PROFF,PROFP,ILIB1,ILIB2,AKFCEL,BEJ,ALJ,
     &           COEXE1,DSGXE,PROFTM,PROFRM,TCNOS,RONOS,CALFA,CBETA,
     %           CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,PROFTC,TMNOS
     %           ,XENOS,PROFXE,DUMMI4(NW-35)
C
      DIMENSION PROFLU(*),CL(*),ALT(*),WW(*),QCEL(*),WGAMC(*),CEFI(*),
     1          PM(*),TEM(*),SM(*),EFB(NGM,*),RES(*),XEV(*),VIOV(*),
     3          FCN(NCM,*),ALBA(*),BQ(*),PH(*),EEF(*),PHV(*),ENF(*),
     4          BE(NRITM,*),AL(NRITM,*),C(NRITM,*),SG(*),PHI(*),XE(*),
     5          AKF(*),CM(*),ALM(*),BEM(*),S(  *  ),VIO(*),PHV1(*),
     6          ROV(*),HEL(*),TREF(*),ZDG(*),TN(*),SER(*),DEN(*),
     8          PALBA(*),ZW(*),EEFR(*),PRPR(*),CLTH(*),NBAR(*),CORD(*)
C-----------------------------------------------------------------------
C     SUBROUTINE PER IL DIMENSIONAMENTO DEI VETTORI IN ARGOMENTO
C     PRIMA DELL'ESECUZIONE DELLO STAZIONARIO
C-----------------------------------------------------------------------
      CALL STEADY(PROFLU,CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,
     1 EFB,RES, FCN,ALBA,BQ,PH,EEF,PHV,ENF,BE,
     2 AL,C,SG,PHI,AKF,CM,ALM,BEM,S(PHS),S(D),S(HBE),S(PHSV),S(HBEV),
     4 S(HBEK),NCM,NGM,NRITM,NC1M,NUZOM,NCOSM,S(C2),S(ENFV),
     5 S(CV),S(ENFVV),S(CVV),S(PHP),S(TEMV),S(DV),S(ALMV),
     6 S(CMV),S(SERFIV),S(BQ1),S(BQV),S(BQV1),S(BQP),S(C2BQ),S(HAKF),
     7 S(WESTV),S(WESTD),NPDM,CORD,S(WESTS),S(H),S(RO),S(CSP),S(GIN),
     8 S(WTRA),JMAPP,JPLOT,JSTAMP,NBAR,EPSR,IPS,ROV,HEL,XE,VIO,PM,SM,
     9 IVELBR,IBORO,TREF,NNYM,NSTRAM,NSM,PRPR,EEFR,PALBA,ZW,CLTH,BO,
     & S(FCNZ),S(ILIB1),S(ILIB2),S(COES1),S(COED1),S(COENF1),S(COEKFT),
     % S(COEEF1),S(RLAM),S(RBETA),S(VELOC),S(BINSTE),S(PROFF),S(PROFP),
     $ NLIBM,NPROFM,S(AKFCEL),S(ALJ),S(BEJ),S(COEXE1),S(DSGXE),ZDG,TN,
     * SER,DEN,PHV1,EPSNOR,S(TCNOS),S(RONOS),S(CALFA),S(CBETA),
     ^ S(CALFA1),S(CBETA1),S(SIGXE),S(GISF),S(SIGXEL),S(GISFL),
     ! XEV,VIOV,S(TMNOS),S(XENOS))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE DINA0D(PHS,SERFIV,C2,TEM,FCN,EEF,ENF,SG,D,RES,
     $            AKF,BQ,CM,HBE,C,BE,DBE,ALM ,  BEMI ,  HBEV ,
     $            HBEK ,  TIMP ,  TIMPT ,NCM,NRITM,DERT,ITJ,NTTJM,
     $            ISCRAM,NSCRAM,IT,EPSKF,ITPS,NSTAMP,JPLOT,IDTJ,IPL,
     $            IVELBR,IPS,IBORO,S,NPDM,BPPM,  WESTS ,  RO ,  H ,
     $            GIN ,  CSP , PHSV ,  WESTD , WTRA ,  NBAR ,TPARTX,
     $            BQV1,C2BQ,BQ1,HAKF,PHP,WESTV,JSTAMP,NGM,ITST1,ITST2,
     $            TST1,DELTAT,PXE,PIO,WEST,RECOBA,PALBA,ALT,
     $            WGAMC,QCEL,CLTH,ALBA,NUZOM,TCNOS,RONOS,CALFA,CBETA,
     $            CALFA1,CBETA1,TMNOS,XENOS)
C
C-----------------------------------------------------------------------
C     GESTISCE IL CALCOLO DINAMICO IN CINETICA ZERODIMENSIONALE
C-----------------------------------------------------------------------
C
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
C
        LOGICAL LP4,LP10,LP17,LP8,LP11,L1TCO,LP12,LP14,
     &  LP1A,LP1B,LP1C
C
        COMMON/PERM00/LP4,LP10,LP17,LP8,LP11,L1TCO,LP12,LP14,
     &  LP1A,LP1B,LP1C
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      INTEGER BEM,AL,PROFLU,WW,XE,VIO,PM,SM,HEL,HBORO,XEV,VIOV,
     &        PHT,WTILD,ATILD,GINV,TREF,ALBAS,WMED,HALBA
      COMMON/INDR1$/ IALT,BEM,AL,WW,XE,VIO,PM,SM,HEL,
     $               PHT,IWGAMC,WTILD,ATILD,GINV,XEV,VIOV,
     *               TREF,ALBAS,WMED,ICORD,INBAR,HALBA,HBORO,IALBA
     &              ,DUMMI1(NW-24)
      COMMON/INDR3$/PROFLU,ICL,DUMMI3(NW-2)
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
C
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),LIZO(15,15),NUEL(5),
     &LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),MAP(2,15),KAP(15,15),
     &HELBT(5),INDEL(15,15)
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      DIMENSION RECOBA(*),PHS(*),SERFIV(*),C2(*),TEM(*),FCN(NCM,*),
     *          EEF(*),ENF(*),SG(*),D(*),RES(*),AKF(*),ALBA(*),
     %          BQ(*),CM(*),HBE(*),C(NRITM,*),BE(NRITM,*),DBE(*),ALM(*),
     /          BEMI(*),HBEV(*),HBEK(*),TIMP(*),TIMPT(*),S(  *  ),H(*),
     +          WESTS(*),RO(*),GIN(*),CSP(*),PHSV(*),WESTD(NPDM,*),
     #          WTRA(*),NBAR(*),BQV1(*),BQ1(*),C2BQ(*),HAKF(*),PHP(*),
     -          WESTV(*),WEST(*),PALBA(*),ALT(*),WGAMC(*),QCEL(*),
     =          CLTH(*),TCNOS(*),RONOS(*),CALFA(*),CBETA(*),CALFA1(*),
     ^          CBETA1(*),TMNOS(*),XENOS(*)                             
C
      NCEL=NC1
      NC=NC1+1
      ISCRAM=0
      LFORMA=.FALSE.
C---- INCREMENTO TEMPO CORRENTE ----------------------------------------
      TIMEY=TIMEV+DTJ
       WRITE(NWRITE,333) TIMEY
  333 FORMAT(//1X,'TIMEY (PREVIS) =',G12.5/)
      TIMEZ=TIMEY-TST-TPARTX
C     DETERMINAZIONE DEI VALORI CORRENTI DELLA CONCENTRAZIONE DI BORO
C     E DELLA POSIZIONE DELLE BARRE DI CONTROLLO (PROVENIENTI DA LEGO)
      BPPM=CBORO
      DO 476 K=1,NG
      BINSER(K)=DINSER(K)
      ALBA(K)=BINSER(K)*ANOCP+ZMIN
      IF(ALBA(K).LE.ZMIN) ALBA(K)=ZMIN
      IF(ALBA(K).GE.ALATT*100.) ALBA(K)=ALATT*100.
  476 CONTINUE
      CALL PREME(TEM,RO,S(HEL),S(TREF),S(PROFLU),TCNOS,RONOS,CALFA,
     &           CBETA,CALFA1,CBETA1,TMNOS,XENOS,S(XE))
      CALL REA0D(PXE,BPPM,ALBA,TEM,S(TREF),RECOBA,ALT)
      CALL KINET0(CM,S(BEM),ALM,NTTJM)
      CALL RIXEDE(CM,S(BEM),ALM,HBEK,HBE,PIO,PXE,WEST,WESTS,S(PROFLU),
     &         ALT,PHS,EEF,WESTD,WESTV,NPDM,S(WMED),WREAT,WREATF,WREATD)
      IF(.NOT.LP4) GO TO 111
C --- SCRAM DEL REATTORE
      NSTAMP=1
      ISCRAM=1
      TIMEVS=TIMEY
      IF(ISCRAM.EQ.1.AND.NSCRAM.EQ.0) THEN
      CALL SSCRAM(NSCRAM,S(ALBAS),ALBA,NGM,ITST1,ITST2,TST1,DELTAT,
     &             TEMFIN,TPARTX,JSTAMP,WEST,ALT)
      WRITE(NWRITE,450) TIMEY,T,WREAT
  450 FORMAT(/5X,'*** ATTENZIONE, SCRAM DEL REATTORE ***',//,1X,
     &'TIME = ',G12.5,3X,'FLUSSO T = ',G12.5,3X,'WREAT = ',G12.5,/)
      ENDIF
  111 CONTINUE
      IF(JSTAMP.NE.0) WRITE(NWRITE,645)
     &             TIMEY,REAT,WREAT,(S(IS),IS=IALBA,IALBA+NG-5),BPPM
  645 FORMAT(1X,'TIMEY=',G12.5,1X,'REAT=',G13.7,1X,
     &       'POTTOT=',G12.5,1X,'ALBA=',2G12.5,1X,'BO=',G12.5,/)
      IF(NSTAMP.EQ.0.OR.NSTAMP.EQ.2) GO TO 902
      WRITE(99,30) TIMEY,T,REAT
   30 FORMAT(/1X,'TIME = ',G12.5,2X,'AMPIEZZA  T = ',G12.5,2X,
     &       'REATTIVITA'' = ',G14.7)                                   
      CALL OUTP0D(TIMEY,ALBA,S(PROFLU),WEST,TEM,S(TREF),H,GIN,WREAT,
     &            BPPM,PXE,CM,T,RECOBA,PALBA)                           
  902 TIMEV=TIMEY
      RETURN                                                            
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PROLEG(REAT,WEST,WESTS,ALT,CANN,REALEG,
     $                  WTOT,WNEUT,WCEL)
C-----------------------------------------------------------------------
C     CALCOLO DELLE POTENZE TOTALI DI CELLA
C     E DELLA POTENZA NEUTRONICA UTILIZZATE DA 'LEGO'
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      DIMENSION WCEL(*),WEST(*),WESTS(*),ALT(*)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
C
      REALEG=REAT*1.E+05
      KN=0
      WTOT=0.
      POTFIS=0.
      DO 473 KT=1,NCELT                                                 
      WCTH=0.
      CLTHH=0.
      DO 474 JN=1,NKIN
      KN=KN+1
      CLTHH=CLTHH+ALT(KN)
      WCTH=WCTH+(WEST(KN)+WESTS(KN))*ALT(KN)*CANN
      POTFIS=POTFIS+WEST(KN)*ALT(KN)*CANN
  474 CONTINUE
      WCEL(KT)=WCTH
      WTOT=WTOT+WCEL(KT)
  473 CONTINUE
      WNEUT=POTFIS
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,45) (WCEL(KT),KT=1,NCELT)
   45 FORMAT(1X,'POTENZA TOTALE DI CELLA (LEGO)',/,6(1X,G12.5))
      WRITE(NWRITE,*) ' WTOT=',WTOT,'  WNEUT=',WNEUT
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE REA0D(PXE,B,ALBA,TEM,TREF,RECOBA,ALT)
C-----------------------------------------------------------------------
C     CALCOLA LA REATTIVITA' DEL NOCCIOLO TRAMITE COEFFICIENTI DI
C     REATTIVITA' PREFISSATI (CINETICA NEUTRONICA 0-D PER PWR)
C     VENGONO PORTATI IN CONTO (RISPETTO ALLO STAZIONARIO):
C     - MOVIMENTI DELLE BARRE DI CONTROLLO
C     - VARIAZIONI DELLA CONCENTRAZIONE DI XENO
C     - VARIAZIONI DELLA CONCENTRAZIONE DI BORO
C     - VARIAZIONI DELLA TEMPERATURA DEL COMBUSTIBILE (EFFETTO DOPPLER)
C     - VARIAZIONI DELLA TEMPERATURA DEL MODERATORE
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION ALBA(*),TEM(*),TREF(*),RECOBA(*),ALT(*)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON /ZEKIN$/ PXE0,B0,REAT0,DHRD0,DRHM0,DHRIT0,DUMMI11(NW-6)
      COMMON/COREA$/ERRE,TZER,HKXE,HKB,HKRI(KGM),DUMMI33(NW-4-KGM)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      REAL*8 REATOT
C
C     UTILIZZO DELLE CONTROREAZIONI E DELLE FUNZIONI DI 'STRIP'
C
      CALL CRLOC(REATOT)
      REAT=REATOT
      HREAT=REAT/ALBIG
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE REENER(ALM,CM,PHS,CL,PHT,PHSV,C2,WEST,EEF,ALT,PH)
C-----------------------------------------------------------------------
C     CALCOLA L'ENERGIA TERMICA DA RESTITUIRE AL FLUIDO TERMOVETTORE
C     (NEL PASSO DTJ SUCCESSIVO) COME DIFFERENZA FRA L'ENERGIA PREVISTA
C     E QUELLA CALCOLATA NEL PASSO CORRENTE (NELLA PRESENTE VERSIONE
C     TALE ENERGIA DA RESTITUIRE E' SUPPOSTA NULLA)
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION ALM(*),CM(*),CL(*),PHT(*),PHSV(*),C2(*),EEF(*),
     1          WEST(*),PHS(*),ALT(*),PH(*)
C
      DO 1 K=1,NC1
      PHS(K)=PHSV(K)+C2(K)*(TIMEV-TIMEVS)
      WEST(K)=PHS(K)*EEF(K)*DEPZ*T*1.E+04
    1 CONTINUE
      WF=0.
      DO 2 K=1,NC1
    2 WF=WF+WEST(K)*ALT(K)
      NCEL=NC1
      PSER=0.
      CSER=0.
      DO 900 K=1,NRIT
  900 CSER=ALM(K)*CM(K)
      C1=CSER/ALUNO
      DO 901 K=1,NC1
  901 PSER=PSER+PHS(K)*CL(K)*T
      PHPR=PSER/ALCAN
C     ENER=(WF-WES)*DTJ*.5
C     IPOTESI DI ENERGIA TERMICA DA RESTITUIRE NULLA
      ENER=0.
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE RIXEDE(CM,BEM,ALM,HBEK,HBE,PIO,PXE,WEST,WESTS,PROFLU,
     $           ALT,PHS,EEF,WESTD,WESTV,NPDM,WMED,WREAT,WREATF,WREATD)
C-----------------------------------------------------------------------
C     RICALCOLA LA DENSITA' DI POTENZA ASSIALE DI FISSIONE E DI
C     DECADIMENTO E LE NUOVE CONCENTRAZIONI DI XENO E DI IODIO
C     NEL CASO DI CALCOLO ZERODIMENSIONALE.
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION CM(*),BEM(*),ALM(*),HBEK(*),HBE(*),WEST(*),WESTS(*),
     &          PROFLU(*),ALT(*),PHS(*),EEF(*),WESTD(NPDM,*),WESTV(*),
     $          WMED(*)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/DANU0$/GIO,GXE,SIGXEM,EFIS,SIGFTH,DUMMI13(NW-5)
      COMMON /DANUC$/ VLAMXE,VLAMIO,VLAMPM,VNUM,YXE,YSM,FRAIO,FRAPM,
     $               FRAXE,FRASM,DUMMI12(NW-10)
      COMMON/PKIN$/DWANOM,SIGFEE,DUMMI14(NW-2)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      NCEL=NC1
      NC=NCEL+1
C     MEMORIZZAZIONE DELLA REATTIVITA' DEL PASSO CORRENTE
      HREATK=HREAT
C     CALCOLO DELLA DENSITA' DI POTENZA ASSIALE DI FISSIONE E DI
C     DECADIMENTO                                                       
      DENWF=T*SIGFEE
C      WRITE(NWRITE,100) DENWF,T,SIGFEE
  100 FORMAT(6(1X,G12.5))                                               
      DO 401 K=1,NCEL
  401 WEST(K)=DENWF*DEPZ*1.E+04*PROFLU(K)                               
      WEST(NC)=0.0
      CALL DECADE(PHS,EEF,WESTD,NPDM,WESTV,WMED,WEST,ALT,WESTS)         
      WTOTF=0.
      WTOTD=0.                                                          
      DO 402 K=1,NCEL
      WTOTD=WTOTD+WESTS(K)*ALT(K)
      WTOTF=WTOTF+WEST(K)*ALT(K)
  402 CONTINUE
      WREATF=WTOTF*CANN
      WREATD=WTOTD*CANN
      WREAT=WREATF+WREATD                                               
C     CALCOLO DELLE NUOVE CONCENTRAZIONI DI XENO E DI IODIO (AT/(CM**3))
      DENWA=DENWF/RSUP
      DWAPER=DENWA*100./DWANOM                                          
      VLAMXS=VLAMXE+SIGXEM*DWAPER
      PIO=(PIO+GIO*DWAPER*DTJ)/(1.+VLAMIO*DTJ)
      PXE=(PXE+(VLAMIO*PIO+GXE*DWAPER)*DTJ)/(1.+VLAMXS*DTJ)
C                                                                       
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PREVIS(FCN,ALBA,CEFI,ALT,EFB,
     1 ENF,EEF,SG,D,RES,AKF,PHS,BQ,NBAR,ALBAS,C2,PHSV,
     2 NCM,NGM,ITJ,CM,ALM,CL,PHT,WEST,IPS,IT,TREF,TEM,BQV,
     3 NRITM,HBE,BEM,C,BE,AL,NSCRAM,BQV1,C2BQ,TPARTX,NTEMZ,ICALL,
     4 NBARRE,TPARTV,TPARTN,NBARN,ALBASN,ALBASV,RO,
     5 XE,VIO,PM,SM,HEL,IVELBR,BO,
     6 IBORO,NITJM,JPLOT,DERT,PHPRJ1,PROFLU,WESTS,WGAMC,QCEL,
     7 TIMEY,WREAT,HALBA,HBORO,NUZOM,DERTVS,
     & FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,
     % VELOC,NLIBM,AKFCEL,ALJ,BEJ,COEXE1,DSGXE,IREINP,CV,TTVP,DTPSI1,
     ! SIGXE,GISF,SIGXEL,GISFL,XEV,VIOV)
C-----------------------------------------------------------------------
C     EFFECTUE LE CALCUL DE PREVISION, SELON LES MODALITES DE LA
C     METHODE IMPROVED QUASI STATIC (IQS).
C     LA GESTIONE DELLE POTENZE DI PREVISIONE PER IL LORO UTILIZZO
C     IN 'LEGO' AVVIENE NELLA SUBROUTINE 'PROLEG'.
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON /MATRIF/FT$(8),AP$(8),GT$(8),FT1$(8),F01$(8),G01$(8),
     &               GT1$(8),AP4$(8),AP5$(8),SS$(8),DD$(8),RM$(8),QQ(8),
     &               TTINF(4),TTSUP(4),PM1$(8),RG$(8),VG$(8),OMR$(8),
     &               DC$(8),RN$(8)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON/TUSEPT/TEMC(24),TEMP(24)
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),LIZO(15,15),NUEL(5),
     &LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),MAP(2,15),KAP(15,15),
     &HELBT(5),INDEL(15,15)
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP                                                 
     &             ,DUMMI22(NW-29)
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION FCN(NCM,1),ALBA(1),CEFI(1),ALT(NCM),EFB(NGM,1),TREF(1),
     1RO(1),BQV(1),AKFCEL(1),ALJ(1),BEJ(1),CV(NRITM,1),XEV(1),VIOV(1),
     2ENF(1),EEF(1),SG(1),D(1),RES(1),AKF(1),ACF(1),QCEL(1),
     3VIO(1),PM(1),PHS(1),BQ(1),NBAR(1),ALBAS(1),PHT(1),PHSV(1),WEST(1),
     4C2(1),HEL(1),XE(1),SM(1),CM(1),ALM(1),CL(1),TEM(1),
     5BE(NRITM,1),AL(NRITM,1),HBE(1),BEM(1),C(NRITM,1),BQV1(1),C2BQ(1),
     6NBARRE(1),NBARN(1),ALBASN(1),ALBASV(1),DSGXE(1),SIGXE(1),GISF(1),
     8PROFLU(1),WESTS(1),WGAMC(1),HALBA(NGM,1),HBORO(1)
      DIMENSION FCNZ(1),ILIB1(1),ILIB2(1),COES1(NLIBM,NCM,1),
     &             COED1(NLIBM,NCM,1),COENF1(NLIBM,NCM,1),
     %             COEKFT(NLIBM,NCM,1),COEEF1(NLIBM,NCM,1),
     &             RLAM(NLIBM,NCM,1),RBETA(NLIBM,NCM,1),SIGXEL(NLIBM,1),
     &             VELOC(NLIBM),COEXE1(NLIBM,NCM,1),GISFL(NLIBM,1)
      DIMENSION RMAT1(4),RMAT2(4)
C
      NCEL=NC1
      NCALC=0
      EPST=1.0
C
      TTVP=T
      DO 391 K=1,NCEL
      XEV(K)=XE(K)
      VIOV(K)=VIO(K)
      DO 392 J=1,NRIT
      CV(J,K)=C(J,K)
  392 CONTINUE
  391 CONTINUE
      IF(IT.EQ.1) IREINP=1
C
C---- INCREMENTO DEL TEMPO CORRENTE ------------------------------------
      TIMEY=TIMEV+DTJ
C      WRITE(NWRITE,333)  TIMEY
  333 FORMAT(//,1X,'TIMEY =',G12.5/)
C-----------------------------------------------------------------------
C     STIMA DELL'AMPIEZZA, DELLA FORMA E DEL RAPPORTO SPETTRALE DI      
C     PREVISIONE PER IL CALCOLO DELLE COSTANTI NUCLEARI.
C     SPLITTING DEL FLUSSO DI PREVISIONE A 1G NEI FLUSSI A 2G.
C-----------------------------------------------------------------------
      IF(IPS.EQ.1.AND.ITJ.EQ.1) DERT=0.0
      IF(IPS.NE.1.AND.IT.GT.1.AND.ITJ.EQ.1) DERT=DERTVS
      PHPR=T+DERT*DTJ
C      IF(ITJ.EQ.1.AND.IT.GT.1) PHPR=PHPRJ1
      DO 10  K=1,NC1
      PHS(K)=PHSV(K)+C2(K)*ITJ*DTJ
      RFIS21(K)=RFI21V(K)+C2RF(K)*ITJ*DTJ
      PHR1(K)=PHS(K)/(1.+RFIS21(K))
      PHR2(K)=PHR1(K)*RFIS21(K)
   10 CONTINUE
C-----------------------------------------------------------------------
C     TEST SULL'AMPIEZZA MASSIMA DELL'INTERVALLO DI RICALCOLO DELLA
C     FORMA DI FLUSSO DATA IN INPUT ( NDTJM=DTPSIM/DTJ < NITJM+1 ).
C     TALE AMPIEZZA MASSIMA VIENE RIAGGIORNATA ALLA FINE DI OGNI
C     INTERVALLO DI FORMA NELLA SUBROUTINE 'TSTPH'.
C
      IF(IPS.EQ.1.AND.IT.EQ.1.AND.ITJ.EQ.1) THEN
      DTPSI1=DTPSIM
      NDTJM1=DTPSI1/DTJ+1.E-03
      IF(NDTJM1.LT.1) NDTJM1=1
      IF(NDTJM1.GT.NDTJM) NDTJM1=NDTJM
      DTPSIM=NDTJM1*DTJ
      DTPSI2=0.5*DTPSIM
C
      NITJMM=DTPSIM/DTJ + 1.E-05
      IF(NITJMM.LE.NITJM) GO TO 128
      WRITE(NWRITE,25) NITJMM,NITJM
   25 FORMAT(1X,'ATTENZIONE, NUMERO DI PASSI TERMOIDRAULICI IN UN ',
     &      'PASSO DI RICALCOLO DELLA FORMA DI FLUSSO (NITJMM= ',I4,
     &       ' )',/,1X,'SUPERIORE AL MASSIMO CONSENTITO (NITJM= ',
     &       I4,' )',/)
      DTPSIM=NITJM*DTJ
      DTPSI2=0.5*DTPSIM
      WRITE(NWRITE,24) DTPSIM
   24 FORMAT(1X,'IL PROGRAMMA RIDUCE AUTOMATICAMENTE L''AMPIEZZA ',
     &       'DEL''INTERVALLO DTPSIM AL VALORE MASSIMO CONSENTITO ',
     &       '( DTPSIM=NITJM*DTJ )',G12.5/)
  128 CONTINUE
      ENDIF
C---- DEFINIZIONE DTPSI CORRENTE IN FASE DI PREVISIONE -----------------
      IF(IT.EQ.1) DTPSI=ITJ*DTJ
      TIMEY1=TIMEY
      TIMEZ=TIMEY1-TST-TPARTX
Casam
Casam      write(6,*)'IT DTPSI=ITJ*DTJ ',IT,DTPSI,ITJ,DTJ
C
C     DETERMINAZIONE DELLA POSIZIONE DELLE BARRE E DELLA CONCENTRAZIONE
C     DI BORO NEL CIRCUITO PRIMARIO PER IL PASSO DI TEMPO CORRENTE
C     (INGRESSI AL MODULO 'STRIQS' PROVENIENTI DA 'LEGO')
C
      IF(IT.EQ.1) THEN
      BO=CBORO
      DO 393 K=1,NG
      BINSER(K)=DINSER(K)
      ALBA(K)=BINSER(K)*ANOCP+ZMIN
      IF(ALBA(K).LE.ZMIN) ALBA(K)=ZMIN
      IF(ALBA(K).GE.ALATT*100.) ALBA(K)=ALATT*100.
  393 CONTINUE
      ENDIF
C     GESTIONE BARRE E BORO NEL CASO DI EVENTUALI RICALCOLI DI FORMA
      CALL GEBABO(ALBA,HALBA,ITJ,IT,NGM,BO,HBORO,PASSI1,PASSI2)
C
      IGESC=0
 6100 CONTINUE
C
C-----------------------------------------------------------------------
C     CALCOLO DELLE COSTANTI SULLA BASE DEL FLUSSO DI PREVISIONE
C-----------------------------------------------------------------------
C
      IF (ILEGO.EQ.1) THEN
      CALL CONUC(ALBA,BO,TEM,RO,ALT,CEFI,PHS,D,SG,ENF,EEF,AKF,
     &           AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,
     &           FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %           COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     $           ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,
     !           SIGXEL,GISFL)
C
C     VALUTAZIONE DEL CONTRIBUTO ALLA SEZIONE MACROSCOPICA DI ASSORBIMEN
C     DOVUTO ALL'AVVELENAMENTO DA XENO.
C     IN QUESTA FASE DI PREVISIONE SI FA USO DELLA CONCENTRAZIONE DI XEN
C     CALCOLATA ALLA FINE DEL PASSO DI TEMPO PRECEDENTE.
      DO 50 KK=1,NCEL
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB1
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB1(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      DSGX11=DSGXE(KK)
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB2
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB2(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      IF(LSTAZ) DSGXE(KK)=DSGX11*(1.-FCNZ(KK))+DSGXE(KK)*FCNZ(KK)
   50 CONTINUE
      ELSE IF(ILEGO.EQ.2) THEN
      JRESTI=0
      PAS1=PASSI1
      PAS2=PASSI2
C
      IF(JSTAMP.EQ.1) THEN
      WRITE(NWRITE,*)'TIMEY PREVIS=',TIMEY,' DTJ=',DTJ
      WRITE(NWRITE,'(6E12.5)')(ALBA(J),J=1,NG)
      WRITE(NWRITE,*)'BO=',BO,' PAS1=',PAS1,' PAS2=',PAS2
      WRITE(NWRITE,'(6E12.5)')(TEM(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TEMC(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TEMP(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(RO(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TREF(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(XE(J),J=1,NCEL)
      ENDIF
      CALL CONUS(JRESTI,NCEL,NRIT,TEM,TEMC,TEMP,TREF,RO,
     &           BO,XE,SG,DSGXE,ENF,EEF,D,AKF,AKFCEL,PHS,GISF,
     &           SIGXE,AL,BE,VEL,NRITM,PAS1,PAS2,ALT)
      ENDIF
C
C     CALCOLO DELLA SEZIONE DI ASSORBIMENTO TOTALE AD UN GRUPPO ENERGETI
C     (MODIFICATA CON I "RESTI" VALUTATI IN "KIQS01")
C
      DO 483 K=1,NCEL
      SG(K)=SG(K)+DSGXE(K)
      SG(K)=SG(K)*RES(K)
      ASS1(K)=ASS1(K)*RES1(K)
  483 ASS2(K)=ASS2(K)*RES2(K)
C
C---- CALCOLO DEI BUCKLING DI PREVISIONE A 1G
      DO 26 K=1,NC1
   26 BQ(K)=BQV1(K)+C2BQ(K)*ITJ*DTJ
C      WRITE(NWRITE,207) (BQ(K),K=1,NCEL)
C  207 FORMAT(/20X,'BUCKLING 1G'/(6G16.7))
C
C-----------------------------------------------------------------------
C     CALCOLO DEI BUCKLINGS DI CELLA A 2 GRUPPI ENERGETICI.
C     SE IND=0 I BUCLINGS SONO IN CONVERGENZA, SE IND=1 NO.
C-----------------------------------------------------------------------
C
      NITEBM=200
      CALL CALRIF
      NITERB=0
    1 NITERB=NITERB+1
C      WRITE(NWRITE,500) NITERB
  500 FORMAT(///,5X,'ITERAZIONE DA BUCKLING N. ',I3,///)
      IF(NITERB.EQ.1) GO TO 2
      CALL BUCK2G(IND,ALT,EPS1,NCEL)
      IF(NITERB.LT.30) GO TO 2
      IF(IND.EQ.0) GO TO 3
      IF(NITERB.GT.NITEBM) THEN
      WRITE(NWRITE,602) NITERB,NITEBM
  602 FORMAT(1X,'NUMERO ITERAZIONI DA BUCKLING NITERB=',I5,
     &       3X,'(NITEBM = ',I5,' )')
      STOP ' NITERB .GT. NITEBM (SUBROUTINE PREVIS)'
      ENDIF
C
C-----------------------------------------------------------------------
C     CALCOLO DELLA MATRICE DI RIFLESSIONE T PER LA RELAZIONE TRA LE
C     CORRENTI DI INTERFACCIA CORE-RIFLETTORE E I FLUSSI MEDI NEI
C     NODI MOLTIPLICANTI ADIACENTI AL RIFLETTORE
C-----------------------------------------------------------------------
C
    2 CALL MATT(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI PARAMETRI G E W DEL METODO COARSE-MESH
C-----------------------------------------------------------------------
C
      CALL GWCOEF(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI COEFFICIENTI OMEGA CHE METTONO IN RELAZIONE CORRENTI
C     D'INTERFACCIA E FLUSSI MEDI
C-----------------------------------------------------------------------
C
      CALL OMEGA2(ALT,NCEL)
      GO TO 1
    3 CONTINUE
C      WRITE(NWRITE,*) ' N. ITERAZ. BUCKLING =',NITERB
C      WRITE(NWRITE,1107) (BQZ1(K),K=1,NCEL)
C      WRITE(NWRITE,2107) (BQZ2(K),K=1,NCEL)
C---- CALCOLO DEI FLUSSI AI CONFINI SUPERIORE ED INFERIORE DEL NOCCIOLO
      CALL PERMA1(QQ(1),TTINF,RMAT1)
      CALL PERMA1(QQ(5),TTSUP,RMAT2)
      PHR11=RMAT1(1)*PHR1(1)+RMAT1(3)*PHR2(1)
      PHR21=RMAT1(2)*PHR1(1)+RMAT1(4)*PHR2(1)
      PHR1N=RMAT2(1)*PHR1(NCEL)+RMAT2(3)*PHR2(NCEL)
      PHR2N=RMAT2(2)*PHR1(NCEL)+RMAT2(4)*PHR2(NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DELLA REATTIVITA', DEI COEFFICIENTI MEDI DELLA CINETICA
C     PUNTIFORME E DEI PARAMETRI PER LA SUA ESECUZIONE AD UN GRUPPO DI
C     RITARDATI PER IL CALCOLO DELL'AMPIEZZA DI PREVISIONE PHPRE.
C-----------------------------------------------------------------------
      CALL REA2G(NCM,FSOT,ALT)
      CALL MED2G(NRITM,FSOT,CM,HBE,BEM,ALT,C,BE,AL,ALM)
      WRITE(NWRITE,*) ' PREVIS : TIME=',TIMEY,' REAT 2G=',REAT
C      WRITE(NWRITE,1107) (BQZ1(K),K=1,NCEL)
C      WRITE(NWRITE,2107) (BQZ2(K),K=1,NCEL)
 1107 FORMAT(/20X,'BUCKLING VELOCI'/(6G16.7))
 2107 FORMAT(/20X,'BUCKLING TERMICI'/(6G16.7))                          
C      WRITE(NWRITE,167) (RFIS21(K),K=1,NCEL)
  167 FORMAT(10X,' RAPPORTO SPETTRALE ',/,6(1X,G12.5))
C      WRITE(NWRITE,*) 'C2RF=',(C2RF(K),K=1,NCEL)                       
C      WRITE(NWRITE,*) 'PHR11 =',PHR11,'  PHR1N =',PHR1N
C      WRITE(NWRITE,*) 'PHR21 =',PHR21,'  PHR2N =',PHR2N                
C
      CALL PREV1R
C                                                                       
      CSER=0.
      DO 8000 K=1,NRIT
 8000 CSER=CSER+CM(K)*ALM(K)
      C1=CSER/ALUNO
      HC=C1-PHPR*AX2
      HA=AX1-AX2
      HC1=C1-PHPR*AX1
      HC2=BPRE+APRE                                                     
      ERCOND=-DTJ*DAPRE
      CONDER=DTJ *HC2
      IF(CONDER.GT.174.) GO TO 72                                       
      IF(ERCOND.GT.174.) GO TO 73
      PHPRE=(HC*EXP(DAPRE*DTJ )-HC1*EXP(-DTJ *HC2))/HA                  
      GO TO 71
   72 PHPRE=(HC*EXP(DAPRE*DTJ ))/HA                                     
      GO TO 71
   73 PHPRE=(-HC1*EXP(-DTJ*HC2))/HA                                     
   71 CONTINUE
      WETT=PHPRE
C      T=PHPRE                                                          
      PHPR=PHPRE
      IF(IGESC.GE.NCALC) GO TO 6200
      IGESC=IGESC+1
      IBORO=0
      GO TO 6100
 6200 CONTINUE                                                          
C      WRITE(NWRITE,781) PHPRE
C  781 FORMAT(1X,'*** AMPIEZZA DI PREVISIONE ***  ',E12.5)
      DO 19 K=1,NC1                                                     
      PHT(K)=PHSV(K)+C2(K)*(TIMEY-TIMEVS)
      WEST(K)=WETT*(PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K))*DEPZ*1.E+04    
   19 CONTINUE
      WES =0.                                                           
      DO 20 K=1,NC1
   20 WES =WES +WEST(K)*ALT(K)
C     CALCOLO DELLE POTENZE TOTALI DI FISSIONE E DI DECADIMENTO         
      WTOTF=0.
      WTOTD=0.
      DO 60 J=1,NCEL
      WTOTD=WTOTD+WESTS(J)*ALT(J)
   60 WTOTF=WTOTF+WEST(J)*ALT(J)
      WPTOT=WTOTF+WTOTD
      FNOR=ALCAN*100./WPTOT
      WREAT=CANN*WPTOT
      DO 63 K=1,NC1
   63 PROFLU(K)=(WEST(K)+WESTS(K))*FNOR
      ENER1=2.*ENER/((DTJ+1.E-20)*ALCAN*100.)
      DO 64 K=1,NC1
   64 WEST(K)=WEST(K)+PROFLU(K)*ENER1
      WTOTF=0.
      DO 638 K=1,NC1
  638 WTOTF=WTOTF+WEST(K)*ALT(K)
      WREATF=CANN*WTOTF
      WREATD=CANN*WTOTD
      WREAT1=WREATF+WREATD
C
      WRITE(6,*) 'TIMEY =',TIMEY,' REAC=',REAT,' PUISSANCE=',WREAT1
      IF(IT.EQ.1.AND.JSTAMP.NE.0) WRITE(NWRITE,645)
     &                 TIMEY,REAT,WREAT1,(ALBA(K),K=1,NG-4),BO
  645 FORMAT(1X,'TIMEY=',G12.5,1X,'REAT=',G13.7,1X,
     &       'POTTOT=',G12.5,1X,'ALBA=',2G12.5,1X,'BO=',G12.5,/)
C     IF(JSTAMP.NE.0) THEN
C     WRITE(NWRITE,*) ' TIMEY=',TIMEY,'  T-PREV=',PHPRE,
C    &                '  REAT-PREV=',REAT
C     WRITE(NWRITE,*) 'K-INFINI=',(AKF(I),I=1,NC1)
C     WRITE(NWRITE,*) ' POTENZA TOTALE DI PREVISIONE =',WREAT1
C     WRITE(NWRITE,'(6G12.5)') (CM(J),J=1,NRIT)
C     WRITE(NWRITE,'(6G12.5)') (ALBA(J),J=1,NG)
C     ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE REINPA(PH,PHV,C2,TEM,
     1 FCN,EEF,ENF,SG,D,RES,AKF,BQ,CM,HBE,C,BE,DBE,
     2 ALM,BEMI,HBEV,HBEK,TIMP,TIMPT,NCM,NRITM,DERT,ITJ,NTTJM,
     3 ALT,BEM,AL,WEST,ISCRAM,PHP,NSCRAM,BQV1,C2BQ,BQ1,IT,HAKF,EPSKF,
     4 ITPS,NSTAMP,ALBA,PROFLU,WW,WESTS,RO,H,GIN,JPLOT,IDTJ,IPL,XE,VIO,
     5 PM,SM,HEL,IVELBR,IPS,IBORO,PALBA,PHPRJ1,BO,NUZOM,TREF,FCNZ,
     & ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,VELOC,
     % NLIBM,AKFCEL,ALJ,BEJ,COEXE1,DSGXE,IREINP,WREAT,CV,TTVP,IMOT,
     ! SIGXE,GISF,SIGXEL,GISFL,XEV,VIOV,AXOFFC,AOXE,AOIO,PASSI1,PASSI2)
C-----------------------------------------------------------------------
C     NEL CASO DI CINETICA ASSIALE PREPARA IL CALCOLO DI TIPO ZERODIMENS
C     (PADEZ4) DELLA FUNZIONE AMPIEZZA PREVISTO DAL METODO IQS , RICALCO
C     COSTANTI NUCLEARI E LE CONCENTRAZIONI DI IODIO E DI XENO , VERIFIC
C     CONDIZIONE DI 'SCRAM' E DETERMINA L'AMPIEZZA EFFETTIVA DELL'INTERV
C     DI RICALCOLO DELLA FUNZIONE FORMA.
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
        LOGICAL LP4,LP10,LP17,LP8,LP11,L1TCO,LP12,LP14,
     &  LP1A,LP1B,LP1C
C
        COMMON/PERM00/LP4,LP10,LP17,LP8,LP11,L1TCO,LP12,LP14,
     &  LP1A,LP1B,LP1C
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON /MATRIF/FT$(8),AP$(8),GT$(8),FT1$(8),F01$(8),G01$(8),
     &               GT1$(8),AP4$(8),AP5$(8),SS$(8),DD$(8),RM$(8),QQ(8),
     &               TTINF(4),TTSUP(4),PM1$(8),RG$(8),VG$(8),OMR$(8),
     &               DC$(8),RN$(8)
      COMMON/TUSEPT/TEMC(24),TEMP(24)
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/RIFLA$/RRFI,RRTI,RRFS,RRTS,DUMMI6(NW-4)
      COMMON/TARGE$/TARAXO,POTF0,DUMMI7(NW-2)
      COMMON/REG22$/TIMERG(NW),WTOTRG(NW),REATRG(NW),PDECRG(NW),
     &              AXOFRG(NW),AMINB1(NW),AMINB2(NW),ALFDRG(NW),
     &              ALFMRG(NW),ALFBRG(NW),DUMMI60(20*NW-10*NW)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      DIMENSION PH(1),PHV(1),C2(1),TEM(1),FCN(NCM,1),SIGXE(1),VIOV(1),
     2 EEF(1),ENF(1),SG(1),CV(NRITM,1),BEM(1),BQ1(1),GISF(1),XEV(1),
     3 D(1),RES(1),AKF(1),BQ(1),CM(1),HBE(1),C(NRITM,1),BE(NRITM,1),
     4 DBE(1),ALM(1),BEMI(1),HBEV(1),TIMP(1),TIMPT(1),HBEK(1),ALT(NCM),
     5 AL(NRITM,1),XE(1),WEST(1),PM(1),SM(1),PHP(1),BQV1(1),C2BQ(1),
     6 HAKF(1),ALBA(1),PROFLU(1),WW(1),RO(1),H(1),GIN(1),VIO(1),
     7 WESTS(1),HEL(1),PALBA(1),AKFCEL(1),BEJ(1),ALJ(1),DSGXE(1)
      DIMENSION FCNZ(1),ILIB1(1),ILIB2(1),COES1(NLIBM,NCM,1),
     &          COED1(NLIBM,NCM,1),COENF1(NLIBM,NCM,1),TREF(1),
     %          COEKFT(NLIBM,NCM,1),COEEF1(NLIBM,NCM,1),
     &          RLAM(NLIBM,NCM,1),RBETA(NLIBM,NCM,1),VELOC(NLIBM),
     $          COEXE1(NLIBM,NCM,1),SIGXEL(NLIBM,1),GISFL(NLIBM,1)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,  
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/REAL6$/BREAK1,BREAK2,DELM1,DELM2,DUMMI17(NW-4)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      DIMENSION RMAT1(4),RMAT2(4)
C
      IPLMX=100
      ISTP1X=0
      ISTP2X=0
C      TGV=T
      TGV=TTVP
      DO 394 J=1,NRIT
      DO 395 K=1,NCEL
      C(J,K)=CV(J,K)
  395 CONTINUE
  394 CONTINUE
      ITPD=0
      NCEL=NC1                                                          
C-----------------------------------------------------------------------
      IF(IDKIN.EQ.0) GO TO 1500
C-----------------------------------------------------------------------
C     GENERAZIONE DELLE COSTANTI SULLA BASE DEL FLUSSO CALCOLATO
C-----------------------------------------------------------------------
      IF(ILEGO.EQ.1) THEN
      CALL CONUC1(ALBA,BO,TEM,RO,ALT,CEFI,PH,D,SG,ENF,EEF,AKF,
     &            AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,
     &            FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %            COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     &            ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,
     !            SIGXEL,GISFL)
C
C     CALCOLO DEI VELENI DI FISSIONE (CONCENTRAZIONI DI IODIO E XENO)
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)
C
C     VALUTAZIONE DEL CONTRIBUTO ALLA SEZIONE MACROSCOPICA DI ASSORBIMEN
C     DOVUTO AL NUOVO AVVELENAMENTO DA XENO APPENA CALCOLATO
      DO 55 KK=1,NCEL
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB1
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB1(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      DSGX11=DSGXE(KK)
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB2
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB2(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      IF(LSTAZ) DSGXE(KK)=DSGX11*(1.-FCNZ(KK))+DSGXE(KK)*FCNZ(KK)
   55 CONTINUE
      ELSE IF(ILEGO.EQ.2) THEN
      JRESTI=0
      PAS1=PASSI1
      PAS2=PASSI2
C
      IF (JSTAMP.EQ.1) THEN
      WRITE(NWRITE,*) 'TIMEY (REINPA)=',TIMEVS+ITJ*DTJ,' DTJ=',DTJ
      WRITE(NWRITE,'(6E12.5)')(ALBA(J),J=1,NG)
      WRITE(NWRITE,*)'BO=',BO,' PAS1=',PAS1,' PAS2=',PAS2
      WRITE(NWRITE,'(6E12.5)')(TEM(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TEMC(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TEMP(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(RO(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(TREF(J),J=1,NCEL)
      WRITE(NWRITE,'(6E12.5)')(XE(J),J=1,NCEL)
      ENDIF
      CALL CONUS(JRESTI,NCEL,NRIT,TEM,TEMC,TEMP,TREF,RO,
     &           BO,XE,SG,DSGXE,ENF,EEF,D,AKF,AKFCEL,PH,GISF,
     &           SIGXE,AL,BE,VEL,NRITM,PAS1,PAS2,ALT)
      ENDIF
C      WRITE(NWRITE,*) 'DSGXE(K)=',(DSGXE(K),K=1,NCEL)
C
C     VALUTAZIONE DELLA SEZIONE DI ASSORBIMENTO TOTALE AD UN GRUPPO
C
      DO 483 K=1,NCEL
      SG(K)=SG(K)+DSGXE(K)
      SG(K)=SG(K)*RES(K)
      ASS1(K)=ASS1(K)*RES1(K)
      ASS2(K)=ASS2(K)*RES2(K)
  483 CONTINUE
C
C---- CALCOLO DEI FLUSSI DI INTERFACCIA CORE-RIFLETTORE
C
      CALL CALRIF
      CALL MATT(ALT,NCEL)
      CALL PERMA1(QQ(1),TTINF,RMAT1)
      CALL PERMA1(QQ(5),TTSUP,RMAT2)
      PHR11=RMAT1(1)*PHR1(1)+RMAT1(3)*PHR2(1)
      PHR21=RMAT1(2)*PHR1(1)+RMAT1(4)*PHR2(1)
      PHR1N=RMAT2(1)*PHR1(NCEL)+RMAT2(3)*PHR2(NCEL)
      PHR2N=RMAT2(2)*PHR1(NCEL)+RMAT2(4)*PHR2(NCEL)
C
C     CALCOLO DELLA REATTIVITA' TOTALE E DEI PARAMETRI MEDI DI REATTORE
C
      CALL REA2G(NCM,FSOT,ALT)
      CALL MED2G(NRITM,FSOT,CM,HBE,BEM,ALT,C,BE,AL,ALM)
      WRITE(NWRITE,*) ' REINPA : TIME=',TIMEVS+ITJ*DTJ,' REAT 2G=',REAT
C      WRITE(NWRITE,*) 'PHR11 =',PHR11,'  PHR1N =',PHR1N
C      WRITE(NWRITE,*) 'PHR21 =',PHR21,'  PHR2N =',PHR2N
C     WRITE(NWRITE,1300) (AKF(KK),KK=1,NCEL)
 1300 FORMAT(/10X,'K-INFINITO DI CELLA'/,6(G16.7,1X))
C-----------------------------------------------------------------------
 1500 CONTINUE
      IF(ITJ.GT.1.OR.IDKIN.EQ.0)  GO TO 90
      DO 233 K=1,NRIT
  233 DBE(K)=(HBE(K)-HBEV(K))/DTJ
      DHRE=(HREAT-HREATV)/DTJ
      DHBE=(HBEM-HBEMV)/DTJ
      GO TO 91
   90 DO 39  K=1,NRIT
   39 DBE(K)=(HBE(K)-HBEK(K))/DTJ
      DHRE=(HREAT-HREATK)/DTJ
      DHBE=(HBEM-HBEMK)/DTJ
   91 REA1=REAT/BEMTOT
      IF(REA1.LT.1.) GO TO 50
      WRITE(NWRITE,100)  REA1
  100 FORMAT(/10X,'REATTIVITA'' =',E10.5)
      STOP ' REA1=REAT/BEMTOT > 1. (IL PROGRAMMA SI BLOCCA) '
   50 AP=1./(1.-REA1)
      DF1=ABS(AP*(1.+ALUNO*ALBIG*REA1*AP*AP/BEMTOT)-1.)
      TG1=AMIN1(DTJ,AP*ALBIG/BEMTOT)
      TG2=DTJ-TG1
      DEL1=AMAX1(TG1*BREAK1/(DF1+BREAK1),DELM1)
      ISTEP1=MAX1(TG1/DEL1,1.)
      IF(ISTEP1.EQ.1) DEL1=TG1
      IF(ISTEP1.GT.1) DEL1X=TG1-ISTEP1*DEL1
      IF(ISTEP1.GT.1) ISTP1X=1
      DF2=ABS(AP*(1.+AP*REA1*ALUNO*TG2)-1.)
      DEL2=AMAX1(TG2*BREAK2/(DF2+BREAK2),DELM2)
      ISTEP2=MAX1(TG2/DEL2,1.)
      IF(ISTEP2.EQ.1) DEL2=TG2
      IF(ISTEP2.GT.1) DEL2X=TG2-ISTEP2*DEL2
      IF(ISTEP2.GT.1) ISTP2X=1
      IF(TG2.LE.0.) ISTEP2=0
C-----------------------------------------------------------------------
C     PROVA INTEGRAZIONE EQUAZIONI CINETICA PUNTO A PASSO DTK COSTANTE
C
C      DTK=0.01
C      DEL1=DTK
C      DEL2=DTK
C      ISTEP1=DTJ*0.5/DEL1
C      IF(ISTEP1.EQ.0) ISTEP1=1
C      ISTEP2=DTJ*0.5/DEL2
C      DEL1X=0.
C      DEL2X=0.
C      ISTP1X=0
C      ISTP2X=0
C-----------------------------------------------------------------------
      NTTJ=ISTEP1+ISTEP2+ISTP1X+ISTP2X
C      WRITE(NWRITE,1201) ISTEP1,ISTEP2,ISTP1X,ISTP2X,NTTJ
C1201 FORMAT(1X,'ISTEP1,ISTEP2,ISTP1X,ISTP2X,NTTJ = ',5I6,/)
C      WRITE(NWRITE,*) 'DEL1=',DEL1,'DEL1X=',DEL1X,'DEL2=',DEL2,
C    &'DEL2X=',DEL2X
      IF(NTTJ.LE.NTTJM) GO TO 691
      WRITE(NWRITE,1021) NTTJ,NTTJM
 1021 FORMAT(5X,'NTTJ=',I6,'SUP NTTJM=',I6,/5X,'LE PROGRAMME STOPPE',/)
      STOP
  691 DO 18  JJ=1,ISTEP1
   18 TIMPT(JJ)=JJ*DEL1
      IF(ISTP1X.EQ.1) TIMPT(ISTEP1+1)=TIMPT(ISTEP1)+DEL1X
      IF(ISTEP2.EQ.0) GO TO 32
      IF(ISTP1X.EQ.1) GO TO 29
      DO 28  JJ=1,ISTEP2
      JK=JJ+ISTEP1
   28 TIMPT(JK)=TIMPT(ISTEP1)+JJ*DEL2
      GO TO 31
   29 DO 30 JJ=1,ISTEP2
      JK=JJ+ISTEP1+1
   30 TIMPT(JK)=TIMPT(ISTEP1+1)+JJ*DEL2
   31 IF(ISTP2X.EQ.1) TIMPT(NTTJ)=TIMPT(ISTEP1+1)+ISTEP2*DEL2+DEL2X
   32 IF(ITJ.GT.1.OR.IDKIN.EQ.0) GO TO 92
      DO 5  K=1,ISTEP1
      HREAI=HREATV+DHRE*K*DEL1
      HBEMI=HBEMV+DHBE*K*DEL1
      REAK=HREAI-HBEMI
      DO 6  I=1,NRIT
    6 BEMI(I)=HBEV(I)+DBE(I)*DEL1*K
      CALL PADEZ4(TGV,DEL1,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
    5 CONTINUE
      IF(ISTP1X.EQ.0) GO TO 93
      HREAI=HREATV+DHRE*(ISTEP1*DEL1+DEL1X)
      HBEMI=HBEMV+DHBE*(ISTEP1*DEL1+DEL1X)
      REAK=HREAI-HBEMI
      DO 611 I=1,NRIT
  611 BEMI(I)=HBEV(I)+DBE(I)*(ISTEP1*DEL1+DEL1X)
      CALL PADEZ4(TGV,DEL1X,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
      GO TO 93
   92 DO 51 K=1,ISTEP1
      HREAI=HREATK+DHRE*K*DEL1
      HBEMI=HBEMK+DHBE*K*DEL1
      REAK=HREAI-HBEMI
      DO 61 I=1,NRIT
   61 BEMI(I)=HBEK(I)+DBE(I)*K*DEL1
      CALL PADEZ4(TGV,DEL1,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
   51 CONTINUE
      IF(ISTP1X.EQ.0) GO TO 93
      HREAI=HREATK+DHRE*(ISTEP1*DEL1+DEL1X)
      HBEMI=HBEMK+DHBE*(ISTEP1*DEL1+DEL1X)
      REAK=HREAI-HBEMI
      DO 612 I=1,NRIT
  612 BEMI(I)=HBEK(I)+DBE(I)*(ISTEP1*DEL1+DEL1X)
      CALL PADEZ4(TGV,DEL1X,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
   93 IF(ISTEP2.EQ.0) GO TO 200
      TSTP1=DEL1*ISTEP1                                                 
      IF(ISTP1X.EQ.1) TSTP1=TSTP1+DEL1X
      IF(ITJ.GT.1.OR.IDKIN.EQ.0) GO TO 94
      DO 7  K=1,ISTEP2
      DTST2=K*DEL2+TSTP1
      HREAI=HREATV+DHRE*DTST2
      HBEMI=HBEMV+DHBE*DTST2
      REAK=HREAI-HBEMI
      DO 8 I=1,NRIT
    8 BEMI(I)=HBEV(I)+DBE(I)*DTST2
      CALL PADEZ4(TGV,DEL2,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
    7 CONTINUE
      IF(ISTP2X.EQ.0) GO TO 95
      HREAI=HREATV+DHRE*(TSTP1+ISTEP2*DEL2+DEL2X)
      HBEMI=HBEMV+DHBE*(TSTP1+ISTEP2*DEL2+DEL2X)
      REAK=HREAI-HBEMI
      DO 811 I=1,NRIT
  811 BEMI(I)=HBEV(I)+DBE(I)*(TSTP1+ISTEP2*DEL2+DEL2X)
      CALL PADEZ4(TGV,DEL2X,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
      GO TO 95
   94 DO 71 K=1,ISTEP2
      DTST2=K*DEL2+TSTP1
      HREAI=HREATK+DHRE*DTST2
      HBEMI=HBEMK+DHBE*DTST2
      REAK=HREAI-HBEMI
      DO 81 I=1,NRIT
   81 BEMI(I)=HBEK(I)+DBE(I)*DTST2
      CALL PADEZ4(TGV,DEL2,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1
      TIMP(ITPD)=TGV
   71 CONTINUE
      IF(ISTP2X.EQ.0) GO TO 95
      HREAI=HREATK+DHRE*(TSTP1+ISTEP2*DEL2+DEL2X)
      HBEMI=HBEMK+DHBE*(TSTP1+ISTEP2*DEL2+DEL2X)
      REAK=HREAI-HBEMI
      DO 911 I=1,NRIT
  911 BEMI(I)=HBEK(I)+DBE(I)*(TSTP1+ISTEP2*DEL2+DEL2X)
      CALL PADEZ4(TGV,DEL2X,ALM,BEMI,REAK,CM,NRIT)
      ITPD=ITPD+1                                                       
      TIMP(ITPD)=TGV
  200 CONTINUE
   95 NTTJ1=NTTJ-1
      DERT=(TIMP(NTTJ)-TIMP(NTTJ1))/(TIMPT(NTTJ)-TIMPT(NTTJ1))          
      T=TGV
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,*) ' AMPIEZZA T =',T,'  REATTIVITA''=',REAT
C      WRITE(NWRITE,'(6G12.5)') (CM(J),J=1,NRIT)
      ENDIF
      IF(ITJ.EQ.1) PHPRJ1=T
C-----------------------------------------------------------------------
      IF(IDKIN.EQ.0) RETURN                                             
C-----------------------------------------------------------------------
      TIMEV=TIMEVS+ITJ*DTJ
      TIMEV1=TIMEVS+DTPSI
      DO 401 K=1,NCEL                                                   
      WEST(K)=T*(PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K))*DEPZ*1.E+04
  401 CONTINUE
      WTOTF=0.
      WTOTD=0.
      DO 402 K=1,NCEL
      WTOTD=WTOTD+WESTS(K)*ALT(K)
      WTOTF=WTOTF+WEST(K)*ALT(K)                                        
  402 CONTINUE
      WPTOT=WTOTF+WTOTD
      ZNOR=ALCAN*100./WPTOT
      DO 321 K=1,NCEL
  321 PROFLU(K)=(WEST(K)+WESTS(K))*ZNOR
      WREATF=WTOTF*CANN
      WREATD=WTOTD*CANN
      WREAT=WREATF+WREATD
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,*) ' TIMEY=',TIMEV,'  AMPIEZZA T=',T,'  REAT =',REAT
      WRITE(NWRITE,*) ' POTENZA TOTALE EFFETTIVA =',WREAT               
C     WRITE(NWRITE,'(6G12.5)') (CM(J),J=1,NRIT)
C     WRITE(NWRITE,'(6G12.5)') (ALBA(J),J=1,NG)
      ENDIF
      NCEL2=NCEL/2
      IF (ILEGO.EQ.1) THEN
C     CALCOLO DELL' "AXIAL OFFSET" (SQUILIBRIO ASSIALE DEL FLUSSO NEUTRO
      NCEL4=NCEL/4 + 1.E-05
      RIV1=0.
      RIV2=0.
      RIV3=0.
      RIV4=0.
      DO 396 K=1,NCEL4
      RIV1=RIV1+PH(K)
      RIV2=RIV2+PH(K+NCEL4)
      RIV3=RIV3+PH(K+2*NCEL4)
      RIV4=RIV4+PH(K+3*NCEL4)
  396 CONTINUE
C      RIV1=(PH(3)+PH(4))*.5
C      RIV2=(PH(9)+PH(10))*.5
C      RIV3=(PH(15)+PH(16))*.5
C      RIV4=(PH(21)+PH(22))*.5
      FIMENO=RIV4+RIV3-RIV2-RIV1
      FIPIU =RIV4+RIV3+RIV2+RIV1
      AXOFFC=100.*FIMENO/FIPIU
      PFISUN=WREATF/POTF0
      FMINB1=TARAXO+5./PFISUN
      FMINB2=TARAXO-5./PFISUN
      ELSE IF(ILEGO.EQ.2) THEN
C CALCUL DE L'AXIAL OFFSET(DESEQUILIBRE AXIAL DE PUISSANCE NEUT)
      PHAUT=0.
      PBAS=0.
      DO 711 K=1,NCEL2
      PBAS=PBAS+PROFLU(K)*ALT(K)
      PHAUT=PHAUT+PROFLU(K+NCEL2)*ALT(K+NCEL2)
  711 CONTINUE
      AXOFFC=100.*(PHAUT-PBAS)/(PHAUT+PBAS)
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)
      ENDIF
C CALCUL AXIAL-OFFSET XENON ET IODE
      XEHAUT=0.
      XEBAS=0.
      VIOHAU=0.
      VIOBAS=0.
      DO 72 K=1,NCEL2
      XEBAS=XEBAS+XE(K)*ALT(K)
      XEHAUT=XEHAUT+XE(K+NCEL2)*ALT(K+NCEL2)                            
      VIOBAS=VIOBAS+VIO(K)*ALT(K)
      VIOHAU=VIOHAU+VIO(K+NCEL2)*ALT(K+NCEL2)
   72 CONTINUE
      AOXE=100.*(XEHAUT-XEBAS)/(XEHAUT+XEBAS)
      AOIO=100.*(VIOHAU-VIOBAS)/(VIOHAU+VIOBAS)
C
C-----------------------------------------------------------------------
C *** TEST SUL SEGNALE DI SCRAM DEL REATTORE ***
C-----------------------------------------------------------------------
      IF(LP4.AND.IT.EQ.1) GO TO 181
      IF(NSTAMP.EQ.1) GO TO 900
      GO TO 1123
  181 CONTINUE
      WRITE(NWRITE,450) T
  450 FORMAT(/5X,'*** ATTENZIONE, SCRAM DEL REATTORE ***',
     $        5X,'T =',E12.5/)
C      WRITE(NWRITE,193)DTPSI,DTJ,ITJ
  193 FORMAT(1X,'DTPSI=',E12.5,5X,'DTJ=',E12.5,5X,'ITJ=',I3,5X)
      IF(NSCRAM.EQ.1) GO TO 1124
      ISCRAM=1
      GO TO 501
  900 CONTINUE
C      WRITE(NWRITE,444) T , WREAT
      WRITE(99,4454) TIMEV,T,REAT,IT
  444 FORMAT(/1X,'*** AMPIEZZA ***  T =',G12.5,5X,
     &           '*** POTENZA TOTALE ***  W =',G12.5)
 4454 FORMAT(/,1X,'TIME =',G12.5,3X,'AMPIEZZA  T =',G12.5,3X,
     &       'REAT =',G13.7,3X,'IT =',I2)
C      WRITE(NWRITE,403)WREAT
C      WRITE(NWRITE,3172)REAT
 3172 FORMAT(1X,'REATTIVITA',3H' =,G12.5)
 3171 FORMAT(6E12.5)
  403 FORMAT(1X,'*** POTENZA TOTALE DI REATTORE ***  W=',E12.5)
 1123 CONTINUE
      IF(IT.GT.1) GO TO 1125
C
C     DETERMINAZIONE DELL'EVENTUALE FINE DELL'INTERVALLO DI RICALCOLO
C     DELLA FUNZIONE FORMA O PER VARIAZIONE DELL'INTERVALLO DI
C     RICALCOLO TERMOIDRAULICO , O PER ECCESSIVA VARIAZIONE DEL
C     K-INFINITO DI CELLA O PER SUPERAMENTO DEL VALORE MASSIMO PREVISTO
C     (QUALORA NELL'AMBITO DEL PRIMO RICALCOLO DI FORMA (IT=1) SI STIA
C      EFFETTUANDO UNA ITERAZIONE TERMOIDRAULICA SUCCESSIVA ALLA PRIMA
C      OCCORRE SALTARE I TEST DI FINE INTERVALLO DI FORMA, ESSENDO
C      L'AMPIEZZA DI QUEST'ULTIMO GIA' STATA DECRETATA NEL CORSO DELLA
C      PRIMA ITERAZIONE TERMOIDRAULICA STESSA)
C
      IF(LIQS3) GO TO 501
      LFORMA=.FALSE.
      IF(ABS(DTJ-DTJNEW) .GT. 1.E-05) GO TO 504
      DO 500 M=1,NCEL
      IF(ABS(AKF(M)-HAKF(M)).GT.EPSKF) GO TO 503
  500 CONTINUE                                                          
      IF(DTPSI.GE.DTPSI2) GO TO 505
      GO TO 1124
C
  504 CONTINUE                                                          
C      PRINT *,'RICALCOLO FORMA PER VARIAZIONE PASSO DI TEMPO DTJ '
      IMOT=3                                                            
      GO TO 501
C                                                                       
  505 CONTINUE
C      PRINT *,'RICALCOLO FORMA PER DTPSI > DTPSI2 '                    
      IMOT=2
      GO TO 501                                                         
  503 CONTINUE
C      PRINT *,'RICALCOLO FORMA PER VARIAZIONE K-INF. DELLA CELLA ',M
      IMOT=1
C                                                                       
  501 CONTINUE
      LFORMA=.TRUE.
      ITPS=1
C      WRITE(NWRITE,193) DTPSI,DTJ,ITJ
      IF(NSTAMP.EQ.1.OR.NSTAMP.EQ.2) GO TO 600
      CALL OUTP(TIMEV,NCM,ALBA,FCN,EEF,ENF,SG,PROFLU,WEST,TEM,RO,H,
     &          GIN,WREAT,BO,XE,SM,PALBA)
C      WRITE(NWRITE,444) T , WREAT                                      
      WRITE(99,4454)TIMEV,T,REAT,IT
C     WRITE(NWRITE,3172) REAT                                           
  600 CONTINUE
      DO 502 M=1,NCEL
  502 HAKF(M)=AKF(M)                                                    
      DO 182 J=1,NCEL
      PHP(J)=PHV(J)+DTPSI*C2(J)
  182 BQ1(J)=BQV1(J)+DTPSI*C2BQ(J)
      GO TO 1124
 1125 IF(ABS(ITJ*DTJ-DTPSI).LE.0.001*DTJ) ITPS=1
 1124 CONTINUE
      IF(JPLOT.EQ.0) GO TO 901
C---- MEMORIZZAZIONE DELLE GRANDEZZE RELATIVE AL PLOTTAGGIO ------------
      QK=FLOAT(IDTJ)/FLOAT(JPLOT)
      KQ=QK
      IF(ABS(FLOAT(KQ)-QK).GT.1.E-06) GO TO 901
      IF(IT.EQ.1) THEN
      IF(IREINP.EQ.1) THEN
      IREINP=0
      IPL=IPL+1
      ENDIF
      ELSE IF(IT.GE.2) THEN
      IPL=IPL+1
      ENDIF
      IF(IPL.LE.IPLMX) GO TO 293
      WRITE(NWRITE,173) IPL,IPLMX
  173 FORMAT(/1X,'ATTENZIONE, PASSI DI PLOTTAGGIO IPL =',I5,1X,'SUPERIOR
     $I A QUELLI PREVISTI IPLMX =',I5,/,1X,'IL PROGRAMMA SI BLOCCA'/)
      STOP
  293 CONTINUE
      WTOTRG(IPL)=WREAT*1.E-06                                          
      REATRG(IPL)=REAT*1.E+05
      PDECRG(IPL)=WREATD*1.E-06                                         
      AXOFRG(IPL)=AXOFFC
      AMINB1(IPL)=FMINB1                                                
      AMINB2(IPL)=FMINB2
      ALFDRG(IPL)=ALFAD
      ALFMRG(IPL)=ALFAM                                                 
      ALFBRG(IPL)=ALFAB
      IF(IT.EQ.1) TIMERG(IPL)=TIMEV
  901 CONTINUE
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE RIT(TIMP,TIMPT,CM,AL,A,B,ALT,BE,ENF,PHJ,PHJV,ENFV,C,
     1               CV,NRITM,HBE,HBEK,C2,PHJ1,ENFVV,CVV,ITJ)
C-----------------------------------------------------------------------
C     CALCOLA LE CONCENTRAZIONI DEI PRECURSORI DI NEUTRONI RITARDATI
C     SECONDO LA METODOLOGIA IQS CON FORMALISMO A UN GRUPPO ENERGETICO
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1              RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION TIMP(*),CM(*),AL(NRITM,*),ALT(*),A(*),B(*),
     1BE(NRITM,*),ENF(*),PHJ(*),PHJV(*),ENFV(*),C(NRITM,*),CV(NRITM,*),
     2HBE(*),HBEK(*),C2(*),PHJ1(*),TIMPT(*),ENFVV(*),CVV(NRITM,*)
C
      DATA DTJMAX /0.5/
C
      NCEL=NC1
      TIMEY=DTJ
      TIMEY1=0.
      DO 8 K=1,NC1
      PHJ(K)=PHJV(K)+C2(K)*(TIMEV-TIMEVS)
    8 PHJ1(K)=PHJV(K)+C2(K)*(TIMEV-DTJ-TIMEVS)
      IF(DTJ.GT.DTJMAX+1.E-05) GO TO 1000
C
C     INTEGRAZIONE DELLE CONCENTRAZIONI DI RITARDATI SECONDO IL METODO I
C
      TPR=.7886751*TIMEY+.2113249*TIMEY1
      TPS=.2113249*TIMEY+.7886751*TIMEY1
      NTTJ1=NTTJ-1
      DO 1 K=1,NTTJ1
      IF(K.EQ.NTTJ1) GO TO 2
      IF(TPS.GT.TIMPT(K).AND.TPS.LT.TIMPT(K+1)) GO TO 2
    1 CONTINUE
    2 T1=TIMPT(K)
      T2=TIMPT(K+1)
      TGS=TIMP(K)+(TPS-T1)*(TIMP(K+1)-TIMP(K))/(T2-T1)
      DO 3 J=K,NTTJ1
      IF(J.EQ.NTTJ1) GO TO 4
      IF(TPR.GT.TIMPT(J).AND.TPR.LT.TIMPT(J+1)) GO TO 4
    3 CONTINUE
    4 T1=TIMPT(J)
      T2=TIMPT(J+1)
      TGP=TIMP(J)+(TPR-T1)*(TIMP(J+1)-TIMP(J))/(T2-T1)
      TINT1=TGS*(TPS-TIMEY1)
      TINT2=TGP*(TPR-TIMEY1)
      TTS=TIMEY-TPS
      TTR=TIMEY-TPR
      TINT3=TGS*TTS
      TINT4=TGP*TTR
      DO 7 J=1,NRIT
    7 CM(J)=0.
      DO 5 K=1,NCEL
      DO 5 J=1,NRIT
      AKK=EXP(-AL(J,K)*TTR)
      AKJ=EXP(-AL(J,K)*TTS)
      A(J)=.5*(AKK*TINT2+AKJ*TINT1)
      B(J)=.5*(AKK*TINT4+AKJ*TINT3)
      IF(ITJ.GT.1) THEN
      C(J,K)=BE(J,K)*(A(J)*ENF(K)*PHJ(K)+B(J)*ENFV(K)*
     $       PHJ1(K))+EXP(-AL(J,K)*DTJ)*CV(J,K)
      ELSE IF(ITJ.EQ.1) THEN
      C(J,K)=BE(J,K)*(A(J)*ENF(K)*PHJ(K)+B(J)*ENFVV(K)*PHJ1(K))+
     $       EXP(-AL(J,K)*DTJ)*CVV(J,K)
      ENDIF
      CM(J)=CM(J)+C(J,K)*ALT(K)
C      CV(J,K)=C(J,K)
    5 CONTINUE
      GO TO 2000
C
 1000 CONTINUE
C
C     INTEGRAZIONE DELLE CONCENTRAZIONI DI PRECURSORI CON UN METODO
C     ALLE DIFFERENZE FINITE IMPLICITO NEL CASO DI PASSI DTJ > 1 s.
C
      DO 77 J=1,NRIT
   77 CM(J)=0.
      DO 55 K=1,NCEL
      DO 55 J=1,NRIT
      IF(ITJ.GT.1) THEN
      C(J,K)=(CV(J,K)+BE(J,K)*ENF(K)*PHJ(K)*T*DTJ)/(1.+AL(J,K)*DTJ)
      ELSE
      C(J,K)=(CVV(J,K)+BE(J,K)*ENF(K)*PHJ(K)*T*DTJ)/(1.+AL(J,K)*DTJ)
      ENDIF
      CM(J)=CM(J)+C(J,K)*ALT(K)
   55 CONTINUE
C
 2000 CONTINUE
C
      DO 75 J=1,NRIT
   75 CM(J)=CM(J)/(ALCAN*100.*VEL)
C      WRITE(NWRITE,141) (CM(J),J=1,NRIT)
  141 FORMAT(9X,'CONCENTRAZIONE MEDIA RITARDATI (RIT)',/,6(1X,G12.5))
      DO 85  K=1,NRIT
   85 HBEK(K)=HBE(K)
      HREATK=HREAT
      HBEMK=HBEM
      DO 88 K=1,NCEL
   88 ENFV(K)=ENF(K)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PREME(TEM,RO,HEL,TREF,PROFLU,TCNOS,RONOS,ALFA,BETA,
     &                 ALFA1,BETA1,TMNOS,XENOS,XE)
C-----------------------------------------------------------------------
C     IN 'KIQS02' PREPARA I VALORI MEDI DI CELLA DELLE DENSITA' DEL
C     MODERATORE E DELLE TEMPERATURE DEL COMBUSTIBILE PER IL CALCOLO
C     NEUTRONICO A PARTIRE DAI QUELLI TERMOIDRAULICI A DISPOSIZIONE.
C     IN STAZIONARIO CALCOLA I COEFFICIENTI DELLA CORRELAZIONE LINEARE
C     ATTA A TRASFORMARE (PER UN CORRETTO CALCOLO DELL'EFFETTO DOPPLER
C     IN TRANSITORIO) LE TEMPERATURE MEDIE DI CELLA PRODOTTE DAL MODULO
C     TERMOIDRAULICO IN QUELLE EFFICACI PROPRIE DELLE LIBRERIE DELLE
C     COSTANTI NUCLEARI PRODOTTE DA 'NOSTRI'.
C     ANALOGO TRATTAMENTO VIENE RISERVATO ALLA CONTROREAZIONE DEL
C     MODERATORE E, NEL CASO DI FUNZIONAMENTO EDF/SEPTEN, ALLA
C     TEMPERATURA DEL MODERATORE E ALLA CONCENTRAZIONE DI XENO.
C     I SUDDETTI COEFFICIENTI VENGONO SCRITTI IN FONDO AL FILE DEI
C     PROFILI ASSIALI NEL CASO DI RICERCA DI UN REGIME PERMANENTE
C     AL 100% DELLA POTENZA NOMINALE , OPPURE VENGONO LETTI DA TALE
C     FILE NEL CASO DI RICERCA DI PERMANENTE A POTENZA RIDOTTA.
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LSTAZ,LFORMA,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/INPAR$/NC1M,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,NNXM,NNYM,
     &              NTTJM,NITJM,NLIBM,NPROFM,NKINM,NCELM,MAXS,KDIM,NCM
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/PROXE/ALFA2(NCNT),BETA2(NCNT),ALFA3(NCNT),BETA3(NCNT)
      DIMENSION  BETA11(2),ALFA11(2)
      DIMENSION TEM(*),RO(*),HEL(*),TREF(*),PROFLU(*),RONOS(*),TCNOS(*),
     &  ALFA(*),BETA(*),ALFA1(*),BETA1(*),TMNOS(*),XENOS(*),XE(*)
C
      DATA TMZP1,TMZP2,TMZP3/291.66,286.00,293.90/
      DATA ROZP1,ROZP2,ROZP3/743.76,753.70,739.00/
      DATA XEZER/0./
C
      NCEL=NC1                                                          
      IF(ILEGO.EQ.1) THEN
C---- CASO ENEL - REATTORE PUN                                          
      TMZER=TMZP1
      ROZER=ROZP1                                                       
      ELSE IF(ILEGO.EQ.2) THEN
        IF(ABS(WNOM-3800.E+6).LE.10.E+6) THEN                           
C---- CASO EDF - REATTORE 1300 MWE
        TMZER=TMZP3                                                     
        ROZER=ROZP3
        ELSE IF(ABS(WNOM-2780.E+6).LE.10.E+6) THEN                      
C---- CASO EDF - REATTORE 900 MWE
        TMZER=TMZP2                                                     
        ROZER=ROZP2
        ENDIF                                                           
      ENDIF
      KN=0                                                              
      DO 15 K=1,NCELT
      DO 70 JN=1,NKIN                                                   
      JKIN=JN
      KN=KN+1                                                           
      TEM(KN)=TCCEL(K)-273.15
      RO(KN)=ROCEL(K)
      TEMC(KN)=TCCELC(K)-273.15
      TEMP(KN)=TCCELP(K)-273.15
      TREF(KN)=TMCEL(K)-273.15
   70 CONTINUE
   15 CONTINUE
      IF(LSTAZ) WRITE(NWRITE,*) 'TEM1(NCEL)= ',(TEM(K),K=1,NCEL)
      IF(LSTAZ) WRITE(NWRITE,*) 'RO1(NCEL)=  ',(RO(K),K=1,NCEL)
C
C     VALUTAZIONE IN STAZIONARIO E NEL CASO DI POTENZA DI FUNZIONAMENTO
C     REATTORE NOMINALE DEI COEFFICIENTI ALFA(K) E BETA(K) NECESSARI
C     AL CALCOLO DELLA TEMPERATURA MEDIA EFFICACE DEL COMBUSTIBILE, CONG
C     CON QUELLA UTILIZZATA PER LA GENERAZIONE DELLE COSTANTI NUCLEARI,
C     PARTIRE DALLA TEMPERATURA DI CELLA DETERMINATA DAL CODICE 'LEGO' M
C     LA CORRELAZIONE LINEARE  TEM(K)=ALFA(K)+BETA(K)*TEM1(K).
C     TALE PROCEDURA E' INDISPENSABILE PER LA CORRETTA VALUTAZIONE NEL C
C     UN TRANSITORIO DELL'EFFETTO DOPPLER AL VARIARE DELLA POTENZA DEL R
C     PROCEDIMENTO ANALOGO VIENE SEGUITO PER LA DENSITA' DEL MODERATORE.
C     SE LA POTENZA DI FUNZIONAMENTO INIZIALE DEL REATTORE E' DIVERSA DA
C     NOMINALE I COEFFICIENTI ALFA(K) E BETA(K) SONO LETTI DAL CODICE.
C
      IF(LSTAZ) THEN
      DATA JALBE /1/
      WRITE(NWRITE,*) 'WTOT=',WTOT,'   WNOM=',WNOM
      IF(ABS(WTOT-WNOM).LE.10.E+06.AND.BURM.LE.10.) THEN
C     CALCOLO DEI COEFFICIENTI DI CELLA ALFA E BETA RELATIVI ALLA TEMPER
C     DEL COMBUSTIBILE E ALFA1 E BETA1 RELATIVI ALLA DENSITA' DEL MODERA
      WRITE(NWRITE,*) '*****  CALCOLO COEFFICIENTI ALFA E BETA  *****'
      DO 478 K=1,NCEL
      BETA(K)=(TCNOS(K)-TMZER)/(TEM(K)-TMZER)
      ALFA(K)=TMZER*(1.-BETA(K))
      BETA1(K)=(RONOS(K)-ROZER)/(RO(K)-ROZER)
      ALFA1(K)=ROZER*(1.-BETA1(K))
      BETA2(K)=(TMNOS(K)-TMZER)/(TREF(K)-TMZER)
      ALFA2(K)=TMZER*(1.-BETA2(K))
      BETA3(K)=(XENOS(K)-XEZER)/(XE(K)-XEZER)
      ALFA3(K)=XEZER*(1.-BETA3(K))
  478 CONTINUE
      BETA11(1)=1.
      IF(ABS(ROILIB-ROZER).GT.1.E-04)
     &       BETA11(1)=(ROILIB-ROZER)/(ROH2OI-ROZER)
      ALFA11(1)=ROZER*(1.-BETA11(1))
      BETA11(2)=(ROULIB-ROZER)/(ROH2OU-ROZER)
      ALFA11(2)=ROZER*(1.-BETA11(2))
      WRITE(NWRITE,111) (K,TCNOS(K),RONOS(K),TMNOS(K),XENOS(K),K=1,NCEL)
  111 FORMAT(/,10X,'VARIABILI INDIPENDENTI DEI CODICI NOSTRI/LIBELLULE',
     &   /,10X,'CELLA  ',7X,'T COMB',8X,'RO MOD',8X,'T  MOD',8X,
     &   'C XENO',3X,/, (12X,I2,6X,4(2X,G12.5)))
C     IF(JALBE.EQ.1) THEN
C     OPEN(UNIT=IRLIB2,FILE='KINPROF',STATUS='OLD',FORM='FORMATTED')
C     JALBE=0
C     ENDIF
C---- POSIZIONAMENTO ALLA FINE DEL FILE DEI PROFILI ASSIALI E SCRITTURA
C     IN CODA AD ESSO DEI COEFFICIENTI ALFA E BETA APPENA CALCOLATI
  101 FORMAT(6E12.5)
      REWIND IRLIB2
      DO 100 JR=1,NUREC2
  100 READ(IRLIB2,101)
C
      WRITE(IRLIB2,'(6E12.5)') (ALFA(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (BETA(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (ALFA1(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (BETA1(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (ALFA2(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (BETA2(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (ALFA3(K),K=1,NCEL)
      WRITE(IRLIB2,'(6E12.5)') (BETA3(K),K=1,NCEL)
      WRITE(IRLIB2,'(2E12.5)') (ALFA11(K),K=1,2)
      WRITE(IRLIB2,'(2E12.5)') (BETA11(K),K=1,2)
      ELSE IF(ABS(WTOT-WNOM).GT.10.E+06.OR.BURM.GT.10.) THEN
      IF(JALBE.EQ.1) THEN
      WRITE(NWRITE,*) '*****  LETTURA COEFFICIENTI ALFA E BETA *****'
C     OPEN(UNIT=IRLIB2,FILE='KINPROF',STATUS='OLD',FORM='FORMATTED')
      JALBE=0
C---- VERIFICA DELLA PRESENZA DEI COEFFICIENTI ALFA E BETA IN CODA AL
C     FILE DEI PROFILI ASSIALI E LORO LETTURA (IN CASO AFFERMATIVO)
      REWIND IRLIB2
      NURECT=0
  222 READ(IRLIB2,101,END=300)
      NURECT=NURECT+1
      GO TO 222
  300 CONTINUE
      IF(NURECT.GT.NUREC2) GO TO 333
      WRITE(NWRITE,91) NURECT
   91 FORMAT(/,1X,'ATTENZIONE! ASSENZA DEI COEFFICIENTI ALFA E BETA ',
     &       'IN FONDO AL FILE DEI PROFILI ASSIALI ',/,1X,
     &       'LA RICERCA DEL REGIME A POTENZA RIDOTTA RICHIESTO DEVE',
     &       ' ESSERE PRECEDUTA DA UNA REGIMAZIONE AL 100% DELLA ',
     &       'POTENZA NOMINALE',/,1X,'NUMERO DI RECORD LETTI =',I6,/,
     &       1X,'IL PROGRAMMA SI BLOCCA',/)
      STOP ' ASSENZA COEFFICIENTI ALFA E BETA IN FONDO AL FILE PROFILI'
  333 CONTINUE
      REWIND IRLIB2
      DO 200 JR=1,NUREC2
  200 READ(IRLIB2,101)
      READ(IRLIB2,'(6E12.5)') (ALFA(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (BETA(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (ALFA1(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (BETA1(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (ALFA2(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (BETA2(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (ALFA3(K),K=1,NCEL)
      READ(IRLIB2,'(6E12.5)') (BETA3(K),K=1,NCEL)
      READ(IRLIB2,'(2E12.5)') (ALFA11(K),K=1,2)
      READ(IRLIB2,'(2E12.5)') (BETA11(K),K=1,2)
C     CLOSE (IRLIB2)
      ENDIF
      ENDIF
      WRITE(NWRITE,*) 'ALFA(NCEL)= ',(ALFA(K),K=1,NCEL)
      WRITE(NWRITE,*) 'BETA(NCEL)= ',(BETA(K),K=1,NCEL)
      WRITE(NWRITE,*) 'ALFA1(NCEL)= ',(ALFA1(K),K=1,NCEL)
      WRITE(NWRITE,*) 'BETA1(NCEL)= ',(BETA1(K),K=1,NCEL)
      WRITE(NWRITE,*) 'ALFA2(NCEL)= ',(ALFA2(K),K=1,NCEL)
      WRITE(NWRITE,*) 'BETA2(NCEL)= ',(BETA2(K),K=1,NCEL)
      WRITE(NWRITE,*) 'ALFA3(NCEL)= ',(ALFA3(K),K=1,NCEL)
      WRITE(NWRITE,*) 'BETA3(NCEL)= ',(BETA3(K),K=1,NCEL)
      WRITE(NWRITE,*) 'ALFA11 =',(ALFA11(I),I=1,2)
      WRITE(NWRITE,*) 'BETA11 =',(BETA11(I),I=1,2)
      ENDIF
C
C   CALCUL DE LA TEMPERATURE EFFECTIVE DES CELLULES AINSI QUE LA DENSITE
C   EFFECTIVE DU MODERATEUR POUR ENTRER LES LIBRAIRIES DE PARAMETRES
C     NUCLEAIRES (EFFET DOPPLER ET CONTREREACTIONS DU MODERATEUR)
C
      DO 479 K=1,NCEL
      TEM(K)=ALFA(K)+BETA(K)*TEM(K)
      TEMC(K)=ALFA(K)+BETA(K)*TEMC(K)
      TEMP(K)=ALFA(K)+BETA(K)*TEMP(K)
      RO(K)=ALFA1(K)+BETA1(K)*RO(K)
      IF (ILEGO.EQ.2) THEN
      TREF(K)=ALFA2(K)+BETA2(K)*TREF(K)
C---- LA TRASFORMAZIONE LINEARE DELLO XENO E' FATTA NELLA ROUTINE DINAMO
C      IF(LSTAZ) XE(K)=ALFA3(K)+BETA3(K)*XE(K)
      ENDIF
  479 CONTINUE
      ROH2OI=ALFA11(1)+BETA11(1)*ROH2OI
      ROH2OU=ALFA11(2)+BETA11(2)*ROH2OU
      IF(LSTAZ) THEN
      WRITE(NWRITE,*) 'TEM(NCEL)= ',(TEM(K),K=1,NCEL)
      WRITE(NWRITE,*) 'RO(NCEL) = ',(RO(K),K=1,NCEL)
      WRITE(NWRITE,*) 'TREF(NCEL) = ',(TREF(K),K=1,NCEL)
      WRITE(NWRITE,*) 'TEMP(NCEL) = ',(TEMP(K),K=1,NCEL)
      WRITE(NWRITE,*) 'TEMC(NCEL) = ',(TEMC(K),K=1,NCEL)
      WRITE(NWRITE,*) 'XE(NCEL) = ',(XE(K),K=1,NCEL)
      ENDIF
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE THERMO(TEM,RO,HRO,HTEM,TREF,NCM,IT,ITJ)
C-----------------------------------------------------------------------
C     MEMORIZZA I RISULTATI DEL CALCOLO TERMOIDRAULICO NELLA FASE DI
C     PREVISIONE PER UTILIZZARLI NEGLI EVENTUALI RICALCOLI DI FORMA
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      DIMENSION RO(*),TEM(*),HTEM(NCM,*),HRO(NCM,*),TREF(*)
      DIMENSION HTREF(NCNT,80),HTEMC(NCNT,80),HTEMP(NCNT,80)
C
   10 FORMAT(1X,8G12.5)
      JTI=ITJ
      NCEL=NC1
      IF(IT.GT.1) GO TO 1000
      DO 4 K=1,NCEL
      HRO(K,JTI)=RO(K)
      HTEM(K,JTI)=TEM(K)
      IF (ILEGO.EQ.2) THEN
      HTREF(K,JTI)=TREF(K)
      HTEMC(K,JTI)=TEMC(K)
      HTEMP(K,JTI)=TEMP(K)
      ENDIF
    4 CONTINUE
C     WRITE(NWRITE,10) (HRO(J,JTI),J=1,NCEL)
      GO TO 2000
 1000 DO 6 K=1,NCEL
      RO(K)=HRO(K,JTI)
      IF (ILEGO.EQ.2) THEN
      TEMC(K)=HTEMC(K,JTI)
      TEMP(K)=HTEMP(K,JTI)
      TREF(K)=HTREF(K,JTI)
      ENDIF
      TEM(K)=HTEM(K,JTI)
    6 CONTINUE
C     WRITE(NWRITE,10) (RO(J),J=1,NCEL)
C
 2000 RETURN
      END
      FUNCTION CRIBO(BURM,IVELBR,IBWR)
C-----------------------------------------------------------------------
C     CALCOLA LA CONCENTRAZIONE CRITICA DI BORO (PPM) IN FUNZIONE DEL
C     BRUCIAMENTO MEDIO DI REATTORE (MWD/T) SIA NEL CASO DI PRESENZA
C     (IVELBR=1) CHE IN QUELLO DI ASSENZA (IVELBR=0) DI VELENI
C     BRUCIABILI (GD) NEGLI ELEMENTI DI COMBUSTIBILE DI PWR.
C     NEL CASO DI BWR LA CONCENTRAZIONE CRITICA DI BORO E' NULLA.
C     (ATTUALMENTE LA CONCENTRAZIONE CRITICA DI BORO VIENE FISSATA
C     NEL MAIN DI 'STRIP' DOPO UNA REGIMAZIONE SUL BORO A BARRE FERME)
C-----------------------------------------------------------------------
      DIMENSION CRIBO1(9),BURMED(10),CRIBO2(9)
      DATA BURMED/0.,2000.,4000.,6000.,8000.,10000.,12000.,14000.,
     &            16000.,2000./
C     CONCENTRAZIONE CRITICA DI BORO IN PRESENZA DI VELENI BRUCIABILI
      DATA CRIBO2/910.,815.,750.,610.,480.,350.,225.,80.,0./
C     CONCENTRAZIONE CRITICA DI BORO IN ASSENZA DI VELENI BRUCIABILI
      DATA CRIBO1/1200.,815.,750.,610.,480.,350.,225.,80.,0./
C
      IF(IBWR.EQ.0) GO TO 500
      CRIBO=0.0
      RETURN
C
  500 CONTINUE
      IND=1
      NMAX=9
      IF(IVELBR.EQ.1) GO TO 100
      CALL INTPOL(BURMED,CRIBO1,BURM,BOR0,NMAX,IND)
      GO TO 200
  100 CONTINUE
      IF(BURM.LE.14000.) GO TO 300
      IF(BURM.GE.15000.) GO TO 400
      BOR0=CRIBO2(8)-(BURM-BURMED(8))*CRIBO2(8)/1000.
      GO TO 200
  400 BOR0=0.                                                           
      GO TO 200
  300 CALL INTPOL(BURMED,CRIBO2,BURM,BOR0,NMAX,IND)
  200 CRIBO=BOR0                                                        
C
      RETURN                                                            
      END
      FUNCTION ETAR(KR)
C-----------------------------------------------------------------------
C     FISSA I COEFFICIENTI DI RIPARTIZIONE DELLA POTENZA TOTALE DI REATT
C     PER CANALE RADIALE.
C-----------------------------------------------------------------------
      IF(KR.GT.5) STOP ' NUMERO ZONE RADIALI SUPERIORE AL MASSIMO (=5)'
      GO TO (1,2,3,4,5),KR
    1 ETAR=1.0
      RETURN
    2 STOP ' CANALE RADIALE N. 2 ATTUALMENTE NON PREVISTO '
    3 STOP ' CANALE RADIALE N. 3 ATTUALMENTE NON PREVISTO '
    4 STOP ' CANALE RADIALE N. 4 ATTUALMENTE NON PREVISTO '
    5 STOP ' CANALE RADIALE N. 5 ATTUALMENTE NON PREVISTO '
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE OUTP(TIME,NCM,ALBA,FCN,EEF,ENF,SG,PROFLU,WW,TEM,RO,
     &                H,GIN,WTOT,BPPM,XE,SM,PALBA)
C-----------------------------------------------------------------------
C     STAMPA LE PRINCIPALI GRANDEZZE DI OUTPUT NEL CASO (1-D)
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION ALBA(*),FCN(NCM,*),EEF(*),ENF(*),SG(*),PROFLU(*),WW(*),
     1          TEM(*),RO(*),H(*),GIN(*),XE(*),SM(*),PALBA(*)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/JSTAX$/JALBA,JEEF,JENF,JSG,JPROFL,JWW,JRO,JTEM,JXE,JSM,
     &              JRBA,JCM,JDUMMI(NW-12)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      NC=NC1+1
      NCEL=NC1
      JFCN=0
      DO 777 K=1,NCEL
      XE(K)=XE(K)*1.E+24
      SM(K)=SM(K)*1.E+24
  777 CONTINUE
      WRITE(NWRITE,1000)TIME
      WRITE(NWRITE,1008)WTOT
      WRITE(NWRITE,1010)BPPM
      IF(IBWR.EQ.0) GO TO 459
      IF(JALBA.EQ.1) WRITE(NWRITE,1001)(ALBA(K),K=1,NG)
      GO TO 460
  459 CONTINUE
      DO 1 K=1,NG
      PALBA(K)=ALCAN*100.-ALBA(K)
      IF(PALBA(K).LE.0.) PALBA(K)=0.0
    1 CONTINUE
      IF(JALBA.EQ.1) WRITE(NWRITE,1001)(PALBA(K),K=1,NG)
  460 CONTINUE
      IF(JFCN.EQ.0.OR.IBWR.EQ.0) GO TO 600
      WRITE(NWRITE,1015)
      DO 500 K=1,NCEL
  500 WRITE(NWRITE,1002)K,(FCN(K,J),J=1,NUZO)
  600 CONTINUE
      IF(JEEF.EQ.1) WRITE(NWRITE,1003)(EEF(K),K=1,NCEL)
      IF(JENF.EQ.1) WRITE(NWRITE,1004)(ENF(K),K=1,NCEL)
      IF(JSG.EQ.1)  WRITE(NWRITE,1005)(SG(K),K=1,NCEL)
      WRITE(NWRITE,1006) REAT
      IF(JPROFL.EQ.1) WRITE(NWRITE,1007)(PROFLU(K),K=1,NCEL)
      IF(JXE.EQ.1)  WRITE(NWRITE,1018)(XE(K),K=1,NCEL)
      IF(JSM.EQ.1)  WRITE(NWRITE,1019)(SM(K),K=1,NCEL)
      IF(JWW.EQ.1)  WRITE(NWRITE,1009)(WW(K),K=1,NCEL)
      IF(JRO.EQ.1)  WRITE(NWRITE,1014)(RO(K),K=1,NCEL)
      IF(JTEM.EQ.1) WRITE(NWRITE,1011)(TEM(K),K=1,NCEL)
      DO 789 K=1,NCEL
      XE(K)=XE(K)/1.E+24
      SM(K)=SM(K)/1.E+24                                                
  789 CONTINUE
C
 1000 FORMAT(//15X,'TEMPO=',G12.5,'SEC'/ )
 1001 FORMAT(/10X,'ALTEZZA BARRE'/8(G12.5,1X))
 1015 FORMAT(/10X,'EFFICIENZA DI CELLA'/)
 1002 FORMAT(/2X,'CELLA',2X,I2,5X,5(G12.5,1X))
 1003 FORMAT(/10X,'FISSION',/8(G12.5,1X))
 1004 FORMAT(/10X,'SIGMA FISSIONE',/8(G12.5,1X))
 1005 FORMAT(/10X,'SIGMA ASSORBIMENTO',/8(G12.5,1X))
 1006 FORMAT(/10X,'REATTIVITA',3H' =,2X,G12.5)
 1007 FORMAT(/10X,'PROFILO DI POTENZA ASSIALE',/8(G12.5,1X))            
 1008 FORMAT(/5X,'POTENZA TOTALE DI REATTORE',3X,G12.5)
 1009 FORMAT(/10X,'POTENZA DI CELLA',/8(G12.5,1X))                      
 1010 FORMAT(/5X,'CONCENTRAZIONE MEDIA DI BORO NEL REATTORE',3X,G12.5)
 1011 FORMAT(/10X,'TEMPERATURE DI CELLA',/8(G12.5,1X))
 1013 FORMAT(/10X,'PORTATA DI CANALE ',/8(G12.5,1X))
 1014 FORMAT(/10X,'DENSITA',1H',' DEL REFRIGERANTE',/8(G12.5,1X))
 1016 FORMAT(/10X,'ENTALPIA SPECIFICA DEL REFRIGERANTE',/8(G12.5,1X))
 1018 FORMAT(/10X,'CONCENTRAZIONE MEDIA DI XENO',/8(G12.5,1X))
 1019 FORMAT(/10X,'CONCENTRAZIONE MEDIA DI SAMARIO',/8(G12.5,1X))
      WRITE(NWRITE,'(//)')
C                                                                       
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE OUTP0D(TIME,ALBA,PROFLU,WW,TEM,TREF,H,GIN,WTOT,BPPM,
     &                  PXE,CM,T,RECOBA,PALBA)
C-----------------------------------------------------------------------
C     STAMPA LE PRINCIPALI GRANDEZZE DI OUTPUT PER LA CINETICA (0-D)
C-----------------------------------------------------------------------
C
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION ALBA(*),PROFLU(*),WW(*),CM(*),TEM(*),H(*),GIN(*),
     &          RECOBA(*),PALBA(*),TREF(*)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/PRODE$/ADEC(KPDM,KPDM-1),GDEC(KPDM,KPDM-1),POTDEC
     &             ,DUMMI50(5*NW-2*KPDM*(KPDM-1)-1)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/JSTAX$/JALBA,JEEF,JENF,JSG,JPROFL,JWW,JRO,JTEM,JXE,JSM,
     &              JRBA,JCM,JDUMMI(NW-12)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      NC=NC1+1                                                          
      NCEL=NC1
      WRITE(NWRITE,1000) TIME
      WRITE(NWRITE,1008) WTOT
      WRITE(NWRITE,1004) POTDEC                                         
      WRITE(NWRITE,1003) T
      IF(JCM.EQ.0) GO TO 777                                            
      DO 78 J=1,NRIT
   78 CM(J)=CM(J)*VEL                                                   
      WRITE(NWRITE,1019) (CM(J),J=1,NRIT)
      DO 79 J=1,NRIT
   79 CM(J)=CM(J)/VEL
  777 WRITE(NWRITE,1010) BPPM
C      WRITE(NWRITE,1018) PXE
      DO 888 K=1,NG
      PALBA(K)=ALCAN*100.-ALBA(K)
      IF(PALBA(K).LE.0.) PALBA(K)=0.0
  888 CONTINUE
      IF(JALBA.EQ.1) WRITE(NWRITE,1001) (PALBA(K),K=1,NG)
      IF(JRBA.EQ.1)  WRITE(NWRITE,1015) (RECOBA(J),J=1,NG)
      WRITE(NWRITE,1006) REAT
      IF(JPROFL.EQ.1) WRITE(NWRITE,1007)(PROFLU(K),K=1,NCEL)
      IF(JWW.EQ.1)  WRITE(NWRITE,1009) (WW(K),K=1,NCEL)
      IF(JRO.EQ.1)  WRITE(NWRITE,1014) (TREF(K),K=1,NCEL)
      IF(JTEM.EQ.1) WRITE(NWRITE,1011) (TEM(K),K=1,NCEL)
C
 1000 FORMAT(//15X,'TEMPO=',G12.5,'SEC'/ )
 1001 FORMAT(/10X,'ALTEZZA BARRE'/8(G12.5,1X))
 1015 FORMAT(/10X,'REATTIVITA'' CONTROLLATA DALLE BARRE',/(8G12.5,1X))
 1003 FORMAT(/5X,'FLUSSO NEUTRONICO =',2X,G12.5)
 1004 FORMAT(/5X,'POTENZA TOTALE DI DECADIMENTO =',2X,G12.5)
 1006 FORMAT(/5X,'REATTIVITA',3H' =,2X,G12.5)
 1007 FORMAT(/10X,'PROFILO DI POTENZA ASSIALE',/8(G12.5,1X))
 1008 FORMAT(/5X,'POTENZA TOTALE DI REATTORE',3X,G12.5)
 1009 FORMAT(/10X,'POTENZA DI CELLA',/8(G12.5,1X))
 1010 FORMAT(/5X,'CONCENTRAZIONE MEDIA DI BORO',3X,G12.5)
 1011 FORMAT(/10X,'TEMPERATURE DI CELLA',/8(G12.5,1X))
 1013 FORMAT(/10X,'PORTATA DI CANALE ',/8(G12.5,1X))
 1014 FORMAT(/10X,'TEMPERATURA DEL REFRIGERANTE',/8(G12.5,1X))
 1016 FORMAT(/10X,'ENTALPIA SPECIFICA DEL REFRIGERANTE',/8(G12.5,1X))
 1018 FORMAT(/5X,'CONCENTRAZIONE MEDIA DI XENO =',2X,G12.5)
 1019 FORMAT(/10X,'CONCENTRAZIONE MEDIA DEI PRECURSORI DI RITARDATI',/
     &       8(G12.5,1X))
      WRITE(NWRITE,'(//)')
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PADEZ4(ENNE,DELT,AL,BT,REA,CR,JRT)
C-----------------------------------------------------------------------
C     CALCOLA LA FUNZIONE AMPIEZZA MEDIANTE INTEGRAZIONE DI EQUAZIONI
C     TIPO CINETICA ZERODIMENSIONALE (METODO DI PADE' DI ORDINE 0-4)
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      DIMENSION AL(9),BT(9),CR(9)
      DIMENSION SER1(10,2),SER2(10,2),SER3(10,2),SER4(10,2),SER5(10,2),
     $  SER6(10,2),SER7(10,2),SER8(10,2),SOR(2),SOI(2),AR(2),AI(2),
     $  AR2(2),UAI(2),AMQ(2),ARMI(2),ARMQ(2),ARI(2),AIMQ(2),DATI(2,2)
      DATA DATI / .04262666,.3946330, .4573733,.2351005/
C
      IF(JRT.GT.9) STOP ' JRT MAGGIORE DI 9 IN PADEZ4 '
      DO 1 K=1,2
      AR(K)=DATI(1,K)*DELT
      AI(K)=DATI(2,K)*DELT
      AR2(K)=2.*AR(K)
      UAI(K)=1./AI(K)
      AMQ(K)=AR(K)**2+AI(K)**2
      ARMI(K)=AMQ(K)-2.*AI(K)**2
      ARI(K)=AR2(K)*AI(K)
      ARMQ(K)=AR(K)*AMQ(K)
      AIMQ(K)=AI(K)*AMQ(K)
      DO 1 J=1,JRT
      SER1(J,K)=1./(1.+AL(J)*(AR2(K)+AMQ(K)*AL(J)))
      SER2(J,K)=SER1(J,K)*AL(J)                                         
      SER3(J,K)=SER1(J,K)*(AR(K)+AMQ(K)*AL(J))
      SER4(J,K)=SER3(J,K)*AL(J)                                         
      SER5(J,K)=SER2(J,K)*(ARMI(K)+ARMQ(K)*AL(J))
    1 SER6(J,K)=SER2(J,K)*(ARI(K)+AIMQ(K)*AL(J))
      DO 2 K=1,2
      SOR(K)=1.
      SOI(K)=0.
      DO 2 J=1,JRT
      SER7(J,K)=SER1(J,K)*BT(J)
      SER8(J,K)=SER3(J,K)*BT(J)
      SOR(K)=SOR(K)-SER5(J,K)*BT(J)
    2 SOI(K)=SOI(K)+SER6(J,K)*BT(J)
      DO 4 K=1,2
      B1=SOR(K)-AR(K)*REA
      B2=SOI(K)+AI(K)*REA
      BEM=1./(B1**2+B2**2)
      CC=BEM*(AR(K)*B1-AI(K)*B2)
      BEM=BEM*(AR(K)*B2+AI(K)*B1)
      B1=ENNE
      B2=0.                                                             
      DO 3 J=1,JRT
      B1=B1+CR(J)*SER4(J,K)
    3 B2=B2+CR(J)*SER2(J,K)
      ENNE=CC*B2+B1*BEM*UAI(K)                                          
      B2=CC*B1-B2*BEM*AI(K)
      DO 4 J=1,JRT                                                      
    4 CR(J)=SER7(J,K)*B2+SER8(J,K)*ENNE+SER1(J,K)*CR(J)
C
      RETURN
      END                                                               
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PADE12(AL,BT,CP,PP,DELT,JRT)
C-----------------------------------------------------------------------
C     EFFETUA L'INTEGRAZIONE DELLE EQUAZIONI DELLA CINETICA NEUTRONICA
C     ZERODIMENSIONALE TRAMITE UN METODO DI PADE' DI ORDINE SUPERIORE
C     (PADE12 : 1 SOTTOPASSO ESPLICITO + 2 SOTTOPASSI IMPLICITI)
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION DSS(9),DBP(9),DBS(9),GP(9),GS(9),DIGE(9),ALHE(9),
     &          BTHE(9)
      DIMENSION AL(*),BT(*),CP(*)
      COMMON/PADKR$/PPF,AAG,PPFV,AAGV,DTKIN,DUMMI15(NW-5)
C
      DATA JPADE /0/
C
      IF(JPADE.EQ.0) THEN
      JPADE=1                                                           
      IF(JRT.LT.1.OR.JRT.GT.9) STOP ' ERRORE : JRT.LT.1  O  JRT.GT.9 '
      P=DELT*0.7071067812D0
      Q=1.414213562D0                                                   
      PESP=-DELT
      QESP=3.0D0
      GAMR=0.E0
      GAMI=0.E0
      DO 10 J=1,JRT
      ALHE(J)=PESP*AL(J)
      BTHE(J)=PESP*BT(J)
      DIGE(J)=ALHE(J)+QESP                                              
      ALH=P*AL(J)
      BTH=P*BT(J)                                                       
      SR1=ALH+Q
      DSS(J)=1.E0/(SR1*SR1+1.E0)                                        
      DPP=DSS(J)*SR1
      DBP(J)=DPP*BTH
      DBS(J)=DSS(J)*BTH
      GP(J)=ALH*DPP
      GS(J)=ALH*DSS(J)
      GAMR=GAMR+BT(J)*GP(J)
      GAMI=GAMI+BT(J)*GS(J)                                             
   10 CONTINUE
      GAMI=GAMI*P
C                                                                       
      ENDIF
C                                                                       
      GAMRH=P*(AAG-GAMR*PPF)+Q
      GAMIH=GAMI*PPF + 1.E0                                             
      PN=1.E0/(GAMRH*GAMRH+GAMIH*GAMIH)
      QN=GAMIH*PN                                                       
      PN=GAMRH*PN
      FPPH=0.E0
      FPSH=0.E0                                                         
      FSPH=0.E0
      FSSH=0.E0
      SR2=0.E0
      SR1=0.E0
      FP=0.E0
      FS=0.E0
      PFPH=-PP*PPFV
      DO 20 J=1,JRT
      SR1=SR1+ALHE(J)*CP(J)
      CP(J)=BTHE(J)*PFPH+DIGE(J)*CP(J)
      FP=FP+GP(J)*CP(J)
   20 FS=FS+GS(J)*CP(J)
      G1HH=FPPH-FSSH+FP-SR1-SR2+(PESP*AAGV+QESP)*PP
      G2HH=FPSH+FSPH+FS
      PP=PN*G2HH+QN*G1HH
      PPHH=PN*G1HH-QN*G2HH                                              
      PFPH=PPF*PP
      PFPHH=PPF*PPHH                                                    
      DO 30 J=1,JRT
   30 CP(J)=DBP(J)*PFPH+DBS(J)*PFPHH+DSS(J)*CP(J)                       
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE TSTPH(IEPS,EPSR,PHS,PHP,PHSV,C2,HBEV,HBEK,ALT,D,NCM,BQ,
     $HRO,    RO,TEM,ROV,TEMV,DV,ALMV,CMV,ALM,CM,BQV,EEF,WEST,
     *ITJ,ISCRAM,NSCRAM,ALBAS,ALBA,NBAR,NGM,FNORM ,IDOIN,EPSNOR,IT,
     &SERFI,SERFIV,C2BQ,BQP,BQV1,BQ1,HTEM,ITST1,
     +ITST2,NPDM,WMED,WESTD,WESTV,WESTS,TST1,IEND1,IEND2,DELTAT,
     /TPARTX,JPLOT,IPL,JSTAMP,NITJM,
     %C,CVV,NRITM,IPS,PROFLU,CLTH,NUEL,PRPR,DTJNUO,DTPSI1,AOXE,AOIO,
     &XE,VIO,XEVV,VIOVV,TREF,TREFV,TEMCV,TEMPV)
C-----------------------------------------------------------------------
C    VERIFICA LA CONVERGENZA DELLA FUNZIONE FORMA , CONTROLLA LO 'SCRAM'
C    E IL CALCOLO DELLA POTENZA DI DECADIMENTO DEI PRODOTTI DI FISSIONE.
C    VALUTA INOLTRE L'AMPIEZZA MASSIMA DELL' INTERVALLO DI FORMA IN
C    FUNZIONE DEL PASSO DI TEMPO TERMOIDRAULICO E CONTROLLA CHE QUESTA S
C    CONGRUENTE CON LE DIMENSIONI DEL CASO CORRENTE (FISSATE IN KIQS01).
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      DIMENSION PHS(*),PHP(*),PHSV(*),C2(*),HBEV(*),HBEK(*),ALT(*),D(*),
     $BQ(*),HRO(NCM,*),RO(*),NUEL(*),TEM(*),ROV(*),TEMV(*),XE(*),
     *DV(*),ALMV(*),CMV(*),ALM(*),CM(*),BQV(*),EEF(*),WEST(*),ALBAS(*),
     $ALBA(*),NBAR(*),SERFI(*),SERFIV(*),C2BQ(*),BQP(*),BQV1(*),BQ1(*),
     &C(NRITM,*),CVV(NRITM,*),HTEM(NCM,*),TREF(*),WMED(*),TREFV(*),
     +WESTD(NPDM,*),WESTV(*),WESTS(*),PROFLU(*),CLTH(*),PRPR(*),VIO(*),
     &XEVV(*),VIOVV(*),TEMCV(*),TEMPV(*)
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)      
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)       
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/REG22$/TIMERG(NW),WTOTRG(NW),REATRG(NW),PDECRG(NW),
     &              AXOFRG(NW),AMINB1(NW),AMINB2(NW),ALFDRG(NW),
     &              ALFMRG(NW),ALFBRG(NW),DUMMI60(20*NW-10*NW)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N                    
     &              ,DUMMI61(NW-16)
      COMMON/FIOLD/PHR11V,PHR1NV,PHR21V,PHR2NV
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT    
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION VARTPH(32)
C
      EPSPH=.1
      IF(NC1+1.GT.32) STOP ' NC1 MAGGIORE DI 31 IN SUB. TSTPH '
      IF(IPS.EQ.1) THEN
      DO 112 K=1,NC1
  112 VARTPH(K)=0.
      ENDIF
      EPSRN=AMIN1(EPSR,1.E-03)
C---- CALCOLO DELLA FORMA DI FLUSSO TOTALE A 1G IMPIEGATA NELLA
C     METODOLOGIA 'IQS'
      DO 77 K=1,NC1
      PHS(K)=PHR1(K)+PHR2(K)
      RFIS21(K)=PHR2(K)/PHR1(K)
   77 SERFI(K)=PHP(K)
C-----------------------------------------------------------------------
C     SCELTA DEL TEST DI CONVERGENZA SULLA FUNZIONE FORMA ASSIALE:
C     IDOIN = 0 --> SOLO TEST DIFFERENZIALE
C     IDOIN = 1 --> SOLO TEST INTEGRALE
C     IDOIN = 2 --> TEST DIFFERENZIALE + TEST INTEGRALE
C-----------------------------------------------------------------------
      IF(IDOIN-1) 100,101,102
  102 IF(ABS(FNORM-1.).GT.EPSNOR) GO TO 2
  100 DO 1 K=1,NC1
      IF(ABS((PHS(K)-PHP(K))/PHP(K)).GT.EPSRN) GO TO 2
    1 CONTINUE
      GO TO 103                                                         
  101 IF(ABS(FNORM-1.).GT.EPSNOR) GO TO 2
C                                                                       
C     CONVERGENZA SULLA FUNZIONE FORMA DI FLUSSO ASSIALE
C                                                                       
  103 DO 104 K=1,NC1
  104 PHS(K)=PHS(K)/FNORM
      WRITE(NWRITE,50) IT , (PHS(I),I=1,NC1)
   50 FORMAT(/,1X,'FORME AXIAL DE FLUX 1-G DE CONVERGENCE  ( ',
     &       'IT =',I3,' )',//, 8(1X,G12.5))
      TIMEVS=TIMEV
C     CALCUL DU FACTEUR DE PIC LOCAL FZ
      FZ=PHS(1)
      KFZ=1
      DO 981 K=2,NC1
      IF(PHS(K).GT.FZ) THEN
      FZ=PHS(K)
      KFZ=K
      ENDIF
  981 CONTINUE
      WRITE(NWRITE,215) FZ,KFZ
  215 FORMAT(/,1X,'FACTEUR DE PIC AXIAL FZ=',F6.3,2X,'DANS LA MAILLE K='
     &,I3)
      WRITE(NWRITE,55) (PROFLU(I),I=1,NC1)
   55 FORMAT(/,1X,'PROFIL AXIAL DE PUISSANCE',//,8(1X,G12.5))
C
C-----------------------------------------------------------------------
C     SELEZIONAMENTO DEI PROFILI DA REGISTRARE PER I PLOTTAGGI ASSIALI
      IPPZ=0
      DO 111 K=1,NC1
      DELTPH=(PHS(K)-PHSV(K))/PHSV(K)
      VARTPH(K)=VARTPH(K)+DELTPH
      IF(ABS(VARTPH(K)).LE.EPSPH) GO TO 111
      IPPZ=1
      D1=D(1)
      DNCEL=D(NC1)
      CALL PROLEG(REAT,WEST,WESTS,ALT,CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
      DO 113 J=1,NC1
  113 VARTPH(J)=0.
      GO TO 114
  111 CONTINUE
  114 CONTINUE
C-----------------------------------------------------------------------
      CALL DECADE(PHS,EEF,WESTD,NPDM,WESTV,WMED,WEST,ALT,WESTS)
C-----------------------------------------------------------------------
      IF(ISCRAM.EQ.1.AND.NSCRAM.EQ.0) THEN
      CALL SSCRAM(NSCRAM,ALBAS,ALBA,NGM,ITST1,ITST2,TST1,DELTAT,
     &             TEMFIN,TPARTX,JSTAMP,WEST,ALT)
      D1=D(1)
      DNCEL=D(NC1)
      CALL PROLEG(REAT,WEST,WESTS,ALT,CANN,
     &            REATC,WTOTC,WNEUTC,WCELC)
      ENDIF
C-----------------------------------------------------------------------
C     DETERMINAZIONE DELL'AMPIEZZA MASSIMA DELL'INTERVALLO DI RICALCOLO
C     DELLA FUNZIONE FORMA ASSIALE IN FUNZIONE DEL PASSO DI TEMPO DELLA
C     TERMOIDRAULICA E CONGRUENTEMENTE CON I PARAMETRI DIMENSIONALI DEL
C     CASO CORRENTE FISSATI IN 'KIQS01'
C
      NDTJM1=DTPSI1/DTJNUO+1.E-03
      IF(NDTJM1.LT.1) NDTJM1=1
      IF(NDTJM1.GT.NDTJM) NDTJM1=NDTJM
      DTPSIM=NDTJM1*DTJNUO
C
C     TEST SULL'AMPIEZZA MASSIMA DELL'INTERVALLO DI RICALCOLO DELLA
C     FUNZIONE FORMA DEL FLUSSO NEUTRONICO ( DTPSIM/DTJNUO < NITJM+1 )
C
      NITJMM=DTPSIM/DTJNUO + 1.E-05
      IF(NITJMM.LE.NITJM) GO TO 128
      WRITE(NWRITE,25) NITJMM,NITJM
   25 FORMAT(1X,'ATTENZIONE, NUMERO DI PASSI TERMOIDRAULICI IN UN ',
     &      'PASSO DI RICALCOLO DELLA FORMA DI FLUSSO (NITJMM= ',I4,
     &       ' )',/,1X,'SUPERIORE AL MASSIMO CONSENTITO (NITJM= ',
     &       I4,' )',/)
      DTPSIM=NITJM*DTJNUO
      WRITE(NWRITE,26) DTPSIM
   26 FORMAT(1X,'IL PROGRAMMA RIDUCE AUTOMATICAMENTE L''AMPIEZZA ',
     &       'DEL''INTERVALLO DTPSIM AL VALORE MASSIMO CONSENTITO ',
     &       '( DTPSIM=NITJM*DTJNUO )',G12.5/)
  128 CONTINUE
C-----------------------------------------------------------------------
      DO 4  K=1,NC1
      C2RF(K)=(RFIS21(K)-RFI21V(K))/DTPSI
    4 C2(K)=(PHS(K)-PHSV(K))/DTPSI
C      DTPSI2=2.*DTPSI
      DTPSI2=DTPSI+2.*DTJNUO
      IF(DTPSI2-DTJNUO+1.E-04 .LT. 0.0) DTPSI2=DTJNUO
      IF(ITST1.EQ.1) DTPSI2=TST1
      IF(DTPSI2.EQ.0.0) DTPSI2=DTJNUO
      IF(ITST1.EQ.0.AND.ITST2.EQ.1) DTPSI2=2.*DTJNUO
      IF(DTPSI2.GT.DTPSIM) DTPSI2=DTPSIM
Casam
Casam      write(6,*)'DTPSI2 ',DTPSI2
      DTPSI=DTPSI2
      JPSII=0
      GO TO 32
   31 CONTINUE
C     RIDUZIONE INTERVALLI DTPSI PER EVITARE FORME ESTRAPOLATE NEGATIVE
C     DTPSI2=0.5*DTPSI
      DTPSI2=DTPSI-2.*DTJNUO
Casam
Casam      write(6,*)'DTPSI2 ',DTPSI2
      DTPSI=DTPSI2
      IF(DTPSI.GE.DTJNUO) GO TO 32
      IF(JPSII.EQ.1) STOP ' FORMA ESTRAPOLATA NEGATIVA CON DTPSI=DTJ '
      WRITE(NWRITE,33) DTPSI2,DTJNUO,DTPSI
   33 FORMAT(1X,'ATTENZIONE, DTPSI DI TENTATIVO = ',G12.5,' MINORE DEL D
     $TJ CORRENTE = ',G12.5,/,1X,'IL PROGRAMMA PROSEGUE PONENDO DTPSI=',
     $'DTJ= ',G12.5/)
Casam
Casam      write(6,*)'DTJNUO ',DTJNUO
      DTPSI=DTJNUO
      JPSII=1
   32 DO 442 K=1,NC1
      PHP(K)=PHS(K)+C2(K)*DTPSI
      IF(PHP(K).LE.0.) GO TO 31
      C2(K)=(PHP(K)-SERFI(K))/DTPSI
      RFI21P=RFIS21(K)+C2RF(K)*DTPSI
      C2RF(K)=(RFI21P-RFIS21(K))/DTPSI
      RFI21V(K)=RFIS21(K)
      SERFIV(K)=SERFI(K)
      PHR1V(K)=PHR1(K)
      PHR2V(K)=PHR2(K)
      PHR11V=PHR11
      PHR1NV=PHR1N
      PHR21V=PHR21
      PHR2NV=PHR2N
      DV(K)=D(K)
  442 PHSV(K)=PHS(K)
  899 FORMAT(/1X,'TIMEVS =',G12.5,3X,'DTPSI DI TENTATIVO =',G12.5,3X,
     &           'DTPSI MAX =',G12.5,3X,'NITJM = ',I4)
      WRITE(NWRITE,899) TIMEVS,DTPSI,DTPSIM,NITJM
C
      DO 8800 K=1,NC1
      C2BQ(K)=(BQP(K)-BQ1(K))/DTPSI
 8800 CONTINUE
      DO 8801 K=1,NC1
      BQV(K)=BQ(K)
      BQV1(K)=BQ1(K)
      BQ1(K)=BQP(K)
 8801 CONTINUE
      DO 5 K=1,NRIT
    5 HBEV(K)=HBEK(K)
      HREATV=HREATK
      HBEMV=HBEMK
      IEPS=1
      IF(IEND1.EQ.0) IEND2=1
   67 FORMAT(1X,6E12.5)
  677 FORMAT(1X,'TIMEVS=',G12.5,5X)
      DO 401 K=1,NC1
      WEST(K)=T*(PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K))*DEPZ*1.E+04
  401 CONTINUE
      WPTOT=0.
      DO 402 K=1,NC1
      WPTOT=WPTOT+(WEST(K)+WESTS(K))*ALT(K)
  402 CONTINUE
      WREAT=WPTOT*CANN
      WRITE(NWRITE,403) WREAT,REAT
  403 FORMAT(1X,'POTENZA TOTALE DI REATTORE, W=',E12.5,
     &       2X,'REATTIVITA'' =',G13.7)
      WRITE(NWRITE,63) AXOFFC,AOXE,AOIO
   63 FORMAT(/,1X,'AXIAL-OFFSET = ',F6.2,2X,'A.O. XENON=',F6.2,
     &2X,'A.O. IODE=',F6.2)
      IF(ITST1.EQ.0.AND.ITST2.EQ.1) ITST2=0
      ITST1=0
      WRITE(NWRITE,'(1X,125(1H*),/)')
C
C      DO 1234 K=1,NC1
C      PHS(K)=PHS(K)*WNEUTC
C 1234 CONTINUE
      IF(IPPZ.EQ.1.AND.JPLOT.NE.0) CALL PREPA2
CCCCCCC      CALL PREPA2
C      DO 1235 K=1,NC1
C      PHS(K)=PHS(K)/WNEUTC
C 1235 CONTINUE
C-----------------------------------------------------------------------
      GO TO 8
C
C     NON-CONVERGENZA SULLA FUNZIONE FORMA DI FLUSSO ASSIALE
C
    2 CONTINUE
      WRITE(NWRITE,600)
  600 FORMAT(/1X,'NON E',1H',' STATA RAGGIUNTA LA CONVERGENZA SULLA FUNZ
     &IONE FORMA'/1X,'VIENE EFFETTUATA UNA NUOVA ITERAZIONE'/)
      DO 3  K=1,NC1
      PHP(K)=PHS(K)/FNORM
      C2(K)=(PHP(K)-SERFIV(K))/DTPSI
      RFI21P=RFIS21(K)
    3 C2RF(K)=(RFI21P-RFI21V(K))/DTPSI
      DO 8803 K=1,NC1
 8803 BQP(K)=BQ(K)
      DO 8802 K=1,NC1
      C2BQ(K)=(BQP(K)-BQV1(K))/DTPSI
      BQ1(K)=BQP(K)
 8802 CONTINUE
C      WRITE(NWRITE,*) 'RIAL =',RIAL,  'RIBA =',RIBA
      T=TVS
      ENER=ENERV
      PHR11=PHR11V
      PHR1N=PHR1NV
      PHR21=PHR21V
      PHR2N=PHR2NV
      DO 8192 J=1,NC1
      D(J)=DV(J)
      TEM(J)=TEMV(J)
      RO(J)=ROV(J)
      IF (ILEGO.EQ.2) THEN
      TREF(J)=TREFV(J)
      TEMC(J)=TEMCV(J)
      TEMP(J)=TEMPV(J)
      ENDIF
      XE(J)=XEVV(J)
      VIO(J)=VIOVV(J)
 8192 CONTINUE
      TIMEV=TIMEVS
C      WRITE(NWRITE,677) TIMEVS
      DO 8292 J=1,NRIT
      ALM(J)=ALMV(J)
      CM(J)=CMV(J)
 8292 CONTINUE
      ALUNO=ALUNOV
      DO 615 K=1,NC1
      DO 615 J=1,NRIT
  615 C(J,K)=CVV(J,K)
C
    8 RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CHANGE(HBE,HBEV,ENFVV,ENF,CVV,C,NRITM,RO,ROV,TEM,
     $                  TEMV,D,DV,ALMV,CMV,ALM,CM,DERT,DERTVS,
     $                  XE,VIO,XEVV,VIOVV,TREF,TREFV,TEMCV,TEMPV)
C-----------------------------------------------------------------------
C     MEMORIZZA ALCUNE GRANDEZZE DEL CALCOLO (1-D) NEL CASO DI CONVERGEN
C     SULLA FUNZIONE FORMA ASSIALE
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      DIMENSION HBE(*),HBEV(*),ENFVV(*),ENF(*),CVV(NRITM,*),
     *          C(NRITM,*),RO(*),ROV(*),TEM(*),CM(*),
     $          TEMV(*),D(*),DV(*),ALMV(*),CMV(*),ALM(*),
     $          XE(*),VIO(*),XEVV(*),VIOVV(*),TREF(*),TREFV(*),TEMCV(*)
     $          ,TEMPV(*)
C
      DO 2 K=1,NRIT
    2 HBEV(K)=HBE(K)
      HREATV=HREAT
      HBEMV=HBEM
      DO 3 K=1,NC1
    3 ENFVV(K)=ENF(K)
      DO 4 K=1,NC1
      DO 4 J=1,NRIT
    4 CVV(J,K)=C(J,K)
      TVS=T
      DERTVS=DERT
      ENERV=ENER                                                        
      DO 8192 K=1,NC1
      DV(K)=D(K)
      TEMV(K)=TEM(K)
      ROV(K)=RO(K)
      XEVV(K)=XE(K)
      VIOVV(K)=VIO(K)
      IF (ILEGO.EQ.2) THEN
      TEMCV(K)=TEMC(K)
      TEMPV(K)=TEMP(K)
      TREFV(K)=TREF(K)
      ENDIF
 8192 CONTINUE
      DO 8292  J=1,NRIT
      ALMV(J)=ALM(J)
      CMV(J)=CM(J)
 8292 CONTINUE
      ALUNOV=ALUNO
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE STEADY(PROFLU,CL,ALT,WW,QCEL,WGAMC,CEFI,TEM,
     1 EFB,RES,FCN,ALBA,BQ,PH,EEF,PHV,ENF,BE,AL,C,SG,PHI,AKF,
     3 CM,ALM,BEM,PHS,D,HBE,PHSV,HBEV,HBEK,NCM,NGM,NRITM,NC1M,
     5 NUZOM,NCOSM,C2,ENFV,CV,ENFVV,CVV,PHP,TEMV,DV,ALMV,
     6 CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,WESTV,WESTD,NPDM,CORD,
     7 WESTS,H,RO,CSP,GIN,WTRA,JMAPP,JPLOT,JSTAMP,NBAR,EPSR,
     8 IPS,ROV,HEL,XE,VIO,PM,SM,IVELBR,
     9 IBORO,TREF,NNYM,NSTRAM,NSM,PRPR,EEFR,PALBA,ZW,CLTH,BO,
     & FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     % COEEF1,RLAM,RBETA,VELOC,BINSTE,PROFF,PROFP,NLIBM,NPROFM,
     $ AKFCEL,ALJ,BEJ,COEXE1,DSGXE,ZDG,TN,SER,DEN,PHV1,EPSNOR,
     ^ TCNOS,RONOS,CALFA,CBETA,CALFA1,CBETA1,SIGXE,GISF,SIGXEL,GISFL,
     ! XEV,VIOV,TMNOS,XENOS)
C-----------------------------------------------------------------------
C     GESTISCE IL CALCOLO STAZIONARIO IN CINETICA MONODIMENSIONALE
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LREGIM,LEND,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/KINA05/JDKIN,JCELT,JKIN,JG,DCANN,DELNUM,DRC,DASPA,DALATT,
     &              DPOTNO,DBURM
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/CCONST/PRLIB,TMLIB,TCREF,DSIGB1(15),DSIGB2(15),BR21,BR22
     &              ,DUMMI5(NW-2*15-5)
C     *,CEFB1,CEFB2
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      COMMON/XEIOTM/XEVV(NCNT),VIOVV(NCNT),TREFV(NCNT),TEMCV(NCNT),
     &              TEMPV(NCNT)
      COMMON/REG22$/TIMERG(NW),WTOTRG(NW),REATRG(NW),PDECRG(NW),
     &              AXOFRG(NW),AMINB1(NW),AMINB2(NW),ALFDRG(NW),
     &              ALFMRG(NW),ALFBRG(NW),DUMMI60(20*NW-10*NW)
      COMMON/TARGE$/TARAXO,POTF0,DUMMI7(NW-2)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/NAS$$/NAS(KUZOM),DUMMI31(NW-KUZOM)
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/BOR$/BORVCT,DUMMI23(NW-1)
      COMMON/SOS$/NSTEP(5),INSER(5,30,22),                 LIZO(15,15),
     1N(5),LIBA(5,15,15),JAP(15,15),SOM(5),NGRU(5),MAP(2,15),KAP(15,15),
     2HELBT(5),INDEL(15,15)
     &           ,DUMMI51(NW*NW-5*5-5*30*22-4*15*15-5*15*15-2*15)
      COMMON/FILES$/IRLIB1,IRLIB2,IRLIB3,IREST,NUREC2,IALBE,IDUMMI(NW-6)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
      COMMON/PRODE$/ADEC(KPDM,KPDM-1),GDEC(KPDM,KPDM-1),POTDEC
     &             ,DUMMI50(5*NW-2*KPDM*(KPDM-1)-1)
      COMMON/PKIN$/DWANOM,SIGFEE,DUMMI14(NW-2)
      DIMENSION PROFLU( * ),CL( * ),ALT( * ),WW( * ),QCEL( * ),NBAR(*),
     1WGAMC( * ),CEFI( * ),VIO(*),  TEM( * ),EFB(NGM,  *  ),RES( * ),
     3ROV(*),HEL(*),XE(*), FCN(NCM, *  ),ALBA( * ),ZDG(*),TN(*),SER(*),
     4BQ( * ),PH( * ),EEF( * ),PHV( * ),ENF( * ),BE(NRITM, * ),PM(*),
     5AL(NRITM, * ),C(NRITM, * ),SG( * ), DSGXE(*),DEN(*),PHV1(*),
     7PHI(*),SM(*),AKF(*),CM(*),ALM(*),BEM(*),WTRA(*),VIOV(*),XEV(*),
     8SERFIV(*),TREF(*),H(*),RO(*),CSP(*),TEMV(*),WESTS(*),D(*),C2(*),
     9HAKF(*),PHS(*),ENFV(*),PHSV(*),WESTV(*),WESTD(NPDM,*),GIN(*),
     $CV(NRITM,*),ENFVV(*),CVV(NRITM,*),HBE(*),HBEK(*),HBEV(*),PHP(*),
     *DV(*),ALMV(*),CMV(*),BQ1(*),BQV(*),BQV1(*),BQP(*),C2BQ(*),CORD(*),
     &PRPR(*),EEFR(*),PALBA(*),ZW(*),CLTH(*),AKFCEL(*),ALJ(*),BEJ(*)
      DIMENSION FCNZ(*),ILIB1(*),ILIB2(*),COES1(NLIBM,NCM,*),RONOS(*),
     &          COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),CALFA(*),
     %          COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),CBETA(*),
     &          RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),PROFP(NPROFM,*),
     &          VELOC(NLIBM),BINSTE(NPROFM,*),PROFF(NPROFM,*),GISF(*),
     &          COEXE1(NLIBM,NCM,*),CALFA1(*),CBETA1(*),TCNOS(*),
     $     SIGXE(*),SIGXEL(NLIBM,*),GISFL(NLIBM,*),TMNOS(*),XENOS(*)
C
      DATA ITERFL/0/ , ITEFMX/30/ , IPERT/0/
      DATA NOC/48/
      IF(ILEGO.EQ.1) THEN
      NOCPWR=228
      ELSE IF(ILEGO.EQ.2) THEN
      IF(ABS(WNOM-2780.E+6).LE.10.E+6) THEN                             
      NOCPWR=225
      ELSE IF(ABS(WNOM-3800.E+6).LE.10.E+6) THEN                        
      NOCPWR=260
      ENDIF                                                             
      ENDIF
C
      IF(ITERFL.GT.0) GO TO 222
C                                                                       
      WRITE(NWRITE,737) IDKIN,IDUEG
      WRITE(99,737) IDKIN,IDUEG
  737 FORMAT(/,125('-'),///,20X,'>>>>>>  MODULO  K I N A  ',
     &       '(PROGRAMMA S T R I Q S)',
     &    '  <<<<<< ',//,28X,'( CINETICA NEUTRONICA (',I1,'-D) A ',I1,
     &    '-G )',///,1X,125('-'),///)
      WRITE(NWRITE,230)
  230 FORMAT(/,25X,'*****       STAMPE IN KIQS02       *****',//,
     &           25X,'*****  INIZIO CALCOLO STAZIONARIO  *****',/)
C
      NCEL=NC1
      DWANOM=WNOM/(CANN*ASPA*ASPA*ALATT*100.)
      RSUP=ASPA*ASPA/(DEPZ*1.E+04)
      ANOCP=(ALATT*100.-ZMIN)/FLOAT(NOCPWR)                             
      ANOC=(ALCAN*100.-ZMIN)/FLOAT(NOC)
      NSTAMP=1                                                          
C
C---- INTERPOLAZIONI SUL B.U. DI INPUT NELLE BIBLIOTECHE LIBELLULE      
      IF(ILEGO.EQ.2) CALL EPUINT(BURM)
C
C     COEFFICIENTI DI AGGIUSTAMENTO DELLA POTENZA DI DECADIMENTO        
      DO 67 J=1,NPD
   67 CORD(J)=1.0
C     SCELTA DELLA STRATEGIA DI BARRE DA IMPIEGARE IN FUNZIONE          
C     DEL BRUCIAMENTO MEDIO DI REATTORE
      IS=1
      IF(IBWR.EQ.0.AND.NST.NE.1)  STOP
     &  ' ERRORE DI INPUT : NST.NE.1 PER UN PWR '
      IF(IBWR.EQ.0) GO TO 6
      IBURM=BURM
      IF(IBURM/4*4.EQ.IBURM)  GO TO 3
      IF(IBURM/2*2.EQ.IBURM)  GO TO 4
      IF((IBURM-1)/4*4.EQ.(IBURM-1))  GO TO 5
      IS=4
      GO TO 6
    3 IS=1
      GO TO 6
    4 IS=3
      GO TO 6
    5 IS=2
C
    6 CONTINUE
C
  222 CONTINUE
C-----------------------------------------------------------------------
C     VALUTAZIONE DEL LIVELLO DI ESTRAZIONE DEGLI NG BANCHI DI BARRE
C     (SIA IN PASSI CHE IN CM.) PER UN PWR.
C
C     - INSER(IS,NST,K),(K=1,NG) : LIVELLO DI ESTRAZIONE DEI BANCHI IN P
C     - BINSER(K),(K=1,NG)       : LIVELLO DI ESTRAZIONE DEI BANCHI IN C
C     - ALBA(K),(K=1,NG)         : COMPLEMENTO ALL'ALTEZZA ATTIVA DEL CA
C                                  DELL'INSERIMENTO (IN CM.) DI OGNI BAN
C                                  (--> ESTRAZIONE DEI BANCHI DI BARRE I
C
C       ( 228 PASSI DI ESTRAZIONE --> BARRE TUTTE FUORI
C           0 PASSI DI ESTRAZIONE --> BARRE TUTTE DENTRO )
C-----------------------------------------------------------------------
      BORVCT=CBORO
      DO 397 K=1,NG
      BINSER(K)=DINSER(K)
      INSER(IS,NST,K)=IFIX(BINSER(K))
C      ALBA(K)=INSER(IS,NST,K)*ANOCP+ZMIN
      ALBA(K)=BINSER(K)*ANOCP+ZMIN
      IF(ALBA(K).LE.ZMIN) ALBA(K)=ZMIN
      IF(ALBA(K).GE.ALATT*100.) ALBA(K)=ALATT*100.
  397 CONTINUE
C     INDIVIDUAZIONE DELLA CONCENTRAZIONE DI BORO NEL CIRCUITO PRIMARIO
      BO=BORVCT                                                         
C
      IF(IFUN.EQ.2) THEN                                                
      IPERT=0
      ITERFL=ITERFL+1
      ENDIF
      IPERT=IPERT+1
C      IF(ITERFL.GT.ITEFMX)
C     & STOP ' NUMERO DI ITERAZIONI IN STAZIONARIO SUPERIORE AL MASSIMO'
      WRITE(NWRITE,*) 'ITERAZIONE N.',ITERFL,'   PERTURBAZIONE N.',IPERT
C
      IF(ABS(ALCAN-ALATT).GT.1.E-04) STOP ' ERRORE : ALCAN.NE.ALATT '
C     CALCOLO DELLA POTENZA TOTALE DI REATTORE (RELATIVA ALLA ITERAZIONE
C     CORRENTE) COME SOMMA DELLE POTENZE TOTALI DI CELLA
C      W=0.
C      DO K=1,NCELT
C      W=W+WCEL(K)
C      ENDDO
C     IPOTESI DI POTENZA TOTALE DI REATTORE IMPOSTA NOTA NELLA
C     RICERCA DEL REGIME PERMANENTE
      W=WTOT
C
      ALCA=W/(ALCAN*CANN)
      DO 9  K=1,NCEL
      WW(K)=ALCA*PROFLU(K)
      WWWK=1.
      DO 300 J=1,NPD
      WWWK=WWWK+ADEC(J,NPD-1)*GDEC(J,NPD-1)*ABS(TPAS)/(1.+ADEC(J,NPD-1)*
     $          ABS(TPAS))
  300 CONTINUE
C ********  POTENZA DI FISSIONE  ***************************************
      WW(K)=WW(K)/WWWK                                                  
C ********  POTENZA DI RISCALDAMENTO GAMMA  ****************************
      WGAMC(K)=RGAM*WW(K)*CL(K)
C ********  POTENZA DI DECADIMENTO  ************************************
      DO 200 J=1,NPD
      WESTD(J,K)=CORD(J)*(ADEC(J,NPD-1)*GDEC(J,NPD-1)*WW(K)*ABS(TPAS))/
     &         (1.+ADEC(J,NPD-1)*ABS(TPAS))                             
  200 CONTINUE
    9 CONTINUE                                                          
      PFIS=0.
      PDEC=0.
      DO 16 K=1,NC1
      WESTS(K)=0.
      DO 17 J=1,NPD
   17 WESTS(K)=WESTS(K)+WESTD(J,K)
      PDEC=PDEC+WESTS(K)*CL(K)                                          
      PFIS=PFIS+WW(K)*CL(K)
   16 CONTINUE                                                          
      POTDEC=PDEC*CANN
      WRITE(NWRITE,30) POTDEC
   30 FORMAT(5(/),1X,'POTENZA MEDIA TOTALE DI DECADIMENTO WDEC =',E12.5)
      POTFIS=PFIS*CANN
      RADEC=POTDEC/W
      DWANOM=DWANOM*(1.-RADEC)
      POTF0=POTFIS
      WRITE(NWRITE,44) POTFIS
   44 FORMAT(1X,'POTENZA TOTALE DI FISSIONE WFIS =',E12.5)
      WRITE(NWRITE,40) W
   40 FORMAT(1X,'POTENZA TOTALE DI REATTORE W =',E12.5)
C---- RICERCA DI REGIME A XENO FISSATO AL VALORE NOMINALE
      IF(IXENO.EQ.0) THEN
      DO 385 K=1,NC1
  385 XEV(K)=XE(K)
      ENDIF
      CALL PREME(TEM,RO,HEL,TREF,PROFLU,TCNOS,RONOS,CALFA,CBETA,
     &           CALFA1,CBETA1,TMNOS,XENOS,XE)
      DO 4113 K=1,NC1
 4113 WW(K)=WW(K)+WESTS(K)
      CALL DINAMO(IS,INSER,AKF,AL,ALBA,ALM,ALT,BE,BEM,BQ,               
     1 C,CEFI,CL,CM,D,EEF,EFB,ENF,FCN,HBE,PH,PHI,
     2 PHS,PHV,RES,SG,TEM,WW,ZW,HBEV,HBEK,NCM,
     3 NSTRAM,NGM,NRITM,NUZOM,NSM,PHSV,CV,CVV,WESTS,EPSR,RO,            
     4 IPS,HEL,XE,VIO,SM,PM,IVELBR,BO,EPSNOR,
     5 IBORO,PRPR,EEFR,PALBA,JMAPP,PROFLU,BQV,FCNZ,ILIB1,ILIB2,
     6 COES1,COED1,COENF1,COEKFT,COEEF1,RLAM,RBETA,VELOC,NLIBM,
     7 AKFCEL,ALJ,BEJ,ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,ITERFL,IPERT,
     8 ZDG,TN,SER,DEN,PHV1,SIGXE,GISF,SIGXEL,GISFL,XEV,VIOV,TREF)
C
      IF(ITERFL.EQ.1) THEN
      WRITE(NWRITE,*) ' DSIGB2 =',DSIGB2
      WRITE(NWRITE,*) ' BQR1 =',BQR1,'  BQR2 =',BQR2
      ENDIF
C     CALCUL DU FACTEUR DE PIC LOCAL FZ
      FZ=PHS(1)
      KFZ=1
      DO 981 K=2,NCEL
      IF(PHS(K).GT.FZ) THEN
      FZ=PHS(K)
      KFZ=K
      ENDIF                                                             
  981 CONTINUE
      WRITE(NWRITE,215) FZ,KFZ                                          
  215 FORMAT(/,1X,'FACTEUR DE PIC AXIAL FZ=',F6.3,2X,'DANS LA MAILLE K='
     &,I3)                                                              
C     CALCOLO DELLE NUOVE POTENZE DI FISSIONE, DI RISCALDAMENTO GAMMA E
C     DECADIMENTO RELATIVE AL NUOVO PROFILO DI POTENZA DELL'ITERAZIONE C
      DO 91  K=1,NCEL
      WW(K)=ALCA*PROFLU(K)
      WW(K)=WW(K)/WWWK
      WGAMC(K)=RGAM*WW(K)*CL(K)                                         
      DO 201 J=1,NPD
      WESTD(J,K)=CORD(J)*(ADEC(J,NPD-1)*GDEC(J,NPD-1)*WW(K)*ABS(TPAS))/
     &         (1.+ADEC(J,NPD-1)*ABS(TPAS))                             
  201 CONTINUE
   91 CONTINUE                                                          
      DO 161 K=1,NCEL
      WESTS(K)=0.
      DO 171 J=1,NPD
  171 WESTS(K)=WESTS(K)+WESTD(J,K)
  161 CONTINUE
C     PREPARAZIONE GRANDEZZE UTILIZZATE IN 'LEGO'
      D1=D(1)
      DNCEL=D(NCEL)
      DO 47 K=1,NCEL                                                    
      WESTV(K)=WW(K)/100.
   47 WESTS(K)=WESTS(K)/100.
      CALL PROLEG(REAT,WESTV,WESTS,ALT,CANN,REATC,WTOTC,WNEUTC,WCELC)   
      NCEL2=NCEL/2
      IF(ILEGO.EQ.1) THEN
C     CALCOLO DELL' "AXIAL OFFSET" (SQUILIBRIO ASSIALE DI FLUSSO NEUTRON
      NCEL4=NCEL/4 + 1.E-05
      RIV1=0.
      RIV2=0.
      RIV3=0.
      RIV4=0.
      DO 398 K=1,NCEL4
      RIV1=RIV1+PHS(K)
      RIV2=RIV2+PHS(K+NCEL4)
      RIV3=RIV3+PHS(K+2*NCEL4)
      RIV4=RIV4+PHS(K+3*NCEL4)
  398 CONTINUE
      FIMENO=RIV4+RIV3-RIV2-RIV1
      FIPIU =RIV4+RIV3+RIV2+RIV1
      AXOFFC=100.*FIMENO/FIPIU                                          
      FMINB1=TARAXO+5.
      FMINB2=TARAXO-5.                                                  
      ELSE IF(ILEGO.EQ.2) THEN
C CALCUL DE L'AXIAL OFFSET(DESEQUILIBRE AXIAL DE PUISSANCE NEUT)        
      PHAUT=0.
      PBAS=0.
      DO 71 K=1,NCEL2
      PBAS=PBAS+PROFLU(K)*ALT(K)
      PHAUT=PHAUT+PROFLU(K+NCEL2)*ALT(K+NCEL2)
   71 CONTINUE                                                          
      AXOFFC=100.*(PHAUT-PBAS)/(PHAUT+PBAS)
      ENDIF
C CALCUL AXIAL-OFFSET XENON ET IODE                                     
      XEHAUT=0.
      XEBAS=0.                                                          
      VIOHAU=0.
      VIOBAS=0.                                                         
      DO 72 K=1,NCEL2
      XEBAS=XEBAS+XE(K)*ALT(K)
      XEHAUT=XEHAUT+XE(K+NCEL2)*ALT(K+NCEL2)
      VIOBAS=VIOBAS+VIO(K)*ALT(K)
      VIOHAU=VIOHAU+VIO(K+NCEL2)*ALT(K+NCEL2)
   72 CONTINUE
      AOXE=100.*(XEHAUT-XEBAS)/(XEHAUT+XEBAS)
      AOIO=100.*(VIOHAU-VIOBAS)/(VIOHAU+VIOBAS)                         
C
      WRITE(NWRITE,33) AXOFFC,AOXE,AOIO                                 
   33 FORMAT(/,1X,'AXIAL-OFFSET = ',F6.2,2X,'A.O. XENON=',F7.3,
     &2X,'A.O. IODE=',F6.2)                                             
C
      IF(JSTAMP.NE.0) THEN
      WRITE(NWRITE,69)
      CALL OUTP(TIMEV,NCM,ALBA,FCN,EEF,ENF,SG,PROFLU,WW,TEM,RO,H,
     &          GIN,W,BO,XE,SM,PALBA)
      ENDIF
   69 FORMAT(1H1)
      IF(JPLOT.EQ.0) GO TO 651
C-----------------------------------------------------------------------
C     SCRIVE SUI FILES '73' E '74' PER IL PLOTTAGGIO (SE JPLOT>0)
C-----------------------------------------------------------------------
      WTOTRG(1)=W*1.E-06
      REATRG(1)=REAT*1.E+05
      PDECRG(1)=POTDEC*1.E-06
      AXOFRG(1)=AXOFFC
      AMINB1(1)=FMINB1
      AMINB2(1)=FMINB2
      ALFDRG(1)=ALFAD
      ALFMRG(1)=ALFAM                                                   
      ALFBRG(1)=ALFAB
      TIMERG(1)=TIMEV
C-----------------------------------------------------------------------
      CALL PREPA1
C-----------------------------------------------------------------------
  651 CONTINUE
      DO 1234 K=1,NCEL
      PHP(K)=PHS(K)
      SERFIV(K)=PHSV(K)
 1234 C2(K)=0.0
      DO 888 K=1,NCEL
      ENFV(K)=ENF(K)
      BQ1(K)=BQ(K)
      BQV(K)=BQ(K)
      BQV1(K)=BQ(K)                                                     
      BQP(K)=BQ(K)
      C2BQ(K)=0.0
      HAKF(K)=AKF(K)                                                    
      DV(K)=D(K)
  888 ENFVV(K)=ENF(K)
      DO 8192 K=1,NCEL
      TEMV(K)=TEM(K)
      ROV(K)=RO(K)
      TREFV(K)=TREF(K)
      XEVV(K)=XE(K)
      XEV(K)=XE(K)                                                      
      VIOVV(K)=VIO(K)
      VIOV(K)=VIO(K)
      IF (ILEGO.EQ.2) THEN                                              
      TEMCV(K)=TEMC(K)
      TEMPV(K)=TEMP(K)                                                  
      ENDIF
      DO 18 J=1,NPD
   18 WESTD(J,K)=WESTD(J,K)/100.
 8192 CONTINUE
      DO 8292 J=1,NRIT
      ALMV(J)=ALM(J)                                                    
      CMV(J)=CM(J)
 8292 CONTINUE
C
      WRITE(NWRITE,150)                                                 
  150 FORMAT(/////,20X,'*****  FINE CALCOLO STAZIONARIO  *****',/,1H1)
C                                                                       
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KINET0(CM,BEM,ALM,NTTJM)
C-----------------------------------------------------------------------
C     INTEGRA CON METODO IMPLICITO LE EQUAZIONI DELLA CINETICA PUNTIFORM
C     CON INTERPOLAZIONE LINEARE DELLA REATTIVITA' SULL'INTERVALLO
C     TEMPORALE DI RICALCOLO TERMOIDRAULICO.
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/PADKR$/PPF,AAG,PPFV,AAGV,DTKIN,DUMMI15(NW-5)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      DIMENSION CM(*),BEM(*),ALM(*)
C
      DTN=DTKIN
      KN=0
      HDREA=(HREAT-HREATK)/DTJ
C     LOOP PER L'INTEGRAZIONE NEUTRONICA (0-D) SULL'INTERVALLO DTJ
C     CON PASSI DTN
  100 KN=KN+1
      IF(KN.GT.NTTJM) STOP 'N. PASSI NEUTRONICI MAGGIORI DEL CONSENTITO'
      DTNT=KN*DTN
      HREAI=HREATK+HDREA*DTNT
      PPFV=PPF
      AAGV=AAG
      HREBE=HREAI-HBEM
      AAG=-HREBE
      CALL PADE12(ALM,BEM,CM,T,DTN,NRIT)
      IF(DTNT.LT.DTJ*(1.-1.E-04)) GO TO 100
C      WRITE(NWRITE,*) 'AMPIEZZA T =',T , '   DTNT =',DTNT
C      WRITE(NWRITE,25) (CM(J),J=1,NRIT)
   25 FORMAT(6(1X,G12.5))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE SSCRAM(NSCRAM,ALBAS,ALBA,NGM,ITST1,ITST2,TST1,
     &                  DELTAT,TEMFIN,TPARTX,JSTAMP,WEST,ALT)
C-----------------------------------------------------------------------
C     DEFINISCE I PARAMETRI NECESSARI IN CONDIZIONI DI 'SCRAM'
C     (LO SCRAM VIENE SIMULATO CON CINETICA NEUTRONICA PUNTIFORME)
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/PKIN$/DWANOM,SIGFEE,DUMMI14(NW-2)
      COMMON/PADKR$/PPF,AAG,PPFV,AAGV,DTKIN,DUMMI15(NW-5)
      COMMON/TRATE$/G0,G1,H0,H1,P0,P1,DELTIM,TPART,DUMMI10(NW-8)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION ALBAS(*),ALBA(*),WEST(*),ALT(*)
C
      TIM=TIMEVS-TST+TST1-TPARTX
C
      NSCRAM=1
      ITST1=1
      ITST2=1
      DO 700 K=1,NG
  700 ALBAS(K)=ALBA(K)
      IF(IDKIN.EQ.1) THEN
C     DEFINIZIONE DEI PARAMETRI ZERODIMENSIONALI
      DENWF=0.0
      DO 477 K=1,NC1
      DENWF=DENWF+WEST(K)*ALT(K)
  477 CONTINUE
      DENWF=DENWF/(ALCAN*100.*DEPZ*1.E+04)
      SIGFEE=DENWF/T
      SIGFNU=VEL/ALBIG
      AAG=(BEMTOT-REAT)/ALBIG
      PPF=1./ALBIG
      VNUM=2.45
      ENDIF
C
      WRITE(99,50) TIMEVS
      WRITE(NWRITE,50) TIMEVS
   50 FORMAT(/1X,'ATTENZIONE, INNESCO AUTOMATICO DELLO "SCRAM" A TIMEY =
     &',G12.5,' SEC.',/,1X,'IL TRANSITORIO DI SCRAM VIENE SIMULATO ',
     %'CON CINETICA NEUTRONICA PUNTIFORME ',/)
      IF(IDKIN.EQ.1) WRITE(NWRITE,713) DTPSI,DTJ,TIMEVS
  713 FORMAT(1X,'DTPSI DI SCRAM =',G12.5,5X,'DTJ DI SCRAM =',G12.5,5X//
     $5X,'*** TIME DI SCRAM ***  =',G12.5,5X//)
      IF(IDKIN.EQ.0) WRITE(NWRITE,714) TIMEVS,DTJ
  714 FORMAT(//5X,'*** TIME DI SCRAM *** =',G12.5,5X,'*** DTJ DI SCRAM *
     $** =',G12.5//)
C
      IDKIN=0
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE CRLOC(REATOT)
C-----------------------------------------------------------------------
C     ROUTINE PER IL CALCOLO DELLE CONTROREAZIONI (0-D) DI REATTIVITA'
C-----------------------------------------------------------------------
      REAL*8 REATOT
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
C
      IF(IDKIN.EQ.0) STOP ' CONTROREAZIONI 0-D ANCORA DA IMPLEMENTARE'
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE DECADE(PHS,EEF,WESTD,NPDM,WESTV,WMED,WEST,ALT,WESTS)
C-----------------------------------------------------------------------
C     CALCOLA LA POTENZA DI DECADIMENTO DEGLI NPD (2-11) PRODOTTI DI
C     FISSIONE (NEL CASO 1-D TALE CALCOLO VIENE EFFETUATO SOLAMENTE
C     ALLA FINE DI UN INTERVALLO DI CONVERGENZA DELLA FUNZIONE FORMA)
C-----------------------------------------------------------------------
C
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/PRODE$/ADEC(KPDM,KPDM-1),GDEC(KPDM,KPDM-1),POTDEC
     &             ,DUMMI50(5*NW-2*KPDM*(KPDM-1)-1)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/REAL1$/EDP,REG,RIG,RGEMLN,RGMILN,CST,COG,DST,BST,RC,COGC,
     1VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     2TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      DIMENSION PHS(*),EEF(*),WESTV(*),WESTD(NPDM,*),WMED(*),WEST(*),
     *          WESTS(*),ALT(*)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
C
      DO 1 K=1,NC1
      IF(IDKIN.EQ.0) GO TO 30
      WEST(K)=T*(PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K))*DEPZ*1.E+04
      WMED(K)=(WESTV(K)+WEST(K))*0.5
      GO TO 31
Casam
Casam      write(6,*)'DTPSI - DTJ ',DTJ
   30 DTPSI=DTJ
      WMED(K)=WEST(K)
   31 DO 3 J=1,NPD
      WESTD(J,K)=(WESTD(J,K)+ADEC(J,NPD-1)*GDEC(J,NPD-1)*WMED(K)*DTPSI)/
     $          (1.+ADEC(J,NPD-1)*DTPSI)
    3 CONTINUE
    1 CONTINUE
      DO 2 K=1,NC1
    2 WESTV(K)=WEST(K)
      PDEC=0.
      DO 11 K=1,NC1
      WESTS(K)=0.
      DO 12 J=1,NPD
   12 WESTS(K)=WESTS(K)+WESTD(J,K)
      PDEC=PDEC+WESTS(K)*ALT(K)
   11 CONTINUE
      POTDEC=PDEC*CANN
C      IF(IDKIN.EQ.1) WRITE(NWRITE,20) POTDEC
   20 FORMAT(1X,'POTENZA MEDIA TOTALE DI DECADIMENTO =',E12.5)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE GEBABO(ALBA,HALBA,ITJ,IT,NGM,BO,HBORO,PASSI1,PASSI2)
C-----------------------------------------------------------------------
C     GESTISCE IL LIVELLO DI ESTRAZIONE DEI BANCHI DI BARRE, IL VALORE
C     DELLA CONCENTRAZIONE DI BORO NEL CIRCUITO PRIMARIO E I PASSI DI
C     ESTRAZIONE DEI BANCHI (NEL CASO DI REGOLAZIONE 'MODE GRIS' EDF 7N)
C     SULLA BASE DEGLI INGRESSI PROVENIENTI DA LEGO NEL CORSO DEL PRIMO
C     (IT=1) RICALCOLO DELLA FUNZIONE FORMA DEL FLUSSO NEUTRONICO
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      DIMENSION ALBA(*),HALBA(NGM,*),HBORO(*),HPAS(5,80)
C
      JTI=ITJ
      IF(IT.GT.1) THEN
      DO 10 K=1,NG
   10 ALBA(K)=HALBA(K,JTI)
      BO=HBORO(JTI)
      IF (ILEGO.EQ.2) THEN
      PASSI1=HPAS(1,JTI)
      PASSI2=HPAS(2,JTI)
      ENDIF
      ELSE
      DO 20 K=1,NG
   20 HALBA(K,JTI)=ALBA(K)
      HBORO(JTI)=BO
      IF (ILEGO.EQ.2) THEN
      HPAS(1,JTI)=PASSI1
      HPAS(2,JTI)=PASSI2
      ENDIF
      ENDIF
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE DINAMO(IS,INSER,AKF,AL,ALBA,ALM,ALT,BE,BEM,
     1 BQ,C,CEFI,CL,CM,D,EEF,EFB,ENF,FCN,HBE,PH,PHI,PHS,PHV,
     2 RES,SG,TEM,WW,ZW,HBEV,HBEK,NCM,NSTRAM,NGM,NRITM,NUZOM,
     3 NSM,PHSV,CV,CVV,WESTS,EPSR,
     4 RO,IPS,HEL,XE,VIO,SM,PM,IVELBR,BO,EPSNOR,IBORO,PRPR,AKFR,
     5 PALBA,JMAPP,PROFLU,BQV,FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,
     6 COEKFT,COEEF1,RLAM,RBETA,VELOC,NLIBM,AKFCEL,ALJ,BEJ,ALFAD,
     7 ALFAM,ALFAB,COEXE1,DSGXE,ITERFL,IPERT,ZDG,TN,SER,DEN,PHV1,
     $ SIGXE,GISF,SIGXEL,GISFL,XEV,VIOV,TREF)
C-----------------------------------------------------------------------
C     RICERCA LA CONDIZIONE DI CRITICITA' DEL REATTORE E CALCOLA LE
C     COSTANTI NUCLEARI NELLO STAZIONARIO
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),       
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/LIBSEP/DDS(66,60),EF(60),FLU1V(60),FLU2T(60),BQR1,BQR2,
     &              BQZ1M,BQZ2M,AKEFFL,NCELRF,BQE2(60),RFIS21(60)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N                    
     &              ,DUMMI61(NW-16)
      COMMON /MATRIF/FT$(8),AP$(8),GT$(8),FT1$(8),F01$(8),G01$(8),
     &               GT1$(8),AP4$(8),AP5$(8),SS$(8),DD$(8),RM$(8),QQ(8),
     &               TTINF(4),TTSUP(4),PM1$(8),RG$(8),VG$(8),OMR$(8),
     &               DC$(8),RN$(8)
      COMMON/FIOLD/PHR11V,PHR1NV,PHR21V,PHR2NV
      COMMON/TUSEPT/TEMC(NCNT),TEMP(NCNT)
      COMMON/BARRE$/VBAR,BINSER(NBBC),DUMMI32(NW-NBBC)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     &       RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/KINA04/WTOT,WNEUT,WTOTP,WNEUTP,REATL,WCEL(NCNT),AXOFF,
     &       ROCEL(NCNT),TCCEL(NCNT),PASSI1,PASSI2,CBORO,DINSER(NBBC),
     &       IFUN,TMCEL(NCNT),TCCELC(NCNT),TCCELP(NCNT)
      COMMON/PROXE/ALFA2(NCNT),BETA2(NCNT),ALFA3(NCNT),BETA3(NCNT)
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/PASSA$/IDKIN,JSTAM$,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/VATE$/DTJ,DTJNEW,NDTJM,DUMMI24(NW-3)
      COMMON/REAL1$/EDP,REG,RIG,RGELMN,RGMILN,CST,COG,DST,BST,RC,COGC,
     *VC,ELNUM,COB,DEPZ,TS,CSIIC,DIDR,ACGRV,EFCP,ENCP,CSIFR,RELN,A,DG,
     *TFIX,DC,ASPA,RSUP
     &             ,DUMMI22(NW-29)
      COMMON/REAL2$/DPN, VEL ,Q,CCOM,VFLU,DUMMI21(NW-5)
      COMMON/REAL4$/HREAT,HBEM,HREATV,HBEMV,HBEMK,HREATK,DUMMI19(NW-6)
      COMMON/RIFLA$/RRFI,RRTI,RRFS,RRTS,DUMMI6(NW-4)
      COMMON/TAPE$/NREAD,NWRITE,NDUMMI1(NW-2)
      DIMENSION ZW(*),WW(*),RES(*),PHI(*),ZDG(*),TN(*),SER(*),DEN(*),
     1FCN(NCM,*),ALBA(*),INSER(NSTRAM,NSM,*),CEFI(*),WESTS(*),XEV(*),
     2EFB(NGM ,*),ALT(NCM),TEM(*),BQ(*),PH(*),EEF(*),PHV(*),ENF(*),
     3BE(NRITM,*),AL(NRITM,*),C(NRITM,*),D(*),SG(*),PROFLU(*),
     5CM(*),ALM(*),BEM(*),CL(*),PHS(*),RO(*),BQV(*),AKF(*),PHV1(*),
     6  HBE(*),HBEV(*),HBEK(*),PHSV(*),CV(NRITM,*),CVV(NRITM,*),
     8XE(*),VIO(*),PM(*),SM(*),HEL(*),ALJ(*),BEJ(*),AKFCEL(*),
     9PALBA(*),PRPR(*),AKFR(*),DSGXE(*),SIGXE(*),GISF(*),VIOV(*)
      DIMENSION FCNZ(*),ILIB1(*),ILIB2(*),COES1(NLIBM,NCM,*),
     &         COED1(NLIBM,NCM,*),COENF1(NLIBM,NCM,*),
     %         COEKFT(NLIBM,NCM,*),COEEF1(NLIBM,NCM,*),
     &         RLAM(NLIBM,NCM,*),RBETA(NLIBM,NCM,*),GISFL(NLIBM,*),
     &         VELOC(NLIBM),COEXE1(NLIBM,NCM,*),SIGXEL(NLIBM,*),TREF(*)
      DIMENSION RMAT1(4),RMAT2(4)
C
      IF(ITERFL.EQ.1.AND.IPERT.EQ.1) THEN                               
      NSTINP=NST
      ENER=0.                                                           
      ENERV=0.
      NCEL=NC1
      NOC=48
      ENDIF
C                                                                       
      DO 5 K=1,NCEL
      ZW(K)=(WW(K)-WESTS(K))/100.
      BQ(K)=0.
      BQZ1(K)=0.
      BQZ2(K)=0.
    5 CONTINUE
      DPFIS=0.
      DPDEC=0.
      DO 22 K=1,NCEL
      DPDEC=DPDEC+WESTS(K)*ALT(K)/100.
   22 DPFIS=DPFIS+ZW(K)*ALT(K)
      POTFIS=DPFIS*CANN
      POTDEC=DPDEC*CANN
      IF(IBWR.EQ.0) GO TO 2138
C     RICERCA DI CRITICITA' DA BARRE (BORO NULLO) PER UN BWR
      BO=CRIBO(BURM,IVELBR,IBWR)
      NKK=0
      NK1=0
      NK2=0
      NKZ=1
  801 IF(NKZ.EQ.1) GO TO 802
      REAT1=REAT
      NS1=NST
      IF(REAT)804,800,805
  804 NK1=1
      NST=NST+1
      IF(NST.LT.1) GO TO 911
      GO TO 802
  805 NK2=1
      NST=NST-1
  802 CONTINUE
      IF(NST.GT.NS) GO TO 910
C
 2138 CONTINUE
C
C      WRITE(NWRITE,*) 'POTFIS=',POTFIS,'  POTDEC=',POTDEC,' WTOT=',W
C      WRITE(NWRITE,'(6G12.5)') (PH(K),K=1,NCEL)
C      WRITE(NWRITE,'(6G12.5)') (TEM(K),K=1,NCEL)
C      WRITE(NWRITE,'(6G12.5)') (RO(K),K=1,NCEL)
C
C-----------------------------------------------------------------------
C     GENERAZIONE DELLE COSTANTI NUCLEARI DELLO STAZIONARIO
C-----------------------------------------------------------------------
C
      IF (ILEGO.EQ.1) THEN
      CALL CONUC(ALBA,BO,TEM,RO,ALT,CEFI,PH,D,SG,ENF,EEF,AKF,
     &           AKFCEL,BE,AL,VEL,NRITM,ALJ,BEJ,
     &           FCNZ,ILIB1,ILIB2,COES1,COED1,COENF1,COEKFT,
     %           COEEF1,RLAM,RBETA,VELOC,NLIBM,NCM,
     %           ALFAD,ALFAM,ALFAB,COEXE1,DSGXE,SIGXE,GISF,
     !           SIGXEL,GISFL)
C
C     CALCOLO DEL RAPPORTO COSTANTE DURANTE IL TRANSITORIO :
C     (TASSO DI PRODUZIONE DELLO IODIO)/(ENERGIA RILASCIATA PER FISSIONE
      WRITE(NWRITE,*) 'SIGXE 2=',(SIGXE(K),K=1,NCEL)
      WRITE(NWRITE,*) 'GISF 2 =',(GISF(K),K=1,NCEL)
      DO 471 K=1,NCEL
      GISF(K)=GISF(K)/EEF(K)
  471 CONTINUE
      WRITE(NWRITE,*) 'GI/E 2 =',(GISF(K),K=1,NCEL)
C
C     CALCOLO DEI VELENI (CONCENTRAZIONI DI IODIO E XENO)
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)
C
C     VALUTAZIONE DEL CONTRIBUTO ALLA SEZIONE MACROSCOPICA DI ASSORBIMEN
C     DOVUTO ALL'AVVELENAMENTO DA XENO
      DO 50 KK=1,NCEL
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB1
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB1(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      DSGX11=DSGXE(KK)
C
C     CONTRIBUTO RELATIVO ALLA LIBRERIA DI BASE ILIB2
C
      CALL SIGXEZ(RO(KK),TEM(KK),BO,ILIB2(KK),KK,NLIBM,NCM,COEXE1,DSGXE)
      IF(LSTAZ) DSGXE(KK)=DSGX11*(1.-FCNZ(KK))+DSGXE(KK)*FCNZ(KK)
   50 CONTINUE
      WRITE(NWRITE,*) 'DSGXE 2=',(DSGXE(K),K=1,NCEL)
       ELSE IF (ILEGO.EQ.2) THEN
      JRESTI=0
      PAS1=PASSI1
      PAS2=PASSI2
      ITEXE=0
      AOXEV=0.
      NCEL2=NCEL/2
  950 ITEXE=ITEXE+1
      DO 484 K=1,NCEL
  484 XE(K)=ALFA3(K)+BETA3(K)*XE(K)
      CALL CONUS(JRESTI,NCEL,NRIT,TEM,TEMC,TEMP,TREF,RO,
     &           BO,XE,SG,DSGXE,ENF,EEF,D,AKF,AKFCEL,PH,GISF,
     &           SIGXE,AL,BE,VEL,NRITM,PAS1,PAS2,ALT)
      CALL VELENI(XE,VIO,GISF,EEF,SIGXE,PROFLU,XEV,VIOV)
C
      IF(IXENO.EQ.0) THEN
C---- RICERCA DI REGIME A XENO FISSATO AL VALORE NOMINALE
      DO 385 K=1,NCEL
  385 XE(K)=XEV(K)
      ELSE IF(IXENO.EQ.1) THEN
C---- SMORZAMENTO OSCILLAZIONI XENO
      PX1=1.
      PX2=1.-PX1
      DO 448 K=1,NCEL
  448 XE(K)=PX1*XE(K)+PX2*XEV(K)
C---- CALCUL AXIAL-OFFSET XENON
      XEHAUT=0.
      XEBAS=0.
      DO 172 K=1,NCEL2
      XEBAS=XEBAS+XE(K)*ALT(K)
      XEHAUT=XEHAUT+XE(K+NCEL2)*ALT(K+NCEL2)                            
  172 CONTINUE
      AOXEV=AOXE                                                        
      AOXE=100.*(XEHAUT-XEBAS)/(XEHAUT+XEBAS)
      WRITE(NWRITE,*) ' ITERAZ. XE =',ITEXE,'  A-O XENON =',AOXE
      IRICXE=1                                                          
      IF(ABS(WTOT-WNOM).LE.10.E+06.AND.BURM.LE.10.) IRICXE=0
      IF(IRICXE.EQ.1.AND.ABS(AOXE-AOXEV).GT.1.E-05) GO TO 950
      ENDIF                                                             
      WRITE(NWRITE,766) (XE(K),K=1,NCEL)
  766 FORMAT(/,20X,'CONCENTRAZIONE DI XENO '/(6E16.7))
C                                                                       
      ENDIF
C
C     CALCOLO DELLA SEZIONE DI ASSORBIMENTO TOTALE
      DO 71 K=1,NCEL
   71 SG(K)=SG(K)+DSGXE(K)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI BUCKLINGS DI CELLA A 2 GRUPPI ENERGETICI.
C     SE IND=0 I BUCLINGS SONO IN CONVERGENZA, SE IND=1 NO.
C-----------------------------------------------------------------------
C
      NITEBM=200
      CALL CALRIF
      NITERB=0
    1 NITERB=NITERB+1
C      WRITE(NWRITE,500) NITERB
  500 FORMAT(///,5X,'ITERAZIONE DA BUCKLING N. ',I3,///)
      IF(NITERB.EQ.1) GO TO 2
      CALL BUCK2G(IND,ALT,EPS1,NCEL)
      IF(NITERB.LT.30) GO TO 2
      IF(IND.EQ.0) GO TO 3                                              
      IF(NITERB.GT.NITEBM) THEN
      WRITE(NWRITE,602) NITERB,NITEBM
  602 FORMAT(1X,'NUMERO ITERAZIONI DA BUCKLING NITERB=',I5,
     &       3X,'(NITEBM = ',I5,' )')                                   
      STOP ' NITERB .GT. NITEBM (SUBROUTINE DINAMO)'
      ENDIF
C                                                                       
C-----------------------------------------------------------------------
C     CALCOLO DELLA MATRICE DI RIFLESSIONE T PER LA RELAZIONE TRA LE
C     CORRENTI DI INTERFACCIA CORE-RIFLETTORE E I FLUSSI MEDI NEI       
C     NODI MOLTIPLICANTI ADIACENTI AL RIFLETTORE
C-----------------------------------------------------------------------
C
    2 CALL MATT(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI PARAMETRI G E W DEL METODO COARSE-MESH
C-----------------------------------------------------------------------
C
      CALL GWCOEF(ALT,NCEL)
C
C-----------------------------------------------------------------------
C     CALCOLO DEI COEFFICIENTI OMEGA CHE METTONO IN RELAZIONE CORRENTI
C     D'INTERFACCIA E FLUSSI MEDI
C-----------------------------------------------------------------------
C
      CALL OMEGA2(ALT,NCEL)
      GO TO 1
    3 CONTINUE
C      WRITE(NWRITE,*) ' N. ITERAZ. BUCKLING =',NITERB
      WRITE(NWRITE,1107) (BQZ1(K),K=1,NCEL)
      WRITE(NWRITE,2107) (BQZ2(K),K=1,NCEL)
C---- CALCOLO DEI FLUSSI AI CONFINI SUPERIORE ED INFERIORE DEL NOCCIOLO
      CALL PERMA1(QQ(1),TTINF,RMAT1)
      CALL PERMA1(QQ(5),TTSUP,RMAT2)
      PHR11=RMAT1(1)*PHR1(1)+RMAT1(3)*PHR2(1)
      PHR21=RMAT1(2)*PHR1(1)+RMAT1(4)*PHR2(1)
      PHR1N=RMAT2(1)*PHR1(NCEL)+RMAT2(3)*PHR2(NCEL)
      PHR2N=RMAT2(2)*PHR1(NCEL)+RMAT2(4)*PHR2(NCEL)
      PHR11V=PHR11
      PHR1NV=PHR1N
      PHR21V=PHR21
      PHR2NV=PHR2N
      WRITE(NWRITE,751) PHR11,PHR1N,PHR21,PHR2N
  751 FORMAT(/,20X,'FLUSSI DI INTERFACCIA CORE-RIFLETTORE',/,1X,
     &      'PHR11 =',G12.5,2X,'PHR1N =',G12.5,2X,'PHR21 =',G12.5,2X,
     &      'PHR2N =',G12.5)
C---- CALCUL DES FUITES AXIALES STRIQS A 2G
      FUITZ1=0.
      FUITZ2=0.
      SOMF=0.
      SOMR=0.
      DMED1=0.
      DMED2=0.
      DO 219 K=1,NCEL
      SOMF=SOMF+(ENFIS1(K)*PHR1(K)+ENFIS2(K)*PHR2(K))*ALT(K)
      SOMR=SOMR+RIM1(K)*PHR1(K)*ALT(K)
      FUITZ1=FUITZ1+DIF1(K)*BQZ1(K)*PHR1(K)*ALT(K)
      FUITZ2=FUITZ2+DIF2(K)*BQZ2(K)*PHR2(K)*ALT(K)
      DMED1=DMED1+DIF1(K)*PHR1(K)*ALT(K)
  219 DMED2=DMED2+DIF2(K)*PHR2(K)*ALT(K)
      BQZ1MM=FUITZ1/DMED1
      BQZ2MM=FUITZ2/DMED2
      FUITZ1=FUITZ1/SOMF
      FUITZ2=FUITZ2/SOMR
      WRITE(NWRITE,*) ' FUGHE AX. VELOCI =',FUITZ1,
     &                '  FUGHE AX. TERMICHE =',FUITZ2
      WRITE(NWRITE,*) ' BUCKLING ASSIALE VELOCE MEDIO =',BQZ1MM
      WRITE(NWRITE,*) ' BUCKLING ASSIALE TERMICO MEDIO =',BQZ2MM
C----------------------------------------------------------------------
C
C     CALCOLO DELLA REATTIVITA' DEL REATTORE
      CALL REA2G(NCM,FSOT,ALT)
      WRITE(NWRITE,1124) REAT
C
C      WRITE(NWRITE,803) NST
  803 FORMAT(5X,'STEP NUMERO',2X,I2/)
 4900 FORMAT(1X,8G12.5)
C      WRITE(NWRITE,*) 'AKINF =',(AKINF(K),K=1,NCEL)
C      WRITE(NWRITE,*) 'ASS1  =',(ASS1(K),K=1,NCEL)
C      WRITE(NWRITE,*) 'ASS2  =',(ASS2(K),K=1,NCEL)
C      WRITE(NWRITE,*) 'BQR1Z(K) =',(BQR1Z(K),K=1,NCEL)
C      WRITE(NWRITE,*) 'BQR2Z(K) =',(BQR2Z(K),K=1,NCEL)
      WRITE(NWRITE,125) (AKF(K),K=1,NCEL)
C      WRITE(NWRITE,121) (ENF(K),K=1,NCEL)
C      WRITE(NWRITE,120) (EEF(K),K=1,NCEL)
C      WRITE(NWRITE,126) (SG(K),K=1,NCEL)
C      WRITE(NWRITE,118) (DSGXE(K),K=1,NCEL)
C      WRITE(NWRITE,122) (D(K),K=1,NCEL)
C      WRITE(NWRITE,128)(AKFCEL(K),K=1,NCEL)
C      WRITE(NWRITE,141) (SIGXE(K),K=1,NCEL)
      IF(REAT.GE..5) STOP ' REATTIVITA'' MAGGIORE DI 0.5 '
      IF(IBWR.EQ.0) GO TO 710
      IF(NKK.EQ.1) GO TO 800
      ABRE=ABS(REAT)
      IF(ABRE.LE..0001) GO TO 800
      IF(NK1.EQ.1.AND.NK2.EQ.1) GO TO 806
      NKZ=2
      GO TO 801
  806 ABRE1=ABS(REAT1)
      IF(ABRE1-ABRE)808,800,800
  808 NST=NS1
      REAT=REAT1
      NKK=1
      GO TO 802
  710 CONTINUE
C
  800 CONTINUE
C      WRITE(NWRITE,812)                                                
  812 FORMAT(/5X,'VALORI DI CONVERGENZA :',/)
C                                                                       
C     CALCOLO DELLA 'FUNZIONE AMPIEZZA' INIZIALE
C
      TT=0.
      DO 88 K=1,NCEL                                                    
      PHEFIK=PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K)
   88 TT=TT+PHEFIK*ALT(K)*DEPZ*1.E+04
      T=POTFIS/(TT*CANN)
      DO 89 J=1,NCEL                                                    
      PHS(J)=PH(J)
      PHSV(J)=PHS(J)
      PHR1V(J)=PHR1(J)
      PHR2V(J)=PHR2(J)
      PHV(J)=PH(J)
      XEV(J)=XE(J)
   89 BQV(J)=BQ(J)
      TVS=T
      TIMEV=0.
      TIMEVS=TIMEV
C      WRITE(NWRITE,809) REAT
  809 FORMAT(5X,'REATTIVITA'' DI CONVERGENZA',2X,G12.5)
C      WRITE(NWRITE,807) NST
  807 FORMAT(/5X,'STEP DI CONVERGENZA NUMERO',2X,I2/)
      IF(IBWR.EQ.0) GO TO 8092                                          
C      WRITE(NWRITE,700) (ALBA(K),K=1,NG)
      GO TO 8094                                                        
 8092 DO 8093 K=1,NG
      PALBA(K)=ALCAN*100.-ALBA(K)
      IF(PALBA(K).LE.0.0) PALBA(K)=0.0                                  
 8093 CONTINUE
      WRITE(NWRITE,700) (PALBA(K),K=1,NG)
      IF(ILEGO.EQ.1) WRITE(NWRITE,755) (BINSER(K),K=1,NG)
      IF(ILEGO.EQ.2) WRITE(NWRITE,955) (BINSER(K),K=1,NG)
 8094 CONTINUE
      WRITE(NWRITE,621) BO
C
C-----------------------------------------------------------------------
      DO 31 K=1,NCEL
      ASS1(K)=ASS1(K)*RES1(K)
      ASS2(K)=ASS2(K)*RES2(K)
   31 SG(K)=SG(K)*RES(K)
C-----------------------------------------------------------------------
C      WRITE(NWRITE,125)(AKF(K),K=1,NCEL)
C      WRITE(NWRITE,127)(SG(K),K=1,NCEL)
      WRITE(NWRITE,1127)(ASS1(K),K=1,NCEL)
      WRITE(NWRITE,2127)(ASS2(K),K=1,NCEL)
C      WRITE(NWRITE,120)(EEF(K),K=1,NCEL)
C      WRITE(NWRITE,121)(ENF(K),K=1,NCEL)
C      WRITE(NWRITE,122)(D(K),K=1,NCEL)
C      WRITE(NWRITE,101)(PH(K),K=1,NCEL)
C      WRITE(NWRITE,107)(BQ(K),K=1,NCEL)
      AVEL=1./VEL
      WRITE(NWRITE,158) AVEL
C      WRITE(NWRITE,159) ((AL(J,K),J=1,NRIT),K=1,NCEL)
C      WRITE(NWRITE,160) ((BE(J,K),J=1,NRIT),K=1,NCEL)
  118 FORMAT(/20X,'DELTA SIGMA ASSORBIMENTO DA XENO'/(6G16.7))
  120 FORMAT(/20X,'E * SIGMA FISSIONE'/(6E16.7))
  121 FORMAT(/20X,'NU * SIGMA FISSIONE'/(6G16.7))                       
  122 FORMAT(/20X,'COEFFICIENTI DIFFUSIONE'/(6G16.7))
  106 FORMAT(/20X,'RESTI'/(6G16.7))                                     
  124 FORMAT(/5X,'REATTIVITA'' CALCOLATA =',F10.5)
 1124 FORMAT(/5X,'REATTIVITA'' A 2G CALCOLATA =',F10.5)                 
  116 FORMAT(/5X,'REATTIVITA'' CORRETTA CON RESTI =',F10.5)
 1116 FORMAT(/5X,'REATTIVITA'' A 2G CORRETTA CON RESTI =',F10.5)
  100 FORMAT(/20X,'CONCENTRAZIONI DI RITARDATI'/(6E16.7))
  101 FORMAT(/20X,'FLUSSI MEDI DI CELLA'/(6E16.7))
  107 FORMAT(/20X,'BUCKLING'/(6G16.7))
 1107 FORMAT(/20X,'BUCKLING VELOCI'/(6G16.7))
 2107 FORMAT(/20X,'BUCKLING TERMICI'/(6G16.7))
  702 FORMAT(/20X,'EFFICIENZA DI CELLA PER ZONE'/)
  703 FORMAT(/10X,'CELLA',2X,I2,5X,5G12.5)
  708 FORMAT(/20X,'FORMA DI FLUSSO A 1G'/(8G12.5))
 1708 FORMAT(/20X,'FORMA DI FLUSSO VELOCE'/(8G12.5))
 2708 FORMAT(/20X,'FORMA DI FLUSSO TERMICO'/(8G12.5))
  709 FORMAT(/5X,'FUNZIONE AMPIEZZA =',G12.5)
  700 FORMAT(/20X,'ALTEZZA BARRE'/(8G12.5))
  621 FORMAT(/5X,'CONCENTRAZIONE DI BORO (PPM) =',G12.5)
  755 FORMAT(/20X,'ESTRAZIONE BARRE (IN PASSI - MODE A)'/(8G12.5))
  955 FORMAT(/20X,'ESTRAZIONE BARRE (IN PASSI - MODE GRIS)'/(8G12.5))
  126 FORMAT(/20X,'SIGMA ASSORBIMENTO TOTALE'/(6G16.7))
  127 FORMAT(/20X,'SIGMA ASSORBIMENTO MODIFICATE CON RESTI'/(6G16.7))
 1127 FORMAT(/20X,'SIGMA ASSORBIMENTO VELOCI MODIFICATE CON RESTI',
     &       /(6G16.7))
 2127 FORMAT(/20X,'SIGMA ASSORBIMENTO TERMICHE MODIFICATE CON RESTI',
     &       /(6G16.7))
  128 FORMAT(/20X,'COST. MOLTIPLIC. INFINITA TERMICA'/(6G16.7))         
  125 FORMAT(/20X,'COST. MOLTIPLIC. INFINITA'/(6G16.7))
  141 FORMAT(/20X,'SIGMA ASSORBIMENTO XENO'/(6G16.7))                   
  158 FORMAT(/5X,'VELOCITA'' NEUTRONICA MEDIA =',G12.5)
  159 FORMAT(/20X,'COSTANTI DI DECADIMENTO',/,(6G12.5))                 
  160 FORMAT(/20X,'FRAZIONI DI RITARDATI',/,(6G12.5))
C
      CALL REA2G(NCM,FSOT,ALT)                                          
      WRITE(NWRITE,1116) REAT
C
      WRITE(NWRITE,709) T
      WRITE(NWRITE,708) (PHS(K),K=1,NCEL)
      WRITE(99,4454) TIMEV,T,REAT,IT
      WRITE(6,4454) TIMEV,T,REAT,IT
 4454 FORMAT(/,1X,'TIME =',G12.5,3X,'AMPIEZZA  T =',G12.5,3X,
     &       'REAT =',G13.7,3X,'IT =',I2)
C---- CALCOLO DEL TEMPO MEDIO DI GENERAZIONE DEI NEUTRONI PRONTI A 2G
      ALBIG=0.
      DO 1432 K=1,NCEL
      PHH2=(PHR1(K)+PHR2(K))*ALT(K)
      ALBIG=ALBIG+VEL*PHH2
 1432 CONTINUE
      ALBIG=ALBIG*FSOT
C---- CALCOLO CONCENTRAZIONI MEDIE DEI PRECURSORI DI RITARDATI A 2G
      DO 2433 K=1,NCEL
      DO 2433 J=1,NRIT                                                  
      PHENFK=ENFIS1(K)*PHR1(K)+ENFIS2(K)*PHR2(K)
      C(J,K)=BE(J,K)*PHENFK*T/AL(J,K)
      CV(J,K)=C(J,K)
      CVV(J,K)=C(J,K)                                                   
 2433 CONTINUE
      WRITE(NWRITE,100) ((C(J,K),J=1,NRIT),K=1,NCEL)                    
C
      CALL MED2G(NRITM,FSOT,CM,HBE,BEM,ALT,C,BE,AL,ALM)                 
C
      CALL PREV1R                                                       
C
      DO 8888  K=1,NRIT
      HBEV(K)=HBE(K)
 8888 HBEK(K)=HBE(K)                                                    
      HREATV=HREAT
      HREATK=HREAT
      HBEMV=HBEM
      HBEMK=HBEM
      PSER=0.
      CSER=0.
      DO 8000 K=1,NRIT
 8000 CSER=CSER+CM(K)*ALM(K)
      C1=CSER/ALUNO
      DO 8001 K=1,NCEL
 8001 PSER=PSER+PH(K)*CL(K)
      PHPR=PSER/ALCAN
      ALUNOV=ALUNO
C      DO 70 J=1,NRIT
C      WRITE(NWRITE,138) J,CM(J),BEM(J),ALM(J)
C   70 CONTINUE
  138 FORMAT(5X,'GRUPPO RITARDATI NUM.=',I2,2X,'CONC=',E16.7,2X,
     &      'FRAZ. RIT.=',E16.7,2X,'COST. DEC.=',E16.7)
C
C     CALCOLO DEL FLUSSO NEUTRONICO STAZIONARIO RELATIVO AD UN DATO PROF
C     TERMOIDRAULICO (PER UNA FISSATA POSIZIONE DELLE BARRE E PER LA
C     CORRENTE CONCENTRAZIONE DI BORO NEL CIRCUITO PRIMARIO).
C     TALE CALCOLO DI FORMA NON VA EFFETUATO NEL CASO DI PERTURBAZIONI
C     PER LA DETERMINAZIONE DELLO JACOBIANO (IFUN=3) RICHESTO DA 'LEGO'.
C
      IF (IFUN.EQ.3) GO TO 300
      CALL FORMA2(BE,ZDG,ALT,TN,SER,AL,C,DERT,NRITM,
     &                  EPSR,NCM,FNORM1,DEN,EPSNOR,IMOT)
C
C     CALCOLO DEI FLUSSI VELOCE E TERMICO (LA CUI SOMMA E' IL FLUSSO
C     TOTALE) E RINORMALIZZAZIONE DELLE FORME DI FLUSSO E DI POTENZA
C     RELATIVE ALLA ITERAZIONE CORRENTE
      BNOR=0.
      DO 631 K=1,NCEL
      RFIS21(K)=PHR2(K)/PHR1(K)
      RFI21V(K)=RFIS21(K)
      C2RF(K)=0.0
  631 BNOR=BNOR+(PHR1(K)+PHR2(K))*ALT(K)
      WRITE(NWRITE,290) (RFIS21(K),K=1,NCEL)
C      WRITE(NWRITE,1708) (PHR1(K),K=1,NCEL)
C      WRITE(NWRITE,2708) (PHR2(K),K=1,NCEL)
  290 FORMAT(/,10X,'RAPPORTO SPETTRALE DIRETTO ',/,8(1X,G12.5))
      DO 632 K=1,NCEL
      PHR1(K)=PHR1(K)*ALCAN*100./BNOR
      PHR2(K)=PHR2(K)*ALCAN*100./BNOR
  632 PH(K)=PHR1(K)+PHR2(K)
  300 CONTINUE
      ZNOR=0.
      DO 434 K=1,NCEL
      PROFLU(K)=PHR1(K)*EEFIS1(K)+PHR2(K)*EEFIS2(K)
      ZNOR=ZNOR+PROFLU(K)*ALT(K)
  434 CONTINUE
      DO 435 K=1,NCEL
      PROFLU(K)=PROFLU(K)*ALCAN*100./ZNOR
  435 CONTINUE
C      WRITE(NWRITE,709) T
      WRITE(NWRITE,439) (PROFLU(K),K=1,NCEL)
  439 FORMAT(10X,'PROFILO DI POTENZA ASSIALE'/(8G12.5))
      WRITE(NWRITE,1708) (PHR1(K),K=1,NCEL)
      WRITE(NWRITE,2708) (PHR2(K),K=1,NCEL)
      WRITE(NWRITE,508) (PH(K),K=1,NCEL)
  508 FORMAT(/20X,'FORMA DI FLUSSO A 1G (PH=PHR1+PHR2)'/(8G12.5))
C
      GO TO 902
C
  910 CONTINUE
      WRITE(NWRITE,901)
  901 FORMAT(/5X,'NUMERO STEP OLTRE IL MASSIMO'/)
      STOP ' NUMERO DI STEP OLTRE IL MASSIMO (SUBROUTINE DINAMO) '
  911 CONTINUE
      WRITE(NWRITE,912)
  912 FORMAT(/5X,'NUMERO STEP MINORE DI UNO'/)
      STOP ' NUMERO DI STEP MINORE DI UNO (SUBROUTINE DINAMO) '
C
  902 RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PREV1R
C-----------------------------------------------------------------------
C     CALCOLA I PARAMETRI NECESSARI ALLA ESTRAPOLAZIONE DELLA FUNZIONE
C     AMPIEZZA IN FASE DI PREVISIONE AD UN GRUPPO MEDIO DI RITARDATI
C-----------------------------------------------------------------------
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      COMMON/N0000$/C1,APRE,BPRE,AX1,AX2,DAPRE,PHPR,HC,HA,HC1,HC2
     &             ,DUMMI16(NW-11)
      COMMON/DATI5$/ALBIG,BEMTOT,ALUNO,ALUNOV,DUMMI18(NW-4)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1              RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
C
      REATV=REAT
      APRE=.5*(ALUNO*ALBIG+BEMTOT-REATV)/ALBIG
      BPRE=.5*SQRT(ALBIG*ALUNO*(ALBIG*ALUNO+4.*REATV)+(BEMTOT-REATV)*
     &     (2.*ALUNO*ALBIG+(BEMTOT-REATV)))/ALBIG
      DAPRE=ALUNO*REATV/(ALBIG*(APRE+BPRE))
      AX1=BEMTOT/(ALBIG*(ALUNO+DAPRE))
      AX2=BEMTOT/(ALBIG*(ALUNO-APRE-BPRE))
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE PREPA1
C-----------------------------------------------------------------------
C     ENREGISTRE SUR LES UNITES 33 ET 34 (ENEL) 33 , 34  ET 12 (SEPTEN)
C     LES PROFILS DE FLUX RAPIDE ET TERMIQUE LORSQUE SON INTEGRALE
C     DIFFERE DE PLUS DE 10% DE LA VALEUR PRECEDENTE
C-----------------------------------------------------------------------
C
C----  Parametri per il dimensionamento massimo di vettori e matrici
C
C      NCTIA = Numero massimo di Celle TermoIdrauliche Assiali
C      NCNTA = Numero massimo di Celle Neutroniche per cella Termoidraulica Assiale
C      NCNT  = Numero massimo di Celle Neutroniche Totali
C      NBBC  = Numero massimo di Banchi di Barre di Controllo
C
      PARAMETER (NCTIA=8,NCNTA=3,NCNT=NCTIA*NCNTA)
      PARAMETER (NBBC=10)
C
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1    ,
     &           KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 ,
     &           KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      LOGICAL LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI
      COMMON/LEND$/LEND,LREGIM,LFORMA,LSTAZ,LIQS3,LDUMMI(NW-5)
      COMMON/KINA03/WTOTC,WNEUTC,REATC,WCELC(NCNT),AXOFFC
      COMMON/DUEG/VEL1,VEL2,DIF1(60),DIF2(60),FIS1(60),FIS2(60),
     &            ASS1(60),ASS2(60),RIM1(60),AKINF(60),ENFIS1(60),
     &            ENFIS2(60),EEFIS1(60),EEFIS2(60),BQZ1(60),BQZ2(60),
     &            BQR1Z(60),BQR2Z(60),PHR1(60),PHR2(60),RES1(60),
     &            RES2(60),RFI21V(60),C2RF(60),PHR1V(60),PHR2V(60)
      COMMON/PARIF/ ROH2OI,ROH2OU,ROILIB,ROULIB,ALEX11,ALEX21,ALEX1N,
     &ALEX2N,D11,D21,D1N,D2N,PHR11,PHR1N,PHR21,PHR2N
     &              ,DUMMI61(NW-16)
      COMMON /MATRIF/FT$(8),AP$(8),GT$(8),FT1$(8),F01$(8),G01$(8),
     &               GT1$(8),AP4$(8),AP5$(8),SS$(8),DD$(8),RM$(8),QQ(8),
     &               TTINF(4),TTSUP(4),PM1$(8),RG$(8),VG$(8),OMR$(8),
     &               DC$(8),RN$(8)
      COMMON /TWOGRP/TT(2),QK1(2),QK2(2),CHI1(60),CHI2(60),W1(60),
     &               W2(60),G1(60),G2(60),OMES1(60),OMES2(60),OMED1(60),
     &               OMED2(60),FLUV1(60),FLUV2(60),S1(60)
      COMMON/NEUT1$/S(  KAXS  ),DUMMI30(MAXSM-KAXS)
      COMMON/INPAR$/NC1M,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,NNXM,NNYM,
     &              NTTJM,NITJM,NLIBM,NPROFM,NKINM,NCELM,MAXS,KDIM,NCM
      COMMON/INTER$/NC1,NCTC,NUZO,NSTRA,NRIT,NCOS,NNX,NNY,NG,NS,ISB,
     $             NTTJ,NST,NPD,IBWR,NTIP,NKIN,NLIB,NPROF,NCOE,NCELT
     &              ,NDUMMI(NW-21)
      COMMON/INDIR$/IPHS,D,HBE,PHSV,HBEV,HBEK,C2,ENFV,CV,ENFVV,CVV,PHP,
     $        TEMV,DV,ALMV,CMV,SERFIV,BQ1,BQV,BQV1,BQP,C2BQ,HAKF,WESTV,
     *        WESTD,WESTS,H,RO,CSP,GIN,WTRA,DUMMI0(NW-31)
      COMMON/INDR1$/IALT,BEM,AL,     WW,XE,VIO,PM,SM,HEL,
     $               PHT,WGAMC,WTILD,ATILD,GINV,XEV,VIOV,
     *               TREF,ALBAS,WMED,CORD,NBAR,HALBA,HBORO,ALBA
     &              ,DUMMI1(NW-24)
      COMMON/INDR3$/IPROFL,CL,DUMMI3(NW-2)
      COMMON/HIGH$/ALTOT,ALATT,DUMMI8(NW-2)
      COMMON/DTIME$/DTPSI,TIMEV,TIMEVS,T,TVS,DTPSI2,DUMMI9(NW-6)
      COMMON/REAL3$/CANN,RGAM,WSCRAM,CLTOT,ALCAN,BQR,EPS1,RIAL,
     1          RIBA,ANOC,REAT,ENER,CF,WES,TST,ENERV,TPAS,ANOCP
     &             ,DUMMI20(NW-18)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
      COMMON/TAPE$/ NREAD,NWRITE,NDUMMI1(NW-2)
      CHARACTER TITOLO*80
      COMMON/TIIQS$/TITOLO
C
C      NGRANZ=NC1M+1
      NGRANZ=NC1
      IFILZ1=33
      IFILZ2=34
C---- DEFINIZIONE DEI COEFFICIENTI DI RIFLESSIONE SUPERIORE ED INFERIORE
      RIAL1=QQ(5)
      RIAL2=TT(2)/D2N
      RIBA1=QQ(1)
      RIBA2=TT(1)/D21
C      WRITE(NWRITE,*) ' COEFFICIENTI DI RIFLESSIONE '
C      WRITE(NWRITE,*) ' RIAL1=',RIAL1,'  RIBA1=',RIBA1
C      WRITE(NWRITE,*) ' RIAL2=',RIAL2,'  RIBA2=',RIBA2
C
C     OPEN(UNIT=IFILZ1,FILE='KINGRAZ1',STATUS='UNKNOWN',
C    &     FORM='UNFORMATTED')
C     OPEN(UNIT=IFILZ2,FILE='KINGRAZ2',STATUS='UNKNOWN',
C    &     FORM='UNFORMATTED')
C
      REWIND IFILZ1
      REWIND IFILZ2
C
      WRITE(IFILZ1) TITOLO
      WRITE(IFILZ2) TITOLO
C
      WRITE(IFILZ1) NGRANZ
      WRITE(IFILZ2) NGRANZ
C    REGISTRAZIONE DELL'ALTEZZA PERCENTUALE DELLE CELLE --> ALT(J)/ALATT
C    E DEI COEFFICIENTI DI RIFLESSIONE SUP. ED INF. RIAL1,2 E RIBA1,2
C      WRITE(74,'(8G12.5)') (S(IS)/ALATT,IS=IALT,IALT+NC1-1)
C      WRITE(74,'(8G12.5)') RIAL/ALATT , RIBA/ALATT
      WRITE(IFILZ1) (S(IS)/ALATT,IS=IALT,IALT+NC1-1)
      WRITE(IFILZ1) RIAL1/ALATT , RIBA1/ALATT
      WRITE(IFILZ2) (S(IS)/ALATT,IS=IALT,IALT+NC1-1)
      WRITE(IFILZ2) RIAL2/ALATT , RIBA2/ALATT
C
      IF(.NOT.LSTAZ) RETURN
C
      ENTRY PREPA2
C     REGISTRAZIONE DEI PROFILI ASSIALI DI FORMA DI FLUSSO VELOCE E
C     TERMICO --> PHR1(J) , PHR2(J)
      WRITE(IFILZ1) TIMEV,(PHR1(K),K=1,NGRANZ)
      WRITE(IFILZ2) TIMEV,(PHR2(K),K=1,NGRANZ)
C      WRITE(74,'(9G12.5)') TIMEV,(S(IS),IS=IPHS,IPHS+NGRANZ-1)
C
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
      SUBROUTINE KIQSWR(KWR,IQSWR)
C
C-----------------------------------------------------------------------
C     PREDIMENSIONA (SE KWR=0) LA MEMORIA DEDICATA AI COMMON DI 'STRIQS'
C     SCRIVE (SE KWR=1) O LEGGE (SE KWR=2) SUL FILE 'IQSWR' IL CONTENUTO
C     DI TUTTI I COMMON UTILIZZATI DA 'STRIQS' PER IL CALCOLO DI CINETIC
C-----------------------------------------------------------------------
C
C
      PARAMETER ( NW = 100 , MAXSM = 250000 ,NREC=MAXSM/100)
C
      PARAMETER (KCELTM = 12 ,
     &           KUZOM  =  3 ,
     &           KRITM  =  6 ,
     &           KPDM   = 11 ,
     &           KGM    =  6 ,
     &           KSM    =  1 ,
     &           KSTRAM =  1 ,
     &           KNXM   = 15 ,
     &           KNYM   = 15 ,
     &           KTTJM  = 200,
     &           KITJM  = 80 ,
     &           KLIBM  =  7 ,
     &           KPROFM = 20 ,
     &           KKINM  =  3)
C
      PARAMETER (KCOE   =  6)
C
      PARAMETER (KCELM  = KKINM * KCELTM ,
     &           KCM    = KCELM + 1 )
C
C---                    KCELM  = 3*12 = 36
C---                    KCM    = 36+1 = 37
C
      PARAMETER (KAXS= 78*KCM + 9*KGM + KGM*KUZOM + KCM*KUZOM +
     &           3*KUZOM + 14*KRITM + 5*KRITM*KCM + 2*KTTJM +
     &           2*KITJM*KCM + KPDM*KCM + KPDM + KITJM*KGM +
     &           KITJM + 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM +
     &           2*KLIBM*KCM*KRITM + 6*KPROFM*KCM + KPROFM*KGM + 1 )
C
      PARAMETER (KLIB= 6*KLIBM*KCM*KCOE + KLIBM + 2*KLIBM*KCM*KRITM
     &           + 2*KLIBM*KCM + 6*KPROFM*KCM + KPROFM*KGM)
C
      INTEGER WINTER,WJSTXX,WTAPE,WFILES,WINDIR,WINDR1,WINDR2,
     &        WINDR3,WINDR5
C
      LOGICAL LVET
C
      COMMON/INPAR$/NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,NNXM,NNYM,
     &              NTTJM,NITJM,NLIBM,NPROFM,NKINM,NCELM,MAXS,KDIM,NCM
C
      COMMON/LEND$/LVET(NW)
C
      COMMON/NEUT1$/S( MAXSM )
      COMMON/NAS$$/NAS( NW )
      COMMON/BARRE$/VBAR,BINSER( NW )
      COMMON/COREA$/WCOREA(NW)
      COMMON/PRODE$/WPRODE(5*NW)
      COMMON/RIFLE$/WRIFLE(NW)
      COMMON/NUCL$/OM(2,NW)
      COMMON/SOS$/WSOS(NW*NW)
      COMMON/TABLKINA/KE(60),IE(60),DDSEP(30*66*60),DDREF(6*60),
     &                NACT(60)
      COMMON/LIBSEP/WLIB(69*60+5),NCELRF,BQE2(60),RFIS21(60)
      COMMON/DUEG/VEL1,VEL2,VDUEG(24*60)
      COMMON/ACSOIR/WSOIR(NW)
      COMMON/DONNEE/WDON(NW)
      COMMON/PARIF/ WPARIF(NW)
      COMMON/CLAPLA/NBUC,WCLAP(152)
C
      COMMON/INTER$/WINTER(NW)
C
      CHARACTER TITOLO*80 , SELSTA*12
      COMMON/PRINT$/SELSTA
      COMMON/TIIQS$/TITOLO
      COMMON/JSTAX$/WJSTXX(NW)
      COMMON/REG22$/WREG22(20*NW)
C
      COMMON/TAPE$/WTAPE(NW)
      COMMON/FILES$/WFILES(NW)
C
      COMMON/INDIR$/WINDIR(NW)
      COMMON/INDR1$/WINDR1(NW)
      COMMON/INDR2$/WINDR2(NW)
      COMMON/INDR3$/WINDR3(NW)
      COMMON/INDR5$/WINDR5(NW)
C
      COMMON/PASSA$/IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      COMMON/VATE$/WVATE(NW)
      COMMON/BOR$/WBOR(NW)
      COMMON/LEGO$$/WNOM,W,TEMFIN,IPPREP,NPAS
C
      COMMON/REAL1$/WREAL1(NW)
      COMMON/REAL2$/WREAL2(NW)
      COMMON/REAL3$/WREAL3(NW)
      COMMON/REAL4$/WREAL4(NW)
      COMMON/DATI5$/WDATI5(NW)
      COMMON/REAL6$/WREAL6(NW)
      COMMON/N0000$/WN0000(NW)
C
      COMMON/PADKR$/WPADKR(NW)
      COMMON/PKIN$/WPKIN(NW)
      COMMON/DANU0$/WDANU0(NW)
      COMMON /DANUC$/WDANUC(NW)
      COMMON /ZEKIN$/WZEKIN(NW)
C
      COMMON/PROVV$/EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
      COMMON/TRATE$/WTRATE(NW)
      COMMON/DTIME$/WDTIME(NW)
C
      COMMON/HIGH$/WHIGH(NW)
      COMMON/TARGE$/WTARGE(NW)
      COMMON/RIFLA$/WRIFLA(NW)
C
      COMMON/CCONST/WCONST(NW)
      COMMON/CFIC10/IFIC10,I10
      COMMON/CEFGRA/IGRAP,IM,COTB(155),IP,CG0,ROIA,KINI,PPA,SKIN
      COMMON/CGEOME/NT,HZ(60),EZ(60),HMINC,HMAXC,IMIN,IMAX,L1,PL1
      COMMON/DBARRE/NBU,WBARR(16*50),ALF2,ALFR,ALFF1,ALFF2
      COMMON/CGRAPP/NGRA,NOG(15),WGRAP(15*15+4)
      COMMON/ZREF/IINF,ISUP,LL1,PLL1
      COMMON/CBARRE/ZMIN,APAS,AMPAS,NGB,AREC(4)
      COMMON/CSERVE/BIDO,SAXE1,SAXE2
C
      NCELTM = KCELTM
      NUZOM = KUZOM
      NRITM = KRITM
      NPDM = KPDM
      NGM = KGM
      NSM = KSM
      NSTRAM = KSTRAM
      NNXM = KNXM
      NNYM = KNYM
      NTTJM = KTTJM
      NITJM = KITJM
      NLIBM = KLIBM
      NPROFM = KPROFM
      NKINM = KKINM
      NCELM = KCELM
      MAXS = KAXS
      KDIM = KLIB
      NCM = KCM
C
      NCOE = KCOE
C
      KKWR=KWR+1
C
      GO TO (100,200,300),KKWR
C
  100 CONTINUE
C
C     PREDIMENSIONAMENTO A VALORI MASSIMI DI SICUREZZA DELL'AREA DI
C     MEMORIA A DISPOSIZIONE DEI COMMON LABELLATI DI 'STRIQS'
C
      RETURN
  200 CONTINUE
C
C     SCRITTURA DELLE VARIABILI IN COMMON DI 'STRIQS'
C
      REWIND IQSWR
C
      WRITE(IQSWR)  NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,
     &              NNXM,NNYM,NTTJM,NITJM,NLIBM,NPROFM,
     &              NKINM,NCELM,MAXS,KDIM,NCM
      WRITE(IQSWR) LVET
C
      DO 10 I=1,NREC
      WRITE(IQSWR) (S(J),J=100*(I-1)+1,100*I)
   10 CONTINUE
      WRITE(IQSWR) (NAS(I),I=1,NUZOM)
      WRITE(IQSWR) VBAR,(BINSER(I),I=1,NGM)
      WRITE(IQSWR) WCOREA
      WRITE(IQSWR) WPRODE
      WRITE(IQSWR) WRIFLE
      WRITE(IQSWR) ((OM(I,J),J=1,NCM),I=1,2)
      DO 20 I=1,NW
      WRITE(IQSWR) (WSOS(J),J=NW*(I-1)+1,NW*I)
   20 CONTINUE
      WRITE(IQSWR) WSOIR
      WRITE(IQSWR) WDON
      WRITE(IQSWR) WPARIF
      WRITE(IQSWR) KE,IE
      DO 52 I=1,1980
   52 WRITE(IQSWR)(DDSEP(J),J=60*(I-1)+1,60*I)
      DO 53 I=1,6
   53 WRITE(IQSWR)(DDREF(J),J=60*(I-1)+1,60*I)
      WRITE(IQSWR) NACT
      DO 26 I=1,69
      WRITE(IQSWR) (WLIB(J),J=60*(I-1)+1,60*I)
   26 CONTINUE
      WRITE(IQSWR) (WLIB(69*60+I),I=1,5),NCELRF,BQE2,RFIS21
      WRITE(IQSWR) NBUC
      DO 229 I=1,3
  229 WRITE(IQSWR)(WCLAP(J),J=50*(I-1)+1,50*I)
      WRITE(IQSWR) WCLAP(151),WCLAP(152)
      WRITE(IQSWR) VEL1,VEL2
      DO 48 I=1,24
   48 WRITE(IQSWR) (VDUEG(J),J=60*(I-1)+1,60*I)
C
      WRITE(IQSWR) WINTER
C
      WRITE(IQSWR) SELSTA
      WRITE(IQSWR) TITOLO
      WRITE(IQSWR) WJSTXX
      WRITE(IQSWR) WREG22
C
      WRITE(IQSWR) WTAPE
      WRITE(IQSWR) WFILES
C
      WRITE(IQSWR) WINDIR
      WRITE(IQSWR) WINDR1
      WRITE(IQSWR) WINDR2
      WRITE(IQSWR) WINDR3
      WRITE(IQSWR) WINDR5
C
      WRITE(IQSWR) IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      WRITE(IQSWR) WVATE
      WRITE(IQSWR) WBOR
      WRITE(IQSWR) WNOM,W,TEMFIN,IPPREP,NPAS
C
      WRITE(IQSWR) WREAL1
      WRITE(IQSWR) WREAL2
      WRITE(IQSWR) WREAL3
      WRITE(IQSWR) WREAL4
      WRITE(IQSWR) WDATI5
      WRITE(IQSWR) WREAL6
      WRITE(IQSWR) WN0000
C
      WRITE(IQSWR) WPADKR
      WRITE(IQSWR) WPKIN
      WRITE(IQSWR) WDANU0
      WRITE(IQSWR) WDANUC
      WRITE(IQSWR) WZEKIN
C
      WRITE(IQSWR) EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
      WRITE(IQSWR) WTRATE
      WRITE(IQSWR) WDTIME
C
      WRITE(IQSWR) WHIGH
      WRITE(IQSWR) WTARGE
      WRITE(IQSWR) WRIFLA
      WRITE(IQSWR) WCONST
      WRITE(IQSWR) IFIC10,I10
      WRITE(IQSWR) IGRAP,IM
      DO 122 I=1,3
  122 WRITE(IQSWR) (COTB(J),J=50*(I-1)+1,50*I)
      WRITE(IQSWR) (COTB(J),J=151,155)
      WRITE(IQSWR) IP,IP,CG0,ROIA,KINI,PPA,SKIN
      WRITE(IQSWR) NT,HZ,EZ,HMINC,HMAXC,IMIN,IMAX,L1,PL1
      WRITE(IQSWR) NBU
      DO 123 I=1,16
  123 WRITE(IQSWR)(WBARR(J),J=50*(I-1)+1,50*I)
      WRITE(IQSWR) ALFA2,ALFR,ALFF1,ALFF2
      WRITE(IQSWR) NGRA,NOG
      DO 124 I=1,15
  124 WRITE(IQSWR)(WGRAP(J),J=15*(I-1)+1,15*I)
      WRITE(IQSWR)(WGRAP(15*15+I),I=1,4)
      WRITE(IQSWR) IINF,ISUP,LL1,PLL1
      WRITE(IQSWR) ZMIN,APAS,AMPAS,NGB,AREC
      WRITE(IQSWR) BIDO,SAXE1,SAXE2
C
      RETURN
C
  300 CONTINUE
C
C     LETTURA DELLE VARIABILI IN COMMON DI 'STRIQS'
C
      REWIND IQSWR
C
      IQSWR1=71
C      WRITE(IQSWR1,*) ' STAMPA DEI COMMON LETTI SULL''UNITA'' IQSWR '
    8 FORMAT(10I8)
    9 FORMAT(8G12.5)
C
      READ(IQSWR)   NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,
     &              NNXM,NNYM,NTTJM,NITJM,NLIBM,NPROFM,
     &              NKINM,NCELM,MAXS,KDIM,NCM
C      WRITE(IQSWR1,*) ' COMMON INPAR$ '
C     WRITE(IQSWR1,8)  NCELTM,NUZOM,NRITM,NPDM,NGM,NSM,NSTRAM,
C    &                NNXM,NNYM,NTTJM,NITJM,NLIBM,NPROFM,
C    &                NKINM,NCELM,MAXS,KDIM,NCM
      READ(IQSWR) LVET
C      WRITE(IQSWR1,*) ' COMMON LVET '
C      WRITE(IQSWR1,*) 'LVET=',LVET
C
      DO 30 I=1,NREC
      READ(IQSWR) (S(J),J=100*(I-1)+1,100*I)
   30 CONTINUE
C      WRITE(IQSWR1,*) ' COMMON/NEUT1$/S(1) '
C      WRITE(IQSWR1,9) (S(I),I=1,MAXS)
      READ(IQSWR) (NAS(I),I=1,NUZOM)
C      WRITE(IQSWR1,*) ' COMMON NAS '
C      WRITE(IQSWR1,8) (NAS(I),I=1,NUZOM)
      READ(IQSWR) VBAR,(BINSER(I),I=1,NGM)
C      WRITE(IQSWR1,*) ' COMMON BARRE '
C      WRITE(IQSWR1,9) VBAR,(BINSER(I),I=1,NGM)
      READ(IQSWR) WCOREA
C      WRITE(IQSWR1,*) ' COMMON CONREA '
C      WRITE(IQSWR1,9) WCOREA
      READ(IQSWR) WPRODE
C      WRITE(IQSWR1,*) ' COMMON PRODEC '
C      WRITE(IQSWR1,9) WPRODE
      READ(IQSWR) WRIFLE
C      WRITE(IQSWR1,*) ' COMMON RIFLE '
C      WRITE(IQSWR1,9) WRIFLE
      READ(IQSWR) ((OM(I,J),J=1,NCM),I=1,2)
C      WRITE(IQSWR1,*) ' COMMON OMEGA '
C      WRITE(IQSWR1,9) ((OM(I,J),J=1,NCM),I=1,2)
      DO 40 I=1,NW
      READ(IQSWR) (WSOS(J),J=NW*(I-1)+1,NW*I)
   40 CONTINUE
C      WRITE(IQSWR1,*) ' COMMON SOS '
C      WRITE(IQSWR1,9) WSOS
      READ(IQSWR) WSOIR
C      WRITE(IQSWR1,*) ' COMMON SOIR '
C      WRITE(IQSWR1,9) WSOIR
      READ(IQSWR) WDON
C      WRITE(IQSWR1,*) ' COMMON DON '
C      WRITE(IQSWR1,9) WDON
      READ(IQSWR) WPARIF
C      WRITE(IQSWR1,*) ' COMMON PARIF'
C      WRITE(IQSWR1,9) WPARIF
      READ(IQSWR) KE,IE
      DO 552 I=1,1980
  552 READ(IQSWR)(DDSEP(J),J=60*(I-1)+1,60*I)
      DO 553 I=1,6
  553 READ(IQSWR)(DDREF(J),J=60*(I-1)+1,60*I)
      READ(IQSWR) NACT
C      WRITE(IQSWR1,*) ' COMMON TABLKINA'
C      WRITE(IQSWR1,9) KE,IE
      DO 46 I=1,69
      READ(IQSWR) (WLIB(J),J=60*(I-1)+1,60*I)
   46 CONTINUE
      READ(IQSWR) (WLIB(69*60+I),I=1,5),NCELRF,BQE2,RFIS21
C      WRITE(IQSWR1,*) ' COMMON LIBSEP '
C      WRITE(IQSWR1,*) (WLIB(I),I=68*60+1,68*60+5),NCELRF
      READ(IQSWR) NBUC
      DO 329 I=1,3
  329 READ(IQSWR)(WCLAP(J),J=50*(I-1)+1,50*I)
      READ(IQSWR) WCLAP(151),WCLAP(152)
C      WRITE(IQSWR1,*) ' COMMON CLAP'
C      WRITE(IQSWR1,9) NBUC,WCLAP

      READ(IQSWR) VEL1,VEL2
C      WRITE(IQSWR1,*) ' COMMON DUEG '
C      WRITE(IQSWR1,*) VEL1,VEL2
      DO 448 I=1,24
      READ(IQSWR) (VDUEG(J),J=60*(I-1)+1,60*I)
C      WRITE(IQSWR1,9) (VDUEG(J),J=60*(I-1)+1,60*I)
  448 CONTINUE
      READ(IQSWR) WINTER
C      WRITE(IQSWR1,*) ' COMMON INTER '
C      WRITE(IQSWR1,*) WINTER
      READ(IQSWR) SELSTA
C      WRITE(IQSWR1,*) ' COMMON SELSTA '
C      WRITE(IQSWR1,'(A)') SELSTA
      READ(IQSWR) TITOLO
C      WRITE(IQSWR1,*) ' COMMON TITOLO '
C      WRITE(IQSWR1,'(A)') TITOLO
      READ(IQSWR) WJSTXX
C      WRITE(IQSWR1,*) ' COMMON JSTAXX '
C      WRITE(IQSWR1,*) WJSTXX
      READ(IQSWR) WREG22
C      WRITE(IQSWR1,*) ' COMMON REG22 '
C      WRITE(IQSWR1,9) WREG22
C
      READ(IQSWR) WTAPE
C      WRITE(IQSWR1,*) ' COMMON TAPE '
C      WRITE(IQSWR1,*) WTAPE
      READ(IQSWR) WFILES
C      WRITE(IQSWR1,*) ' COMMON FILES '
C      WRITE(IQSWR1,*) WFILES
C
      READ(IQSWR) WINDIR
C      WRITE(IQSWR1,*) ' COMMON INDIR '
C      WRITE(IQSWR1,*) WINDIR
      READ(IQSWR) WINDR1
C      WRITE(IQSWR1,*) ' COMMON INDIR1 '
C      WRITE(IQSWR1,*) WINDR1
      READ(IQSWR) WINDR2
C      WRITE(IQSWR1,*) ' COMMON INDIR2 '
C      WRITE(IQSWR1,*) WINDR2
      READ(IQSWR) WINDR3
C      WRITE(IQSWR1,*) ' COMMON INDIR3 '
C      WRITE(IQSWR1,*) WINDR3
      READ(IQSWR) WINDR5
C      WRITE(IQSWR1,*) ' COMMON INDIR5 '
C      WRITE(IQSWR1,*) WINDR5
C
C      READ(IQSWR) WPASSA
      READ(IQSWR) IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
C      WRITE(IQSWR1,*) ' COMMON PASSA '
C      WRITE(IQSWR1,*) IDKIN,JSTAMP,DTPSIM,BURM,ILEGO,IDUEG,IXENO
      READ(IQSWR) WVATE
C      WRITE(IQSWR1,*) ' COMMON VATE '
C      WRITE(IQSWR1,9) WVATE
      READ(IQSWR) WBOR
C      WRITE(IQSWR1,*) ' COMMON BORO '
C      WRITE(IQSWR1,*) WBOR
C      READ(IQSWR) WLEGO
      READ(IQSWR) WNOM,W,TEMFIN,IPPREP,NPAS
C      WRITE(IQSWR1,*) ' COMMON LEGO$ '
C      WRITE(IQSWR1,*) WNOM,W,TEMFIN,IPPREP,NPAS
C
      READ(IQSWR) WREAL1
C      WRITE(IQSWR1,*) ' COMMON REAL1 '
C      WRITE(IQSWR1,9) WREAL1
      READ(IQSWR) WREAL2
C      WRITE(IQSWR1,*) ' COMMON REAL2 '
C      WRITE(IQSWR1,9) WREAL2
      READ(IQSWR) WREAL3
C      WRITE(IQSWR1,*) ' COMMON REAL3 '
C      WRITE(IQSWR1,9) WREAL3
      READ(IQSWR) WREAL4
C      WRITE(IQSWR1,*) ' COMMON REAL4 '
C      WRITE(IQSWR1,9) WREAL4
      READ(IQSWR) WDATI5
C      WRITE(IQSWR1,*) ' COMMON REAL5 '
C      WRITE(IQSWR1,9) WDATI5
      READ(IQSWR) WREAL6
C      WRITE(IQSWR1,*) ' COMMON REAL6 '
C      WRITE(IQSWR1,9) WREAL6
      READ(IQSWR) WN0000
C      WRITE(IQSWR1,*) ' COMMON N0000 '
C      WRITE(IQSWR1,9) WN0000
C
      READ(IQSWR) WPADKR
C      WRITE(IQSWR1,*) ' COMMON PADEKR '
C      WRITE(IQSWR1,9) WPADKR
      READ(IQSWR) WPKIN
C      WRITE(IQSWR1,*) ' COMMON PERKIN'
C      WRITE(IQSWR1,9) WPKIN
      READ(IQSWR) WDANU0
C      WRITE(IQSWR1,*) ' COMMON DANUC0 '
C      WRITE(IQSWR1,9) WDANU0
      READ(IQSWR) WDANUC
C      WRITE(IQSWR1,*) ' COMMON DANUC '
C      WRITE(IQSWR1,9) WDANUC
      READ(IQSWR) WZEKIN
C      WRITE(IQSWR1,*) ' COMMON ZERKIN '
C      WRITE(IQSWR1,*) WZEKIN
C
C     READ(IQSWR) WPROVV
      READ(IQSWR) EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
C      WRITE(IQSWR1,*) ' COMMON PROVV '
C      WRITE(IQSWR1,*) EPSR,EPSNOR,EPSKF,TST1,IDOIN,JPLOT,IVELBR
      READ(IQSWR) WTRATE
C      WRITE(IQSWR1,*) ' COMMON TRATER '
C      WRITE(IQSWR1,9) WTRATE
      READ(IQSWR) WDTIME
C      WRITE(IQSWR1,*) ' COMMON DTIME '
C      WRITE(IQSWR1,9) WDTIME
C
      READ(IQSWR) WHIGH
C      WRITE(IQSWR1,*) ' COMMON HIGH '
C      WRITE(IQSWR1,9) WHIGH
      READ(IQSWR) WTARGE
C      WRITE(IQSWR1,*) ' COMMON TARGET '
C      WRITE(IQSWR1,9) WTARGE
      READ(IQSWR) WRIFLA
C      WRITE(IQSWR1,*) ' COMMON RIFLAS '
C      WRITE(IQSWR1,9) WRIFLA
C
      READ(IQSWR) WCONST
      READ(IQSWR) IFIC10,I10
      READ(IQSWR) IGRAP,IM
      DO 222 I=1,3
  222 READ(IQSWR) (COTB(J),J=50*(I-1)+1,50*I)
      READ(IQSWR) (COTB(J),J=151,155)
      READ(IQSWR) IP,IP,CG0,ROIA,KINI,PPA,SKIN
      READ(IQSWR) NT,HZ,EZ,HMINC,HMAXC,IMIN,IMAX,L1,PL1
      READ(IQSWR) NBU
      DO 223 I=1,16
  223 READ(IQSWR)(WBARR(J),J=50*(I-1)+1,50*I)
      READ(IQSWR) ALFA2,ALFR,ALFF1,ALFF2
      READ(IQSWR) NGRA,NOG
      DO 224 I=1,15
  224 READ(IQSWR)(WGRAP(J),J=15*(I-1)+1,15*I)
      READ(IQSWR)(WGRAP(15*15+I),I=1,4)
      READ(IQSWR) IINF,ISUP,LL1,PLL1
      READ(IQSWR) ZMIN,APAS,AMPAS,NGB,AREC
      READ(IQSWR) BIDO,SAXE1,SAXE2
      RETURN
      END
C
C**********************************************************************
C
C
C**********************************************************************
C
