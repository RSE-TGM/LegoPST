C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
C----------------------------------------------------------------------------
C
C     VERSIONE DI "DRIS" MODIFICATA DA L. POLLACHINI E S. SPELTA
C
C      
C      - le pressioni e le entalpie medie non sono piu' stati 
C        ma uscite algebriche (NSTATI=0)
C      - versione con moltiplicatore d'attrito di MARTINELLI-NELSON   
C        (controllato dal coefficiente IFIQLO=0/1)
C
C----------------------------------------------------------------------------
      SUBROUTINE DRISI3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/DRIS01/IBLOC
      COMMON/DRIS02/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'DRIS'/
C
      CALL DRISI4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 0
      NUSCIT= 4*NCEL+NPAR*NCEL
      NINGRE= NPAR*NCEL+5
C
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HM',I2,A4,2X,'--UA-- ENTALPIA MEDIA FLUIDO', 
     1' CELLA ',I2,' TUBO')
   20 CONTINUE
C
      DO 30 K=1,NCEL-1
      WRITE(IFO,3001)K,IOB,K
 3001 FORMAT('PU',I2,A4,2X,'--UA-- PRESSIONE FLUIDO', 
     1' USCITA CELLA ',I2,' TUBO')
   30 CONTINUE
      WRITE(IFO,3101)IOB
 3101 FORMAT('PUTU',A4,2X,'--UA-- PRESSIONE FLUIDO USCITA TUBO')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('WITU',A4,2X,'--UA-- PORTATA FLUIDO INGRESSO TUBO')
      DO 40 K=1,NCEL-1
      WRITE(IFO,3201)K,IOB,K
 3201 FORMAT('WI',I2,A4,2X,'--UA-- PORTATA FLUIDO', 
     1' INGRESSO CELLA ',I2,' TUBO')
   40 CONTINUE
C
      DO 50 K=1,NCEL
      WRITE(IFO,3003)K,IOB,K
 3003 FORMAT('Q1',I2,A4,2X,'--UA-- POTENZA SCAMBIATA', 
     1' PARETE 1 CELLA ',I2,' TUBO')
   50 CONTINUE
      IF(NPAR.EQ.1)GO TO 80
C
      DO 51 K=1,NCEL
      WRITE(IFO,3013)K,IOB,K
 3013 FORMAT('Q2',I2,A4,2X,'--UA-- POTENZA SCAMBIATA',
     1' PARETE 2 CELLA ',I2,' TUBO')
   51 CONTINUE
      IF(NPAR.EQ.2)GO TO 80
C
      DO 52 K=1,NCEL
      WRITE(IFO,3023)K,IOB,K
 3023 FORMAT('Q3',I2,A4,2X,'--UA-- POTENZA SCAMBIATA',
     1' PARETE 3 CELLA ',I2,' TUBO')
   52 CONTINUE
C
   80 CONTINUE
C
      DO 45 K=1,NCEL-1
      WRITE(IFO,3221)K,IOB,K
 3221 FORMAT('HU',I2,A4,2X,'--UA-- ENTALPIA TOTALE USCITA CELLA ', 
     1I2,' TUBO')
   45 CONTINUE
      WRITE(IFO,3004)IOB
 3004 FORMAT('HUTU',A4,2X,'--UA-- ENTALPIA TOTALE USCITA TUBO')
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HITU',A4,2X,'--IN-- ENTALPIA TOTALE INGRESSO TUBO')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('PITU',A4,2X,'--IN-- PRESSIONE FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WUTU',A4,2X,'--IN-- PORTATA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('HVAL',A4,2X,'--IN-- ENTALPIA FLUIDO USCITA TUBO',
     1' (INVERSIONE PORTATA)')
C
      DO 150 K=1,NCEL
      WRITE(IFO,4003)K,IOB,K
 4003 FORMAT('T1',I2,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA 1', 
     1' CELLA',I2,' TUBO')
  150 CONTINUE
      IF(NPAR.EQ.1)GO TO 180
C
      DO 151 K=1,NCEL
      WRITE(IFO,4013)K,IOB,K
 4013 FORMAT('T2',I2,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA 2',
     1' CELLA',I2,' TUBO')
  151 CONTINUE
      IF(NPAR.EQ.2)GO TO 180
C
      DO 152 K=1,NCEL
      WRITE(IFO,4023)K,IOB,K
 4023 FORMAT('T3',I2,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA 3',
     1' CELLA',I2,' TUBO')
  152 CONTINUE
C
  180 CONTINUE
      WRITE(IFO,3009)IOB
 3009 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO TUBO')
C
      RETURN
      END
      SUBROUTINE DRISI4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/DRIS01/IBLOC
      COMMON/DRIS02/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      MAX=8
C
    1 WRITE(6,1000)
 1000 FORMAT(//10X,'TUBAZIONE SENZA PARETE METALLICA CON SCAMBIO '//
     $ 10X,'NUMERO DI PARETI DI SCAMBIO PER OGNI CELLA (MAX = 3) ?')
      READ(5,*) NPAR
      IF(NPAR.GE.1.AND.NPAR.LE.3)GO TO 3
      WRITE(6,1004) NPAR
 1004 FORMAT(/10X,'ERRORE - N. PARETI =',I3)
      GO TO 1
    3 IF(NPAR.GT.1) MAX=5
      WRITE(6,1003) MAX
 1003 FORMAT(//10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.MAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
    5 CONTINUE
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
      SUBROUTINE DRISI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      DIMENSION TUBI(10),DIAI(10),HLU(10),DZE(10),CRIG(10)
      DIMENSION SUP(3,10),TAUQ(10)                                      
      CHARACTER*4 NT,ND,NL,NZ,NR,SP(3),PC                                  
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA PIGR/3.1415926/
      DATA NT/'NTUB'/,ND/'DIAI'/,NL/'LUNG'/,NZ/'DELZ'/,PC/'PACO'/        
      DATA NR/'CRIG'/,SP/'SUP1','SUP2','SUP3'/
C                                                                       
      NCEL=(NUSCIT-NINGRE+5)/4
      NPAR=(NUSCIT-4*NCEL)/NCEL                                              
C                                                                       
      NN0=IV1-1                                                         
      NN1=NN0+NCEL                                                    
      NN2=NN1+NCEL                                                  
      NN3=NN2+NCEL 
      NN4=NN3+NPAR*NCEL
      NEQ=NN4+NCEL                                          
C                                                                       
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C     
    1 WRITE(14,1011)PC                                                  
 1011 FORMAT(4X,A4,4X,' =',10X,'*')
      DO 5 I=1,NCEL                                                     
      WRITE(14,1002)I                                                   
      WRITE(14,1003) NT,I,ND,I,NL,I,NZ,I,NR,I,(SP(J),I,J=1,NPAR)        
    5 CONTINUE                                                          
 1001 FORMAT(4X,A4,I4,' =',10X,'*')
 1002 FORMAT('*   DATI DELLA CELLA ',I3,'*',55X)                        
 1003 FORMAT(3(4X,A4,I4,' =',10X,'*'),5X)                               
C                                                                       
      RETURN                                                            
C                                                                       
C-----LETTURA DEI DATI                                                  
C                                                                       
   10 READ(14,1004)                                                     
      READ(14,1004) PACO
C                                                                       
      DO 15 I=1,NCEL                                                    
        READ(14,1004)
        READ(14,1004) TUB ,DIAI(I),HLU(I),DZE(I),CRIG(I)
     $               ,(SUP(J,I),J=1,NPAR)
        TUBI(I)=TUB
        DO JS=1,NPAR
          IF (SUP(JS,I).LE.0.) THEN
            SUP(JS,I)=PIGR*DIAI(I)*HLU(I)*TUBI(I)
	  END IF
	END DO
   15 CONTINUE                                                          
C                                                                       
      DO 21 I=1,NCEL                                                    
      IF(TUBI(I).GT.0) GOTO 21                                          
      TUBI(I)=TUBI(I-1)                                                 
      DIAI(I)=DIAI(I-1)                                                 
      HLU(I)=HLU(I-1)                                                   
      DZE(I)=DZE(I-1)                                                   
      CRIG(I)=CRIG(I-1)
      DO 20 J=1,NPAR                                                    
      SUP(J,I)=SUP(J,I-1)                                               
   20 CONTINUE                                                          
   21 CONTINUE
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C                                                                       
      DATI(ID2)=NCEL                                                    
      DATI(ID2+1)=NPAR
C                                                                       
      DO 25 I=1,NCEL                                                    
       K=ID2+10*(I-1)+1                                                  
       S=PIGR*DIAI(I)*HLU(I)*TUBI(I)                                     
       V=S*DIAI(I)/4.                                                    
       A=V/HLU(I)                                                        
       TAUQ(I)=HLU(I)/A                                                  
       DATI(K+1)=V                                                       
       DATI(K+2)=HLU(I)                                                  
       DATI(K+3)=A                                                       
       DATI(K+4)=DIAI(I)                                                 
       DATI(K+5)=2.*HLU(I)/(DIAI(I)*A*A)                                 
       DATI(K+6)=DZE(I)*9.81                                             
       DATI(K+7)=CRIG(I)
       DATI(K+8)=SUP(1,I)                                                
       DATI(K+9)=SUP(2,I)                                                
       DATI(K+10)=SUP(3,I)                                               
   25 CONTINUE                                                          
C ULTIMO DATO GEOMETRICO MEMORIZZATO NEL VETTORE DATI  
      DATI(ID2+2+10*NCEL)=PACO                                          
C INCREMENTO DI ID2 DOPO MEMORIZZAZIONE DI TAU2H,TAU1H,TAU2P.TAU1P IN DRITAU
      ID2 = ID2+15*NCEL+1                                               
C INCREMENTO DI ID2 DOPO MEMORIZZAZIONE DI GAMMA(NPAR,NCEL) IN DRIRES
      ID2 = ID2+NPAR*NCEL+1                                            
C---- MEMORIZZAZIONE PRESSIONI ED ENTALPIE DEL PASSO DI TEMPO PRECEDENTE
       DO I=1,NCEL+1
       DATI(ID2+I)=0.
       ENDDO
       DO I=1,NCEL
       DATI(ID2+NCEL+1+I)=0.
       ENDDO
C INCREMENTO DI ID2 DOPO MEMORIZZAZIONE DELLE PRESSIONI E DELLE ENTALPIE 
      ID2 = ID2+2*NCEL+1
C---- MEMORIZZAZIONE DH , DR E RO ( TERMINI DI DRIFT )
       DO I=1,NCEL+1
       DATI(ID2+I)=0.
       DATI(ID2+NCEL+1+I)=0.
       DATI(ID2+2*NCEL+2+I)=0.
       ENDDO
C INCREMENTO DI ID2 PER DH , DR E RO 
      ID2 = ID2+3*NCEL+3
C---- MEMORIZZAZIONE DEL MOLTIPLICATORE D'ATTRITO DI MARTINELLI-NELSON 
       DO I=1,NCEL+1
       DATI(ID2+I)=1.
       ENDDO
C INCREMENTO DI ID2 DOPO MEMORIZZAZIONE DEL MOLTIPLICATORE FIQLO(NCEL+1)
      ID2 = ID2+NCEL+1
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
C---- USCITE
      DO 35 I=1,NCEL                                                    
       CNXYU(NN0+I)=H0                                                   
       CNXYU(NN1+I)=P0                                                   
       CNXYU(NN2+I)=W0                                                   
       CNXYU(NN4+I)=H0                                          
C                                                                       
       DO 35 J=1,NPAR                                                    
        CNXYU(NN3+(J-1)*NCEL+I)=W0*H0                                     
        CNXYU(NEQ+(J-1)*NCEL+4+I)=T0                                      
   35 CONTINUE                                                          
C                                                                      
C---- INGRESSI              
      CNXYU(NEQ+1)=H0                                                   
      CNXYU(NEQ+2)=P0                                                   
      CNXYU(NEQ+3)=W0                                                   
      CNXYU(NEQ+4)=H0                                                   
C                                                                       
      CNXYU(NEQ+NPAR*NCEL+5)=1.                                         
C                                                                       
C-----STAMPE                                                            
C                                                                       
      WRITE(6,3000)                                                     
C                                                                       
      DO 60 I=1,NCEL                                                    
      K=ID1+10*(I-1)+1                                                  
      V= DATI(K+1)                                                      
      H= DATI(K+2)                                                      
      A= DATI(K+3)                                                      
      D=DATI(K+4)                                                       
      C=DATI(K+6)/9.81                                                       
      WRITE(6,3001) I,V,H,A,D,C
   60 CONTINUE
C
      WRITE(6,3002)(J,J=1,NPAR)
C
      DO I=1,NCEL
        WRITE(6,3003) I,(SUP(J,I),J=1,NPAR)
      END DO
C
      WRITE(6,'(/)')
      IF(PACO.EQ.1)
     & WRITE(6,*) '   *****  DRIS  -  Correlazione di ZUBER_DIX  *****'
      IF(PACO.EQ.2)
     & WRITE(6,*) '   *****  DRIS  -  Correlazione di BANKOFF  *****'
      IF(PACO.EQ.3)
     & WRITE(6,*)'  ***  DRIS  -  Correlazione di CHEXAL_LELLOUCHE  ***'
      IF(PACO.EQ.4)
     & WRITE(6,*) '   ***  DRIS  -  Correlazione di ZUBER-ROUHANY  ***'
      IF(PACO.EQ.0)
     & WRITE(6,*) '   *****  DRIS  -  Modello Omogeneo  *****'
C
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3000 FORMAT(6X,'CELLA',4X,'VOLUME     LUNGHEZZA    SEZIONE     ',      
     $           'DIAM.INT.  DISLIVELLO'//)                             
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)
 3002 FORMAT(/,5X,'CELLA',2X, 3('SUPERFICIE INTERNA PARETE ',I1,2X),/)
 3003 FORMAT(/,8X,I1,8X,3(E11.4,1X)/)
 3010 FORMAT(6X,3E11.4/)
      END                                                               
      SUBROUTINE DRISC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
      COMMON/PARD05/CF,PACO,NCEL,NPAR,NEQ,K0                         
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/MEDD05/HM(10),TP(3,10),TF(10),CAL(3,10),ROM(10),DRDH(10),  
     $            DRDP(10),GAMMA(3,10),SM(10),TITOL(10)                 
      COMMON/DATD05/V(10),HLU(10),AREA(10),DIAI(10),SUP(3,10),          
     $              CKF(10),DZG(10),CRIG(10)
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NUL(7),ITERT                                         
      COMMON/REGIME/KREGIM
      COMMON/DRIFT/ALF0(11),SL(11),C00(11),VGJ0(11),FLU(11)            
      COMMON/DRI05/DR(11),DH(11),HT(11)      
      LOGICAL KREGIM                                                    
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
C
      NN2=2*NCEL                                                  
      NN3=NN2+NCEL 
      NN4=NN3+NPAR*NCEL
      NEQ=NN4+NCEL                                          
      NVAR=NEQ+NPAR*NCEL+5                                              
C                                                                       
      ISTA=ISTA09(IFUN)                                                 
C                                                                       
      GO TO (10,30,60),IFUN                                             
C                                                                       
C                                                                       
C       TOPOLOGIA JACOBIANO                                             
C      (TUTTO PIENO)                                                    
C                                                                       
   10 DO 12 I=1,NEQ                                                     
      DO 12 J=1,NVAR                                                    
      AJAC(I,J)=1.                                                      
   12 CONTINUE                                                          
      RETURN                                                            
C                                                                       
C-----DECODIFICA VARIABILI E DATI                                       
C                                                                       
   30 CALL DRIDEC (XYU,IXYU,DATI,IPD,IFUN)                              
C                                                                       
C-----CALCOLO COEFFICIENTI DERIVATE H,P                                 
C                                                                       
      CALL DRITAU(IFUN,DATI,IPD)  
C                                                                       
C-----CALCOLO DEI RESIDUI                                               
C                                                                       
      CALL DRIRES (IFUN,RNI,DATI,IPD)                                 
C
      IF(.NOT.KREGIM) RETURN
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
C      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
C 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))                     
C      IF(ISTA.NE.0) CALL DRISTA(ISTA)
C      IF(ISTA.EQ.0.AND.IFUN.EQ.2) THEN
C       CALL DRISTA(ISTA)
C      ENDIF
C      IF (IFUN.EQ.2.AND.PACO.NE.0.) THEN
C       IF(PACO.EQ.1) WRITE(6,*) 'Correlazione di ZUBER_DIX'
C       IF(PACO.EQ.2) WRITE(6,*) 'Correlazione di BANKOFF'
C       IF(PACO.EQ.3) WRITE(6,*) 'Correlazione di CHEXAL_LELLOUCHE'
C       IF(PACO.EQ.4) WRITE(6,*) 'Correlazione di ZUBER-ROUHANY'
C       WRITE(6,1235)
C       DO 65 I=1,NCEL+1
C        WRITE (6,1236) I,ALF0(I),SL(I),C00(I),VGJ0(I),FLU(I),HT(I),
C     &                   DR(I),DH(I)     
C   65  CONTINUE
C      ELSE
C       WRITE(6,*)'Modello omogeneo'
C      ENDIF      
C 1235 FORMAT(1X,'CONFINE',6X,'ALFA',8X,'SLIP RATIO',9X,'C0',13X
C     $        ,'VGJ',8X,'FLUSSO VOL.',4X,'ENT.TOT.',10X,'DR',13X,'DH'/)
C 1236 FORMAT(1X,I3,5X,5(F12.8,3X),3(G12.5,3X))                                 
C     
       RETURN                                                           
C                                                                       
C-----CALCOLO DELLO JACOBIANO                                           
C          NUMERICO                                                     
C                                                                       
   60 CONTINUE                                                          
C                                                                       
      CALL DRISJC(AJAC,MX5,IXYU,XYU,DATI,IPD,RNI,IFUN)                  
C                                                                       
      RETURN                                                            
      END                                                               
      SUBROUTINE DRISJC(AJAC,MX5,IXYU,XYU,DATI,IPD,RNI,IFUN)            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION G1(50),G2(50),
     $  RNI(*),AJAC(MX5,*),DATI(*),VAR(100),XYU(*)        
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM
      LOGICAL KREGIM
C                                                                       
C*** CALCOLO JACOBIANO NUMERICO                                          
C                                                                       
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NN2=2*NCEL                                                        
      NN3=NN2+NCEL                                                        
      NN4=NN3+NPAR*NCEL
      NSTATI=0
      NEQ=NN4+NCEL                                               
      NVAR=NEQ+NPAR*NCEL+5                                              
C                                                                       
      CALL DRIDEC(XYU,IXYU,DATI,IPD,IFUN)                                  
C                                                                       
      CALL DRITAU(IFUN,DATI,IPD)  
C
      CALL DRIRES (IFUN,G1,DATI,IPD)
C                                                                       
      DO J=1,NEQ                                                     
      IF(J.GT.NSTATI) THEN
       G1(J)=-G1(J)                                       
      ENDIF
      ENDDO
C
      EPSLIM=1.E-4
      DO 30 I=1,NVAR                                                    
      EPS=XYU(IXYU+I-1)*1.E-3                                           
      IF(ABS(EPS).LT.EPSLIM)EPS=EPSLIM
C                                                                       
      DO 15 J=1,NVAR                                                    
      VAR(J)=XYU(IXYU+J-1)                                              
      IF(J.EQ.I)VAR(J)=VAR(J)+EPS                                       
   15 CONTINUE                                                          
C                                                                       
      CALL DRIDEC(VAR,1,DATI,IPD,IFUN)                                  
C                                                                       
      CALL DRIRES (IFUN,G2,DATI,IPD)
C                                                                       
      DO 45 J=1,NEQ                                                     
      IF(J.GT.NSTATI) THEN
       G2(J)=-G2(J)                                       
      ENDIF
      AJAC(J,I)=(G2(J)-G1(J))/EPS                                      
   45 CONTINUE                                                          
C
   30 CONTINUE                                                          
C
      RETURN                                                            
      END                                                               
      SUBROUTINE DRIRES (IFUN,RNI,DATI,IPD)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION RNI(*),DATI(*),F(40)                                    
      COMMON/PARD05/CF,PACO,NCEL,NPAR,NEQ,K0                         
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/MEDD05/HM(10),TP(3,10),TF(10),CAL(3,10),ROM(10),DRDH(10),  
     $            DRDP(10),GAMMA(3,10),SM(10),TITOL(10)                 
      COMMON/DATD05/V(10),HLU(10),AREA(10),DIAI(10),SUP(3,10),          
     $              CKF(10),DZG(10),CRIG(10)
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NUL(7),ITERT                                         
      COMMON/DRI05/DR(11),DH(11),HT(11)
      COMMON/MARTIN/FIQLO(11),ROLS(11)
      COMMON/REGIME/KREGIM                                              
C************************* 19/9/1988 ************ I ********************
      COMMON/CEL01/ NTCEL,IVER,ICEL                                     
C************************* 19/9/1988 ************ F ********************
      LOGICAL KREGIM                                                    
C************************* 24/8/1988 ************ I ********************
C                                                                       
C       IL VALORE DI IGAM (INTERO) SERVE PER CALCOLARE O MENO
C       IL COEFFICIENTE DI SCAMBIO CON LA SUB. GAM01 :                    
C       SE IGAM =0  NON SI CALCOLA                                      
C       SE IGAM >0   SI CALCOLA                                         
C                                                                       
C                                                                       
      IGAM=IGAM09(IFUN)                                                 
C************************* 24/8/1988 ************ F ********************
C                                                                       
      NNN=NCEL+1                                                        
      NN2=2*NCEL                                                        
      NN3=NN2+NCEL
      NN4=NN3+NPAR*NCEL
C____ PASST DI INTEGRAZIONE
      DELTAT=DTINT
      IF(DELTAT.EQ.0.)DELTAT=1.
C                                                                       
C-------- RIPRISTINO DEL COEFF. DI SCAMBIO PRESO DAL VETTORE DATI       
C                                                                       
         K0=IPD+15*NCEL+1                                                  
         DO 1 KJ=1,NPAR                                                   
         DO 1 KI=1,NCEL                                                   
         KK = K0 + (KJ-1)*NCEL + KI                                        
         GAMMA(KJ,KI)=DATI(KK)
           IF(CRIG(KI).EQ.30.) THEN
         G=ABS(Q(KI))/AREA(KI)    
         GAMMA(KJ,KI)=DATI(KK)*G**(0.8)        
           END IF
    1 CONTINUE                                                          
         NTCEL=NCEL                                                        
         IF(IGAM.EQ.0) GOTO 9
C**********************************************************
C
C___ CALCOLO COEFFICIENTI DI SCAMBIO
C
C**********************************************************
C                                                                       
C  IVER= 1 ===> NELLA GAM01 SI FA IL TEST DI CRISI DALL'ULTIMA CELLA    
C  IVER=-1 ===> NELLA GAM01 SI FA IL TEST DI CRISI DALLA PRIMA CELLA    
C  IVER=-2 ===> NELLA GAM01 SI FA IL TEST DI CRISI SU TUTTE LE CELLE,   
C               A PARTIRE DALLA PRIMA                                   
C                                                                       
         DO 7 K=1,NCEL                                                    
           IF ((Q(1).GT.0.).AND.(Q(NCEL).GT.0.)) THEN                      
         IVER=1                                                            
         I=NCEL-K+1                                                        
           ELSE IF ((Q(1).LT.0.).AND.(Q(NCEL).LT.0.)) THEN                 
         IVER=-1                                                           
         I=K                                                               
           ELSE                                                            
         IVER=-2                                                           
         I=K                                                               
           END IF                                                          
         ICEL=I                                                            
C
         G=ABS(Q(I))/AREA(I)                                                    
         PMI=(P(I)+P(I+1))/2.                                              
C                                                                       
         DO 7 J=1,NPAR                                                    
C
         IF(CRIG(I).GE.0.) GOTO 17
C                                                                       
C  CHIAMA LA SUBROUTINE UTENTE GAMUT
C                                                                       
      CALL DRISGAMUT(PMI,HM(I),SM(I),TF(I),ROM(I),TITOL(I),TP(J,I),
     $           DIAI(I),CRIG(I),G,CAL(J,I),SUP(J,I),GAMMA(J,I))
         GOTO 7
   17 IF(CRIG(I).NE.20.) GOTO 18
C                                                                       
C  COEFFICIENTE DI SCAMBIO COSTANTE = 50000. (W/M**2/C)
C                                                                       
         GAMMA(J,I)=50000.
         GOTO 7
   18 IF(CRIG(I).NE.30) GOTO 19
C                                                                       
C  COEFFICIENTE DI SCAMBIO DIPENDENTE SOLO DALLA PORTATA G
C                                                                       
           IF(KREGIM) THEN
         CRI=0.
      CALL GAM01(PMI,HM(I),SM(I),TF(I),ROM(I),TITOL(I),TP(J,I),         
     $           DIAI(I),CRI,G,CAL(J,I),SUP(J,I),GAMMA(J,I))        
           END IF
         GOTO 7
C                                                                       
C  COEFFICIENTE DI SCAMBIO DATO DALLE CORRELAZIONI STANDARD
C     
   19 CALL GAM01(PMI,HM(I),SM(I),TF(I),ROM(I),TITOL(I),TP(J,I),         
     $           DIAI(I),CRIG(I),G,CAL(J,I),SUP(J,I),GAMMA(J,I))
         IF (IFUN.NE.2) GOTO 7        
    7 CONTINUE
C
C      IF (IFUN.EQ.2.) WRITE(6,*)(GAMMA(1,I),I=1,NCEL)
C                                                                       
C-------- SALVATAGGIO DEL COEFF. DI SCAMBIO NEL VETTORE DATI            
C                                                                       
         K0=IPD+15*NCEL+1                                                  
         DO 6 KJ=1,NPAR                                                    
         DO 6 KI=1,NCEL                                                    
         KK = K0 + (KJ-1)*NCEL + KI                                        
C$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
         IF(KREGIM) GOTO 30
           IF(CRIG(KI).EQ.30.)GOTO 6
         GAMMA(KJ,KI)=(DATI(KK)+CDT/ALFADT/2.*GAMMA(KJ,KI))
     $/(1.+CDT/ALFADT/2.)
         DATI(KK)=GAMMA(KJ,KI)
         GOTO 6
   30 IF(CRIG(KI).EQ.30.) THEN
         G=ABS(Q(KI))/AREA(KI)    
         DATI(KK)=GAMMA(KJ,KI)/(G**(0.8))        
           ELSE
         DATI(KK)=GAMMA(KJ,KI)
           ENDIF
C$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    6 CONTINUE                                                          
    9 CONTINUE                                                          
C                                                                       
C-----CALCOLO SECONDO MEMBRO EQUAZIONI DIFFERENZIALI                    
C
C 1) EQQ. SCAMBI TERMICI ==> NPAR*NCEL                                      
C 2) EQU. ENERGIA        ==> NCEL                                           
C 3) EQU. MOMENTO        ==> NCEL
C 4) EQU. CONTINUITA'    ==> NCEL                                           
C                                                                       
      DO 20 I=1,NCEL                                                    
      CALT=0.                                                           
C                                                                       
C---- CALCOLO FUNZIONALI EQUAZIONI POTENZE SCAMBIATE                  
C                                                                       
      DO 42 J=1,NPAR                                                    
       F(NN3+(J-1)*NCEL+I)=
     $        CAL(J,I)/(GAMMA(J,I)*SUP(J,I))-(TP(J,I)-TF(I))
      CALT=CALT+CAL(J,I)
   42 CONTINUE    
        CMOLT2=1.
        TFC=TF(I)-273.
        IF(TFC.LT.170.) CMOLT2=-0.058*TFC+10.937
      IF(KREGIM) THEN
C  
C---- CALCOLO FUNZIONALI EQUAZIONI ENERGIA 
        IF(ABS(Q(I)).GT.1.E-3) THEN
           F(I)=Q(I)*(H(I)-HM(I)) +DH(I)-DH(I+1) + CALT            
        ELSE    
           F(I)=H(I)-HM(I)                                                   
        ENDIF
C____ CALCOLO EQUAZIONE DEL MOMENTO
        F(NCEL+I)= -P(I+1)+P(I)+DR(I)-DR(I+1)-ROM(I)*DZG(I)
     &           -CKF(I)*CF*FIQLO(I+1)*Q(I)*ABS(Q(I))/ROLS(I)
     &           -CMOLT2*CKF(I)*AREA(I)*CF*Q(I)/10.
C____ CALCOLO EQUAZIONE CONTINUITA`
        F(2*NCEL+I)=Q(I)-Q(I+1)                                             
C
      ELSE
C       PPUNTO=(P(I+1)-PN(I+1))/DELTAT
C       HPUNTO=(HM(I)-HN(I))/DELTAT
       DELTAP=P(I+1)-PN(I+1)
       DELTAH=HM(I)-HN(I)
C$$$SPEL
C   _______ PROTEZIONE PER INVERSIONE DI PORTATA
C
       QE=Q(I)
       DEH=DH(I)
       DUH=DH(I+1)
       IF(QE.LT.0.)THEN
         QE=0.
         DEH=0.
         DUH=0.
       ENDIF
C_____ CALCOLO EQUAZIONE ENERGIA
        F(I)     =( QE*(H(I)-HM(I))
     $             + DEH - DUH + CALT ) * DELTAT            
     $            - TAU1P(I)*DELTAP - TAU1H(I)*DELTAH
C$$$SPEL
C____ CALCOLO EQUAZIONE DEL MOMENTO
        F(NCEL+I)= -P(I+1)+P(I)+DR(I)-DR(I+1)-ROM(I)*DZG(I)
     &           -CKF(I)*CF*FIQLO(I+1)*Q(I)*ABS(Q(I))/ROLS(I)
     &           -CMOLT2*CKF(I)*AREA(I)*CF*Q(I)/10.
C____ CALCOLO EQUAZIONE CONTINUITA`
        F(NN2+I)=(Q(I)-Q(I+1))*DELTAT - TAU2P(I)*DELTAP-TAU2H(I)*DELTAH
      ENDIF
   20 CONTINUE
C
      DO 23 I=1,NCEL                                                    
C---- RESIDUI EQUAZIONI ENERGIA (--> ENTALPIE MEDIE STATICHE DI CELLA)
      RNI(I)      =F(I)/W0/H0
C---- RESIDUI EQUAZIONI MOMENTO (--> PRESSIONI USCITA CELLA)
      RNI(NCEL+I) =F(NCEL+I)/P0                                                
C---- RESIDUI EQUAZIONI CONTINUITA' (--> PORTATE INGRESSO CELLA) 
C
C---- Modifica di Pagani: la precisione richiesta al calcolo del residuo
C---- e` adeguata alla portata circolante e non eccessiva (come avviene
C---- se la normalizzazione e` sempre W0 e la Q(I) e` maggiore di W0).   
C---- La modifica non serve se funziona il TOLIN della LEGRES
C
CCC      IF (Q(I) .GT. W0) THEN
CCC        RNI(NN2+I)  =F(NN2+I)/1000.
CCC      ELSE
CCC        RNI(NN2+I)  =F(NN2+I)/W0
CCC      ENDIF
      RNI(NN2+I)  =F(NN2+I)/W0
C
C---- RESIDUI EQUAZIONI SCAMBIO TERMICO (--> POTENZE SCAMBIATE)
      DO 25 J=1,NPAR                                                    
      RNI(NN3+(J-1)*NCEL+I) =F(NN3+(J-1)*NCEL+I)/T0                     
  25  CONTINUE                                                          
C
C-----CALCOLO RESIDUO EQUAZIONE ENTALPIA TOTALE DI USCITA                       
      IF(Q(I+1).GT.0.) THEN
      RNI(NN4+I)=(Q(I+1)*(HT(I+1)-HM(I))-DH(I+1))/W0/H0
      ELSE
      RNI(NN4+I)=(HT(I+1)-HM(I))/H0
      ENDIF
  23  CONTINUE
C                                                                       
C____ IN STAZIONARIO SI MEMORIZZANO LE PRESSIONI E LE ENTALPIE NEL VETTORE DATI
C
      IF(KREGIM) THEN
       KS=IPD+15*NCEL+NPAR*NCEL+2
       DO I=1,NCEL+1
       DATI(KS+I)=P(I)
       ENDDO
       DO I=1,NCEL
       DATI(KS+NCEL+1+I)=HM(I)
       ENDDO
      ENDIF
      RETURN                                                            
      END                                                               
      SUBROUTINE DRIDEC(XYU,IXYU,DATI,IPD,IFUN)                         
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION XYU(*),DATI(*)                                          
      COMMON/PARD05/CF,PACO,NCEL,NPAR,NEQ,K0                         
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/MEDD05/HM(10),TP(3,10),TF(10),CAL(3,10),ROM(10),DRDH(10),  
     $            DRDP(10),GAMMA(3,10),SM(10),TITOL(10)                 
      COMMON/DATD05/V(10),HLU(10),AREA(10),DIAI(10),SUP(3,10),          
     $              CKF(10),DZG(10),CRIG(10)                            
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NUL(7),ITERT                                         
      COMMON/REGIME/KREGIM                                              
      COMMON/DRI05/DR(11),DH(11),HT(11)
      COMMON/DRIFT/ALF0(11),SL(11),C00(11),VGJ0(11),FLU(11)            
      COMMON/MARTIN/FIQLO(11),ROLS(11)
C%%%%%%%%%%%
      COMMON/TOLEG00/TOLIN(100)
C%%%%%%%%%%%
      LOGICAL KREGIM                                                  
      DATA PCRIT /2.212E+07/
C                                                                       
      NFL=1                                                             
      NNN=NCEL+1                                                        
C                                                                       
C        DATI                                                           
C                                                                       
      DO 10 I=1,NCEL                                                    
      K3=IPD+(I-1)*10+1                                                 
      V(I)=DATI(K3+1)                                                   
      HLU(I)=DATI(K3+2)                                                 
      AREA(I)=DATI(K3+3)                                                
      DIAI(I)=DATI(K3+4)                                                
      CKF(I)=DATI(K3+5)                                                 
      DZG(I)=DATI(K3+6)                                                 
      CRIG(I)=DATI(K3+7)                                                
      SUP(1,I)=DATI(K3+8)                                               
      SUP(2,I)=DATI(K3+9)                                               
      SUP(3,I)=DATI(K3+10)                                              
   10 CONTINUE                                                          
      KD=NCEL*10+IPD+1 
      PACO=DATI(KD+1)                                      
CCC
CCC     DECODIFICO I TERMINI DI DRIFT
CCC
CC       KS=IPD+15*NCEL+NPAR*NCEL+2+2*NCEL+1
CC       DO I=1,NCEL+1
CC       DH(I)=DATI(KS+I)
CC       DR(I)=DATI(KS+NCEL+1+I)
CC       RO(I)=DATI(KS+2*NCEL+2+I)
CC       ENDDO
C
C        VARIABILI ESTREME                                              
C                                        
      HI    =XYU(IXYU+NEQ  )*H0                                                
      P(1)  =XYU(IXYU+NEQ+1)*P0                                              
      Q(NNN)=XYU(IXYU+NEQ+2)*W0                                            
      HUINV =XYU(IXYU+NEQ+3)*H0                                                
      CF=XYU(IXYU+NEQ+NPAR*NCEL+4)                                      
      HT(1)=HI
      H(1) =HI
C%%%%%%%%%%%%%%
C     DEFINIZIONE DELLA TOLLERANZA PER L'EQUAZIONE DI CONTINUITA`
C
      WW=ABS(Q(NNN))
      IF(WW.GT.1000.)WW=1000.
      IF(WW.LT..1)WW=.1
      DELTAT=DTINT
      IF(DELTAT.LE.0.)DELTAT=1.
      WWTOL=WW*.01*DELTAT/W0
C     DEFINIZIONE DELLA TOLLERANZA PER L'EQUAZIONE DEL MOMENTO
C
      PPTOL=50./P0
C%%%%%%%%%%%%%%
C                                                                      
      NN0=IXYU-1                                                         
      NN1=NN0+NCEL                                                        
      NN2=NN1+NCEL                                                        
      NN3=NN2+NCEL                                                        
      NN4=NN3+NPAR*NCEL            
      NN5=NN0+NEQ+4                                                       
C
C        VARIABILI INTERNE
C                                                                       
      DO 60 I=1,NCEL                                                    
C%%%%%%%%%%%%%
       TOLIN(2*NCEL+I)=WWTOL
       TOLIN(  NCEL+I)=PPTOL
C%%%%%%%%%%%%%
       HM(I)  =XYU(NN0+I)*H0
       P(I+1) =XYU(NN1+I)*P0                                                  
       Q(I)   =XYU(NN2+I)*W0
       HT(I+1)=XYU(NN4+I)*H0
Casam
       write(6,*)' sono dentro '
       write(6,*)'I',I,'  I+1 ',I+1
       write(6,*)'P(I+1),HM(I),NFL',P(I+1),HM(I),NFL
Casam ------
C
C----- CALCOLO ENTALPIE DI CONFINE STATICHE 
       H(I+1)  =HM(I)
C
       SM(I)   =SHEV(P(I+1),HM(I),NFL)
       TF(I)   =TEV (P(I+1),SM(I),NFL)
       TITOL(I)=YEV (P(I+1),SM(I),NFL)
Casam ------
       write(6,*)'I',I,'  I+1 ',I+1
       write(6,*)'P(I+1),HM(I),NFL',P(I+1),HM(I),NFL
       write(6,*)'SM(I)',SM(I)
Casam
       DO 40 J=1,NPAR
        CAL(J,I)=XYU(NN3+(J-1)*NCEL+I)*W0*H0 
        TP(J,I) =XYU(NN5+(J-1)*NCEL+I)*T0
   40 CONTINUE
      IF (PACO.EQ.0.) THEN
C---- MODELLO OMOGENEO (MODIFICHE POLLACHINI 21/05/1993)
C---- ESAME I-ESIMO CONFINE (I=1,NCEL)
       CALL SATUR (P(I),3,RL,RV,1)
       SMI   =SHEV(P(I),H(I),NFL)
       TITOLI=YEV (P(I),SMI,NFL)                                            
       RO(I)=ROEV(P(I),SMI,NFL)              
Casam ------
       write(6,*)'I',I
       write(6,*)'P(I),H(I),NFL',P(I),H(I),NFL
       write(6,*)'SMI',SMI
Casam
C
C-- CALCOLO DEL MOLTIPLICATORE D'ATTRITO DI MARTINELLI-NELSON SECONDO BECKER
C        
         PI=P(I)
         IF(PI.LE.10.E+05) PI=10.E+05
         FIQLO(I)=1.+10.*PCRIT/PI*TITOLI
           IF(FIQLO(I).GT.1.) THEN
           ROLS(I)=RL
           ELSE
           ROLS(I)=RO(I)
           ENDIF            
       DR(I)=0.
       DH(I)=0.
       ALF0(I)=0.
       IF(TITOLI.GT.0.)
     &       ALF0(I)=1./(1.+(1.-TITOLI)/TITOLI*RV/RL)
      ELSE
C
C---- MODELLO DI "DRIFT" (correzioni di POLLACHINI 05/12/1991)
C---- ESAME I-ESIMO CONFINE (I=1,NCEL)
CC        IF(KREGIM) GO TO 41
CC         IF(IFUN.EQ.2.AND.ITERT.EQ.0) THEN
CCC
CC   41 CONTINUE
         SI=SHEV(P(I),H(I),NFL)
         TIF =TEV(P(I),SI,NFL)                                             
         DIAH=DIAI(I)
         ARE=AREA(I)
      CALL NONOMG(TIF,ARE,DIAH,IFUN,PACO,Q(I),H(I),P(I),HT(I),
     &             RM,DRD,DHD,ALFN,SLN,C0,VGJ,FL,I,FIQLOI,RL)       
C---- MEMORIZZAZIONE DELLE GRANDEZZE DI "DRIFT"
         RO(I)=RM
         DR(I)=DRD
         DH(I)=DHD
         ALF0(I)=ALFN
         SL(I)=SLN
         C00(I)=C0
         VGJ0(I)=VGJ
         FLU(I)=FL
         FIQLO(I)=FIQLOI
             IF(FIQLO(I).GT.1.) THEN
             ROLS(I)=RL
             ELSE
             ROLS(I)=RO(I)
             ENDIF            
CC         ENDIF
      ENDIF
  60  CONTINUE
C---- ESAME CONFINE NNN=NCEL+1
      IF(PACO.EQ.0.) THEN
       CALL SATUR (P(NNN),3,RL,RV,1)
       SM1=SHEV(P(NNN),H(NNN),NFL)
       TITOL1=YEV (P(NNN),SM1,NFL)                                            
       RO(NNN)=ROEV(P(NNN),SM1,NFL)          
       ALF0(NNN)=0.
       IF(TITOL1.GT.0.)
     &    ALF0(NNN)=1./(1.+(1.-TITOL1)/TITOL1*RV/RL)
C
C-- CALCOLO DEL MOLTIPLICATORE D'ATTRITO DI MARTINELLI-NELSON SECONDO BECKER
C        
         PI1=P(NNN)
         IF(PI1.LE.10.E+05) PI1=10.E+05
         FIQLO(NNN)=1.+10.*PCRIT/PI1*TITOL1
           IF(FIQLO(NNN).GT.1.) THEN
           ROLS(NNN)=RL
           ELSE
           ROLS(NNN)=RO(NNN)
           ENDIF            
       DR(NNN)=0.
       DH(NNN)=0.
      ELSE
CC        IF(KREGIM) GO TO 61
CC         IF(IFUN.EQ.2.AND.ITERT.EQ.0) THEN
CCC
CC  61  CONTINUE
         SI1=SHEV(P(NNN),H(NNN),NFL)
         TIF1 =TEV(P(NNN),SI1,NFL)                                             
         ARE=AREA(NCEL)
         DIAH=DIAI(NCEL)
       CALL NONOMG(TIF1,ARE,DIAH,IFUN,PACO,Q(NNN),H(NNN),P(NNN),
     &           HT(NNN),RM,DRD,DHD,ALFN,SLN,C0,VGJ,FL,NNN,FIQLOI,RL)       
         RO(NNN)=RM
         DR(NNN)=DRD
         DH(NNN)=DHD
         ALF0(NNN)=ALFN
         SL(NNN)=SLN
         C00(NNN)=C0
         VGJ0(NNN)=VGJ
         FLU(NNN)=FL
         FIQLO(NNN)=FIQLOI
             IF(FIQLO(NNN).GT.1.) THEN
             ROLS(NNN)=RL
             ELSE
             ROLS(NNN)=RO(NNN)
             ENDIF            
CC         ENDIF
      ENDIF
C---- CALCOLO DELLA DENSITA' MEDIA DI CELLA 
      DO 70 I=1,NCEL
      ROLS(I)=2.*ROLS(I)*ROLS(I+1)/(ROLS(I)+ROLS(I+1))
   70 ROM(I)=2.*RO(I)*RO(I+1)/(RO(I)+RO(I+1))
C
C----- MEMORIZZAZZIONE NEL VETTORE DATI DEL CORRETTORE D'ATTRITO DI 
C      MARTINELLI-NELSON ALL'INIZIO DI OGNI PASSO DI TEMPO   
C      (L. POLLACHINI 13/05/1993)
C
       IF(.NOT.KREGIM.AND.IFUN.EQ.2.AND.ITERT.EQ.0) THEN
       KS=IPD+15*NCEL+NPAR*NCEL+2+2*NCEL+1+3*NCEL+3
       DO I=1,NCEL+1
       DATI(KS+I)=FIQLO(I)     
       ENDDO
       ENDIF
C
C----- CARICAMENTO DEL MOLTIPLICATORE D'ATTRITO DI MARTINELLI-NELSON    
C      RELATIVO ALLA ITERAZIONE PRECEDENTE
C    
       IF(.NOT.KREGIM) THEN
       KS=IPD+15*NCEL+NPAR*NCEL+2+2*NCEL+1+3*NCEL+3
       DO I=1,NCEL+1       
       FIQLO(I)=DATI(KS+I) 
       ENDDO
       ENDIF
C
C----- ESCLUSIONE DEL CORRETTORE D'ATTRITO DI MARTINELLI-NELSON (IFIQLO=0)
       IFIQLO=1
       IF(IFIQLO.EQ.0) THEN
       DO 77 I=1,NCEL
       FIQLO(I)=1.
       ROLS(I)=ROM(I)
   77  CONTINUE
       FIQLO(NCEL+1)=1.
       ENDIF
CCC
CCC     MEMORIZZO I TERMINI DI DRIFT
CCC
CC       KS=IPD+15*NCEL+NPAR*NCEL+2+2*NCEL+1
CC       DO I=1,NCEL+1
CC       DATI(KS+I)       =DH(I)
CC       DATI(KS+NCEL+1+I)  =DR(I)
CC       DATI(KS+2*NCEL+2+I)=RO(I)
CC       ENDDO
C
      IF(.NOT.KREGIM.AND.IFUN.EQ.2.AND.ITERT.EQ.0) THEN
C
C---- IN TRANSITORIO , ALL'INIZIO DI OGNI PASSO DI TEMPO,
C     MEMORIZZA LE PRESSIONI E LE ENTALPIE ATTUALI NEL VETTORE DATI 
C
       KS=IPD+15*NCEL+NPAR*NCEL+2
       DO I=1,NCEL+1
       DATI(KS+I)= P(I)
       ENDDO
       DO I=1,NCEL
       DATI(KS+NCEL+1+I)= HM(I)
       ENDDO
      ENDIF
C
C____ CARICAMENTO DEI VETTORI PRESSIONI ED ENTALPIE DEL PASSO PRECEDENTE 
C     DA USARE PER CALCOLARE LE P_PUNTO IN TRANSITORIO
C
      KS=IPD+15*NCEL+NPAR*NCEL+2
      IF(.NOT.KREGIM) THEN
       DO I=1,NCEL+1
       PN(I) = DATI(KS+I)
       ENDDO
       DO I=1,NCEL
       HN(I) = DATI(KS+NCEL+1+I)
       ENDDO
      ENDIF
C
      IF (Q(1).GT.0.)  H(1)=H(1)-DH(1)/Q(1)
C
C
C_______ STAMPE
C
      IF (KREGIM.AND.IFUN.EQ.5) THEN
       WRITE(6,*)'HM ',(HM(I),I=1,NCEL)
       WRITE(6,*)'ROM ',(ROM(I),I=1,NCEL)
       WRITE(6,*)'HT ',(HT(I),I=1,NCEL+1)
       WRITE(6,*)'DH ',(DH(I),I=1,NCEL+1)
       WRITE(6,*)'DR ',(DR(I),I=1,NCEL+1)
       WRITE(6,*)'FIQLO ',(FIQLO(I),I=1,NCEL+1)
       WRITE(6,*)'ROLS ',(ROLS(I),I=1,NCEL)
      ENDIF
Casam
      write(6,*)' sono fuori'
C
      RETURN                                                            
      END                                                               
      SUBROUTINE DRITAU(IFUN,DATI,IPD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION DATI(*)
      COMMON/PARD05/CF,PACO,NCEL,NPAR,NEQ,K0                         
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/MEDD05/HM(10),TP(3,10),TF(10),CAL(3,10),ROM(10),DRDH(10),  
     $            DRDP(10),GAMMA(3,10),SM(10),TITOL(10)                 
      COMMON/DATD05/V(10),HLU(10),AREA(10),DIAI(10),SUP(3,10),          
     $              CKF(10),DZG(10),CRIG(10)                            
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NUL(7),ITERT                                         
      COMMON/REGIME/KREGIM                                              
      LOGICAL KREGIM                                                    
C                                                                       
C       CALCOLO DELLE TAU (MASSA-ENERGIA)               
C                                                                       
      NFL=1                                                             
      KTAU=IPD+11*NCEL+1                                                  
C
      DO 10 I=1,NCEL                                                    
C
C____ IL CALCOLO DELLE COSTANTI DI TEMPO VIENE FATTO SOLO
C     ALLA PRIMA ITERAZIONE
C
      IF(ITERT.EQ.0.AND.IFUN.EQ.2) THEN
C
        PV=P(I+1)                                               
        S =SM(I)
        T =TF(I)
        B =BEV (PV,S ,NFL)                                                
        A =A2EV(PV,S ,NFL)                                                
        DRDH(I)=B/T                                               
        DRDP(I)=1./A-B/(ROM(I)*T)                                 
C
        TAU2H(I)=V(I)*DRDH(I)                                             
        TAU1H(I)=V(I)*ROM(I)                                              
        TAU2P(I)=V(I)*DRDP(I)                                             
        TAU1P(I)=-V(I)                                                    
C
        DATI(KTAU+(I-1)*4 +1)=TAU2H(I)        
        DATI(KTAU+(I-1)*4 +2)=TAU1H(I)        
        DATI(KTAU+(I-1)*4 +3)=TAU2P(I)        
        DATI(KTAU+(I-1)*4 +4)=TAU1P(I)        
      ELSE
        TAU2H(I)=DATI(KTAU+(I-1)*4 +1)
        TAU1H(I)=DATI(KTAU+(I-1)*4 +2)
        TAU2P(I)=DATI(KTAU+(I-1)*4 +3)
        TAU1P(I)=DATI(KTAU+(I-1)*4 +4)
      ENDIF
C
      TAU3(I)=0.
   10 CONTINUE                                                          
      RETURN                                                            
      END                                                               
C                                                             
      INTEGER FUNCTION ISTA09(IFUN)                                        !SNGL
C      DOUBLE PRECISION FUNCTION ISTA09(IFUN)                            !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      ISTA09=0                                                          
      IF(KREGIM) ISTA09=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) ISTA09=1                      
C******************   
      RETURN                                                            
      END                                                               
      SUBROUTINE DRISTA(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/PARD05/CF,PACO,NCEL,NPAR,NEQ,K0                         
      COMMON/TERD05/H(11),P(11),Q(11),RO(11),PN(11),HN(11),HI,HUINV
      COMMON/MEDD05/HM(10),TP(3,10),TF(10),CAL(3,10),ROM(10),DRDH(10),  
     $            DRDP(10),GAMMA(3,10),SM(10),TITOL(10)                 
      COMMON/DATD05/V(10),HLU(10),AREA(10),DIAI(10),SUP(3,10),          
     $              CKF(10),DZG(10),CRIG(10)                            
      COMMON/DYND05/TAU1H(10),TAU2H(10),TAU1P(10),TAU2P(10),TAU3(10)    
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0  
      DIMENSION AM(10)                           
      WRITE(6,1001)
      AMT=0.                                                     
      DO 10 I=1,NCEL
       AM(I)=ROM(I)*AREA(I)*HLU(I)                                        
        G=Q(I)/AREA(I)                                                      
        T=TF(I)-273.16                                                    
        WRITE(6,1002) I,Q(I),HM(I),P(I+1),AM(I),ROM(I),TITOL(I),G,T
      AMT=AMT+AM(I)          
   10 CONTINUE                               
      DO 20 J=1,NPAR                                                    
       WRITE(6,1003) J,J,J                                               
       DO 20 I=1,NCEL                                                    
        T=TP(J,I)-273.16                                                  
        WRITE(6,1004) I,T,GAMMA(J,I),CAL(J,I)                             
   20 CONTINUE
C      WRITE(6,1850)AMT                                           
 1001 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',    
     $       6X,'MASSA TOT.',5X,'DENS.MEDIA',7X,'TITOLO',8X,            
     $       'PORT.SPEC.',4X,'TEMPERATURA',4X/)                        
 1002 FORMAT(1X,I3,5X,8(E12.5,3X))                                      
 1003 FORMAT(//1X,'CELLA',4X,'TEMP.PAR.',I2,7X,'COEFF.SCAMBIO',I2,      
     $       3X,'POT. TERM.',I2,7X/)                                   
 1004 FORMAT(1X,I3,5X,8(E12.5,6X))
 1850 FORMAT(/,1X,' MASSA DEL TRONCONE COMPLETO:  ',F12.6)                     
      RETURN 
      END                                                               
      INTEGER FUNCTION IGAM09(IFUN)                                        !SNGL
C      DOUBLE PRECISION FUNCTION IGAM09(IFUN)                            !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C-----IGAM09=0 NON CALCOLA IL COEFFICIENTE DI SCAMBIO                   
C-----IGAM09=1 CALCOLA IL COEFFICIENTE DI SCAMBIO                       
C                                                                       
    1 IGAM09=1                                                          
      IF(KREGIM)RETURN                                                  
      IF(ITERT.NE.0)IGAM09=0                                            
      IF(IFUN.NE.2)IGAM09=0                                             
      RETURN                                                            
      END                                                               
C
       SUBROUTINE NONOMG(TIF,AREA,DIAH,IFUN,PACO,QQI,HHI,PPI,HTI,
     &                   RM,DRD,DHD,ALFN,SLN,C0,VGJ,FL,I,FIQLOJ,RL)       
C****************************************************************************
C    Alla subroutine NONOMG il modulo si rivolge sempre tranne che per 
C    il caso di modello omogeneo (PACO=0.).
C    Lo schema utilizzato  e' il seguente :
C
C          - dal valore di PACO si sceglie la correlazione per il 
C            calcolo di VGJ e C0;
C          - dalla routine della correlazione particolare scelta si
C            chiama la UGJALF che calcola UGJ e ALF;
C          - tornando alla NONOMG e' ora possibile calcolare i valori
C            dei termini di drift ed inserirli in opportuni vettori.
C
C            Attualmente si ha:
C       
C      PACO=1.: ZUBER-DIX    
C      PACO=2 : BANKOFF
C      PACO=3 : CHEXAL-LELLOUCHE
C      PACO=4 : ZUBER-ROUHANY
C  
C      AGGIORNARE IL COMMENTO SE SI INSERISCONO ALTRE CORRELAZIONI
C
C>>>>  Versione di "NONOMG" modificata da L. POLLACHINI il 05/12/1991  <<<<
C>>>>  Introduzione del calcolo del coefficiente d'attrito di Martinelli-Nelson
C      (Pollachini 31/03/1993)
C
C****************************************************************************
C
C********** CALCOLO TERMINI UGUALI PER QUALUNQUE CORRELAZIONE *************
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        DATA PCRIT /2.212E+07/
        G=QQI/AREA
C
C----- PROTEZIONE SULLA PORTATA SPECIFICA MINIMA        
        IF(G.LT.10.) G=10. 
C----- INIZIALIZZAZIONE DEL MOLTIPLICATORE DI MARTINELLI-NELSON
        FIQLO=1.
        FIQLOJ=1.
        OMEGAJ=1.
C
        CALL SATUR (PPI,2,HL,HV,1)
        CALL SATUR (PPI,3,RL,RV,1)
C        IF(HTI.LE.HL) GOTO 100
C        IF(HTI.GE.HV) GOTO 200
        IF(HHI.LE.HL) GOTO 100
        IF(HHI.GE.HV) GOTO 200
        HLAT =HV-HL 
C----- CALCOLO DEL GRADO DI VUOTO TRAMITE LE ENTALPIE DI CONFINE 
C----- STATICHE AGGIORNATE HHI
        ALF=RL*(HL-HHI)/(RV*(HHI-HV)+(HL-HHI)*RL)    
C        IF(ALF.LT.0.) ALF=0.
C        IF(ALF.GT.1.) ALF=1.
C
C*****************************************************************************  
C   Calcolo titolo volumetrico (fraz. di vuoto omogenea) XV,  
C   densita' omogenea RH, flusso FL e titolo massico XP 
C
        XV=RL*(HL-HTI)/(RV*(HTI-HV)+(HL-HTI)*RL)
        RH=XV*RV+(1.-XV)*RL
        FL=G/RH
        XP=XV*RV/RL/(1.-XV*(1.-RV/RL))
C
C-- CALCOLO DEL MOLTIPLICATORE D'ATTRITO DI MARTINELLI-NELSON SECONDO BECKER
C        
         PI=PPI
         IF(PPI.LE.10.E+05) PI=10.E+05
         FIQLO=1.+10.*PCRIT/PI*XP
C
C-- FATTORE CORRETTIVO DI JONES (PER PORTARE IN CONTO LA PORTATA SPECIFICA)
C
C         PB=PPI/1.E+05
C         IF(G.LE.950.) THEN
C         OMEGAJ=1.36 + 0.0073*PB + 0.074*G/1000. - 0.0076*PB*G/1000. 
C         ELSE
C         OMEGAJ=1.26 - 0.0058*PB + 0.161*1000./G - 0.0055*PB*1000./G
C         ENDIF
C
         FIQLOJ=FIQLO*OMEGAJ
C
C        IF (IFUN.EQ.2) THEN         
C         WRITE(6,*) 'G= ',G,' OMEGA= ',OMEGAJ,' FIQLOJ= ',FIQLOJ
C        WRITE(6,*)' ALF   XV   XP  HHI   HTI  HL  HV'
C        WRITE(6,'(I2,2X,7G12.5)') I,ALF,XV,XP,HHI,HTI,HL,HV
C        ENDIF
C****************************************************************************
C
        DTK=647.3-TIF
        SIG=TENSUP(DTK) 
C 
        IF (PACO.EQ.1.)  CALL ZUBDIX(RL,RV,XV,FL,SIG,AREA,
     $                               UGJ,ALFN,C0,VGJ,XP)
C
        IF (PACO.EQ.2.)  CALL BANKO(PPI,XV,FL,UGJ,ALFN,C0,VGJ)
C
        IF (PACO.EQ.3.)  CALL CHELEL(PPI,XV,FL,ALF,SIG,RV,RL,TIF,
     $                               DIAH,UGJ,ALFN,C0,VGJ) 
C
        IF (PACO.EQ.4.)  CALL ZUBROU(RL,RV,FL,XV,SIG,G,DIAH,
     $                               UGJ,ALFN,C0,VGJ,XP)
C        IF (IFUN.EQ.2) THEN         
C        WRITE(6,*)' ALFN  SLN  VGJ  C0'
C        WRITE(6,*)ALFN,SLN,VGJ,C0
C        ENDIF
        ALF=ALFN     
        RM=ALF*RV+(1.-ALF)*RL
        DRD =ALF/(1.-ALF)*RL*RV/RM*UGJ*UGJ
        DHD =DRD/UGJ*HLAT*(1.-ALF)*AREA
        SLN=(1.-ALF)/ALF*XP/(1.-XP)*RL/RV
        GOTO 950
 100    DRD=0.
        DHD=0.
        SSI=SHEV(PPI,HHI,1)
        RM =ROEV(PPI,SSI,1)                                                   
        FL=G/RM
        ALFN=0.
        XP=0.
        SLN=1.
        C0=0.
        VGJ=0.
        GO TO 950
 200     DRD=0.
         DHD=0.
         SSI=SHEV(PPI,HHI,1)
         RM =ROEV(PPI,SSI,1)                                                   
         FL=G/RM
         ALFN=1.
         XP=1.
         SLN=1.
         C0=1.
         VGJ=0.
 950    RETURN      
        END
C
        SUBROUTINE ZUBDIX(RL,RV,XV,FL,SIG,AREA,UGJ,ALFN,C0,VGJ,XP)
C
C------ CORRELAZIONE DI ZUBER-DIX
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        B=(RV/RL)**0.1
        VGJ=2.9*(9.81*SIG*(RL-RV)/RL**2)**.25*(1.- XP **4.)
        SG=(1./XV-1.)/ABS(1./XV-1.)
        C0= XV*(1.+SG*(ABS(1./XV-1.))**B)
        CALL UGJALF(C0,FL,VGJ,XV,UGJ,ALF) 
        ALFN=ALF
        RETURN
        END
C
        SUBROUTINE BANKO(P,XV,FL,UGJ,ALFN,C0,VGJ)
C
C------ CORRELAZIONE DI BANKOFF       
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        C0= 1./(.71+1.45E-08*P)
        UGJ=(C0-1.)*FL
        VGJ=0.
        ALFN=XV/C0 
        RETURN
        END 
C
        SUBROUTINE CHELEL(PPI,XV,FL,ALF,SIG,RV,RL,TIF,
     $             DIAH,UGJ,ALFN,C0,VGJ)
C
C------ CORRELAZIONE DI CHEXAL-LELLOUCHE
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        PR=PPI
        RA=RV/RL
        VG=FL*XV/ALF
        VL=FL*(1.-XV)/(1.-ALF)
C
C       
C    CALCOLO VISCOSITA'
C
        CALL VISCO(TIF,UL,UV) 
C
  50    CALL RECHEX(RL,RV,VG,VL,DIAH,UL,UV,REG,REL,RE)
        CALL C0CHEX(RE,RA,PR,ALF,B1,C0)
        C3= 2.*EXP(-ABS(REL/60000.))
        IF (C3.LT.0.5) C3=.5
        TK1= B1
C
        C2=1.
        C5 =SQRT (150.*RA)
         IF (C5.LT.1.) THEN        
         C6 = C5/(1.-C5) 
         C2=1./(1.-EXP(-C6))
         ENDIF
C
        C7= (.0914/DIAH)**.6
C       C7=1.
        C4=1.
        IF(C7.LT.1.) THEN
         C8=C7/(1.-C7)
         C4=1./(1.-EXP(-C8))
        ENDIF
C
        VGJP=.43*((RL-RV)*SIG*9.81/RL**2.)**.25
C
        VGJ= VGJP*(1.-ALF)**TK1*C2*C3*C4
        CALL UGJALF(C0,FL,VGJ,XV,UGJ,ALF)  
        ALFN=ALF
        RETURN
        END
C
        SUBROUTINE UGJALF(C0,FL,VGJ,XV,UGJ,ALF)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        UGJ=(C0-1.)*FL+VGJ
        ALF= XV/(C0+VGJ/FL)
        RETURN
        END
C
        SUBROUTINE C0CHEX (RE,RA,P,ALF,B1,C0)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        REAL K0,L                                                       !SNGL
C        DOUBLE PRECISION K0,L                                           !DBLE
        DATA PCRIT /2.212E07/
C
        A1=1./(1.+EXP(-RE/60000.))
        B1=.8
        IF(A1.LT.0.8) B1=A1
        R= (1.+1.57*RA)/(1.-B1)
        K0= B1+(1.-B1)*RA**.25
        C1=4.*PCRIT**2./(P*(PCRIT-P))
        L=(1.-EXP(-C1*ALF))/(1.-EXP(-C1))
        C0=L/(K0+(1.-K0)*ALF**R)
        RETURN
        END
C
        SUBROUTINE RECHEX(RL,RV,VG,VL,DIAH,UL,UV,REG,REL,RE)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        REL= VL*RL*DIAH/UL 
        REG= VG*RV*DIAH/UV
        IF (REG.GT.REL) RE=REG
        IF (REG.LE.REL) RE=REL
        IF (REG.LT.0.) RE=REG
        RETURN
        END
C
        SUBROUTINE VISCO(TK,UL,UV)
C
C  Calcolo VISCOSITA` di liquido e vapore saturi
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        DIMENSION VISVAP(39)
        DIMENSION VISLIQ(39)
        DATA VISLIQ
     $/1750,1300,1000,797,651,544,463,400,351,311,279,252,
     $230,211,195,181,169,159,149,141,134,127,122,116,111,
     $107,103,99.4,96.1,93,90.1,86.5,83,79.4,75.4,70.9,65.3,
     $56.0,45./
C
        DATA VISVAP
     $/8.02,8.42,8.82,9.22,9.62,10.02,10.42,10.82,11.22,
     $11.62,12.02,12.42,12.80,13.17,13.54,13.90,14.25,14.61,
     $14.96,15.30,15.65,15.99,16.34,16.70,17.07,17.45,
     $17.85,18.28,18.75,19.27,19.84,20.7,21.7,23.1,24.7,
     $26.6,29.2,34.0,45./
C
        T=TK-273.16
        IND=T/10. +1
        IF (IND.GT.38) WRITE(6,1000)
1000    FORMAT (2X,'ERRORE ,SEI IN CAMPO IPERCRITICO')
        FRA =T/10.-(IND-1)
C      
        IF (IND.EQ.38)FRA=FRA/.415
        UL=VISLIQ(IND+1)+FRA*(VISLIQ(IND+2)-VISLIQ(IND+1))
        UV=VISVAP(IND+1)+FRA*(VISVAP(IND+2)-VISVAP(IND+1))
C
        RETURN
        END
C 
        REAL FUNCTION TENSUP(T)                                         !SNGL
C        DOUBLE PRECISION FUNCTION TENSUP(T)                             !DBLE
C
C                   calcolo tensione superficiale
C 
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        TENSUP=.001*((.1161*T**2.)/(1.+.83*T)+(1.121E-03)*T**2.
     $           -(5.752E-06)*T**3.+(1.286E-08)*T**4.
     $           -(1.149E-11)*T**5.) 
        RETURN
        END
        SUBROUTINE ZUBROU(RL,RV,FL,XV,SIG,G,DE,UGJ,ALFN,C0,VGJ,XP)
C
C------ CORRELAZIONE DI ZUBER-ROUHANY
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        VGJ=1.18*(1.-XP)*(9.81*SIG*(RL-RV)/RL**2.)**.25
        C0 = 1. +0.2 * (1.-XP) * (9.81*DE)**.25 / (G/RL)**.5 
        CALL UGJALF(C0,FL,VGJ,XV,UGJ,ALF) 
        ALFN=ALF
        RETURN
        END
C
      SUBROUTINE DRISD1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
C----significato delle variabili di uscita
C   SIGNEQ = DESCRIZIONE DELL'EQUAZIONE (IN STAZIONARIO) - 50 CAR.
C   UNITEQ = UNITA` DI MISURA DEL RESIDUO - 10 CAR.
C   COSNOR = COSTANTE DI NORMALIZZAZIONE DEL RESIDUO IN STAZIONARIO
C   ITOPVA = TOPOLOGIA JACOBIANO DI REGIME - matrice di INTEGER
C
C---- Evaporatore
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0
      CHARACTER *8 BLOCCO, SYMVAR(*)
      CHARACTER *(*) SIGNEQ(*), UNITEQ(*)
      DIMENSION DATI(*), XYU(*), COSNOR(*), ITOPVA(MXT,*)
C
       RETURN
       END
C
C~FORAUS_DRIS~C
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE DRISGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE DRISGAMUT SIA CHIAMATA DA TUBS
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   CRIG < 0.
C
C  La subroutine fornisce al modulo TUBS il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]          
C   H     entalpia specifica del fluido           [J/kg]        
C   S     entropia specifica del fluido           [J/kg/C] 
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]     
C   TITOL titolo della miscela
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   CRIG  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato 
C         come si vuole.
C         RICORDATI CHE CRIG E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]   
C   Q     potenza totale scambiata                [W]           
C   SUP   superficie di scambio                   [m**2]        
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE DRISGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_DRIS~C 
