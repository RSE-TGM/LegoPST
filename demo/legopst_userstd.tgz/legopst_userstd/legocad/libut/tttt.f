      SUBROUTINE TTTTI2 (IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
      REAL VAR(MX1,2)
      DIMENSION XYU(*),DATI(*),CNXYU(*),TOL(*)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
C
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
C
C---temperatura di p ed h
C
      GO TO(100,200), IFUN
C
  100 RETURN
C
C---lettura e memorizzazione dati
C
  200 READ(14,501)
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  501 FORMAT(3(14X,F10.0,1X))
C
      ID2 = ID1
C
C---costanti di normalizzazione
C
      CNXYU(IV1   ) = T0
      CNXYU(IV1+ 1) = P0
      CNXYU(IV1+ 2) = H0
C
      RETURN
      END
C
C
C
      SUBROUTINE TTTTC1 (IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      EXTERNAL TTTT
C
C---temperatura di p ed h
C
      GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100 CONTINUE
      CALL TTTTJC (1,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
      RETURN
C
C---calcolo residui
C
  200 CALL TTTT (IFUN,IXYU,XYU,IPD,DATI,RNI)
      RETURN
C
C---calcolo jacobiano
C
C      jacobiano analitico CALL TTTTJC (2,...
C
C      jacobiano numerico  CALL TTTTJC (3,...
C
C$*$
  300 CONTINUE
      CALL TTTTJC (3,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
      RETURN
      END
C
C
C
      SUBROUTINE TTTTJC (IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      EXTERNAL TTTT
C
      GOTO (1,2,3), IFUN
C
C---topologia jacobiano
C
    1 CONTINUE
C
C---equazione n.1 (algebrica):
C   ---dipendenza da TTTT
      AJAC(1,1)=1.
      AJAC(1,2)=1.
      AJAC(1,3)=1.
C
      RETURN
C
C     calcolo jacobiano analitico
C
    2 CONTINUE
      TTTI   = XYU(IXYU   )
      PPPP   = XYU(IXYU+ 1)
      HHHH   = XYU(IXYU+ 2)
C
C
C$*$
C
C--derivata del residuo n.  1 (equazione algebrica)   *******
C     --- rispetto alla variabile TTTI
C      AJAC(1,1) = 
C
      RETURN
C
C---calcolo jacobiano numerico
C
    3 CONTINUE
C
      NSTATI = 0
      NUSCIT = 1
      NINGRE = 2
      EPS    = 1.E-3
      EPSLIM = 1.E-4
      CALL NAJAC (AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,TTTT)
      RETURN
      END
C
C
C
      SUBROUTINE TTTT (IFUN,IXYU,XYU,IPD,DATI,RNI)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
      LOGICAL KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
C---temperatura di p ed h
C   calcolo residui
C
C---decodifica variabili e dati
C
      TTTI   = XYU(IXYU   )
      PPPP   = XYU(IXYU+ 1)
      HHHH   = XYU(IXYU+ 2)
C
      SSSS= SHEV(PPPP*P0,HHHH*H0,1)
      TTTC=TEV(PPPP*P0,SSSS,1)
C$*$
C
C---calcolo residui
C
C--residuo n.  1 (equazione algebrica)   *******
      RNI(1) =TTTI -TTTC/T0 
C
      RETURN
      END
C
C
C
      SUBROUTINE TTTTI3 (IFO,IOB,DEBL)
C
      COMMON/TTTT01/IBLOC
      COMMON/TTTT02/NCEL,NPAR
      CHARACTER*4 IOB, MOD, IBLOC*8, DEBL*80
      DATA MOD/'TTTT'/
C
      CALL TTTTI4(IOB,MOD)
      NSTATI = 0
      NUSCIT = 1
      NINGRE = 2
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
      WRITE(IFO,3001)IOB
 3001 FORMAT('TTTT',A4,2X,
     $  57H--UA-- Temperatura                                       )
      WRITE(IFO,3002)IOB
 3002 FORMAT('PPPP',A4,2X,
     $  57H--IN-- Pressione                                         )
      WRITE(IFO,3003)IOB
 3003 FORMAT('HHHH',A4,2X,
     $  57H--IN-- Entalpia                                          )
      RETURN
      END
C
C
C
      SUBROUTINE TTTTI4 (IOB,MOD)
      COMMON/TTTT01/IBLOC
      COMMON/TTTT02/NCEL,NPAR
      CHARACTER*4 IOB, MOD, IBLOC*8
C
      WRITE(IBLOC,1)MOD,IOB
    1 FORMAT(2A4)
      RETURN
      END
C
C
C
      SUBROUTINE TTTTD1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
C----significato delle variabili di uscita
C   SIGNEQ = DESCRIZIONE DELL'EQUAZIONE (IN STAZIONARIO) - 50 CAR.
C   UNITEQ = UNITA` DI MISURA DEL RESIDUO - 10 CAR.
C   COSNOR = COSTANTE DI NORMALIZZAZIONE DEL RESIDUO IN STAZIONARIO
C   ITOPVA = TOPOLOGIA JACOBIANO DI REGIME - matrice di INTEGER
C
C---temperatura di p ed h
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0
      CHARACTER *8 BLOCCO, SYMVAR(*)
      CHARACTER *(*) SIGNEQ(*), UNITEQ(*)
      DIMENSION DATI(*), XYU(*), COSNOR(*), ITOPVA(MXT,*)
C
C$*$
C
C DATI RELATIVI ALL'EQUAZIONE ALGEBRICA RESIDUO TTTT
C
C---descrizione equazione TTTT in stazionario (max. 50 car)
C      SIGNEQ ( 1) = 
C
C---unita` di misura residuo TTTT (max. 10 car)
C      UNITEQ ( 1) = 
C
C---costante di normalizzazione residuo TTTT in stazionario
C      COSNOR ( 1) = 
C
C---topologia jacobiano in stazionario per il residuo TTTT
C------dipendenza dalla variabile TTTT
      ITOPVA ( 1, 1) = 1
      RETURN
      END
