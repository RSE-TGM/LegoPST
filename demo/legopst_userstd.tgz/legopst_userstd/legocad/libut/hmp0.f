C***********************************************************************
C*                                                                     *
C*                   CESI RICERCA    October 2007                      *
C*                                                                     *
C*                      Heavy Metal Pipe rel.0                         *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE HMP0I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMP001/IBLOC
      COMMON/HMP002/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'HMP0'/
C
      CALL HMP0I4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
C
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HM',I2,A4,2X,'--US-- ENTALPIA MEDIA FLUIDO', 
     1' CELLA ',I2,' TUBO')
   20 CONTINUE
C
      DO 30 K=1,NCEL-1
      WRITE(IFO,3001)K,IOB,K
 3001 FORMAT('PU',I2,A4,2X,'--US-- PRESSIONE FLUIDO', 
     1' USCITA CELLA ',I2,' TUBO')
   30 CONTINUE
      WRITE(IFO,3101)IOB
 3101 FORMAT('PUTU',A4,2X,'--US-- PRESSIONE FLUIDO USCITA TUBO')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('WITU',A4,2X,'--US-- PORTATA FLUIDO INGRESSO TUBO')
      DO 40 K=2,NCEL
      WRITE(IFO,3002)K,IOB,K
 3002 FORMAT('WI',I2,A4,2X,'--US-- PORTATA FLUIDO INGRESSO CELLA ',I2)
   40 CONTINUE
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3013)J,K,IOB,J,K
 3013     FORMAT('TL',I1,I1,A4,2X,'--UA-- Lead Temperature - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
          WRITE(IFO,3023)J,K,IOB,J,K
 3023     FORMAT('GL',I1,I1,A4,2X,'--UA-- Heat Transfer Coefficient - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
        END DO
      END DO
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3003)J,K,IOB,J,K
 3003     FORMAT('QT',I1,I1,A4,2X,'--UA-- POTENZA SCAMBIATA', 
     1           ' PARETE ',I1,' CELLA ',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3014)IOB
 3014 FORMAT('HITI',A4,2X,'--UA-- ENTALPIA FLUIDO IGRESSO TUBO - W<0' )
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('HOLD',A4,2X,'--UA-- ENTALPIA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HILD',A4,2X,'--IN-- ENTALPIA FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('PITU',A4,2X,'--IN-- PRESSIONE FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WUTU',A4,2X,'--IN-- PORTATA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('HDLC',A4,2X,'--IN-- ENTALPIA FLUIDO USCITA TUBO',
     1' (INVERSIONE PORTATA)')
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,4003)J,K,IOB,J,K
 4003     FORMAT('TW',I1,I1,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA ' 
     1           ,I1,' CELLA',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO TUBO')
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0I4(IOB,MOD)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      COMMON/HMP001/IBLOC
      COMMON/HMP002/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
    1 WRITE(6,1000)NPMAX
 1000 FORMAT(//10X,'TUBAZIONE SENZA PARETE METALLICA CON SCAMBIO '//10X
     $ ,'NUMERO DI PARETI DI SCAMBIO PER OGNI CELLA (MAX = ',I2,') ?')
      READ(5,*) NPAR
      IF(NPAR.GE.1.AND.NPAR.LE.NPMAX)GO TO 3
      WRITE(6,1004) NPAR
 1004 FORMAT(/10X,'ERRORE - N. PARETI =',I3)
      GO TO 1
    3 CONTINUE
      WRITE(6,1003) NCMAX
 1003 FORMAT(//10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.NCMAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
    5 CONTINUE
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER VAR
      INTEGER CMSL,FluidIndex
      LOGICAL JPB,JPB1,JLEAD,JLBE,JLBE1,JNA,JNA1,JSODIUM
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      DIMENSION NTUB(NCMAX),DIAI(NCMAX),HLU(NCMAX),DZE(NCMAX)
      DIMENSION FLOWSEC(NCMAX),EHYD(NCMAX),VOL(NCMAX)
      DIMENSION RTNUMB(NCMAX),RODDIAM(NCMAX),RTLENG(NCMAX),RTSUP(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX),HeadLossIndex(NCMAX)              
      DIMENSION RODLPITCH(NCMAX)              
      DIMENSION ROUGHNESS(NCMAX),HTCS(NCMAX),SUP(NPMAX,NCMAX)                                      
      DIMENSION ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),DB(NCMAX)                                
      DIMENSION GT(NCMAX),GD(NCMAX),GR(NCMAX)                       
      DIMENSION DELTAA(NCMAX),DD(NCMAX),HB(NCMAX),ASpacer(NCMAX)                             
      CHARACTER*6 NT,ND,NL,NZ,NR,SP(NPMAX)                                  
C      CHARACTER*6 NT,ND,NL,NZ,NR,SP                                 
      CHARACTER*6 RTN,RTD,RTL,RTDZ,HLC,FluidT,ROUGH
      CHARACTER*7 RTP, RLP                                
      CHARACTER*10 FluidType                                
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA FluidT/'Fluid '/
      DATA RTN/'RodsNb'/,RTD/'RodExD'/,RTL/'RodLen'/                 
      DATA RTP/'RodTPit'/ ,RTDZ/'RodDZ '/,RLP /'RodLPit'/               
      DATA NT/'ChanNb'/,ND/'ChnExD'/,NL/'ChnLen'/,NZ/'ChanDZ'/          
      DATA HLC/'HLossS'/ ,ROUGH/'Roughn'/              
      DATA NR/'HTCorS'/SP(1)/'HTSur1'/,SP(2)/'HTSur2'/,SP(3)/'HTSur3'/
      DATA SP(4)/'HTSur4'/,SP(5)/'HTSur5'/,SP(6)/'HTSur6'/
C                    
C     RodTPit - Rod Transverse Pitch
C     RodLPit - Rod Longitudinal Pitch                                          
C      WRITE(6,*) ' Inizio I2'
C-----------------------------------------------------                                                    
      NCEL=NSTATI/3                                                     
      NPAR=(NUSCIT-2)/NSTATI
C                                                                       
      NN0=IV1-1                                                         
      NN1=NCEL+IV1-1                                                    
      NN2=2*NCEL+IV1-1                                                  
      NN3=3*NCEL+IV1-1                                                  
      NEQ=NSTATI+NUSCIT                                          
C                                                                       
C      WRITE(6,*) 'NSTATI ',NSTATI,' NUSCIT ',NUSCIT,' NINGRE',NINGRE                                                    
C      WRITE(6,*) 'IFUN ',IFUN                                                  
C       WRITE(6,*) ' NPAR',NPAR
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C                                                                       
   1  CONTINUE                                                          
      WRITE(14,3700)
 3700 FORMAT ('*   Heavy Metal Selection : Lead, LBE, Sodium')
      WRITE(14,'(4X,A6,A4,10X,A1)')FluidT,'   =','*'
      WRITE(14,3800)
 3800 FORMAT ('*   -')
      WRITE(14,3900)
 3900 FORMAT ('*   Channel Model Selection :')
      WRITE(14,4000)                                                 
 4000 FORMAT ('*   0 --> Cilindrical pipe - Tubes bundle' )
      WRITE(14,4001)
 4001 FORMAT ('*   1 --> Parallel interstitial flow - tubes / ',
     $                      'fuel rods arranged in concentric annulus') 
      WRITE(14,4002)
 4002 FORMAT ('*   2 --> Parallel interstitial flow - tubes / ',
     $                       'fuel rods arranged in triangular arrays')
      WRITE(14,4003)
 4003 FORMAT ('*   3 --> Parallel interstitial flow - tubes / ',
     $                           'fuel rods arranged in square arrays')
      WRITE(14,5001)
 5001 FORMAT ('*   4 --> Cross interstitial flow - tubes / ',
     $               'fuel rods arranged in a staggered configuration')
      WRITE(14,4004)
 4004 FORMAT (4X,'ChanMdSl =',10X,'*')
      DO 5 I=1,NCEL                                                     
        WRITE(14,4005)
 4005   FORMAT ('*   -')
        WRITE(14,1002)I 
        WRITE(14,4006)
 4006   FORMAT ('*   Fuel rods data')
        WRITE(14,1013) RTN,I,RTD,I,RTL,I,RTP,I,RLP,I,RTDZ,I       
 1013   FORMAT(3(4X,A7,I1,' =',10X,'*'),5X)          
        WRITE(14,4007)
 4007   FORMAT ('*   Heavy metal channel data')
        WRITE(14,1013) NT,I,ND,I,NL,I,NZ,I,ROUGH,I,NR,I
     $               ,(SP(J),I,J=1,NPAR)
C        WRITE(14,1014)(SP(J),I,J=1,NPAR) 
C 1014   FORMAT(3(4X,A6,I2,' =',10X,'*'),5X)                               
        WRITE(14,1013)HLC,I
        WRITE(14,4008)
 4008   FORMAT ('*   Local pressure drop data')
        WRITE(14,4009)
 4009 FORMAT ('*     1 - Entrance into a straight tube of constant ',
     $        'cross section')
        WRITE(14,4010)
 4010 FORMAT ('*         Th - [m] Thickness of the entrance ')
        WRITE(14,4011)
 4011 FORMAT ('*         B  - [m] Distance of the entrance from the '
     $                                                        ,'wall')
        WRITE(14,1100) 'Th ',I,' [m] =','B  ',I,' [m] ='
 1100 FORMAT(3(4X,A3,I1,A6,10X,'*'),5X)     
        WRITE(14,4012)
 4012 FORMAT ('*     2-5 - Changes of the stream direction ',
     $        '- single, S-shaped and U-shaped bends')
        WRITE(14,4013)
 4013 FORMAT ('*         Delta B - [�] angle of the bend ')
        WRITE(14,4014)
 4014 FORMAT ('*         RC0     - [m] average radius of curvature')
        WRITE(14,4015)
 4015 FORMAT ('*         Db      - [m] distance between the bends')
        WRITE(14,1101)I,I,I
 1101 FORMAT(4X,'Delta B',I1,' =',10X,'*',4X,'RC0 ',I1,'[m] =',10X,'*',
     $       4X,'Db ',I1,' [m] =',10X,'*',5X)
        WRITE(14,4016)
 4016 FORMAT ('*     6-8 - Flanged joint with gasket, Sudden expansion,'
     $        ,' Sudden contraction ')
        WRITE(14,4017)
 4017 FORMAT ('*         GT - [m] gasket thickness ')
        WRITE(14,4018)
 4018 FORMAT ('*         GD - [m] gasket diameter, Exp/Contr. diameter')
        WRITE(14,4019)
 4019 FORMAT ('*         GR - [m] gasket roughness')
       WRITE(14,1100)'GT ',I,' [m] =','GD ',I,' [m] =','GR ',I,' [m] =' 
        WRITE(14,4020)
 4020 FORMAT ('*     9 - Discharge from a tube onto a buffle - '
     $                                 ,'Straight wall diffuser')
        WRITE(14,4021)
 4021 FORMAT ('*         Delta D - [�] angle of the diffuser ')
        WRITE(14,4022)
 4022 FORMAT ('*         DD      - [m] diffuser diameter')
        WRITE(14,4023)
 4023 FORMAT ('*         HB      - [m] distance of the buffle from the '
     $                                                     ,'diffuser')
        WRITE(14,1102) I,I,I
 1102 FORMAT(4X,'Delta D',I1,' =',10X,'*',4X,'DD ',I1,' [m] =',10X,'*',
     $       4X,'HB ',I1,' [m] =',10X,'*',5X)
       WRITE(14,4024)
 4024 FORMAT ('*     10 - Flow through spacers (Rehme reference)')
       WRITE(14,4025)
 4025 FORMAT ('*         As - [mq] Spacer projected frontal area')
        WRITE(14,1103) I
 1103 FORMAT(4X,'As [mq]',I1,' =',10X,'*')
    5 CONTINUE                                                        
 1002 FORMAT('*   VOLUMETRIC NODE ',I2,'  *',55X)
 1003 FORMAT(3(4X,A8,' =',10X,'*'),5X)                               
C                                                                       
C      WRITE(6,*) ' uscita I2 con IFUN 1'                                                    
      RETURN                                                            
C                                                                      
C-----LETTURA DEI DATI                                                  
C 
   10 CONTINUE                                                         
C      WRITE(6,*) ' sto leggendo F14 -0'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 -1'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 2 FluidType'                                                    
      READ(14,'(14X,A10)') FluidType                                   
C      WRITE(6,*) ' sto leggendo F14 - 3' , FluidType                                                  
      READ(14,1004)                                                     
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 4' , FluidType                                                  
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 5'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 6 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 7 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 8 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 9 - CMSLD'                                                    
      READ(14,1004)CMSLD                                                  
C                                                                       
      DO 15 I=1,NCEL                                                    
C      WRITE(6,*) ' sto leggendo celle F14   CMSLD', CMSLD                                                   
        READ(14,1004)                                                     
        READ(14,1004)                                                     
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle in do F14'                                                    
        READ(14,1004) RTNUMB(I),RODDIAM(I),RTLENG(I),RODPITCH(I)
     $               ,RODLPITCH(I),RODTDZ(I)
C      WRITE(6,*) ' sto leggendo celle 2 F14'                                                    
        READ(14,1004)                                                     
        READ(14,1004) TUB ,DIAI(I),HLU(I),DZE(I)            
     $               ,ROUGHNESS(I),HTCS(I),(SUP(J,I),J=1,NPAR)      
        READ(14,1004)HeadLossIndex(I)                  
        NTUB(I)=TUB                                                       
C      WRITE(6,*) ' sto leggendo celle 3 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 5 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 6 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 7 F14'                                                    
        READ(14,1004)ET(I),WD(I)                                    
C      WRITE(6,*) ' ET(I),WD(I)',ET(I),WD(I)                                                   
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 9 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 10 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 11 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 12 F14'                                                    
        READ(14,1004)DELTA(I),RC0(I),DB(I)                            
C      WRITE(6,*) ' DELTA(I),RC0(I),DB(I)',DELTA(I),RC0(I),DB(I)                                                
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 15 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)GT(I),GD(I),GR(I)                                                     
C      WRITE(6,*) ' GT(I),GD(I),GR(I)',GT(I),GD(I),GR(I)                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 15 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)DELTAA(I),DD(I),HB(I)                                                     
C      WRITE(6,*) ' DELTAA(I),DD(I),HB(I)',DELTAA(I),DD(I),HB(I)                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)ASpacer(I)                                            
   15 CONTINUE                                                          
C                                                                       
C      WRITE(6,*) ' sto caricando dati righe vuote'
C      IF (RTNUMB(1).EQ.0) THEN
C	 WRITE(6,*) 'ERROR. SOME F14 DATA ARE MISSING!!'
C         STOP
C      ENDIF                                                  
      DO J=1,NCEL
        RTSUP(J)=PIGR*RODDIAM(J)*RTLENG(J)*RTNUMB(J)
C	write(6,*)'RTSUP(',J,')',RTSUP(J)
      END DO
C                                                    
      DO J=2,NCEL
        IF (RTNUMB(J).LE.0) THEN
          RTNUMB(J)=RTNUMB(J-1)                                                 
          RODDIAM(J)=RODDIAM(J-1)                                                 
          RTLENG(J)=RTLENG(J-1)                                                   
          RODPITCH(J)=RODPITCH(J-1)                                                   
          RODLPITCH(J)=RODLPITCH(J-1)                                                   
          RODTDZ(J)=RODTDZ(J-1)
	  RTSUP(J)=RTSUP(J-1)                                                 
        END IF                                         
      END DO
C                                                    
C      DO J=1,NCEL
C	write(6,*)'Dopo riassegnazione RTSUP(',J,')',RTSUP(J)
C      END DO
      IF (NTUB(1).EQ.0) THEN
	 WRITE(6,*) 'ERROR. SOME F14 DATA ARE MISSING!!'
         STOP
      ENDIF                                                  
C                                                    
      DO I=2,NCEL                                                    
        IF (NTUB(I).LE.0) THEN                                         
          NTUB(I)=NTUB(I-1)                                                 
          DIAI(I)=DIAI(I-1)                                                 
          HLU(I)=HLU(I-1)                                                   
          DZE(I)=DZE(I-1)                                                   
C          HeadLossIndex(I)=HeadLossIndex(I-1)
          ROUGHNESS(I)=ROUGHNESS(I-1)
          HTCS(I)=HTCS(I-1)                                                 
          DO J=1,NPAR
            SUP(J,I)=SUP(J,I-1)                                               
C	    write(6,*)'Prima riassegnazione sup(',J,',',I,')',SUP(J,I)
          END DO
        END IF                                         
      END DO
C                                                    
      DO I=1,NCEL                                                    
C          DO J=1,NPAR
C	    write(6,*)'Do del test sup(',J,',',I,')',SUP(J,I)
C	  END DO
        IF (SUP(1,I).LE.0.) THEN 
	  IF (CMSLD.EQ.4.) THEN
            SUP(1,I)= RTSUP(I)
C                  si assume una zona sola pari alla superficie dei tubi
C	    write(6,*)'dentro test sup(',1,',',I,')',SUP(1,I)
	  ELSE
            SUP(1,I)= (PIGR*DIAI(I)*HLU(I)*NTUB(I)+RTSUP(I))/FLOAT(NPAR)
	  END IF
           DO J=2,NPAR
            SUP(J,I)=0. !si assume una zona sola                                              
C	    write(6,*)'dentro test sup(',J,',',I,')',SUP(J,I)
          END DO
        END IF                                                 
      END DO
C
C---- Fluid index assignement
C
C
C--- SELECT CASE on CHARACTER type not supported by GNU FORTRAN ----
C
C      Select Case  (FluidType)
C        Case ("PB","Pb","pB","pb")
C          FluidIndex=1
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Lead','lead')
C          FluidIndex=1
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('LBE','Lbe','lbe')
C          FluidIndex=2
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Sodium','sodium','NA','Na','nA','na')
C          FluidIndex=3.
C          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case Default
C          FluidIndex=1
C          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
C          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
C          write(6,*)'WARNING!!! default case - Fluid Index   ='
C     $              ,FluidIndex                                             
C      End Select
CC                                           
C
       JPB=(FluidType.EQ.'PB'.OR.FluidType.EQ.'Pb')
       JPB1=(FluidType.EQ.'pB'.OR.FluidType.EQ.'pb')
       JLEAD=(FluidType.EQ.'Lead'.OR.FluidType.EQ.'lead')
       JLBE=(FluidType.EQ.'LBE'.OR.FluidType.EQ.'Lbe')
       JLBE1=(FluidType.EQ.'lbe')
       JSODIUM=(FluidType.EQ.'Sodium'.OR.FluidType.EQ.'sodium')
       JNA=(FluidType.EQ.'NA'.OR.FluidType.EQ.'Na')
       JNA1=(FluidType.EQ.'nA'.OR.FluidType.EQ.'na')
C
       IF (JPB.OR.JPB1.OR.JLEAD) THEN
          FluidIndex=1
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JLBE.OR.JLBE1) THEN
          FluidIndex=2
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JNA.OR.JNA1.OR.JSODIUM) THEN
          FluidIndex=3.
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE
          FluidIndex=1
          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
          write(6,*)'WARNING!!! default case - Fluid Index   ='
     $              ,FluidIndex                                             
       END IF                                             
CC                                           
C
C--- ---------------------------------------------------------------- ----
C
C------ General data calculation
C
C
      CMSL=INT(CMSLD)
C
      Select Case  (CMSL)
C
        Case (0)
C
          write(6,'(18x,2A)')'Channel model :  Cilindrical pipe'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            FLOWSEC(I)=PIGR/4.*DIAI(I)**2.*NTUB(I)
            PB=PIGR*DIAI(I)*NTUB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case (1)
C
          write(6,'(18x,2A)')'Channel model :  Concentric annulus'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            PIPES=PIGR/4.*DIAI(I)**2.*NTUB(I)
            RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            FLOWSEC(I)=PIPES-RODS
            PB=PIGR*DIAI(I)*NTUB(I)+PIGR*RODDIAM(I)*RTNUMB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case (2)
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
C------ Equivalent HYdraulic Diameter
C
C
        Case (3)
C
          write(6,'(18x,2A)')'Channel model :  Tubes buldles - square',
     $                       ' array arranged'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            PIPES=PIGR/4.*DIAI(I)**2.*NTUB(I)
            RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            FLOWSEC(I)=PIPES-RODS
            PB=PIGR*DIAI(I)*NTUB(I)+PIGR*RODDIAM(I)*RTNUMB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case (4)
C
          write(6,'(18x,3A)')'Channel model :  Cross interstitial flow',
     $                       ' - tubes / fuel rods arranged in a',
     $                       ' staggered configuration'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            RodTrRows=AINT(DIAI(I)/(2.*RODPITCH(I)))+1.
	    write(6,*)'RodTrRows ',RodTrRows
            TrFlSec=(2.*RODPITCH(I)-RODDIAM(I))*RTLENG(I)*(RodTrRows-1.)
C--------- Valore usato da KIT ------ start
C	    RODLPITCH(I)=0.012
C            TrFlSec=(2.*RODPITCH(I)-RODDIAM(I))*0.487*(RodTrRows-1.)
C	    write(6,*)'TrFlSec ',TrFlSec
C--------- Valore usato da KIT ------ end
C	    write(6,*)'RODLPITCH(I) ',RODLPITCH(I)
            RodDPitch=(RODPITCH(I)**2.+RODLPITCH(I)**2.)**0.5
C	    write(6,*)'RodDPitch ',RodDPitch,' XD ',RodDPitch/RODDIAM(I)
            DgFlSec=2.*(RodDPitch-RODDIAM(I))*RTLENG(I)*(RodTrRows-1.)
C--------- Valore usato da KIT ------ start
C            DgFlSec=2.*(RodDPitch-RODDIAM(I))*0.487*(RodTrRows-1.)
C--------- Valore usato da KIT ------ end
C	    write(6,*)'DgFlSec ',DgFlSec
            PIPES=PIGR/4.*DIAI(I)**2.*NTUB(I)    
            RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            IF (TrFlSec.LE.DgFlSec) THEN
              FLOWSEC(I)=TrFlSec
            ELSE
              FLOWSEC(I)=DgFlSec
            END IF
	    write(6,*)'FLOWSEC(I) ',FLOWSEC(I)
            EHYD(I)=RODDIAM(I)
C
C------ Control volume
C
            ChannelVolume=DIAI(I)*RTLENG(I)*HLU(I)*NTUB(I)
            RodTubsVolume=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            VOL(I)=ChannelVolume-RodTubsVolume
C
          END DO
C
        Case Default
C
          write(6,*)'WARNING!!! Channel model is not assigned'                                        
          write(6,*)'WARNING!!! default case - Channel model ='
     $             ,' Cilindrical pipe'                                          
          write(6,*)'WARNING!!! default case -'
     $             ,' Channel Model Selection =',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            FLOWSEC(I)=PIGR/4.*DIAI(I)**2.*NTUB(I)
            PB=PIGR*DIAI(I)*NTUB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Heat transfer surface
C
C            HTS(I)=PB**HLU(I)
C
          END DO
C
      End Select
C
C                                                                       
C
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C                                                                       
      DATI(ID2)=NCEL                                                    
      DATI(ID2+1)=NPAR                                                  
C      WRITE(6,*) ' sto caricando vettore dati'                                                    
C                                                                       
      DO 25 I=1,NCEL                                                    
        K=ID2+(7+NPAR)*(I-1)+1                                                  
C        S=PIGR*DIAI(I)*HLU(I)*NTUB(I)                                     
C        V=S*DIAI(I)/4.                                                    
C        A=V/HLU(I)                                                        
C        DATI(K+1)=V                                                       
        DATI(K+1)=VOL(I)                                                      
        DATI(K+2)=HLU(I)                                                  
C        DATI(K+3)=A                                                       
        DATI(K+3)=FLOWSEC(I)                                                       
        DATI(K+4)=DIAI(I)                                                 
C        DATI(K+5)=2.*HLU(I)/(DIAI(I)*A*A)                                 
        DATI(K+5)=FluidIndex                                
        DATI(K+6)=DZE(I)                                             
        DATI(K+7)=HTCS(I)                                                 
        DO J=1,NPAR                                               
          DATI(K+7+J)=SUP(J,I)
C	  write(6,*)'sup(',J,',',I,')',SUP(J,I)
        END DO                                                
C       write(6,*)'nel vettore dati HLU(',I,') =',HLU(I)                                              
   25 CONTINUE                                                          
C                                                                       
      ID2 = ID2+(7+NPAR)*NCEL+1                                               
C      ID2 = ID2+NCEL+1
      ID2 = ID2+NCEL
      DATI(ID2+1)=CMSLD                                             
      ID2 = ID2+1
      DO J=1,NCEL
        DATI(ID2+J)=RTNUMB(J)                                              
        DATI(ID2+NCEL+J)=RODDIAM(J)                                              
        DATI(ID2+2*NCEL+J)=RTLENG(J)                                                  
        DATI(ID2+3*NCEL+J)=RODPITCH(J)                                                
        DATI(ID2+4*NCEL+J)=RODTDZ(J)                                       
        DATI(ID2+5*NCEL+J)=HeadLossIndex(J)                                       
        DATI(ID2+6*NCEL+J)=NTUB(J)                                       
        DATI(ID2+7*NCEL+J)=ROUGHNESS(J)                                       
        DATI(ID2+8*NCEL+J)=ET(J)                                       
        DATI(ID2+9*NCEL+J)=WD(J)                                       
        DATI(ID2+10*NCEL+J)=DELTA(J)                                       
        DATI(ID2+11*NCEL+J)=RC0(J)                                       
        DATI(ID2+12*NCEL+J)=DB(J)                                       
        DATI(ID2+13*NCEL+J)=GT(J)                                     
        DATI(ID2+14*NCEL+J)=GD(J)                                       
        DATI(ID2+15*NCEL+J)=GR(J)                                       
        DATI(ID2+16*NCEL+J)=DELTAA(J)                                     
        DATI(ID2+17*NCEL+J)=DD(J)                                       
        DATI(ID2+18*NCEL+J)=HB(J)                                       
        DATI(ID2+19*NCEL+J)=ASpacer(J)                                       
        DATI(ID2+20*NCEL+J)=RODLPITCH(J)                                                
      END DO
      ID2 = ID2+21*NCEL+1                                              
C      WRITE(6,*) ' sto caricando normalizzazioni'                                                    
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
      DO I=1,NCEL                                                    
        CNXYU(NN0+I)=H0                                                   
        CNXYU(NN1+I)=P0                                                   
        CNXYU(NN2+I)=W0
      END DO                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*(I-1)*NPAR+2*J-1)=T0                                     
          CNXYU(NN3+2*(I-1)*NPAR+2*J)=GAM0
        END DO
      END DO                                      
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=W0*H0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ-2)=H0                                                     
      CNXYU(IV1+NEQ-1)=H0                                                   
C                                                                       
      CNXYU(IV1+NEQ)=H0                                                   
      CNXYU(IV1+NEQ+1)=P0                                                   
      CNXYU(IV1+NEQ+2)=W0                                                   
      CNXYU(IV1+NEQ+3)=H0                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(IV1+NEQ+3+(I-1)*NPAR+J)=T0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ+NPAR*NCEL+4)=1.                                         
C                                                                       
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.                           
C                                                                       
C*******************************                                        
      DO 45 I=1,NCEL                                                    
        TOL(NCEL+I)=.01E5/P0                                              
        TOL(2*NCEL+I)=.1/W0                                               
   45 CONTINUE                                                          
C*******************************                                        
C                                                                       
C-----STAMPE                                                            
C                                                                       
C                                                                       
      GLOBDZ=0.
      GLOBLE=0.
      DO I=1,NCEL                                                    
        GLOBDZ=GLOBDZ+DZE(I)
        GLOBLE=GLOBLE+HLU(I)
      END DO
C
      WRITE(6,3000)                                                     
C                                                                       
      DO 60 I=1,NCEL                                                    
        K=ID1+(7+NPAR)*(I-1)+1                                                  
        V= DATI(K+1)                                                      
        S= DATI(K+2)                                                      
        A= DATI(K+3)                                                      
        D=DATI(K+4)                                                       
        C=DATI(K+6)                                                       
        WRITE(6,3001) I,V,S,A,D,C,(DATI(K+7+J),J=1,NPAR)
C        do J=1,NPAR
C          SURF=DATI(K+7+J)
C	  write(6,*)'stampe sup(',J,',',I,')',SURF
C        END DO                                        
   60 CONTINUE                                                          
C                                                                       
C
      WRITE(6,'(/,10X,A,2X,A,3X,A,F10.5,A,3X,A,F10.5,A)')IBLOC1,IBLOC2
     $                               ,'Global elevation ',GLOBDZ,' [m]'
     $                               ,'Global length ',GLOBLE,' [m]'                                                     
C                                                                       
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3000 FORMAT(//,6X,'CELLA',4X,'VOLUME',10X,'LUNGHEZZA',7X,'SEZIONE',9X,      
     $          'DIAMETRO INT.   DISLIVELLO',6X,'SUPERFICI DI SCAMBIO'/)                             
 3001 FORMAT(6X,I3,5X,11(E11.4,5X)/)                                     
 3010 FORMAT(6X,3E11.4/)                                                
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
C-----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*80 SccsID
C
C---     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
C
      COMMON/REGIME/KREGIM                                              
C
      COMMON/HMP0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      EXTERNAL HMP0
C
C----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'%W%\t %I%\t %G%'/          
C
C----     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      IBLOC1X=IBLOC1
      IBLOC2X=IBLOC2
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
      NVAR=NEQ+NINGRE                                             
C                                                                       
      ISTA=HMP0ISTA05(IFUN)                                                 
C                                                                       
      GO TO (10,20,30),IFUN                                             
C
C---topologia jacobiano
C
   10 CONTINUE
C
      DO I=1,NEQ                                                     
        DO J=1,NVAR                                                    
          AJAC(I,J)=1.                                                      
        END DO
      END DO
C                                                          
      RETURN                                                            
C                                                                       
C
C---calcolo residui
C
   20 CONTINUE
C
      CALL HMP0 (IFUN,IXYU,XYU,IPD,DATI,RNI)                                   
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))                     
      IF(ISTA.NE.0) CALL HMP0STAS05(ISTA)                                   
C                                                                       
      RETURN                                                            
C  
   30 CONTINUE
C
C---calcolo jacobiano
C
C      jacobiano numerico
C
C
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      CALL HMP0JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,HMP0)
                  
C                                                                       
      RETURN                                                            
C                                                                       
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                  NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/WAD1NQ/NEQ
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      DO J=1,NCOL
        IF (J.GE.(NCEL+1).AND.J.LE.(2*NCEL).OR.J.EQ.(5*NCEL+4)) THEN
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
          VAR=VARP
C
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C       DO I=1,NRIG
C          write(6,*)'equazione ',I
C         DO J=1,NCOL
C          write(6,*)'var ',j,'J ',AJAC(I,J)
C      END DO
C      END DO
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0 (IFUN,IXYU,XYU,IPD,DATI,RNI)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
      INTEGER CMSL,FluidIndex,HLIndex
C
      REAL TK(NCMAX),QTCV(NCMAX),QCV(NPMAX,NCMAX),QTCDA(NCMAX)
      REAL QTCDB(NCMAX),HMVOL(NCMAX)
      REAL SW(NCMAX),SH(NCMAX),SP(NCMAX),GSPEED(NCMAX)
      REAL LHTC,MU(NCMAX),MUI,MUD,ROUGHNESS(NCMAX)
      REAL CP(NCMAX),BETAP(NCMAX),UQ(NCMAX)
      REAL A0(NCMAX),B0(NCMAX),B1(NCMAX),DET(NCMAX)                                   
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
      DIMENSION RTLENG(NCMAX),RODLPITCH(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX)             
      DIMENSION EHYD(NCMAX),HeadLossIndex(NCMAX)            
C
      COMMON/HMP0PARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/HMP0TERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/HMP0MEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/HMP0DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/HMP0PRESSDROP/ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),
     $                     DB(NCMAX),GT(NCMAX),GD(NCMAX),GR(NCMAX),
     $                     DELTAA(NCMAX),DD(NCMAX),HB(NCMAX)
      COMMON/HMP0LOCFC/RTNUMB(NCMAX),RODDIAM(NCMAX),SUBCHNUM(NCMAX)
     $                ,DIAI(NCMAX),ASpacer(NCMAX)
      COMMON/HMP0LACANES/ FRICF(NCMAX),FFXLD(NCMAX),CSILOC(NCMAX)
     $                   ,CFC(NCMAX),EHYD,MU                                  
C                                                                       
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
C                                                                       
C      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
C      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C                                                                       
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA GA/9.81/                                              
C                                                                       
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)
      NNN=NCEL+1                                                        
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
C                                                                       
C--------- Data ------                                                         
C                                                                       
      DO I=1,NCEL                                                    
        K3=IPD+(7+NPAR)*(I-1)+1                                                 
        V(I)=DATI(K3+1)                                                   
        HLU(I)=DATI(K3+2)                                                 
C        AREA(I)=DATI(K3+3)                                                
        DIAI(I)=DATI(K3+4)                                                
C        CKF(I)=DATI(K3+5)                                                 
        FluidIndex=DATI(K3+5)                                                 
CX      write(6,*)'da vettore dati FluidIndex(',I,') =',FluidIndex                                              
C        write(6,*)'da vettore dati FluidIndex(',K3+5,') =',DATI(K3+5)                                              
        DZ(I)=DATI(K3+6)                                                 
        HTCS(I)=DATI(K3+7)                                                
        DO J=1,NPAR                                               
          SUP(J,I)=DATI(K3+7+J)
        END DO                                               
C        write(6,*)'da vettore dati HLU(',I,') =',HLU(I)                                              
      END DO                                               
C                                                    
      KD=IPD+(7+NPAR)*NCEL+1
C                                                  
C      KD=KD+NCEL+1
      KD=KD+NCEL
      CMSL=INT(DATI(KD+1))                                             
      KD=KD+1
CX          write(6,*)'CMSL =',CMSL
C                                              
      DO J=1,NCEL
        RTNUMB(J)=DATI(KD+J)                                              
        RODDIAM(J)=DATI(KD+NCEL+J)                                              
        RTLENG(J)=DATI(KD+2*NCEL+J)                                                  
        RODPITCH(J)=DATI(KD+3*NCEL+J)                                              
        RODTDZ(J)=DATI(KD+4*NCEL+J)                                      
        HeadLossIndex(J)=DATI(KD+5*NCEL+J)                                      
        SUBCHNUM(J)=DATI(KD+6*NCEL+J)                                      
        ROUGHNESS(J)=DATI(KD+7*NCEL+J)                                      
        ET(J)=DATI(KD+8*NCEL+J)                                       
        WD(J)=DATI(KD+9*NCEL+J)                                       
        DELTA(J)=DATI(KD+10*NCEL+J)                                       
        RC0(J)=DATI(KD+11*NCEL+J)                                       
        DB(J)=DATI(KD+12*NCEL+J)                                       
        GT(J)=DATI(KD+13*NCEL+J)                                     
        GD(J)=DATI(KD+14*NCEL+J)                                       
        GR(J)=DATI(KD+15*NCEL+J)                                       
        DELTAA(J)=DATI(KD+16*NCEL+J)                                     
        DD(J)=DATI(KD+17*NCEL+J)                                       
        HB(J)=DATI(KD+18*NCEL+J)                                       
        ASpacer(J)=DATI(KD+19*NCEL+J)                                       
        RODLPITCH(J)=DATI(KD+20*NCEL+J)                                       
      END DO
CX      DO J=1,NCEL
C          write(6,*)'RTNUMB (',J,')=',RTNUMB(J)                                              
C          write(6,*)'RTDIAM (',J,')=',RODDIAM(J)                                             
C          write(6,*)'RTLENG (',J,')=',RTLENG(J)                                             
C          write(6,*)'RTPITCH (',J,')=',RODPITCH(J)                                             
C          write(6,*)'RODTDZ (',J,')=',RODTDZ(J)                                             
CX          write(6,*)'HeadLossIndex (',J,')=',HeadLossIndex(J)                                             
C          write(6,*)'SUBCHNUM (',J,')=',SUBCHNUM(J)                                             
CX          write(6,*)'ROUGHNESS (',J,')=',ROUGHNESS(J)                                             
CX          write(6,*)'ET (',J,')=',ET(J)                                              
CX          write(6,*)'WD (',J,')=',WD(J)                                             
CX          write(6,*)'DELTA (',J,')=',DELTA(J)                                             
CX          write(6,*)'RC0 (',J,')=',RC0(J)                                             
CX          write(6,*)'DB (',J,')=',DB(J)                                             
CX          write(6,*)'GT (',J,')=',GT(J)                                             
CX          write(6,*)'GD (',J,')=',GD(J)                                             
CX          write(6,*)'GR (',J,')=',GR(J)                                             
CX          write(6,*)'DELTAA (',J,')=',DELTAA(J)                                             
CX          write(6,*)'DD (',J,')=',DD(J)                                             
CX          write(6,*)'HB (',J,')=',HB(J)                                             
CX      END DO
C                                                                       
C
C----   Output variables
C
      K5=IXYU-1                                                         
      K6=IXYU-1+NCEL                                                        
      K7=IXYU-1+2*NCEL                                                        
      K8=IXYU-1+3*NCEL                                                        
C
      DO I=1,NCEL                                                    
        HM(I)=XYU(K5+I)*H0                                                   
        P(I+1)=XYU(K6+I)*P0                                                  
        WI(I)=XYU(K7+I)*W0                                                    
        DO J=1,NPAR                                                    
          TLP(J,I)=XYU(K8+2*(I-1)*NPAR+2*J-1)*T0                                     
          GL(J,I)=XYU(K8+2*(I-1)*NPAR+2*J)*GAM0
          QT(J,I)=XYU(K8+2*NCEL*NPAR+(I-1)*NPAR+J)*W0*H0                                     
C          write(6,*)'TLP (',J,',',I,')=',TLP(J,I)                                              
C          write(6,*)'GL (',J,',',I,')=',GL(J,I)                                              
C          write(6,*)'QT (',J,',',I,')=',QT(J,I)                                              
        END DO                                                                                         
      END DO                                                                                         
      HITI=XYU(IXYU+NEQ-2)*H0                                             
      HOLD =XYU(IXYU+NEQ-1)*H0                                              
C
C----   Input variables
C
      HILD  =XYU(IXYU+NEQ)*H0                                                
      P(1)=XYU(IXYU+NEQ+1)*P0                                              
      WI(NNN)=XYU(IXYU+NEQ+2)*W0                                            
      HDLC=XYU(IXYU+NEQ+3)*H0                                                
C
      DO I=1,NCEL
       DO J=1,NPAR                                                    
         TW(J,I)=XYU(IXYU+NEQ+3+(I-1)*NPAR+J)*T0                                    
C          write(6,*)'TW (',J,',',I,')=',TW(J,I)                                              
       END DO                                                                                         
      END DO                                                                                         
C
      CF=XYU(IXYU+NEQ+NPAR*NCEL+4)                                      
C        write(6,*)'CF =',CF                                              
C
C
C------ Equivalent HYdraulic Diameter, Liquid Metal Volume and Mass speed @*v
C
      SELECT CASE (CMSL)
C
         CASE (0)
C
            DO I=1,NCEL
              EHYD(I)=DIAI(I)
              FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
              HMVOL(I)=FLOWSEC(I)*HLU(I)
              GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
CX            write(6,*)'Case 0  ','EHYD (',I,')=',EHYD(I)                                             
CX            write(6,*)'Case 0  ','FLOWSEC (',I,')=',FLOWSEC(I)                                             
CX            write(6,*)'Case 0  ','HMVOL (',I,')=',HMVOL(I)                                             
CX            write(6,*)'Case 0  ','GSPEED (',I,')=',GSPEED(I)                                             
C$           CASE (1)
C$            RPITCH=RODPITCH(I)/RODDIAM(I)
C$            EHYD(I)=RODDIAM(I)*(2.*3.**0.5/PIGR*RPITCH**2.-1.)
C$            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
C$            SUBCHSEC=3.**0.5/4.*RODPITCH(I)*RODPITCH(I)
C$            FLOWSEC(I)=(SUBCHSEC-0.5*RODSEC)*SUBCHNUM(I)
C$            HMVOL(I)=FLOWSEC(I)*HLU(I)
C$            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C$        write(6,*)'FLOWSEC (',I,')=',FLOWSEC(I),'WI (',I,')=',WI(I)                                              
C$        write(6,*)'SUBCHNUM (',I,')=',SUBCHNUM(I)                                              
C$        write(6,*)'GSPEED (',I,')=',GSPEED(I)                                             
C$          CASE (2)
C$            RPITCH=RODPITCH(I)/RODDIAM(I)
C$            EHYD(I)=RODDIAM(I)*(4./PIGR*RPITCH**2.-1.)
C$            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
C$            SUBCHSEC=RODPITCH(I)*RODPITCH(I)
C$            FLOWSEC(I)=(SUBCHSEC-RODSEC)*SUBCHNUM(I)
C$            HMVOL(I)=FLOWSEC(I)*HLU(I)
C$            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
            END DO
C
C
         CASE (1)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
C            write(6,*)'Case 1  ','FLOWSEC (',I,')=',FLOWSEC(I)                                             
           END DO
C
C
         CASE (2)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
           END DO
C
C
         CASE (3)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
           END DO
C
        Case (4)
C
C        Channel model :  Cross interstitial flow',
C    $                       ' - tubes / fuel rods arranged in a',
C    $                       ' staggered configuration'                                          
C         write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            RodTrRows=AINT(DIAI(I)/(2.*RODPITCH(I)))+1.
C	    write(6,*)'RodTrRows 2',RodTrRows
            TrFlSec=(2.*RODPITCH(I)-RODDIAM(I))*RTLENG(I)*(RodTrRows-1.)
C	    write(6,*)'TrFlSec 2',TrFlSec
C-------  valori usati da KIT --------- start
C	    RODLPITCH(I)=0.012
C            TrFlSec=(2.*RODPITCH(I)-RODDIAM(I))*0.487*(RodTrRows-1.)
C-------  valori usati da KIT --------- end
C	    write(6,*)'RODLPITCH(I) ',RODLPITCH(I)
            RodDPitch=(RODPITCH(I)**2.+RODLPITCH(I)**2.)**0.5
C	    write(6,*)'RodDPitch 2',RodDPitch,' XD',RodDPitch/RODDIAM(I)
            DgFlSec=2.*(RodDPitch-RODDIAM(I))*RTLENG(I)*(RodTrRows-1.)
C-------  valori usati da KIT --------- start
C            DgFlSec=2.*(RodDPitch-RODDIAM(I))*0.687*(RodTrRows-1.)
C-------  valori usati da KIT --------- end
C	    write(6,*)'DgFlSec 2',DgFlSec
            IF (TrFlSec.LE.DgFlSec) THEN
              FLOWSEC(I)=TrFlSec
            ELSE
              FLOWSEC(I)=DgFlSec
            END IF
C	    write(6,*)'FLOWSEC(I) 2',FLOWSEC(I)
            EHYD(I)=RODDIAM(I)
C
C------ Control volume
C
            ChannelVolume=DIAI(I)*RTLENG(I)*HLU(I)*SUBCHNUM(I)
            RodTubsVolume=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
C
            HMVOL(I)=ChannelVolume-RodTubsVolume
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)
C
C-------- Conti KIT
C        write(6,*)'HMP0 HM (',I,')=',HM(I)                                            
C        CALL HMP0_FLUID_PROP(FluidIndex,HM(I),TL(I),RO(I),TK(I),MU(I)
C     $                      ,CP(I),BETAP(I),UQ(I))
C
C             FlowKIT=DIAI(I)*RTLENG(I)
C             FlowKIT=DIAI(I)*0.487
C             velKIT=ABS(WI(I))/FlowKIT/10532.
C	write(6,*)'WI(I) ',WI(I),'FlowKIT ',FlowKIT,' velKIT ',velKIT
C	write(6,*)'RO(I) ',RO(I),' vel ',WI(I)/(RO(I)*DIAI(I)*RTLENG(I))
CC
C-------- Conti KIT fine
C
          END DO
C
         CASE DEFAULT
           DO I=1,NCEL
            EHYD(I)=DIAI(I)
            FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
            HMVOL(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
            write(6,*)'WARNING!!! Channel model is not assigned'                                        
            write(6,*)'WARNING!!! default case - Channel model ='
     $               ,' Cilindrical pipe'                                          
            write(6,*)'WARNING!!! default case -'
     $               ,' Channel Model Selection =',CMSL                                             
C
           END DO
C
        END SELECT
C
C
C
CC      DO I=1,NCEL
CC        CKF(I)=2.*HLU(I)/(EHYD(I)*FLOWSEC(I)*FLOWSEC(I))                                 
CC        write(6,*)'CKF (',I,')=',CKF(I)                                             
CC      END DO
C
C----------- Heavy Metal Physical properties
C
C-----------   TK ---> Thermal Conductivity                                                                      
C-----------   RO ---> Density                                                                      
C-----------   DRODH ---> d@/dh                                                                      
C                                    
      DO I=1,NCEL
C
C        write(6,*)'HMP0 HM (',I,')=',HM(I)                                            
        CALL HMP0_FLUID_PROP(FluidIndex,HM(I),TL(I),RO(I),TK(I),MU(I)
     $                      ,CP(I),BETAP(I),UQ(I))
C
C        TL(I)=T_H_LEAD(HM(I))
C        write(6,*)'HMP0 TL (',I,')=',TL(I)                                              
C        RO(I)=RO_T_LEAD(TL(I))                                            
C        write(6,*)'RO (',I,')=',RO(I)                                              
C        DRODH(I)=DRODH_LEAD(HM(I))
C        write(6,*)'DRODH (',I,')=',DRODH(I)                                              
C        TK(I)=TC_H_LEAD(HM(I))
C        MU(I)=MU_T_LEAD(TL(I))
CX       write(6,*)'TL(',I,')=',TL(I),' MU=',MU(I) ,'TK=',TK(I)                                              
CX       write(6,*)'RO(',I,')=',RO(I),' CP=',CP(I) ,'BETAP=',BETAP(I)                                              
CX       write(6,*)'UQ(',I,')=',UQ(I)                                              
      END DO                                  
C
C      TDLC=T_H_LEAD(HDLC)                                               
C      TILD=T_H_LEAD(HILD)                                               
CX      write(6,*)'Prima di FLUID_PROP FluidIndex= ',FluidIndex                                              
      CALL HMP0_FLUID_PROP(FluidIndex,HILD,TILD,ROI,TKI,MUI
     $                     ,CPI,BETAPI,UQI)
      CALL HMP0_FLUID_PROP(FluidIndex,HDLC,TDLC,ROD,TKD,MUD
     $                     ,CPD,BETAPD,UQD)
CX        write(6,*)'Dopo di FLUID_PROP '                                             
C
C
C----------- Friction factor
C                                                                       
      DO I=1,NCEL
        IF (GSPEED(I).NE.0.) THEN
          RE=ABS(GSPEED(I))*EHYD(I)/MU(I)
        ELSE
          RE=.0001*EHYD(I)/MU(I)
        END IF                                               
        FRICF0=0.3164/RE**0.25                                                
CX           write(6,*)'EHYD(',I,')=',EHYD(I),'RE=',RE                                              
C           write(6,*)'EHYD(',I,')=',EHYD(I)                                          
C
        SELECT CASE (CMSL)
C
          CASE (0)
C
CX        write(6,*)'Prima di MOODY_FF '                                          
            CALL HMP0_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                        ,FRICF(I))
            HLIndex=AINT(HeadLossIndex(I))                                              
CX        write(6,*)'Dopo di MOODY_FF HLIndex=',HLIndex                                          
            CALL HMP0_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I)
     $                      ,CSILOC(I))
            FFXLD(I)=FRICF(I)*HLU(I)/EHYD(I)                                          
            CFC(I)=FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
CX        write(6,*)'Dopo di LOC_FC '                                          
C
          CASE (1)
C
            IF (SUBCHNUM(I).EQ.1..AND.RTNUMB(I).EQ.1.) THEN
C
C----------- Concentric Annulus
C                                                                       
              CALL HMP0_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
              ICA=101
C
              CALL HMP0_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
              FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
              HLIndex=AINT(HeadLossIndex(I))                                              
C
              CALL HMP0_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
              CFC(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
             ELSE
C
              CALL HMP0_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
              ICA=101
C
              CALL HMP0_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
              FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
              HLIndex=AINT(HeadLossIndex(I))                                              
C
              CALL HMP0_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
              CFC(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
C                                            
             END IF 
C                                            
          CASE (2)
C
C----------- Triangular Array
C                                                                       
             CALL HMP0_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
             ICA=101
C
             CALL HMP0_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
C             FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
             ATR=0.58*(1.-EXP(-70.*(RPITCH-1.)))+9.2*(RPITCH-1.)
             DELTATR=0.57+0.18*(RPITCH-1.)+0.53*(1-EXP(-ATR))
C
             FFXLD(I)=XK2R*FRICF(I)*DELTATR*HLU(I)/EHYD(I)
C
C             CFC(I)=FRICF0*DELTATR                                               
C
             HLIndex=AINT(HeadLossIndex(I))                                              
C
             CALL HMP0_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
             CFC(I)=XK2R*FRICF(I)*DELTATR*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
          CASE (3)
C
C----------- Square Array
C                                                                       
            CALL HMP0_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
            ICA=101
C
            CALL HMP0_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
            DELTASQ=0.59+0.19*(RPITCH-1.)+0.52*(1-EXP(10.*(RPITCH-1.)))
C
            FFXLD(I)=XK2R*FRICF(I)*DELTASQ*HLU(I)/EHYD(I)
C
            HLIndex=AINT(HeadLossIndex(I))                                              
C
            CALL HMP0_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
            CFC(I)=XK2R*FRICF(I)*DELTASQ*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
C
          CASE (4)
C
C----------- Cross flow - staggered array
C                                                                       
            CALL HMP0_ZUKAUSKAS_FF(RODPITCH(I),RODLPITCH(I),EHYD(I),
     $                         GSPEED(I),MU(I),FRICF(I))
C
C-------  Number of Rod/Tube rows in the direction of flow
C
            RodRowsLong=HLU(I)/RODLPITCH(I)+1.
C            RodRowsLong=4.
C
            CFC(I)=FRICF(I)*RodRowsLong
C	    write(6,*)'RodRowsLong ',RodRowsLong,'CFC(I) ', CFC(I)
C
          CASE DEFAULT
            CFC(I)=FRICF0                                             
        END SELECT
      END DO        
C
C
C
C----------- Heat Transfer Coefficient
C                                                                       
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
CX          write(6,*)'prima di IF HTCS(',I,')=',HTCS(I)                                              
          IF (HTCS(I).LT.0.) THEN
C            CALL HMP0_UHTC(HTCS(I),TL(I),RODPITCH(I),RODDIAM(I)
C     $                                    ,GSPEED(I),EHYD(I),LHTC(J,I))
          ELSE
CX           write(6,*)'prima di chiamare HMP0_HTC HTCS(',I,')=',HTCS(I)                                              
CXX        write(6,*)'prima di chiamare HMP0_HTC HM (',I,')=',HM(I)                                              
            CALL HMP0_HTC(HTCS(I),RODPITCH(I),RODDIAM(I),GSPEED(I)
     $                         ,EHYD(I),TK(I),MU(I),CP(I),LHTC(J,I))
CXX           write(6,*)'LHTC (',J,',',I,')=',LHTC(J,I)                                              
          END IF        
        END DO        
      END DO        
C
C
CXX        write(6,*)' Convective Heat Transfer'                                          
C----------- Convective Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        QTCV(I)=0.
        DO J=1,NPAR
          QCV(J,I)=LHTC(J,I)*SUP(J,I)*(TL(I)-TW(J,I))
          QTCV(I)=QTCV(I)+QCV(J,I)
        END DO        
      END DO        
C
CXX        write(6,*)' Conductive Heat Transfer'                                          
C
C----------- Conductive Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        IF (I.LT.NCEL) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I+1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I+1)/TK(I+1))
          QTCDA(I)=-GHTC*HTS*(TL(I)-TL(I+1))
C        write(6,*)'GHTC =',GHTC ,'HTS =',HTS ,'TL (',I,')=',TL(I)                                              
C        write(6,*)'TK (',I,')=',TK(I),'HLU (',I,')=',HLU(I)                                              
        ELSE
          QTCDA(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TDLC)/(HLU(I)/2.)
        END IF
        IF (I.GT.1) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I-1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I-1)/TK(I-1))
          QTCDB(I)=-GHTC*HTS*(TL(I)-TL(I-1))
        ELSE
          QTCDB(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TILD)/(HLU(I)/2.)
        END IF
      END DO        
C
C
CXX        write(6,*)' Conservation Equations'                                          
C---------- Conservation Equations' Constants and coefficient 
C
C---------- Sw ---->  Mass Conservation
C---------- Sp ---->  Momentum Conservation
C---------- Sh ---->  Energy Conservation
C
      DO I=1,NCEL
        A0(I)=HMVOL(I)*(1./UQ(I)+BETAP(I)/CP(I))
        B0(I)=RO(I)*HMVOL(I)*BETAP(I)/CP(I)
        B1(I)=RO(I)*HMVOL(I)
        DET(I)=A0(I)*B1(I)-B0(I)*HMVOL(I)
C
        SW(I)=WI(I)-WI(I+1)
        SIG2=FLOWSEC(I)*FLOWSEC(I)                                 
CX        write(6,*)'SIG2 (',I,')=',SIG2
        DPDARCY=CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
CX        write(6,*)'DPDARCY (',I,')=',DPDARCY
        IF (I.EQ.1) THEN
          SP(I)=(WI(I)*WI(I)/ROI-WI(I+1)*WI(I+1)/RO(I))/SIG2+P(I)-P(I+1)
     $          -CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
     $          -RO(I)*DZ(I)*GA
CX        write(6,*)'SP (',I,')=',SP(I)
        ELSE
          SP(I)=(WI(I)*WI(I)/RO(I-1)-WI(I+1)*WI(I+1)/RO(I))/SIG2
     $          -CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
     $          +P(I)-P(I+1)-RO(I)*DZ(I)*GA
CX        write(6,*)'SP (',I,')=',SP(I)
        END IF
        IF (WI(I).GE.0.) THEN
          IF (I.EQ.1) THEN
            SHI=WI(I)*(HILD-HM(I))
          ELSE
            SHI=WI(I)*(HM(I-1)-HM(I))
          END IF
        ELSE
          SHI=0.
        END IF
C
        IF (WI(I+1).LE.0.) THEN
          IF (I.EQ.NCEL) THEN
            SHO=WI(I+1)*(HDLC-HM(I))
          ELSE
            SHO=WI(I+1)*(HM(I+1)-HM(I))
          END IF
        ELSE
          SHO=0.
        END IF
C
        SH(I)=SHI-SHO-QTCV(I)+QTCDA(I)+QTCDB(I)
C        SH(I)=SHI-QTCV(I)+QTCDA(I)+QTCDB(I)
      END DO
CZ      IF (IFUN.EQ.2.AND.ITERT.EQ.0) THEN
CZ        DO I=1,NCEL
CZ         write(6,*)'QTCDA(',I,')',QTCDA(I),'QTCDB(',I,')',QTCDB(I)
CZ        END DO
CZ      END IF
C
      NN2=2*NCEL
      NN3=3*NCEL
C
      IF (KREGIM) THEN                                         
        DO I=1,NCEL                                                    
          RNI(I)     =SH(I)/(W0*H0)                                     
          RNI(NCEL+I)=SP(I)/P0                                          
CXX          write(6,*)'RNI(NCEL+I)(',NCEL+I,')',RNI(NCEL+I)
          RNI(NN2+I) =SW(I)/W0                                          
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(GL(J,I)-LHTC(J,I))/GAM0         
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QT(J,I)-QCV(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0                
       ELSE
        DO I=1,NCEL                                                    
          RNI(I)     =(A0(I)*SH(I)+HMVOL(I)*SW(I))/(DET(I)*H0)                          
          RNI(NCEL+I)=(B0(I)*SH(I)+B1(I)*SW(I))/(DET(I)*P0)            
          RNI(NN2+I) =FLOWSEC(I)/HLU(I)*SP(I)/W0                           
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(LHTC(J,I)-GL(J,I))/GAM0          
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QCV(J,I)-QT(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0      
C                                                                       
       END IF
C                                                                       
      RETURN                                                            
      END                                                               
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMP0_FLUID_PROP(FluidType,H,T,RO,TK,MU,CP,BETAP,UQ)
C
      INTEGER FluidType
C
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C
      Select Case  (FluidType)
        Case (1)
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LEAD(T)
          BETAP=1.
          UQ=1.
CX          write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
        Case (2)
C         Case ('LBE')
          T=T_H_LBE(H)
          RO=RO_T_LBE(T)
          TK=TC_T_LBE(T)
          MU=MU_T_LBE(T)
          CP=CP_T_LBE(T)
          BETAP=BETAP_T_LBE(T)
          UQ=UQ_T_LBE(T)
C            write(6,*)'Case LBE ','T=',T,' MU=',MU                                        
C       Case (3)
C         Case ('Sodium')
        Case Default
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LBE(T)
          BETAP=1.
          UQ=1.
C          write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
CX        write(6,*)'Propriet� fluidi'                                             
CX        write(6,*)'RO=',RO,' CP=',CP ,'BETAP=',BETAP                                              
CX        write(6,*)'UQ=',UQ                                              
      RETURN
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0_HTC(HTCS,PITCH,D,G,DH,K,MU,CP,LHTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C     HTCS  = Heat Transfer Correlation Selection code
C     HME   = Heavy Metal Enthalpy
C     THM   = Temperature of the Heavy Metal
C     PITCH = Lattice pitch
C     D     = Rod outside diameter
C     G     = Mass speed @�V
C     DH    = Hydraulic diameter
C     LHTC  = Lead Heat Transfer Coefficient
C
C
C
C     p = lattice pitch
C     D = rod outside diameter
C
C
C     Selection Code    Correlations for outside tube flow - triangular arrays
C                                                           
C                  1    V.M. Borishanski et al.  Nu=24.151*lg[-8.12 +12.76p/D-3.65(p/D)**2]+0.0174{1-exp[-6(p/D-1)]}(Pe-200)**0.9 
C                  2    H. Graber                Nu=0.25+6.2p/D+(0.32p/D-0.07)Pe**(0.8-0.024p/D)
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles with spacers
C                                                           
C                  3    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.09Pe**(0.64+0.264p/D) 
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles without spacers
C                                                           
C                  4    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.07Pe**(0.64+0.264p/D) 
C
C
C
C     Selection Code    Correlations for outside tube flow - doesn't refer to any particular lattice
C                                                           
C                  5    H. Calamai et al.        Nu=4.+0.16(p/D)**5+0.33(p/D)**3.8(Pe/100.)**0.86
C
C
C     Selection Code    Correlations for inside tube flow 
C                                                           
C                  6    Kirillow - Stromquist    Nu=A+0.018Pe**0.8  
C                                                                | 4.5                  Pe < 1000
C                                                             A=<  5.4-0.0009Pe  1000 < Pe < 2000
C                                                                | 3.6                  Pe > 2000
C                                                           
C                  7    Lubarsky                 Nu=0.625Pe**0.4
C                                                                
C                  8    Seban - Shimazaki        Nu=5.+0.025Pe**0.8 - Pure liquid lead
C                  9                             Nu=3.3+0.014Pe**0.8 - without special purification 
C
C                 10    Babcock & Wilcox          Nu=4.03 + 0.228*Pe**0.67    Correlations for outside tube flow - helicoidal coil
C                                                                                                                - staggered arrangement
C                                                           
C
C            default    Subbotin                 Nu=7.55p/D-20(p/D)**-13+(3.67/90)(p/D)**-2Pe**(0.19p/D+0.56)
C probably used in RELAP5/PARCS
C
      INTEGER HTCSC
C
      REAL LHTC,K,MU,NU
C
      HTCSC=INT(HTCS)
C
      SELECT CASE (HTCSC)
        CASE (0)
          PD=1.
        CASE (1,2,3,4,5,6,7,8,9)
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pitch/Pin diameter not assigned'
	    write(6,*)'             Default value assumed 1.3'
            PD=1.3
	  ELSE
           PD=PITCH/D
	  END IF
        CASE DEFAULT 
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pin diameter not assigned'
	    write(6,*)'             Default value assumed 0.01 m'
            PD=1.3
	  ELSE
            PD=PITCH/D
	  END IF
      END SELECT
CXX      write(6,*)'PD= ',PD
C
C      K=TC_T_LEAD(TL)
C      write(6,*)'TL=',THM,' K=',K                                              
C      write(6,*)' routine HTC     K=',K                                              
C
C      MU=MU_T_LEAD(TL)
C      write(6,*)' routine HTC     MU=',MU                                              
C
C      CP=CP_T_LEAD(TL)
C      write(6,*)'TL=',THM,' CP=',CP                                              
C      write(6,*)' routine HTC     CP=',CP                                              
C
      RE=G*DH/MU
CXX      write(6,*)'RE= ',RE
C
      PR=MU*CP/K      
CXX      write(6,*)'PR= ',PR
C
      PE=RE*PR     
CXX      write(6,*)' routine HTC     PE=',PE                                              
C
      SELECT CASE (HTCSC)
        CASE (0)
C          write(6,*)' routine HTC  case 0   PE=',PE                                              
C          write(6,*)' PITCH,D,G,DH,K,MU,CP,LHTC='                                              
C          write(6,*) PITCH,D,G,DH,K,MU,CP,LHTC                                             
          NU=0.625*PE**0.4
C          write(6,*)' routine HTC  case 0   Nu=',NU                                              
        CASE (1)
          A0TR=-8.12 +12.76*PD-3.65*PD**2.
          A1TR=-6.*(PD-1.)
          NU=24.151*LOG(A0TR)+0.0174*(1.-EXP(A1TR))*(PE-200.)**0.9
        CASE (2)
          NU=0.25+6.2*PD+(0.32*PD-0.07)*PE**(0.8-0.024*PD)
        CASE (3)
          NU=7.55*PD-14./PD**5.-0.09*PE**(0.64+0.264*PD)
        CASE (4)
          NU=7.55*PD-14./PD**5.-0.07*PE**(0.64+0.264*PD)
C          write(6,*)' routine HTC  case 4   PE=',PE                                              
C          write(6,*)' PITCH,D,P/D,G,DH,K,MU,CP,NU='                                              
C          write(6,*) PITCH,D,PD,G,DH,K,MU,CP,NU                                             
        CASE (5)
          NU=4.+0.16*PD**5.+0.33*PD**3.8*(Pe/100.)**0.86
        CASE (6)
          IF (PE.LT.1000.) AKS=4.5
          IF (PE.GE.1000..AND.PE.LE.2000.) THEN
            AKS=5.4+0.0009*PE
          END IF
          IF (PE.GT.2000.) AKS=3.6
          NU=AKS+0.018*PE**0.8
        CASE (7)
          NU=0.625*PE**0.4
        CASE (8)
          NU=5.+0.025*PE**0.8
        CASE (9)
          NU=3.3+0.014*PE**0.8
        CASE (10)
          NU=4.03 + 0.228*Pe**0.67
C      write(6,*)' Case 10 RE=',RE,' PR=',PR,' PE=',PE  ,' NU=',NU
C          NU=1.*NU                                            
C      write(6,*)' Case 10 NU=',NU
      CASE DEFAULT 
          NU=7.55*PD-20./PD**13.+3.67/(90.*PD**2.)*PE**(0.19*PD+0.56)
C          write(6,*)' routine HTC  case default SUBBOTIN   PE=',PE                                              
C          write(6,*)' PITCH,D,P/D,G,DH,K,MU,CP,NU='                                              
C          write(6,*) PITCH,D,PD,G,DH,K,MU,CP,NU                                             
C      write(6,*)' RE=',RE,' PR=',PR,' PE=',PE  ,' NU=',NU                                            
      END SELECT
C
      LHTC=K/DH*NU
C      IF (LHTC.LT.0.1) LHTC=100.1
CXX      write(6,*)' LHTC=',LHTC                                              
C
      RETURN
      END
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE HMP0_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C  La subroutine CNDLIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  WAD1  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
      SUBROUTINE HMP0_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C CALCOLA IL LIVELLO  IN UN CILINDRO ORIZZONTALE
C
C     Y  livello diviso 100
C     YTOT livello in metri
C     SEZ  superficie del pelo libero
C NOTI:
C     VCAV  volume occupato
C     RCAV  raggio del cilindro
C     HLCAV lunghezza del cilindro
C
C ESECUZIONE
C
C
      REAL MU
C
      COMMON/HMP0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
C
      RE=GSPEED*DIA/MU
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
	FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
	  FRICF=64./RE
	ELSE
	  IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
	  IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25                                                
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
	  DO WHILE (I.LE.100)
CXXX 1 CONTINUE
            IT=IT+1
C
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
CXXX          IF(ABS(RES).LT.1.E-4)GO TO 10
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
	    END IF
	    
CXXX          IF(IT.GT.100)GO TO 20
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
C        write(6,*) 'prima di dXLGdY Y=', Y,'RE=', RE
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
CXXX          GO TO 1
          END DO
C
C   SOLUZIONE
C
CC   10 CONTINUE
          WRITE(6,1000)RES
CXXX   20 WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP0_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBLOC1X,IBLOC2X
CXXX      GO TO 10
        END IF
      END IF
      RETURN                                                            
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMP0_LOC_FC(VolIndex,HLIndex,TD,W,MU,CSILOC)
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER HLIndex,VolIndex
C
      REAL CSILOC,MU,L0SUD0,K1,KRE,LDBD,LDBD0,LDBD1
C
      PARAMETER (NFGSUFS=4,NL0SUD0=8,NK1=NFGSUFS*NL0SUD0)
      PARAMETER (NCR0SUD0=4,NRE=12,NKRE=NCR0SUD0*NRE)
      PARAMETER (NCDUMMY=2,NCR0DBD0=21,NB1=NCDUMMY*NCR0DBD0)
      PARAMETER (NCDELTA=8,NVLDBD=16,NVA=NCDELTA*NVLDBD)
      PARAMETER (NCDELTA0=3,NVLDBD0=14,NVA0=NCDELTA0*NVLDBD0)
      PARAMETER (NCDELTA1=3,NVLDBD1=14,NVA1=NCDELTA1*NVLDBD1)
      PARAMETER (NCDELTA2=11,NV1A1=NCDUMMY*NCDELTA2)
      PARAMETER (NCDELTAA=6,NVHdDh=11,NVCSI=NCDELTAA*NVHdDh)
      PARAMETER (NREYNOLD=6,NVDdD0=11,NK2R=NREYNOLD*NVDdD0)
      PARAMETER (NETsDh=11,NVBsDh=11,NECSI=NETsDh*NVBsDh)
C
      DIMENSION TABFGSUFS(NFGSUFS),TABL0SUD0(NL0SUD0),TABNK1(NK1)
      DIMENSION TABDUMMY(NCDUMMY),TABR0DBD0(NCR0DBD0),TABB1(NB1)
      DIMENSION TABR0SUD0(NCR0SUD0),TABRE(NRE),TABKRE(NKRE)
      DIMENSION TABDELTA(NCDELTA),TABLDBD(NVLDBD),TABA(NVA)
      DIMENSION TABDELTA0(NCDELTA0),TABLDBD0(NVLDBD0),TABA0(NVA0)
      DIMENSION TABDELTA1(NCDELTA1),TABLDBD1(NVLDBD1),TABA1(NVA1)
      DIMENSION TABDELTA2(NCDELTA2),TAB1A1(NV1A1)
      DIMENSION TABDELTAA(NCDELTAA),TABHdDh(NVHdDh),TABCSI(NVCSI)
      DIMENSION TABREYNOLD(NREYNOLD),TABDdD0(NVDdD0),TABK2R(NK2R)
      DIMENSION TABETsDh(NETsDh),TABBsDh(NVBsDh),TABECSI(NECSI)
C
      COMMON/HMP0DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/HMP0PRESSDROP/ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),
     $                     DB(NCMAX),GT(NCMAX),GD(NCMAX),GR(NCMAX),
     $                     DELTAA(NCMAX),DD(NCMAX),HB(NCMAX)
      COMMON/HMP0LOCFC/RTNUMB(NCMAX),RODDIAM(NCMAX),SUBCHNUM(NCMAX)
     $                ,DIAI(NCMAX),ASpacer(NCMAX)
      COMMON/HMP0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA PIG /3.141592/
C
C--------------------------------------------------------------------------
C--
C-- old interpolation coefficient for Rehme modified drag coefficient -----
C--
C--      DATA C0/4.68621626/,C1/-2.42827697/,C2/-0.809518313/,C3/2.50047/
C--
C--------------------------------------------------------------------------
C--
C-- interpolation coefficient for Rehme modified drag coefficient -----
C--
      DATA C0/-14.5172776/,C1/7.88567002/,C2/-1.38061547/,C3/23.4108852/
C--
C--------------------------------------------------------------------------
C
C
      DATA TABFGSUFS/1.6,2.3,3.2,4./
      DATA TABL0SUD0/0.0,0.5,0.6,0.7,0.8,1.,1.4,2./
      DATA TABNK1/1.0,  1.02, 1.01, 1.0,  1.0 , 1.0,  1.0,  1.0,
     $            1.0,  1.06, 1.03, 1.02, 1.01, 1.0,  1.0,  1.0, 
     $            1.0,  1.16, 1.10, 1.06, 1.04, 1.01, 1.0,  1.0,
     $            1.0,  1.20, 1.15, 1.10, 1.08, 1.04, 1.03, 1.0/
C
C
      DATA TABDUMMY/0.,1./
      DATA TABDELTA2 /0.,20.,30.,45.,60.,75.,90.,110.,130.,150.,180./
      DATA TAB1A1/0.,0.31,0.45,0.6,0.78,0.9,1.,1.13,1.2,1.28,1.4,
     $            0.,0.31,0.45,0.6,0.78,0.9,1.,1.13,1.2,1.28,1.4/
      DATA DUMMY /0.5/
C
C
      DATA TABR0DBD0/0.5,0.6,0.7,0.8,0.9,1.0,1.25,1.5,2.0,3.0,4.0,6.0
     $              ,8.0,10.,15.,20.,25.,30.,35.,40.,50./
      DATA TABB1/1.18,0.77,0.51,0.37,0.28,0.21,0.19,0.17,0.15,0.12,0.11,
     $           0.09,0.07,0.07,0.06,0.05,0.05,0.04,0.04,0.03,0.03
     $          ,1.18,0.77,0.51,0.37,0.28,0.21,0.19,0.17,0.15,0.12,0.11,
     $           0.09,0.07,0.07,0.06,0.05,0.05,0.04,0.04,0.03,0.03/
C
C
      DATA TABR0SUD0/0.5,0.65,0.75,1./
      DATA TABRE/0.1,0.14,0.2,0.3,0.4,0.6,0.8,1.,1.4,2.0,3.0,4.0/
      DATA TABKRE/1.4,1.33,1.26,1.19,1.14,1.09,1.06,1.04,1.,1.,1.,1.,
     $      1.67,1.58,1.49,1.4,1.34,1.26,1.21,1.19,1.17,1.14,1.06,1.,
     $      2.0 ,1.89,1.77,1.64,1.56,1.46,1.38,1.30,1.15,1.02,1. ,1.,
     $      2.0 ,1.89,1.77,1.64,1.56,1.46,1.38,1.30,1.15,1.02,1. ,1./
C
C
      DATA TABDELTA/0.,15.,30.,45.,60.,75.,90.,120./
      DATA TABLDBD/0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,16.,18.,20.,25.,
     $                                                         40.,50./
      DATA TABA/0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $ .2,.42,.6,.78,.94,1.16,1.2,1.15,1.08,1.05,1.02,1.,1.1,1.25,2.,2.,
     $ .4,.65,.88,1.16,1.2,1.18,1.12,1.06,1.06,1.15,1.28,1.4,
     $                                                    1.5,1.7,2.,2.,
     $ .6,1.06,1.2,1.23,1.2,1.08,1.03,1.08,1.17,1.3,1.42,1.55
     $                                                  ,1.65,1.8,2.,2.,
     $1.05,1.38,1.37,1.28,1.15,1.06,1.16,1.3,1.42,1.54,1.66,
     $                                             1.76,1.85,1.95,2.,2.,
     $1.5,1.58,1.46,1.3,1.27,1.3,1.37,1.47,1.57,1.68,1.75,1.8,
     $                                                  1.88,1.97,2.,2.,
     $1.7,1.67,1.4,1.37,1.38,1.47,1.55,1.63,1.7,1.76,1.82,1.
     $                                               88,1.92,1.98,2.,2.,
     $1.78,1.64,1.48,1.55,1.62,1.7,1.75,1.82,1.88,1.9,1.92,
     $                                             1.95,1.97,1.99,2.,2./
C
C
      DATA TABDELTA0 /0.,60.,90./
      DATA TABLDBD0  /0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,20.,25.,40.,50./
      DATA TABA0     /0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $     2.,1.9,1.5,1.35,1.3 ,1.2 ,1.25,1.5,1.63,1.73,1.85,1.95,2.,2.,
     $     2.,1.8,1.6,1.55,1.55,1.65,1.8 ,1.9,1.93,1.98,2.  ,2.  ,2.,2./
C
C
      DATA TABDELTA1 /0.,60.,90./
      DATA TABLDBD1  /0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,20.,25.,40.,50./
      DATA TABA1     /0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $  1.5 ,1.15,1.05,1.1 ,1.2,1.3,1.35,1.46,1.57,1.73,1.85,1.95,2.,2.,
     $  1.37,0.95,1.1 ,1.25,1.35,1.45,1.45,1.45,1.5 ,1.6 ,1.7,1.9,2.,2./
C
C
      DATA TABDELTAA /0.,15.,30.,45.,60.,90./
      DATA TABHdDh  /0.1,0.15,0.2,0.25,0.3,0.4,0.5,0.6,0.7,1.,1.5/
      DATA TABCSI/0.00,0.00,0.00,0.00,0.00,0.00,1.37,1.20,1.11,1.00,1.,
     $            0.00,0.00,0.00,1.50,1.06,0.72,0.61,0.59,0.58,0.58,.58,
     $            0.00,0.00,1.23,0.79,0.66,0.64,0.66,0.66,0.67,0.67,.67,
     $            0.00,1.50,0.85,0.73,0.75,0.79,0.81,0.82,0.82,0.82,.82,
     $            0.00,0.98,0.76,0.80,0.90,0.96,1.0,1.01,1.02,1.02,1.02,
     $            1.50,0.72,0.74,0.83,0.89,0.94,0.96,0.98,1.00,1.00,1.0/
C
C
      DATA TABREYNOLD /1000.,2000.,1.E+04,1.E+05,1.E+06,1.E+07/
      DATA TABDdD0  /0.,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1.,1.2/
      DATA TABK2R 
     $        /1.,1.40,1.45,1.47,1.48,1.485,1.49,1.4925,1.495,1.5 ,1.5 ,                                                     
     $         1.,1.40,1.45,1.47,1.48,1.485,1.49,1.4925,1.495,1.5 ,1.5 ,
     $         1.,1.03,1.04,1.05,1.05,1.060,1.06,1.0700,1.070,1.07,1.07,
     $         1.,1.02,1.03,1.04,1.05,1.050,1.06,1.0600,1.060,1.06,1.06,
     $         1.,1.02,1.03,1.04,1.04,1.050,1.05,1.0500,1.050,1.06,1.06,
     $         1.,1.01,1.02,1.03,1.03,1.040,1.04,1.0400,1.050,1.05,1.05/
C
C
      DATA TABETsDh /0.,.004,.008,.012,.016,.02,.024,.03,.04,.05,1000./
      DATA TABBsDh  /0.,0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.3,0.5,100./
      DATA TABECSI  /.5,.57,.63,.68,.73,.80,.86,.92,.97,1.00,1.00,
     $               .5,.54,.58,.63,.67,.74,.80,.86,.90,0.94,0.94,
     $               .5,.53,.55,.58,.62,.68,.74,.81,.85,0.88,0.88,
     $               .5,.52,.53,.55,.58,.63,.68,.75,.79,0.83,0.83,
     $               .5,.51,.51,.53,.55,.58,.64,.70,.74,0.77,0.77,
     $               .5,.51,.51,.52,.53,.55,.60,.66,.69,0.72,0.72,
     $               .5,.5 ,.5 ,.51,.52,.53,.58,.62,.65,0.68,0.68,
     $               .5,.5 ,.5 ,.52,.52,.52,.54,.57,.59,0.61,0.61,
     $               .5,.5 ,.5 ,.51,.51,.51,.51,.52,.52,0.54,0.54,
     $               .5,.5 ,.5 ,.50,.50,.50,.50,.50,.50,0.50,0.50,
     $               .5,.5 ,.5 ,.50,.50,.50,.50,.50,.50,0.50,0.50/
C
C
C
      Select Case  (HLIndex)
C
        Case (1)
C
C         Entrance into a straight tube of constant cross section
C         rif. Idelchik pag.122
C
C           DIAI = Tube diameter
C           ET   = Entrance Thickness
C           WD   = Entrance Wall Distance
C
          BsDh=WD(VolIndex)/DIAI(VolIndex)
          ETsDh=ET(VolIndex)/DIAI(VolIndex)
C
          CALL LINTAB(TABETsDh,NETsDh,TABBsDh,NVBsDh,TABECSI,BsDh,ETsDh
     $               ,ECSI,Z1,Z2)
C
C---  Valore provvisorio per imbocco non raccordato e senza sporgenze
C---  b/D=0       rif. Idelchik pag.122
C
CCC          CSILOC=0.5
          CSILOC=ECSI
CC          write(6,*)'CSI locale ','TD=',TD,' ET(VolIndex)=',ET(VolIndex)                                           
CC          write(6,*)'CSI locale ','WD(VolIndex)=',WD(VolIndex)                                           
CC          write(6,*)'CSI locale ','DIAI(VolIndex)=',DIAI(VolIndex)                                           
CC          write(6,*)'CSI locale ','BsDh=',BsDh,' ETsDh=',ETsDh                                           
CC          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C
        Case (2,3,4,5)
C
C         Bends at R0/D0 < 3. and 0< delta < 180�, L0/Dh > 10
C
C         (It is calculated only the local term CSIloc=Krough*Kre*A*B*C)
C                 
C           DELTA [�]= bend angle
C           TD       = bend diameter
C           RC0/TD   = relative radius of curvature (R0SUD0)
C           CSIP     = local coefficient for smooth pipe
C           CSIC     = contraction coefficient
C           CL       = linear loss coefficient
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
          FS=FLOWSEC(VolIndex)
          GSPEED=ABS(W)/FS
          RE=GSPEED*TD/MU
C          DELTA=90.
C          RX0=0.05154+0.0495/2.
          R0SUD0=RC0(VolIndex)/TD             
C          R0SUD0=.8             
C          A=A0+A1*sind(DELTA(VolIndex))+A2*(DELTA(VolIndex))**A3
C          write(6,*)'Case Bend ','DELTA=',DELTA(VolIndex),'sind(DELTA)='
c     $               ,sind(DELTA(VolIndex)),'A=',A                                       
          CALL LINTAB(TABDUMMY,NCDUMMY,TABDELTA2,NCDELTA2,TAB1A1
     $                ,DELTA(VolIndex),DUMMY,AA,Z1,Z2)
CX          write(6,*)'Case Bend ','DELTA(',VolIndex,')=',DELTA(VolIndex)
CX     $             ,'da lintab AA=',AA
C
C          B=B0/(R0SUD0**B1)+B2/(R0SUD0**B3)
C          write(6,*)'Case Bend ','R0SUD0=',R0SUD0,'B=',B
C
          CALL LINTAB(TABDUMMY,NCDUMMY,TABR0DBD0,NCR0DBD0,TABB1,R0SUD0
     $                ,DUMMY,B1,Z1,Z2)
C          write(6,*)'Case Bend ','R0SUD0=',R0SUD0,'da lintab B1=',B1
C
C
C   !!!  For a circular o square cross section C=1.
C
          C=1.
          CSIP=AA*B1*C
C
C          REN=0.1
C          R0SUD0=0.55
C           DO I=1,55
          REN=1.E-05*RE
C
          CALL LINTAB(TABR0SUD0,NCR0SUD0,TABRE,NRE,TABKRE,REN,R0SUD0
     $                ,KRE,Z1,Z2)
C
          CSILOC=KRE*CSIP
CX          write(6,*)'Case Bend ','RC0=',RC0(VolIndex),' R0SUD0=',R0SUD0                                  
CX          write(6,*)'Case Bend ','AA=',AA,' B1=',B1,'CSIP =',CSIP                                        
CX          write(6,*)'Case Bend ','REN=',REN,' KRE=',KRE                                     
CX          write(6,*)'Case Bend ','Z1=',Z1,' Z2=',Z2                                           
C          write(6,*)'Case Bend ','TABR0SUD0=',TABR0SUD0,' TABRE=',TABRE                                           
CX          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
CX          write(6,*)'Case Bend 2 3 4 5 ','CSILOC=',CSILOC                                    
C          REN=REN+0.1
C          R0SUD0=R0SUD0+1.
C          END DO
C
C
          Select Case  (HLIndex)
            Case (3)
C         Doubly curved - S-shaped bend - flow in one plane
C
C           DELTA=45.
              LDBD=DB(VolIndex)/TD
C           DO I=1,55
C          write(6,*)'CSI locale ',' TABLdbD=',TABLDBD                                          
              CALL LINTAB(TABDELTA,NCDELTA,TABLDBD,NVLDBD,TABA,LDBD
     $                   ,DELTA(VolIndex),A,Z1,Z2)
C          CSILOC=K1*(CSIE+CSIC+CL)
C          write(6,*)'CSI locale ','TABDELTA=',TABDELTA,' TABLdbD='
C     $                                                          ,TABLDBD                                          
C          write(6,*)'CSI locale ','NVLdbD=',NVLDBD,'TABA=',TABA                                            
C          write(6,*)'CSI locale ',' DELTA=',DELTA(VolIndex) 
C     $             ,'LdbD=',LDBD,' A=',A                                      
C          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C           LDBD=LDBD+1.
C          END DO
              CSILOC=0.5*A*CSILOC
C          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
C          write(6,*)'Case Bend 3 ','CSILOC=',CSILOC                                    
            Case (4)
C         Doubly curved - S-shaped bend - flow in two mutually perpendicular planes
C
C           DELTA0=90.
              LDBD0=DB(VolIndex)/TD
C           DO I=1,55
              CALL LINTAB(TABDELTA0,NCDELTA0,TABLDBD0,NVLDBD0,TABA0
     $                   ,LDBD0,DELTA(VolIndex),A0,Z1,Z2)
C        write(6,*)'CSI locale ','DELTA0=',DELTA(VolIndex)
C     $           ,'LDBD0=',LDBD0,'A0=',A0                                      
C          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
              CSILOC=0.5*A0*CSILOC
C          write(6,*)'Case Bend 4 ','CSILOC=',CSILOC                                    
C           LDBD0=LDBD0+1.
C          END DO
C
C
            Case (5)
C         Doubly curved - U-shaped bend - flow in one plane
C
C           DELTA1=90.
              LDBD1=DB(VolIndex)/TD
C           DO I=1,55
              CALL LINTAB(TABDELTA1,NCDELTA1,TABLDBD1,NVLDBD1,TABA1
     $                   ,LDBD1,DELTA(VolIndex),A1,Z1,Z2)
C        write(6,*)'CSI locale ','DELTA0=',DELTA(VolIndex)
C     $           ,'LDBD0=',LDBD1,'A1=',A1                                      
C           LDBD1=LDBD1+1.
C          END DO
CX          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
              CSILOC=0.5*A1*CSILOC
CX          write(6,*)'Case Bend 5 ','CSILOC=',CSILOC                                    
            Case Default
          End Select
C
C
        Case (6,7,8)
C
C         Flanged joint with gasket
C
C           TD   = Tube diameter
C           FS   = main stream flow section
C           GT   = Gasket thickness
C           GD   = Gasket diameter
C           FG   = Gasket flow section
C           CSIE = Expansion coefficient
C           CSIC = Contraction coefficient
C           CL   = Linear loss coefficient
C             
C          TD=0.0495
C          GT=0.0045
C          GD=0.0699
C          GROUGH=2.53E-06
          GROUGH=GR(VolIndex)
C
          Select Case  (HLIndex)
            Case (6)
C 20 novembre              FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
C              write(6,*)'DIAI(VolIndex) =',DIAI(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIE=(1-FS/FG)**2.
              CSIC=0.5*(1-FS/FG)**(3./4.)
              GASPEED=ABS(W)/FG
              CALL HMP0_MOODY_FF(GROUGH,GD(VolIndex),GASPEED,MU,GF)
               CL=GT(VolIndex)/GD(VolIndex)*GF
              FGSUFS=FG/FS
              L0SUD0=GT(VolIndex)/GD(VolIndex)
              CALL LINTAB(TABFGSUFS,NFGSUFS,TABL0SUD0,NL0SUD0,TABNK1,
     $                L0SUD0,FGSUFS,K1,Z1,Z2)
              CSILOC=K1*(CSIE+CSIC+CL)
CXX          write(58,'(2A4)')IBLOC1X,IBLOC2X                                             
CXX          write(58,*)'FLOWSEC(VolIndex)=',FLOWSEC(VolIndex)                                              
CXX          write(58,*)'CSI locale ','PIG*TD*TD/4.=',PIG*TD*TD/4.                                             
CX          write(6,*)'CSI locale ','FGSUFS=',FGSUFS,' L0SUD0=',L0SUD0                                             
CX          write(6,*)'CSI locale ','GF=',GF,' CL=',CL,' K1=',K1                                              
C          write(6,*)'CSI locale ','Z1=',Z1,' Z2=',Z2                                           
C          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C
            Case (7)
C
C         Sudden expansion
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIE=(1-FS/FG)**2.
              CSILOC=CSIE
            Case (8)
C
C         Sudden contraction
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIC=0.5*(1-FG/FS)**(3./4.)
              CSILOC=CSIC
          End Select
C
C
C
        Case (9)
C
C         Discharge from a tube (channel) onto a baffle
C               Straight wall diffuser at l/D =1.
C
           HdDh=HB(VolIndex)/TD
C
              CALL LINTAB(TABDELTAA,NCDELTAA,TABHdDh,NVHdDh,TABCSI
     $                   ,HdDh,DELTAA(VolIndex),CSI,Z1,Z2)
CX        write(6,*)'CSI locale ','DELTAA=',DELTA(VolIndex)
CX     $           ,'HdDh=',HdDh,'CSI=',CSI                                      
              CSILOC=CSI
C
C
C
        Case (10)
C
C            Flow through spacers (Rehme reference)
C
          GSPEED=ABS(W)/FLOWSEC(VolIndex)
          RE=GSPEED*TD/MU
          RENOR=RE/2000.
CXX         write(6,*)'Rehme GSPEED',GSPEED,'RE=',RE,'TD=',TD,'MU=',MU 
CXX         write(6,*)'RENOR ',RENOR
          IF (RENOR.LT.1.)RENOR=1.5
          CvRehme=C0*((LOG(RENOR))**(1./C1))+(LOG(RENOR)**C2)+C3
C
          CSILOC=CvRehme*(ASpacer(VolIndex)/FLOWSEC(VolIndex))**2.
C
C       write(6,*)'RENOR ',RENOR,'CvRehme=',CvRehme,'ASpacer='
C     $           ,ASpacer(VolIndex),'FLOWS=',FLOWSEC(VolIndex)                                    
C
C
        Case (11)
C
C         simmetric turn through 180� in one plane (with pumping)
C
C
C
        Case (101)
C
C         Parallel interstitial flow - Concentric Annulus
CC
          PIPES=SUBCHNUM(VolIndex)*PIG/4.*DIAI(VolIndex)**2.
          RODS=RTNUMB(VolIndex)*PIG/4.*RODDIAM(VolIndex)**2.
          PIPEWP=PIG*DIAI(VolIndex)*SUBCHNUM(VolIndex)
          RODWP=PIG*RODDIAM(VolIndex)*RTNUMB(VolIndex)
          FLOWS=PIPES-RODS
          PB=PIPEWP+RODWP
          EQHYD=4.*FLOWS/PB
C        write(6,*)'RODDIAM(',VolIndex,')',RODDIAM(VolIndex),'TD=',TD
C     $           ,'EQHYD=',EQHYD                                     
C        write(6,*)'PIPES ',PIPES,'RODS=',RODS
C     $           ,'FLOWS=',FLOWS                                    
C
C------ Mass speed
C
          ANSPEED=ABS(W)/FLOWS                                                  
          RE=ANSPEED*EQHYD/MU
          DdD0=RODDIAM(VolIndex)/DIAI(VolIndex)
          CALL LINTAB(TABREYNOLD,NREYNOLD,TABDdD0,NVDdD0,TABK2R
     $                                        ,DdD0,RE,CSI,Z1,Z2)
          CSILOC=CSI
C        write(6,*)'ANSPEED ',ANSPEED,'RE=',RE,'DdD0=',DdD0
C     $           ,'EQHYD=',EQHYD,'CSI=',CSI                                      
C
        Case Default
C                   No local Head loss
C
          CSILOC=0.
CX         write(6,*)'Case default ','CSILOC=',CSILOC                                          
      End Select
CX       write(6,*)'Dopo Select  HLIndex =',HLIndex
C
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMP0_ZUKAUSKAS_FF(PITCHT,PITCHL,DIA,GSPEED,MU,FRICF)
C
C	    
      PARAMETER (NRE=410,NXT=4,NRZ=184,NCZ=4,NREZ=4)
C
      REAL ZKS_StD(NXT),ZKS_RE(NRE),ZKS_FRICFACT(NRE,NXT)
      REAL ZKS_STSL(NRZ),ZKS_CORFACT(NRZ,NCZ),ZKS_CF_RE(NXT)
C
C
      REAL MU
C
      COMMON/HMP0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      COMMON /ZKS_St_Divided_D/ZKS_StD    
      COMMON /ZKS_REYNOLDS/ZKS_RE    
      COMMON /ZKS_FRICTION_FACT/ZKS_FRICFACT    
      COMMON /ZKS_CORFACT_RE/ZKS_CF_RE    
      COMMON /ZKS_CORRECTION_FACT/ZKS_CORFACT    
      COMMON /ZKS_ST_D_SL/ZKS_STSL    
C
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
C
      RE=GSPEED*DIA/MU
C----- KIT ----- start
C      RE=0.569*10532.822*DIA/MU
C----- KIT ----- end
C
      ST=2.*PITCHT
      XT=ST/DIA
      XTL=ST/PITCHL
C     if (XTL.GT.2.8) XTL=3.
C
      IF (RE.LT.10.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Zukauskas chart minimum value'
     $         ,'Reynolds Number limited to 10.'
        RE=10.
        ZETA=1.
        FRICF0=4.
	FRICF=FRICF0*ZETA
      ELSE
         CALL LINTAB(ZKS_StD,NXT,ZKS_RE,NRE,ZKS_FRICFACT,RE,XT,FRICF0,
     $                Z1,Z2)
         CALL LINTAB(ZKS_CF_RE,NREZ,ZKS_STSL,NRZ,ZKS_CORFACT,XTL,RE,
     $                ZETA,Z11,Z22)
C        ZETA=1.
C        FRICF0=2.                                                
        FRICF=FRICF0*ZETA
      END IF
      write(6,*)'XT ',XT,'RE ',RE,' FRICF0 ',FRICF0
      write(6,*)'XL ',PITCHL/DIA,'XTL ',XTL,'RE ',RE,' ZETA ',ZETA
      write(6,*)' FRICF ',FRICF
      RETURN                                                            
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      FUNCTION HMP0ISTA05(IFUN)                                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      HMP0ISTA05=0                                                          
      IF(KREGIM) HMP0ISTA05=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) HMP0ISTA05=1                         
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP0STAS05(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      REAL LHTC,FSPEED(NCMAX+1),MU(NCMAX)
C
      DIMENSION  EHYD(NCMAX),REIN(NCMAX)
C
      COMMON/HMP0PARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/HMP0TERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/HMP0MEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/HMP0DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)      
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                  ,HTCS(NCMAX)                           
      COMMON/HMP0LACANES/ FRICF(NCMAX),FFXLD(NCMAX),CSILOC(NCMAX)
     $                   ,CFC(NCMAX),EHYD,MU                                  
C
      COMMON/HMP0BLOCKS/IBLOC1X,IBLOC2X                                              
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
C
      WRITE(6,1001)                                                     
      DO 10 I=1,NCEL                                                    
      G=WI(I)/FLOWSEC(I)
      FSPEED(I)=G/RO(I)                                                    
      REIN(I)=G*EHYD(I)/MU(I)
      AM=RO(I)*FLOWSEC(I)*HLU(I)                                          
      T=TL(I)-273.16                                                    
      WRITE(6,1002) I,WI(I),HM(I),P(I+1),AM,RO(I),G,T          
   10 CONTINUE                                                          
      DO 20 J=1,NPAR                                                    
      WRITE(6,1003) J,J,J                                               
      DO 20 I=1,NCEL                                                    
      T=TW(J,I)-273.16                                                  
      WRITE(6,1004) I,T,LHTC(J,I),QT(J,I)                             
   20 CONTINUE
C
      FFXLDTOT=0.
      CSILOCTOT=0.
      DARCYTOT=0.
      AVERSPEED=0.
      AVREIN=0.
      DO I=1,NCEL
        SIG2=FLOWSEC(I)*FLOWSEC(I)                                 
        DPDARCY=CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
        WRITE(6,*)                                                      
        WRITE(6,*)                                                      
        WRITE(6,*)' Control volume ',I
        WRITE(6,*)                                                      
        WRITE(6,*)'            Fluid reference speed [m/s] :',FSPEED(I)
        WRITE(6,*)'                     Reinolds number RE :',REIN(I)
        WRITE(6,*)'                Moody friction factor f :',FRICF(I)
        WRITE(6,*)'                                 f(L/D) :',FFXLD(I)
        WRITE(6,*)'      Local pressure drop coefficient K :',CSILOC(I)
        WRITE(6,*)'Global pressure drop coefficient [f(L/D)+K] :',CFC(I)
        WRITE(6,*)'    Darcy pressure drop [f(L/D)+K]@VV/2 :',DPDARCY
        AVREIN=AVREIN+REIN(I)/FLOAT(NCEL)
        AVERSPEED=AVERSPEED+FSPEED(I)/FLOAT(NCEL)
        FFXLDTOT=FFXLDTOT+FFXLD(I)
        CSILOCTOT=CSILOCTOT+CSILOC(I)
        DARCYTOT=DARCYTOT+DPDARCY
      END DO
C
      WRITE(6,*)                                                      
      WRITE(6,*)' Global values'                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)'              Fluid average speed [m/s] :',AVERSPEED
      WRITE(6,*)'              Average Reinolds number RE:',AVREIN
      WRITE(6,*)'                                 f(L/D) :',FFXLDTOT
      WRITE(6,*)'      Local pressure drop coefficient K :',CSILOCTOT
      WRITE(6,*)'    Darcy pressure drop [f(L/D)+K]@VV/2 :',DARCYTOT
C
      FCTOT=FFXLDTOT+CSILOCTOT
      WRITE(34,1005)IBLOC1X,IBLOC2X,FFXLDTOT,CSILOCTOT,FCTOT,AVERSPEED
     $              ,AVREIN                                                      
1005  FORMAT('Block ',2A4,5x,'f(L/D)',F12.6,5x,'Form loss coefficient K'
     $       ,F12.6,5x,'f(L/D)+K',F12.6,5x,'Average speed [m/s]',F12.6
     $       ,5x,'Average Reinolds number RE  ',F15.6 )
C
      RETURN                                                            
 1001 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',    
     $       6X,'MASSA TOT.',5X,'DENS.MEDIA',4X,            
     $       'PORT.SPEC.',6X,'TEMPERATURA',4X//)                        
 1002 FORMAT(1X,I3,5X,8(E12.5,3X))                                      
 1003 FORMAT(//1X,'CELLA',4X,'TEMP.PAR.',I2,7X,'COEFF.SCAMBIO',I2,      
     $       3X,'POT. TERM.',I2,7X//)                                   
 1004 FORMAT(1X,I3,5X,8(E12.5,6X))                                      
      END                                                               
C
C
C
      SUBROUTINE HMP0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      RETURN
      END
C
C
C------------------------------------------------------------------------------
C
C           BLOCK DATA per Zukauskas
C
C------------------------------------------------------------------------------
C
      BLOCK DATA ZUKAUS
C	    
C
C------------------------------------------------------------------------------
C
C           Zukauskas correlations for friction factor in case of
C           cross flow, trought tubes staggered arranged
C
C------------------------------------------------------------------------------
C
      PARAMETER (NRE=410,NXT=4,NRZ=184,NCZ=4,NREZ=4)
C
      REAL ZKS_StD(NXT),ZKS_RE(NRE),ZKS_FRICFACT(NRE,NXT)
      REAL ZKS_STSL(NRZ),ZKS_CORFACT(NRZ,NCZ),ZKS_CF_RE(NXT)
C
      COMMON /ZKS_St_Divided_D/ZKS_StD    
      COMMON /ZKS_REYNOLDS/ZKS_RE    
      COMMON /ZKS_FRICTION_FACT/ZKS_FRICFACT    
      COMMON /ZKS_CORFACT_RE/ZKS_CF_RE    
      COMMON /ZKS_CORRECTION_FACT/ZKS_CORFACT    
      COMMON /ZKS_ST_D_SL/ZKS_STSL    
C
      DATA ZKS_StD /  1.25, 1.5, 2.0, 2.5 /
C
      DATA ZKS_RE /   10.,         
     $                10.4518995 ,
     $                10.5291004 ,
     $                10.8439999 ,
     $                11.1681995 ,
     $                11.3339996 ,
     $                11.7592001 ,
     $                11.8460999 ,
     $                12.2905998 ,
     $                12.3814001 ,
     $                12.8458996 ,
     $                13.0366001 ,
     $                13.5256004 ,
     $                13.6255999 ,
     $                14.2412996 ,
     $                14.8849001 ,
     $                15.1057997 ,
     $                15.5574999 ,
     $                15.7882996 ,
     $                16.1410999 ,
     $                16.5018005 ,
     $                16.7467003 ,
     $                17.2474003 ,
     $                17.3749008 ,
     $                18.0268002 ,
     $                18.2943001 ,
     $                18.9806004 ,
     $                19.1210003 ,
     $                19.6926994 ,
     $                19.8383007 ,
     $                20.8880005 ,
     $                21.198	 ,
     $                21.9932995 ,
     $                22.3197002 ,
     $                23.1571007 ,
     $                23.5007    ,
     $                24.5625992 ,
     $                24.9272003 ,
     $                25.6725006 ,
     $                26.4402008 ,
     $                27.0310001 ,
     $                28.0450993 ,
     $                28.2523994 ,
     $                29.9673004 ,
     $                31.3213997 ,
     $                31.7861996 ,
     $                33.222599  ,
     $                33.7155991 ,
     $                35.2391014 ,
     $                35.7621002 ,
     $                36.5611    ,
     $                37.9328003 ,
     $                39.3558998 ,
     $                41.7447014 ,
     $                42.053299  ,
     $                43.6310005 ,
     $                44.6058998 ,
     $                45.6025009 ,
     $                47.3134003 ,
     $                48.0155983 ,
     $                49.8168983 ,
     $                50.1851997 ,
     $                51.6859016 ,
     $                52.8406982 ,
     $                54.0214005 ,
     $                55.6366997 ,
     $                56.4623985 ,
     $                58.5806999 ,
     $                61.6804008 ,
     $                64.9440994 ,
     $                68.8861008 ,
     $                72.5311966 ,
     $                78.0754013 ,
     $                82.2067032 ,
     $                84.0435028 ,
     $                88.4906006 ,
     $                89.8038025 ,
     $                94.5557022 ,
     $                98.8283997 ,
     $                103.293999 ,
     $                104.827003 ,
     $                105.601997 ,
     $                106.383003 ,
     $                108.760002 ,
     $                112.012001 ,
     $                112.839996 ,
     $                114.514999 ,
     $                115.361    ,
     $                119.689003 ,
     $                120.573997 ,
     $                124.179001 ,
     $                126.954002 ,
     $                129.791    ,
     $                133.671997 ,
     $                135.656006 ,
     $                140.744995 ,
     $                143.889999 ,
     $                146.024994 ,
     $                151.503006 ,
     $                156.033997 ,
     $                159.520004 ,
     $                165.505005 ,
     $                169.203003 ,
     $                171.714005 ,
     $                174.261993 ,
     $                179.473007 ,
     $                182.136002 ,
     $                186.205994 ,
     $                196.059006 ,
     $                197.507996 ,
     $                211.046005 ,
     $                212.606003 ,
     $                214.177994 ,
     $                228.856995 ,
     $                240.966995 ,
     $                250.007004 ,
     $                251.856003 ,
     $                261.303986 ,
     $                271.106995 ,
     $                273.112    ,
     $                275.131012 ,
     $                285.453003 ,
     $                291.830994 ,
     $                298.351013 ,
     $                311.833008 ,
     $                314.138    ,
     $                323.532013 ,
     $                328.333008 ,
     $                340.651001 ,
     $                343.169006 ,
     $                350.837006 ,
     $                353.431    ,
     $                369.401001 ,
     $                374.884003 ,
     $                377.654999 ,
     $                397.638    ,
     $                400.578003 ,
     $                431.197998 ,
     $                434.385986 ,
     $                437.597992 ,
     $                467.589996 ,
     $                471.046997 ,
     $                474.529999 ,
     $                510.803009 ,
     $                514.578979 ,
     $                518.383972 ,
     $                553.914001 ,
     $                558.008972 ,
     $                562.133972 ,
     $                591.879028 ,
     $                637.122009 ,
     $                641.83197  ,
     $                646.578003 ,
     $                661.023987 ,
     $                701.146973 ,
     $                706.330994 ,
     $                732.830017 ,
     $                749.203979 ,
     $                783.057983 ,
     $                788.846985 ,
     $                849.146973 ,
     $                855.424988 ,
     $                868.119995 ,
     $                920.812988 ,
     $                927.620972 ,
     $                948.346985 ,
     $                998.528015 ,
     $                1107.	  ,
     $                1115.18005 ,
     $                1140.09998 ,
     $                1209.30005 ,
     $                1227.25    ,
     $                1254.67004 ,
     $                1263.93994 ,
     $                1360.56006 ,
     $                1370.62    ,
     $                1380.75    ,
     $                1411.59998 ,
     $                1497.28003 ,
     $                1508.34998 ,
     $                1530.73999 ,
     $                1599.91003 ,
     $                1635.65002 ,
     $                1659.93005 ,
     $                1709.56006 ,
     $                1800.02002 ,
     $                1826.73999 ,
     $                1895.27002 ,
     $                1995.56006 ,
     $                2132.33008 ,
     $                2179.97998 ,
     $                2212.33008 ,
     $                2295.33008 ,
     $                2346.61011 ,
     $                2452.6499  ,
     $                2507.44995 ,
     $                2544.65991 ,
     $                2582.42993 ,
     $                2739.17993 ,
     $                2759.42993 ,
     $                2862.94995 ,
     $                2970.36011 ,
     $                2992.32007 ,
     $                3104.58008 ,
     $                3221.05005 ,
     $                3268.8501  ,
     $                3416.56006 ,
     $                3492.8999  ,
     $                3570.93994 ,
     $                3597.34009 ,
     $                3787.68994 ,
     $                3988.12012 ,
     $                4017.6001  ,
     $                4324.70996 ,
     $                4356.68018 ,
     $                4486.9502  ,
     $                4520.12012 ,
     $                4759.2998  ,
     $                4794.49023 ,
     $                4865.64014 ,
     $                5085.5	 ,
     $                5237.56982 ,
     $                5315.2998  ,
     $                5637.93018 ,
     $                5679.60986 ,
     $                5721.6001  ,
     $                5763.8999  ,
     $                5980.14014 ,
     $                6024.3501  ,
     $                6437.25977 ,
     $                6532.7998  ,
     $                6629.75    ,
     $                6929.33008 ,
     $                7242.43994 ,
     $                7295.97998 ,
     $                7514.1499  ,
     $                7970.24023 ,
     $                8029.16992 ,
     $                8579.49023 ,
     $                8642.91992 ,
     $                8706.80957 ,
     $                9167.51953 ,
     $                9235.2998  ,
     $                9372.36035 ,
     $                9441.65039 ,
     $                9795.87012 ,
     $                10014.7002 ,
     $                10088.7998 ,
     $                10940.2998 ,
     $                11021.0996 ,
     $                11102.5996 ,
     $                11951.2998 ,
     $                12128.7002 ,
     $                12308.7002 ,
     $                13152.2998 ,
     $                13446.2002 ,
     $                13545.5996 ,
     $                14688.7998 ,
     $                14906.7998 ,
     $                16284.4004 ,
     $                16404.8008 ,
     $                16648.3008 ,
     $                17658.8008 ,
     $                17789.3008 ,
     $                18053.4004 ,
     $                18321.3008 ,
     $                19149.1992 ,
     $                19290.6992 ,
     $                20162.4004 ,
     $                21864.0996 ,
     $                22025.6992 ,
     $                22352.5996 ,
     $                23362.5996 ,
     $                23709.4004 ,
     $                24598.9004 ,
     $                24963.9004 ,
     $                25334.4004 ,
     $                26092.	 ,
     $                27271.	 ,
     $                27472.5996 ,
     $                29140.0996 ,
     $                30011.5    ,
     $                30682.	 ,
     $                30908.9004 ,
     $                31833.0996 ,
     $                32544.4004 ,
     $                34266.3984 ,
     $                34519.8008 ,
     $                35032.1016 ,
     $                35552.	 ,
     $                37433.1992 ,
     $                37988.6992 ,
     $                38552.5    ,
     $                40294.6016 ,
     $                44018.3984 ,
     $                44343.8008 ,
     $                45001.8984 ,
     $                47383.1016 ,
     $                47733.3984 ,
     $                49524.1992 ,
     $                49890.3984 ,
     $                51005.1016 ,
     $                52144.6992 ,
     $                55309.8008 ,
     $                55718.6992 ,
     $                56963.6992 ,
     $                58236.5    ,
     $                60421.3008 ,
     $                60868.	 ,
     $                64562.6016 ,
     $                65039.8984 ,
     $                66005.1016 ,
     $                66493.1016 ,
     $                69497.7031 ,
     $                70011.5    ,
     $                72638.1016 ,
     $                73716.1016 ,
     $                74261.1016 ,
     $                75920.3984 ,
     $                79937.6016 ,
     $                85416.5    ,
     $                86048.	 ,
     $                87325.	 ,
     $                91945.7969 ,
     $                92625.5    ,
     $                93310.2969 ,
     $                95395.2031 ,
     $                96811.	 ,
     $                100443.    ,
     $                101186.    ,
     $                101934.    ,
     $                108920.    ,
     $                109725.    ,
     $                110537.    ,
     $                111354.    ,
     $                116386.    ,
     $                118986.    ,
     $                121645.    ,
     $                125282.    ,
     $                129028.    ,
     $                134859.    ,
     $                135856.    ,
     $                139918.    ,
     $                140952.    ,
     $                145167.    ,
     $                150613.    ,
     $                151727.    ,
     $                155117.    ,
     $                156264.    ,
     $                164532.    ,
     $                165749.    ,
     $                166974.    ,
     $                170705.    ,
     $                182405.    ,
     $                185112.    ,
     $                187859.    ,
     $                194907.    ,
     $                200735.    ,
     $                202219.    ,
     $                214493.    ,
     $                216079.    ,
     $                219286.    ,
     $                229195.    ,
     $                230889.    ,
     $                248538.    ,
     $                257863.    ,
     $                267537.    ,
     $                277574.    ,
     $                287987.    ,
     $                292261.    ,
     $                298791.    ,
     $                305467.    ,
     $                312293.    ,
     $                316927.    ,
     $                331248.    ,
     $                336164.    ,
     $                343675.    ,
     $                359205.    ,
     $                375436.    ,
     $                378212.    ,
     $                386662.    ,
     $                389521.    ,
     $                398224.    ,
     $                401169.    ,
     $                425519.    ,
     $                428665.    ,
     $                441483.    ,
     $                461432.    ,
     $                489440.    ,
     $                493058.    ,
     $                496704.    ,
     $                511556.    ,
     $                567125.    ,
     $                575542.    ,
     $                597134.    ,
     $                614989.    ,
     $                638061.    ,
     $                661999.    ,
     $                676791.    ,
     $                702181.    ,
     $                739336.    ,
     $                767073.    ,
     $                801735.    ,
     $                807662.    ,
     $                813633.    ,
     $                863019.    ,
     $                882302.    ,
     $                915403.    ,
     $                935856.    ,
     $                1000000.      / 
C
       DATA ZKS_FRICFACT / 
     $               25.5256004 , 9.05023003 , 2.5102787  , 1.69588685 ,
     $               24.2537003 , 8.665061   , 2.46667361 , 1.67129731 ,
     $               23.9827385 , 8.59926033 , 2.45948696 , 1.66723788 ,
     $               22.8775005 , 8.32975483 , 2.43091869 , 1.65108085 ,
     $               22.0185699 , 8.05228996 , 2.40269232 , 1.63508606 ,
     $               21.5792999 , 7.9397254  , 2.38869548 , 1.62714303 ,
     $               20.5626717 , 7.65105009 , 2.35407019 , 1.60746014 ,
     $               20.3549004 , 7.59741545 , 2.34720874 , 1.60355401 ,
     $               19.3958168 , 7.32307005 , 2.31317854 , 1.58415294 ,
     $               19.1998997 , 7.27174091 , 2.30643773 , 1.58030427 ,
     $               18.3340683 , 7.00916004 , 2.27300477 , 1.56118798 ,
     $               17.9785995 , 6.91116714 , 2.25976348 , 1.55360401 ,
     $               17.2348881 , 6.65989017 , 2.2270124  , 1.53481364 ,
     $               17.0827999 , 6.61352158 , 2.22051787 , 1.53108215 ,
     $               16.1133995 , 6.32803011 , 2.18194842 , 1.50888371 ,
     $               15.3105001 , 6.09327412 , 2.1440444  , 1.48700452 ,
     $               15.0251627 , 6.01270008 , 2.13155866 , 1.4797833  ,
     $               14.4417	, 5.84211969 , 2.10680342 , 1.46544516 ,
     $               14.1969004 , 5.75496006 , 2.09453869 , 1.45833099 ,
     $               13.8226995 , 5.63297558 , 2.076267   , 1.44771993 ,
     $               13.4697418 , 5.50825977 , 2.05815363 , 1.43718529 ,
     $               13.2300997 , 5.43070364 , 2.04616761 , 1.43020582 ,
     $               12.7046919 , 5.27214003 , 2.02240753 , 1.41634989 ,
     $               12.5709	, 5.24461699 , 2.01651073 , 1.412907   ,
     $               12.0319996 , 5.10389423 , 1.98727739 , 1.39581394 ,
     $               11.8638659 , 5.04615021 , 1.97570562 , 1.38903618 ,
     $               11.4324999 , 4.86657667 , 1.94706774 , 1.37223411 ,
     $               11.3522739 , 4.82984018 , 1.94138694 , 1.36889637 ,
     $               11.0255985 , 4.69080019 , 1.91884303 , 1.35563421 ,
     $               10.9424	, 4.66232777 , 1.91324711 , 1.35233819 ,
     $               10.233696  , 4.45705986 , 1.87453353 , 1.32949185 ,
     $               10.0243998 , 4.40347385 , 1.86361659 , 1.32303524 ,
     $               9.62108517 , 4.26599979 , 1.83660126 , 1.3070302  ,
     $               9.45555973 , 4.21471214 , 1.82590556 , 1.30068278 ,
     $               9.07511997 , 4.08312988 , 1.79943621 , 1.28494787 ,
     $               8.9190197  , 4.03339052 , 1.78895915 , 1.27870905 ,
     $               8.4967165  , 3.8796699  , 1.75788653 , 1.2601701  ,
     $               8.35171986 , 3.83397913 , 1.74764693 , 1.25404894 ,
     $               8.11827755 , 3.74058008 , 1.72735286 , 1.24189949 ,
     $               7.87782001 , 3.64996481 , 1.70729136 , 1.22986603 ,
     $               7.71326542 , 3.58023    , 1.69239831 , 1.22091734 ,
     $               7.43080997 , 3.4736557  , 1.66786587 , 1.20614827 ,
     $               7.37983704 , 3.45186996 , 1.66300333 , 1.20321667 ,
     $               6.95815992 , 3.3039     , 1.62460053 , 1.18001282 ,
     $               6.66423225 , 3.16228008 , 1.59638262 , 1.16290474 ,
     $               6.56334019 , 3.12913871 , 1.58708644 , 1.15725768 ,
     $               6.28607321 , 3.02672005 , 1.55951798 , 1.14047837 ,
     $               6.19090986 , 2.99500084 , 1.55043685 , 1.13494039 ,
     $               5.92939472 , 2.89698005 , 1.5235064  , 1.11848533 ,
     $               5.83962011 , 2.86398983 , 1.51463366 , 1.11305332 ,
     $               5.74748135 , 2.81359005 , 1.50142288 , 1.10495567 ,
     $               5.58930016 , 2.73522806 , 1.47965777 , 1.09158874 ,
     $               5.38890982 , 2.65392995 , 1.45820916 , 1.07838404 ,
     $               5.11811304 , 2.54016995 , 1.42453647 , 1.05758822 ,
     $               5.08312988 , 2.52820754 , 1.42038286 , 1.05501747 ,
     $               4.92657757 , 2.46705008 , 1.39979315 , 1.04225492 ,
     $               4.82984018 , 2.43193078 , 1.3875829  , 1.03467166 ,
     $               4.72896147 , 2.39602995 , 1.37547994 , 1.02714407 ,
     $               4.55577993 , 2.3351264  , 1.35554063 , 1.01471853 ,
     $               4.50027037 , 2.31012988 , 1.34764624 , 1.00979066 ,
     $               4.35787487 , 2.24362993 , 1.32811177 , 0.997575819,
     $               4.32876015 , 2.23090386 , 1.3242389  , 0.995150566,
     $               4.2238946  , 2.17904997 , 1.30885935 , 0.985508025,
     $               4.14319992 , 2.1480329  , 1.29744303 , 0.978338122,
     $               4.0682025  , 2.11631989 , 1.2861253  , 0.971219778,
     $               3.96560001 , 2.07600689 , 1.27118945 , 0.961809814,
     $               3.91792321 , 2.05539989 , 1.26378644 , 0.957138896,
     $               3.79560995 , 2.01085997 , 1.24546659 , 0.945560396,
     $               3.6329	, 1.93877006 , 1.22026503 , 0.929585934,
     $               3.45186996 , 1.88295996 , 1.19557345 , 0.913881421,
     $               3.3039	, 1.81544995 , 1.16796517 , 0.896257758,
     $               3.13927007 , 1.75037003 , 1.14433098 , 0.881115735,
     $               2.96113992 , 1.67533004 , 1.11139631 , 0.859927714,
     $               2.85497999 , 1.62562096 , 1.08890712 , 0.845399678,
     $               2.80762696 , 1.60352004 , 1.07940876 , 0.839248836,
     $               2.69298005 , 1.55913627 , 1.05756688 , 0.825070202,
     $               2.66392541 , 1.54603004 , 1.05140829 , 0.821063578,
     $               2.55878997 , 1.50153005 , 1.03013301 , 0.807192147,
     $               2.46705008 , 1.46898997 , 1.01224005 , 0.795489013,
     $               2.38599992 , 1.42978036 , 0.995018661, 0.783955991,
     $               2.35817599 , 1.41631997 , 0.989106655, 0.779191792,
     $               2.34411001 , 1.41084373 , 0.986117959, 0.776783288,
     $               2.33326793 , 1.40532506 , 0.983106017, 0.774356127,
     $               2.3002696  , 1.38852894 , 0.974834144, 0.766969025,
     $               2.25512433 , 1.36555004 , 0.963517308, 0.756092727,
     $               2.24362993 , 1.36174858 , 0.9606359  , 0.753323495,
     $               2.22010803 , 1.35405815 , 0.954806983, 0.747721434,
     $               2.20822763 , 1.35017407 , 0.951810241, 0.744892001,
     $               2.14744997 , 1.33030319 , 0.936479568, 0.73436749 ,
     $               2.13623667 , 1.32623994 , 0.933344722, 0.732215405,
     $               2.0905602  , 1.30764198 , 0.920575023, 0.723448992,
     $               2.05539989 , 1.2933259  , 0.912828803, 0.718866587,
     $               2.02667451 , 1.27868998 , 0.904909492, 0.714181781,
     $               1.9873786  , 1.26244891 , 0.89407599 , 0.70777297 ,
     $               1.96729004 , 1.25414622 , 0.888927639, 0.703817189,
     $               1.91917789 , 1.23284996 , 0.87572217 , 0.693670571,
     $               1.88944459 , 1.2199285  , 0.867561162, 0.687399983,
     $               1.86925995 , 1.21115673 , 0.862021029, 0.683921158,
     $               1.82540417 , 1.18865001 , 0.851948321, 0.674995005,
     $               1.78912997 , 1.17485833 , 0.843616903, 0.667612016,
     $               1.76655984 , 1.16424739 , 0.837207019, 0.663782656,
     $               1.72781014 , 1.14602995 , 0.825021446, 0.657208204,
     $               1.70386744 , 1.13729596 , 0.817492247, 0.653146029,
     $               1.68761003 , 1.13136542 , 0.812379777, 0.650398314,
     $               1.67489111 , 1.1253475  , 0.807192028, 0.647610188,
     $               1.64887917 , 1.11303997 , 0.799561381, 0.64190799 ,
     $               1.63558626 , 1.10663378 , 0.795661807, 0.638993979,
     $               1.61527002 , 1.09684289 , 0.789701998, 0.632928431,
     $               1.55490708 , 1.07314003 , 0.77478385 , 0.61824441 ,
     $               1.54603004 , 1.07043505 , 0.772589982, 0.616084993,
     $               1.50101423 , 1.0451622  , 0.754529297, 0.607152998,
     $               1.49582708 , 1.04225004 , 0.752448142, 0.606000721,
     $               1.49059999 , 1.04006481 , 0.750351012, 0.604839563,
     $               1.43716002 , 1.01966    , 0.728751004, 0.593997002,
     $               1.4018836  , 0.997569025, 0.717705131, 0.584206522,
     $               1.37555003 , 0.984804451, 0.709459484, 0.576897979,
     $               1.37038338 , 0.982193649, 0.70777297 , 0.575897634,
     $               1.3439827  , 0.968852997, 0.699503005, 0.570786238,
     $               1.31658995 , 0.954752743, 0.69092226 , 0.565482736,
     $               1.3120234  , 0.951868773, 0.689167261, 0.564397991,
     $               1.30742502 , 0.948964715, 0.687399983, 0.563098371,
     $               1.28391623 , 0.934117973, 0.678603649, 0.556454301,
     $               1.26938999 , 0.928139329, 0.673168361, 0.552348852,
     $               1.25747907 , 0.922027528, 0.667612016, 0.54815203 ,
     $               1.23284996 , 0.909389675, 0.659866869, 0.542810857,
     $               1.22931468 , 0.907229006, 0.658542693, 0.541897655,
     $               1.21490645 , 0.894644737, 0.653146029, 0.53817606 ,
     $               1.2075429  , 0.888213336, 0.649386048, 0.536274016,
     $               1.18865001 , 0.871712148, 0.639738917, 0.529913545,
     $               1.18491721 , 0.868339002, 0.637766898, 0.528613389,
     $               1.17354989 , 0.862295508, 0.631761551, 0.524653971,
     $               1.16970444 , 0.860251069, 0.629729986, 0.523554385,
     $               1.14602995 , 0.847664416, 0.623181522, 0.516784787,
     $               1.13805115 , 0.843343019, 0.620933235, 0.514460623,
     $               1.1340189  , 0.841372252, 0.619796991, 0.513285995,
     $               1.10494006 , 0.827160001, 0.611603022, 0.506798446,
     $               1.10239589 , 0.82506901 , 0.610060632, 0.505843997,
     $               1.07589877 , 0.801319003, 0.593997002, 0.496778756,
     $               1.07314003 , 0.799473584, 0.592869461, 0.495834947,
     $               1.07015193 , 0.797614276, 0.591733456, 0.494884014,
     $               1.04225004 , 0.780253112, 0.581125975, 0.489057273,
     $               1.03950071 , 0.778252006, 0.579787731, 0.488385648,
     $               1.03673065 , 0.776459634, 0.578439474, 0.487708986,
     $               1.00788295 , 0.757793188, 0.564397991, 0.478967875,
     $               1.00487995 , 0.755850017, 0.563326895, 0.478057921,
     $               1.00199735 , 0.754265726, 0.562247574, 0.477140993,
     $               0.975080311, 0.739471972, 0.552169025, 0.467871368,
     $               0.971978009, 0.737743735, 0.551305473, 0.466803014,
     $               0.968852997, 0.736002743, 0.550435603, 0.465978742,
     $               0.947860003, 0.723448992, 0.544162989, 0.460034996,
     $               0.92732197 , 0.69995749 , 0.533913732, 0.451790214,
     $               0.925358236, 0.697511971, 0.532846749, 0.450931907,
     $               0.923379481, 0.696399868, 0.5317716  , 0.450067014,
     $               0.917356491, 0.693014741, 0.528499007, 0.448339641,
     $               0.900627971, 0.683612764, 0.522100568, 0.443542004,
     $               0.898345888, 0.682398021, 0.521273851, 0.443193913,
     $               0.886680603, 0.676089883, 0.517048001, 0.441414505,
     $               0.879472494, 0.672192037, 0.513773024, 0.440315008,
     $               0.864569426, 0.664133072, 0.507001877, 0.43711099 ,
     $               0.862021029, 0.662755013, 0.505843997, 0.436555922,
     $               0.843145967, 0.6497491  , 0.494884014, 0.430774003,
     $               0.841180801, 0.648395002, 0.494309992, 0.430226922,
     $               0.837207019, 0.645667195, 0.493149281, 0.42912069 ,
     $               0.821378827, 0.634344995, 0.488331467, 0.424528986,
     $               0.819333792, 0.633140922, 0.487708986, 0.423723131,
     $               0.813108027, 0.629475236, 0.484619975, 0.421269834,
     $               0.801319003, 0.620599985, 0.477140993, 0.415329993,
     $               0.779869556, 0.606912673, 0.470223993, 0.409307986,
     $               0.778252006, 0.605880439, 0.46953088 , 0.409069955,
     $               0.774249911, 0.602735996, 0.467419386, 0.408344746,
     $               0.763136387, 0.590660632, 0.461555928, 0.406331003,
     $               0.760253668, 0.587528348, 0.460034996, 0.405286103,
     $               0.755850017, 0.582743585, 0.458759338, 0.403689981,
     $               0.754564762, 0.581125975, 0.458328068, 0.40315035 ,
     $               0.741168559, 0.574157178, 0.453833014, 0.397525996,
     $               0.73977381 , 0.573431611, 0.453364998, 0.397101939,
     $               0.738369286, 0.572700977, 0.452949166, 0.396674961,
     $               0.734091997, 0.569700837, 0.451682746, 0.395374566,
     $               0.72447753 , 0.561368525, 0.448165566, 0.391763002,
     $               0.723235309, 0.560292006, 0.44771114 , 0.391534984,
     $               0.720722854, 0.5584988  , 0.446792006, 0.391073823,
     $               0.712961018, 0.552959025, 0.444286615, 0.389649153,
     $               0.7102018  , 0.550096631, 0.442992091, 0.388913006,
     $               0.708327293, 0.54815203 , 0.442112654, 0.388553411,
     $               0.704495728, 0.545336246, 0.440315008, 0.387818426,
     $               0.697511971, 0.540203989, 0.437205344, 0.386478722,
     $               0.69544667 , 0.536920428, 0.436286807, 0.386083007,
     $               0.690149784, 0.528499007, 0.433930993, 0.38494274 ,
     $               0.682398021, 0.520837009, 0.430774003, 0.383273989,
     $               0.676156104, 0.515237033, 0.430774003, 0.381514937,
     $               0.673981428, 0.513285995, 0.428948402, 0.380902082,
     $               0.672505021, 0.511841178, 0.427708954, 0.380486012,
     $               0.668406785, 0.508134246, 0.424528986, 0.3776384  ,
     $               0.66587472 , 0.505843997, 0.423263073, 0.375879049,
     $               0.660638809, 0.500915706, 0.420645386, 0.37224099 ,
     $               0.657932997, 0.4983688  , 0.419292569, 0.371757269,
     $               0.656524539, 0.496639431, 0.418374002, 0.371428818,
     $               0.655094862, 0.494884014, 0.417782933, 0.371095419,
     $               0.649161518, 0.490874738, 0.415329993, 0.369711757,
     $               0.648395002, 0.490356773, 0.415065289, 0.369533002,
     $               0.645575404, 0.487708986, 0.413712084, 0.368338197,
     $               0.64264977 , 0.484539181, 0.412308007, 0.36709848 ,
     $               0.642051637, 0.4838911  , 0.411868274, 0.366845012,
     $               0.638993979, 0.480578184, 0.409620374, 0.36553508 ,
     $               0.635535479, 0.477140993, 0.407288164, 0.364176005,
     $               0.634116113, 0.476196021, 0.406331003, 0.363247603,
     $               0.629729986, 0.47327593 , 0.405001342, 0.360378712,
     $               0.628787518, 0.47176677 , 0.404314131, 0.358895987,
     $               0.627824008, 0.470223993, 0.40361163 , 0.358895987,
     $               0.62749809 , 0.469621778, 0.403373986, 0.358895987,
     $               0.625147998, 0.465279609, 0.400725245, 0.358895987,
     $               0.621183157, 0.460707486, 0.397936225, 0.358895987,
     $               0.620599985, 0.460034996, 0.397525996, 0.358588427,
     $               0.616510689, 0.456687987, 0.395758599, 0.355384558,
     $               0.616084993, 0.456443548, 0.3955746  , 0.355051011,
     $               0.614751399, 0.455447465, 0.394824892, 0.353691995,
     $               0.614411831, 0.455193818, 0.394634008, 0.353691995,
     $               0.611963272, 0.453364998, 0.392213792, 0.353691995,
     $               0.611603022, 0.452642232, 0.391857684, 0.353691995,
     $               0.609474838, 0.451180905, 0.391137749, 0.353691995,
     $               0.602898598, 0.446665317, 0.388913006, 0.35243395 ,
     $               0.598349988, 0.443542004, 0.388133973, 0.351563781,
     $               0.597584546, 0.442592263, 0.387735784, 0.351119012,
     $               0.594407439, 0.438650161, 0.386083007, 0.349090964,
     $               0.593997002, 0.438140899, 0.385479301, 0.348828971,
     $               0.593470693, 0.437627822, 0.384871125, 0.348565012,
     $               0.592940509, 0.43711099 , 0.384258419, 0.348150104,
     $               0.590230167, 0.43711099 , 0.381126344, 0.346029013,
     $               0.589676023, 0.436679721, 0.380486012, 0.345785499,
     $               0.586191297, 0.432651758, 0.376005679, 0.343510985,
     $               0.585385025, 0.43171975 , 0.374969006, 0.342544079,
     $               0.583652139, 0.430774003, 0.374596298, 0.341562897,
     $               0.578297496, 0.42796585 , 0.373444647, 0.338530988,
     $               0.572700977, 0.425030857, 0.37224099 , 0.335903257,
     $               0.57239449 , 0.424528986, 0.371692151, 0.335453957,
     $               0.571145654, 0.421791703, 0.369455606, 0.333622992,
     $               0.56853497 , 0.416069359, 0.364780098, 0.331473708,
     $               0.567455769, 0.415329993, 0.364176005, 0.33119601 ,
     $               0.557377636, 0.410439432, 0.361526012, 0.327296227,
     $               0.556216002, 0.409875751, 0.360960662, 0.326846749,
     $               0.55557096 , 0.409307986, 0.360391229, 0.326393992,
     $               0.550919652, 0.407247245, 0.356285006, 0.324323624,
     $               0.550235331, 0.406944066, 0.355904937, 0.324019015,
     $               0.548851609, 0.406331003, 0.355136395, 0.322870582,
     $               0.54815203 , 0.405479431, 0.354747832, 0.322290003,
     $               0.54080987 , 0.401126087, 0.352761596, 0.31932199 ,
     $               0.536274016, 0.398436666, 0.351534516, 0.316998005,
     $               0.535961747, 0.397525996, 0.351119012, 0.316376477,
     $               0.532373011, 0.389659464, 0.344728947, 0.309234321,
     $               0.531451046, 0.388913006, 0.344122589, 0.308556616,
     $               0.530521095, 0.388498068, 0.343510985, 0.307873011,
     $               0.520837009, 0.384177178, 0.336553067, 0.304181606,
     $               0.519721627, 0.383273989, 0.335098684, 0.303409994,
     $               0.518589914, 0.381872386, 0.333622992, 0.302574843,
     $               0.513285995, 0.375303507, 0.330035746, 0.298660785,
     $               0.511158586, 0.373014987, 0.328785986, 0.29729718 ,
     $               0.510439098, 0.37224099 , 0.328028917, 0.296835989,
     $               0.502164006, 0.365467638, 0.31932199 , 0.288291007,
     $               0.500189066, 0.364176005, 0.318443   , 0.287437499,
     $               0.487708986, 0.355882704, 0.312888443, 0.282043993,
     $               0.486753464, 0.355157882, 0.312402993, 0.281555086,
     $               0.484821022, 0.353691995, 0.310656756, 0.280566305,
     $               0.476801604, 0.349063516, 0.303409994, 0.276462913,
     $               0.475765944, 0.34846577 , 0.302884281, 0.275932997,
     $               0.473670006, 0.347256094, 0.301820368, 0.274390429,
     $               0.472366184, 0.346029013, 0.300741166, 0.272825658,
     $               0.468336999, 0.341549784, 0.297406018, 0.267989993,
     $               0.467648357, 0.340784222, 0.296835989, 0.267717659,
     $               0.463405997, 0.336068004, 0.292531997, 0.266039997,
     $               0.45304212 , 0.32855168 , 0.284110993, 0.257329226,
     $               0.452057928, 0.327837884, 0.28366679 , 0.256502002,
     $               0.450067014, 0.326393992, 0.28276825 , 0.255779922,
     $               0.44382593 , 0.322169304, 0.279992014, 0.25354901 ,
     $               0.441682935, 0.320718676, 0.278924942, 0.252783   ,
     $               0.436186433, 0.316998005, 0.276188046, 0.250066638,
     $               0.433930993, 0.3155545  , 0.275065005, 0.248952001,
     $               0.431925058, 0.314089239, 0.273925006, 0.247820571,
     $               0.427823305, 0.311093032, 0.271822125, 0.245507002,
     $               0.421440005, 0.30643031 , 0.268549562, 0.242102399,
     $               0.420602709, 0.305633008, 0.267989993, 0.241520241,
     $               0.413677216, 0.299940109, 0.262923598, 0.236705005,
     $               0.410058111, 0.296965122, 0.26027599 , 0.234500125,
     $               0.407273382, 0.294676006, 0.258292466, 0.232803583,
     $               0.406331003, 0.294051379, 0.257621229, 0.232229471,
     $               0.402320951, 0.291507155, 0.254887223, 0.229891002,
     $               0.399234653, 0.289549023, 0.252783   , 0.228783473,
     $               0.391763002, 0.284808576, 0.248617142, 0.226102248,
     $               0.390860647, 0.284110993, 0.248004109, 0.22570768 ,
     $               0.389036328, 0.282606691, 0.246764749, 0.224910006,
     $               0.387184978, 0.281080067, 0.245507002, 0.223491997,
     $               0.380486012, 0.275556177, 0.241076261, 0.218361109,
     $               0.378359646, 0.273925006, 0.239767909, 0.216846004,
     $               0.37620151 , 0.272714108, 0.238440007, 0.215697318,
     $               0.369533002, 0.268972546, 0.233273   , 0.212147996,
     $               0.359052926, 0.260974854, 0.226558   , 0.206040993,
     $               0.358137131, 0.26027599 , 0.226083249, 0.205393955,
     $               0.356285006, 0.258965552, 0.225123107, 0.20408538 ,
     $               0.350174904, 0.254224002, 0.221649006, 0.199350536,
     $               0.349276066, 0.253526479, 0.221031979, 0.198653996,
     $               0.344680905, 0.249960557, 0.217877552, 0.196332738,
     $               0.343741238, 0.249231353, 0.21723251 , 0.195858061,
     $               0.34088096 , 0.247011721, 0.215268999, 0.19441317 ,
     $               0.337956786, 0.244742498, 0.213628441, 0.192936003,
     $               0.329835206, 0.238440007, 0.209071994, 0.188392282,
     $               0.328785986, 0.237922728, 0.208439097, 0.18780528 ,
     $               0.326110631, 0.23634775 , 0.206512064, 0.186018005,
     $               0.323375523, 0.234737605, 0.204541996, 0.18453449 ,
     $               0.318680614, 0.231973752, 0.200110003, 0.181988001,
     $               0.317720711, 0.231408656, 0.199552909, 0.181422904,
     $               0.309781432, 0.226734832, 0.194945261, 0.176749006,
     $               0.308755785, 0.226131022, 0.194350004, 0.176303327,
     $               0.306681663, 0.224910006, 0.193438023, 0.175402045,
     $               0.305633008, 0.224355265, 0.192976922, 0.174946368,
     $               0.300823241, 0.220939726, 0.190137997, 0.172140777,
     $               0.300000727, 0.22035566 , 0.189547658, 0.171661004,
     $               0.295796067, 0.217369825, 0.18652977 , 0.169464648,
     $               0.294070393, 0.216144398, 0.185291186, 0.168563232,
     $               0.29319796 , 0.215524852, 0.184664994, 0.168107495,
     $               0.290541738, 0.213638619, 0.183111072, 0.166720003,
     $               0.284110993, 0.209071994, 0.179349005, 0.161920995,
     $               0.278310746, 0.204358563, 0.175463006, 0.158774644,
     $               0.27764222 , 0.203815296, 0.17509529 , 0.158411995,
     $               0.276290327, 0.202716708, 0.174351692, 0.157526687,
     $               0.271398515, 0.198741481, 0.171661004, 0.15432322 ,
     $               0.270678967, 0.198156744, 0.17131342 , 0.153852001,
     $               0.269953996, 0.197567627, 0.170963213, 0.153559953,
     $               0.267969936, 0.195774004, 0.16989702 , 0.152670786,
     $               0.266622603, 0.194861799, 0.169173002, 0.152066976,
     $               0.263166279, 0.192521662, 0.167136595, 0.150518   ,
     $               0.262459219, 0.192042947, 0.166720003, 0.150343329,
     $               0.26174739 , 0.191560999, 0.166370571, 0.150167495,
     $               0.255099267, 0.18705985 , 0.163106993, 0.148525238,
     $               0.254333198, 0.186541185, 0.162852108, 0.148335993,
     $               0.253560483, 0.186018005, 0.162594989, 0.148147479,
     $               0.252783	, 0.185620591, 0.162336305, 0.147957817,
     $               0.250344515, 0.183172867, 0.160742998, 0.146789595,
     $               0.249084577, 0.181908146, 0.15972504 , 0.146185994,
     $               0.247796044, 0.180614725, 0.158683971, 0.145624653,
     $               0.246033579, 0.178845569, 0.157260001, 0.144856825,
     $               0.244218305, 0.177023396, 0.156452283, 0.144066006,
     $               0.241392627, 0.174187005, 0.155194983, 0.142394885,
     $               0.240909502, 0.174018532, 0.154980004, 0.142109141,
     $               0.238941073, 0.173332155, 0.154487908, 0.140945002,
     $               0.238440007, 0.173157439, 0.154362634, 0.140766025,
     $               0.236756727, 0.172445208, 0.153852001, 0.140036464,
     $               0.234581843, 0.171524972, 0.153302833, 0.139093816,
     $               0.234136954, 0.171336725, 0.153190508, 0.138900995,
     $               0.232783139, 0.17076391 , 0.152848661, 0.138900995,
     $               0.232325077, 0.17057009 , 0.152732998, 0.138900995,
     $               0.229023218, 0.169173002, 0.151875317, 0.138900995,
     $               0.228537202, 0.169074714, 0.151749074, 0.138900995,
     $               0.228047997, 0.1689758  , 0.151621997, 0.138837099,
     $               0.226558	, 0.168674484, 0.151355073, 0.13864249 ,
     $               0.224645406, 0.167729631, 0.150518   , 0.138032198,
     $               0.224202886, 0.167511016, 0.150518   , 0.137890995,
     $               0.22375384 , 0.167289183, 0.150518   , 0.13771446 ,
     $               0.222601712, 0.166720003, 0.150518   , 0.137261525,
     $               0.221649006, 0.166720003, 0.150518   , 0.136886999,
     $               0.221607104, 0.166720003, 0.150518   , 0.13704811 ,
     $               0.221260548, 0.166720003, 0.150518   , 0.138380647,
     $               0.22121577 , 0.166891992, 0.150518   , 0.13855283 ,
     $               0.221125215, 0.167239785, 0.150757059, 0.138900995,
     $               0.220845446, 0.168314353, 0.151495725, 0.139770374,
     $               0.220797613, 0.168498069, 0.151621997, 0.139918998,
     $               0.220299289, 0.170412004, 0.153819129, 0.140945002,
     $               0.220036	, 0.171763524, 0.154980004, 0.141962469,
     $               0.219838321, 0.173165634, 0.156664401, 0.143018007,
     $               0.219633222, 0.174620345, 0.158411995, 0.144572884,
     $               0.219420448, 0.17612955 , 0.160716236, 0.146185994,
     $               0.219333112, 0.176749006, 0.161661997, 0.146947742,
     $               0.219199687, 0.177926242, 0.163106993, 0.148111567,
     $               0.219063267, 0.179129809, 0.164101496, 0.14930141 ,
     $               0.218923777, 0.180360407, 0.165118337, 0.150518   ,
     $               0.218829095, 0.181195825, 0.165808648, 0.151165217,
     $               0.218536451, 0.183777645, 0.167942002, 0.1531654  ,
     $               0.218436003, 0.184663907, 0.169040129, 0.153852001,
     $               0.218243569, 0.186018005, 0.170717925, 0.155338481,
     $               0.217845678, 0.189040869, 0.174187005, 0.158411995,
     $               0.217429847, 0.192200169, 0.176252022, 0.160486311,
     $               0.217358723, 0.1927405  , 0.176605195, 0.160841092,
     $               0.217142224, 0.19438526 , 0.177680269, 0.161920995,
     $               0.217068985, 0.194941759, 0.178044006, 0.163409844,
     $               0.216846004, 0.196635768, 0.181988001, 0.167942002,
     $               0.216805026, 0.197209001, 0.181988001, 0.167942002,
     $               0.216466203, 0.196451381, 0.181988001, 0.167942002,
     $               0.216422424, 0.196353495, 0.181988001, 0.168002591,
     $               0.216244057, 0.19595468 , 0.181490839, 0.168249443,
     $               0.215966463, 0.195334002, 0.180717081, 0.168633625,
     $               0.215576738, 0.194462568, 0.179630756, 0.169173002,
     $               0.215526402, 0.194350004, 0.179490417, 0.169173002,
     $               0.215475664, 0.194350004, 0.179349005, 0.169173002,
     $               0.215268999, 0.194350004, 0.179626346, 0.169173002,
     $               0.215268999, 0.194350004, 0.180664003, 0.169173002,
     $               0.215268999, 0.194350004, 0.180664003, 0.169173002,
     $               0.215268999, 0.194350004, 0.180664003, 0.168325812,
     $               0.214738518, 0.194350004, 0.180664003, 0.167625263,
     $               0.214053035, 0.194350004, 0.180664003, 0.166720003,
     $               0.213341832, 0.194350004, 0.180664003, 0.166720003,
     $               0.212902352, 0.194350004, 0.180664003, 0.166720003,
     $               0.212147996, 0.194350004, 0.180664003, 0.166720003,
     $               0.211571753, 0.194350004, 0.180664003, 0.166720003,
     $               0.211141571, 0.194350004, 0.180664003, 0.167176202,
     $               0.210603997, 0.194350004, 0.180664003, 0.167746305,
     $               0.210603997, 0.194350004, 0.180664003, 0.167843789,
     $               0.210603997, 0.194350004, 0.180664003, 0.167942002,
     $               0.210603997, 0.194350004, 0.180664003, 0.167942002,
     $               0.210603997, 0.194350004, 0.180664003, 0.167942002,
     $               0.210603997, 0.194350004, 0.180664003, 0.167942002,
     $               0.210603997, 0.194350004, 0.180664003, 0.194350004,
     $               0.210603997, 0.194350004, 0.180664003, 0.194350004/	  
C
C
       DATA ZKS_CF_RE /  100., 1000., 10000., 100000. /
C
C
       DATA ZKS_STSL / 
     $      	          0.4342,
     $      	          0.4416,
     $      	          0.4504,
     $      	          0.4594,
     $      	          0.4673,
     $      	          0.4766,
     $      	          0.4834,
     $      	          0.4847,
     $      	          0.4875,
     $      	          0.4944,
     $      	          0.4972,
     $      	          0.4986,
     $      	          0.5072,
     $      	          0.5086,
     $      	          0.5144,
     $      	          0.5173,
     $      	          0.5202,
     $      	          0.5306,
     $      	          0.5321,
     $      	          0.5428,
     $      	          0.5458,
     $      	          0.5474,
     $      	          0.5599,
     $      	          0.5631,
     $      	          0.5647,
     $      	          0.5727,
     $      	          0.5759,
     $      	          0.5808,
     $      	          0.5825,
     $      	          0.5891,
     $      	          0.5941,
     $      	          0.5992,
     $      	          0.6009,
     $      	          0.6043,
     $      	          0.6112,
     $      	          0.6181,
     $      	          0.6216,
     $      	          0.6269,
     $      	          0.6358,
     $      	          0.6431,
     $      	          0.6467,
     $      	          0.6578,
     $      	          0.6615,
     $      	          0.6690,
     $      	          0.6785,
     $      	          0.6843,
     $      	          0.6999,
     $      	          0.7039,
     $      	          0.7079,
     $      	          0.7241,
     $      	          0.7261,
     $      	          0.7282,
     $      	          0.7386,
     $      	          0.7448,
     $      	          0.7512,
     $      	          0.7640,
     $      	          0.7771,
     $      	          0.7815,
     $      	          0.8016,
     $      	          0.8039,
     $      	          0.8085,
     $      	          0.8223,
     $      	          0.8269,
     $      	          0.8293,
     $      	          0.8458,
     $      	          0.8603,
     $      	          0.8701,
     $      	          0.8800,
     $      	          0.8950,
     $      	          0.8976,
     $      	          0.9233,
     $      	          0.9259,
     $      	          0.9444,
     $      	          0.9524,
     $      	          0.9633,
     $      	          0.9770,
     $      	          0.9937,
     $      	          0.9993,
     $      	          1.0193,
     $      	          1.0338,
     $      	          1.0426,
     $      	          1.0544,
     $      	          1.0664,
     $      	          1.0755,
     $      	          1.1001,
     $      	          1.1284,
     $      	          1.1316,
     $      	          1.1641,
     $      	          1.1674,
     $      	          1.1773,
     $      	          1.1907,
     $      	          1.1940,
     $      	          1.2179,
     $      	          1.2283,
     $      	          1.2318,
     $      	          1.2635,
     $      	          1.2671,
     $      	          1.2706,
     $      	          1.2924,
     $      	          1.3108,
     $      	          1.3145,
     $      	          1.3257,
     $      	          1.3598,
     $      	          1.3637,
     $      	          1.3675,
     $      	          1.3753,
     $      	          1.3988,
     $      	          1.4267,
     $      	          1.4308,
     $      	          1.4389,
     $      	          1.4430,
     $      	          1.4801,
     $      	          1.4885,
     $      	          1.4927,
     $      	          1.5012,
     $      	          1.5268,
     $      	          1.5355,
     $      	          1.5442,
     $      	          1.5751,
     $      	          1.5795,
     $      	          1.5930,
     $      	          1.5975,
     $      	          1.6202,
     $      	          1.6386,
     $      	          1.6479,
     $      	          1.6526,
     $      	          1.6952,
     $      	          1.6999,
     $      	          1.7144,
     $      	          1.7388,
     $      	          1.7586,
     $      	          1.7736,
     $      	          1.7786,
     $      	          1.8141,
     $      	          1.8244,
     $      	          1.8608,
     $      	          1.8661,
     $      	          1.8714,
     $      	          1.8820,
     $      	          1.9142,
     $      	          1.9414,
     $      	          1.9469,
     $      	          1.9635,
     $      	          1.9914,
     $      	          2.0255,
     $      	          2.0312,
     $      	          2.0543,
     $      	          2.0953,
     $      	          2.1132,
     $      	          2.1252,
     $      	          2.1493,
     $      	          2.1615,
     $      	          2.1799,
     $      	          2.1985,
     $      	          2.2047,
     $      	          2.2487,
     $      	          2.2615,
     $      	          2.2679,
     $      	          2.3329,
     $      	          2.3395,
     $      	          2.3594,
     $      	          2.3930,
     $      	          2.4134,
     $      	          2.4270,
     $      	          2.4477,
     $      	          2.4895,
     $      	          2.5107,
     $      	          2.5178,
     $      	          2.5609,
     $      	          2.5682,
     $      	          2.5754,
     $      	          2.5973,
     $      	          2.6195,
     $      	          2.6418,
     $      	          2.6567,
     $      	          2.6642,
     $      	          2.6793,
     $      	          2.7252,
     $      	          2.7406,
     $      	          2.7796,
     $      	          2.7875,
     $      	          2.8033,
     $      	          2.8112,
     $                    5.8000 /
C
       DATA ZKS_CORFACT / 
     $      	          1.0027, 1.0617, 1.2515, 1.4682,
     $      	          1.0027, 1.0581, 1.2435, 1.4602,
     $      	          1.0027, 1.0538, 1.2341, 1.4502,
     $      	          1.0027, 1.0496, 1.2248, 1.4421,
     $      	          1.0027, 1.0460, 1.2167, 1.4341,
     $      	          1.0027, 1.0418, 1.2074, 1.4241,
     $      	          1.0027, 1.0388, 1.2007, 1.4191,
     $      	          1.0027, 1.0382, 1.1993, 1.4181,
     $      	          1.0027, 1.0370, 1.1971, 1.4160,
     $      	          1.0027, 1.0340, 1.1913, 1.4075,
     $      	          1.0027, 1.0328, 1.1891, 1.4040,
     $      	          1.0027, 1.0325, 1.1880, 1.4028,
     $      	          1.0027, 1.0305, 1.1813, 1.3952,
     $      	          1.0027, 1.0301, 1.1804, 1.3940,
     $      	          1.0027, 1.0288, 1.1768, 1.3900,
     $      	          1.0027, 1.0280, 1.1750, 1.3880,
     $      	          1.0027, 1.0273, 1.1732, 1.3859,
     $      	          1.0027, 1.0247, 1.1662, 1.3772,
     $      	          1.0027, 1.0246, 1.1652, 1.3759,
     $      	          1.0027, 1.0233, 1.1590, 1.3647,
     $      	          1.0027, 1.0229, 1.1572, 1.3615,
     $      	          1.0027, 1.0227, 1.1563, 1.3599,
     $      	          1.0027, 1.0198, 1.1492, 1.3519,
     $      	          1.0027, 1.0191, 1.1476, 1.3498,
     $      	          1.0027, 1.0187, 1.1468, 1.3486,
     $      	          1.0027, 1.0178, 1.1428, 1.3422,
     $      	          1.0027, 1.0175, 1.1411, 1.3397,
     $      	          1.0027, 1.0169, 1.1381, 1.3358,
     $      	          1.0027, 1.0167, 1.1371, 1.3345,
     $      	          1.0027, 1.0153, 1.1331, 1.3295,
     $      	          1.0027, 1.0142, 1.1314, 1.3257,
     $      	          1.0027, 1.0131, 1.1297, 1.3197,
     $      	          1.0027, 1.0127, 1.1291, 1.3186,
     $      	          1.0027, 1.0124, 1.1279, 1.3163,
     $      	          1.0027, 1.0117, 1.1255, 1.3117,
     $      	          1.0027, 1.0110, 1.1231, 1.3064,
     $      	          1.0027, 1.0107, 1.1215, 1.3037,
     $      	          1.0027, 1.0103, 1.1191, 1.2997,
     $      	          1.0027, 1.0096, 1.1150, 1.2930,
     $      	          1.0027, 1.0090, 1.1131, 1.2876,
     $      	          1.0027, 1.0087, 1.1121, 1.2852,
     $      	          1.0027, 1.0077, 1.1090, 1.2780,
     $      	          1.0027, 1.0074, 1.1076, 1.2756,
     $      	          1.0027, 1.0067, 1.1047, 1.2703,
     $      	          1.0027, 1.0067, 1.1010, 1.2636,
     $      	          1.0027, 1.0067, 1.0994, 1.2595,
     $      	          1.0027, 1.0067, 1.0950, 1.2489,
     $      	          1.0027, 1.0067, 1.0938, 1.2462,
     $      	          1.0027, 1.0067, 1.0925, 1.2435,
     $      	          1.0027, 1.0067, 1.0876, 1.2339,
     $      	          1.0027, 1.0067, 1.0870, 1.2327,
     $      	          1.0027, 1.0067, 1.0865, 1.2314,
     $      	          1.0027, 1.0067, 1.0840, 1.2252,
     $      	          1.0027, 1.0067, 1.0825, 1.2214,
     $      	          1.0027, 1.0067, 1.0809, 1.2174,
     $      	          1.0027, 1.0067, 1.0789, 1.2094,
     $      	          1.0027, 1.0067, 1.0769, 1.2019,
     $      	          1.0027, 1.0065, 1.0753, 1.1993,
     $      	          1.0027, 1.0057, 1.0677, 1.1873,
     $      	          1.0027, 1.0056, 1.0669, 1.1860,
     $      	          1.0027, 1.0054, 1.0662, 1.1833,
     $      	          1.0027, 1.0049, 1.0640, 1.1753,
     $      	          1.0027, 1.0047, 1.0632, 1.1729,
     $      	          1.0027, 1.0047, 1.0629, 1.1717,
     $      	          1.0027, 1.0047, 1.0597, 1.1632,
     $      	          1.0027, 1.0047, 1.0569, 1.1560,
     $      	          1.0027, 1.0047, 1.0546, 1.1512,
     $      	          1.0027, 1.0047, 1.0523, 1.1454,
     $      	          1.0027, 1.0047, 1.0488, 1.1366,
     $      	          1.0027, 1.0047, 1.0485, 1.1351,
     $      	          1.0027, 1.0047, 1.0452, 1.1231,
     $      	          1.0027, 1.0047, 1.0448, 1.1220,
     $      	          1.0027, 1.0047, 1.0418, 1.1144,
     $      	          1.0027, 1.0044, 1.0405, 1.1110,
     $      	          1.0027, 1.0039, 1.0388, 1.1048,
     $      	          1.0027, 1.0034, 1.0365, 1.0970,
     $      	          1.0027, 1.0027, 1.0337, 1.0890,
     $      	          1.0027, 1.0027, 1.0328, 1.0863,
     $      	          1.0027, 1.0027, 1.0305, 1.0769,
     $      	          1.0027, 1.0027, 1.0288, 1.0707,
     $      	          1.0027, 1.0027, 1.0271, 1.0669,
     $      	          1.0027, 1.0027, 1.0248, 1.0619,
     $      	          1.0027, 1.0030, 1.0225, 1.0569,
     $      	          1.0027, 1.0032, 1.0207, 1.0531,
     $      	          1.0027, 1.0039, 1.0179, 1.0428,
     $      	          1.0027, 1.0047, 1.0147, 1.0320,
     $      	          1.0027, 1.0048, 1.0144, 1.0308,
     $      	          1.0027, 1.0058, 1.0110, 1.0187,
     $      	          1.0027, 1.0059, 1.0107, 1.0172,
     $      	          1.0027, 1.0062, 1.0099, 1.0127,
     $      	          1.0125, 1.0066, 1.0089, 1.0067,
     $      	          1.0150, 1.0067, 1.0086, 1.0060,
     $      	          1.0326, 1.0088, 1.0067, 1.0009,
     $      	          1.0403, 1.0097, 1.0063, 0.9987,
     $      	          1.0428, 1.0100, 1.0062, 0.9979,
     $      	          1.0638, 1.0127, 1.0050, 0.9914,
     $      	          1.0662, 1.0135, 1.0048, 0.9906,
     $      	          1.0686, 1.0142, 1.0047, 0.9899,
     $      	          1.0829, 1.0188, 1.0055, 0.9853,
     $      	          1.0933, 1.0227, 1.0061, 0.9814,
     $      	          1.0954, 1.0232, 1.0063, 0.9806,
     $      	          1.1017, 1.0246, 1.0067, 0.9781,
     $      	          1.1209, 1.0288, 1.0095, 0.9703,
     $      	          1.1231, 1.0296, 1.0098, 0.9694,
     $      	          1.1252, 1.0303, 1.0101, 0.9686,
     $      	          1.1295, 1.0319, 1.0107, 0.9673,
     $      	          1.1426, 1.0368, 1.0125, 0.9636,
     $      	          1.1582, 1.0410, 1.0147, 0.9592,
     $      	          1.1604, 1.0416, 1.0151, 0.9585,
     $      	          1.1650, 1.0428, 1.0159, 0.9577,
     $      	          1.1672, 1.0436, 1.0163, 0.9573,
     $      	          1.1903, 1.0508, 1.0199, 0.9537,
     $      	          1.1955, 1.0526, 1.0207, 0.9529,
     $      	          1.1981, 1.0535, 1.0211, 0.9525,
     $      	          1.2033, 1.0554, 1.0218, 0.9515,
     $      	          1.2165, 1.0609, 1.0240, 0.9485,
     $      	          1.2209, 1.0623, 1.0247, 0.9475,
     $      	          1.2254, 1.0638, 1.0257, 0.9465,
     $      	          1.2412, 1.0689, 1.0289, 0.9442,
     $      	          1.2435, 1.0699, 1.0294, 0.9438,
     $      	          1.2508, 1.0729, 1.0308, 0.9428,
     $      	          1.2532, 1.0739, 1.0313, 0.9425,
     $      	          1.2656, 1.0789, 1.0338, 0.9407,
     $      	          1.2756, 1.0835, 1.0358, 0.9392,
     $      	          1.2800, 1.0858, 1.0368, 0.9385,
     $      	          1.2822, 1.0870, 1.0373, 0.9379,
     $      	          1.3025, 1.0990, 1.0423, 0.9324,
     $      	          1.3048, 1.0999, 1.0428, 0.9321,
     $      	          1.3117, 1.1025, 1.0448, 0.9312,
     $      	          1.3224, 1.1070, 1.0481, 0.9297,
     $      	          1.3310, 1.1116, 1.0508, 0.9284,
     $      	          1.3376, 1.1150, 1.0522, 0.9279,
     $      	          1.3398, 1.1163, 1.0527, 0.9277,
     $      	          1.3552, 1.1251, 1.0559, 0.9264,
     $      	          1.3596, 1.1277, 1.0569, 0.9256,
     $      	          1.3754, 1.1371, 1.0619, 0.9228,
     $      	          1.3776, 1.1385, 1.0627, 0.9224,
     $      	          1.3799, 1.1399, 1.0634, 0.9221,
     $      	          1.3844, 1.1427, 1.0649, 0.9216,
     $      	          1.3981, 1.1512, 1.0692, 0.9200,
     $      	          1.4097, 1.1578, 1.0729, 0.9187,
     $      	          1.4120, 1.1592, 1.0736, 0.9184,
     $      	          1.4203, 1.1632, 1.0756, 0.9180,
     $      	          1.4341, 1.1713, 1.0789, 0.9173,
     $      	          1.4459, 1.1813, 1.0844, 0.9165,
     $      	          1.4479, 1.1828, 1.0853, 0.9164,
     $      	          1.4560, 1.1887, 1.0890, 0.9158,
     $      	          1.4702, 1.1993, 1.0924, 0.9148,
     $      	          1.4773, 1.2040, 1.0940, 0.9144,
     $      	          1.4820, 1.2071, 1.0950, 0.9140,
     $      	          1.4915, 1.2134, 1.0983, 0.9133,
     $      	          1.4963, 1.2165, 1.1000, 0.9129,
     $      	          1.5027, 1.2211, 1.1025, 0.9124,
     $      	          1.5091, 1.2258, 1.1050, 0.9120,
     $      	          1.5112, 1.2274, 1.1060, 0.9118,
     $      	          1.5264, 1.2400, 1.1130, 0.9108,
     $      	          1.5306, 1.2437, 1.1150, 0.9105,
     $      	          1.5328, 1.2455, 1.1157, 0.9104,
     $      	          1.5543, 1.2615, 1.1224, 0.9104,
     $      	          1.5565, 1.2633, 1.1231, 0.9104,
     $      	          1.5638, 1.2686, 1.1258, 0.9104,
     $      	          1.5761, 1.2776, 1.1303, 0.9096,
     $      	          1.5836, 1.2828, 1.1331, 0.9091,
     $      	          1.5886, 1.2863, 1.1346, 0.9088,
     $      	          1.5950, 1.2916, 1.1367, 0.9084,
     $      	          1.6080, 1.3023, 1.1411, 0.9084,
     $      	          1.6145, 1.3077, 1.1436, 0.9084,
     $      	          1.6167, 1.3094, 1.1444, 0.9084,
     $      	          1.6298, 1.3200, 1.1495, 0.9084,
     $      	          1.6320, 1.3217, 1.1503, 0.9084,
     $      	          1.6342, 1.3237, 1.1512, 0.9084,
     $      	          1.6408, 1.3297, 1.1539, 0.9084,
     $      	          1.6478, 1.3358, 1.1566, 0.9084,
     $      	          1.6549, 1.3418, 1.1594, 0.9084,
     $      	          1.6596, 1.3458, 1.1612, 0.9084,
     $      	          1.6620, 1.3478, 1.1621, 0.9084,
     $      	          1.6667, 1.3510, 1.1639, 0.9084,
     $      	          1.6812, 1.3606, 1.1692, 0.9084,
     $      	          1.6861, 1.3639, 1.1712, 0.9084,
     $      	          1.6985, 1.3739, 1.1762, 0.9084,
     $      	          1.7009, 1.3759, 1.1773, 0.9084,
     $      	          1.7059, 1.3800, 1.1793, 0.9084,
     $      	          1.7084, 1.3820, 1.1803, 0.9104,
     $      	          2.2800, 1.8700, 1.4000, 0.9100 /
C
C
      END
C
C
C~FORAUS_HMP0~C 
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE HMP0_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE HMP0_UHTC SIA CHIAMATA DA HMP0
C	    RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C		    HTCS < 0.
C
C  La subroutine fornisce al modulo HMP0 il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P	  pressione del fluido  		  [Pa]  	
C   H	  entalpia specifica del fluido 	  [J/kg]	
C   S	  entropia specifica del fluido 	  [J/kg/C] 
C   TF    temperatura del fluido		  [K]
C   RO    densita' del fluido			  [kg/m**3]	
C   TP    temperatura di parete 		  [K]
C   DIA   diametro idraulico del condotto	  [m]
C   HTCS  dato fornito dall'utente nel file F14
C	  per ogni cella del canale.
C	  In questa subroutine puo` essere usato 
C	  come si vuole.
C	  RICORDATI CHE HTCS E` NEGATIVO !!!
C   G	  portata specifica di fluido		  [kg/m**2/s]	
C   Q	  potenza totale scambiata		  [W]		
C   SUP   superficie di scambio 		  [m**2]	
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C	SUBROUTINE HMP0_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
CC	IMPLICIT DOUBLE PRECISION (A-H, O-Z)				  !DBLE
C     RETURN
C     END
C
C~FORAUS_HMP0~C 





























































 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
