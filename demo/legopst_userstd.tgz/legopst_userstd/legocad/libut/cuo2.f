C**********************************************************************
C modulo cuo2.f
C tipo 
C release  3.1
C data 9/5/94
C reserver @(#)cuo2.f	3.1
C**********************************************************************
C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE CUO2I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/CUO201/IBLOC
      COMMON/CUO202/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'CUO2'/
C
      CALL CUO2I4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      DO I=1,NCEL
      WRITE(IFO,3001)I,IOB,I
 3001 FORMAT('T',I2,'1',A4,2X,
     $'--US-- TEMPERATURA AL CENTRO DELLA BARRETTA CELLA ASSIALE ',I2)
      WRITE(IFO,3002)I,IOB,I
 3002 FORMAT('T',I2,'2',A4,2X,
     $'--US-- TEMPERATURA INTERNA DELLA BARRETTA   CELLA ASSIALE ',I2)
      WRITE(IFO,3003)I,IOB,I
 3003 FORMAT('T',I2,'3',A4,2X,
     $'--US-- TEMPERATURA SUPERFICIALE DELLA BARRETTA ',
     1'CELLA ASSIALE ',I2)
      ENDDO
C
      DO I=1,NCEL
      WRITE(IFO,3004)I,IOB,I
 3004 FORMAT('QG',I2,A4,2X,
     $'--UA-- POTENZA DALLA BARRETTA ALLA GUAINA CELLA ASS. ',I2)
      ENDDO
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('QNEU',A4,2X,
     $'--IN-- POTENZA TERMICA TOTALE GENERATA NELL''UO2')
C
      DO I=1,NCEL
      WRITE(IFO,3006)I,IOB,I
 3006 FORMAT('TG',I2,A4,2X,
     $'--IN-- TEMPERATURA INTERNA DI GUAINA CELLA ASS. ',I2)
      ENDDO
C
      RETURN
      END
      SUBROUTINE CUO2I4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/CUO201/IBLOC
      COMMON/CUO202/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      MAX=10
C
    1 WRITE(6,1001)MAX
 1001 FORMAT(10X,'NUMERO DI CELLE ASSIALI (01 -',I2,') ?')
      READ(5,*)NCEL
      IF(NCEL.LE.0.OR.NCEL.GT.MAX)GO TO 1
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
C
      RETURN
      END
      SUBROUTINE CUO2I1(IFUN,K,IBL1,IBL2,NSTATI,NUSCIT,NINGRE)
C
C     BARRA DI COMBUSTIBILE  UO2+INTERCAPEDINE
C         3 CELLE RADIALI
C         N CELLE ASSIALI  (MAX=10)
C                 *==================*=================*=========
C        .     .   *                  *                 *
C         .     .   *                  *                 *
C          .     .   *                  *                 *
C    PT     .     .   *       Q         *        Q        *
C    +       .    .   *      ===>>      *       ====>>    *
C            .    .   *                 *                 *
C           .    .   *                 *                 *
C          .    .   *                 *                 *
C        .     .   *=================*================*===========
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      GO TO (1,10),IFUN
    1 MAX=10
      WRITE(6,1000)MAX
 1000 FORMAT(//10X,'BARRE DI COMBUSTIBILE CON 3 CELLE RADIALI'//
     $         10X,'NUMERO DI CELLE ASSIALI (01-',I3,') ?')
    2 READ(5,*)N
 1001 FORMAT(I2)
      IF(N.GT.1.AND.N.LE.MAX)GO TO 3
      WRITE(6,1002)N
 1002 FORMAT(10X,'ERRORE - N.CELLE=',I3/)
      GO TO 2
C
   3  NSTATI=3*N
      NUSCIT=N
      NINGRE=N+1
      RETURN
C
   10 IF(K.GT.NSTATI)GO TO 12
      IF(K.GT.1)GO TO 11
      WRITE(6,1004)
 1004 FORMAT(/20X,'VARIABILI DI STATO'//)
C
   11 KA=(K-1)/3
      KR=K-KA*3
      KA=KA+1
      WRITE(6,1005)KA,KR
 1005 FORMAT(14X,'TEMPERATURA MEDIA CELLA ASS.',I2,' CELLA RAD.',I2)
      GO TO 30
C
  12  KA=K-NSTATI
      IF(KA.GT.NUSCIT)GO TO 20
      IF(KA.GT.1)GO TO 15
      WRITE(6,1006)
 1006 FORMAT(/20X,'VARIABILI DI USCITA'//)
  15  WRITE(6,1007)KA
 1007 FORMAT(14X,'POTENZA CEDUTA ALLA GUAINA CELLA ASS.',I2)
      GO TO 30
   20 KA=K-NSTATI-NUSCIT
      IF(KA.NE.1)GO TO 25
      WRITE(6,1008)
 1008 FORMAT(/20X,'VARIABILI DI INGRESSO'//)
      WRITE(6,1009)
 1009 FORMAT(14X,'POTENZA TERMICA GENERATA')
      GO TO 30
C
  25  KA=KA-1
      WRITE(6,1010)KA
 1010 FORMAT(14X,'TEMPERATURA GUAINA SUP. INT. CELLA ASS.',I2)
   30 RETURN
      END
      SUBROUTINE CUO2I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBL1,IBL2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=10)
      DIMENSION AL(MAX),CPT(MAX),SUP(MAX)
      INTEGER VAR
      DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
      CHARACTER*4 IN1,IR,IRG,IL1,IK,IN2
      CHARACTER*2 IL2
      CHARACTER*1 IB
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      DATA IN1/'N.BA'/,IN2/'RRE'/,IR/'RUO2'/,IRG/'RGUA'/,
     $     IL1/'L CE'/,IL2/'L.'/,IK/'K PT'/,IB/' '/
C
C
      NVAR=IV2-IV1+1
      N=NVAR/5
      GO TO (1,10),IFUN
C
C  SCRITTURA SIMBOLI DEI DATI SU FILE 14
C
   1  WRITE(14,1000)IN1,IN2,IR,IB,IRG,IB
 1000 FORMAT(3(4X,2A4,' =',10X,'*'),5X)
      WRITE(14,1001)(IL1,IL2,I,I=1,N)
 1001 FORMAT(3(4X,A4,A2,I2,' =',10X,'*'),5X)
C
      WRITE(14,1001)(IK,IB,I,I=1,N)
      RETURN
C
C  LETTURA DEI DATI DA FILE 14
C
  10  READ(14,1002)
      READ(14,1002)BAR,RUO2,RGUI
 1002 FORMAT(3(14X,F10.0,1X),5X)
      READ(14,1002)(AL(I),I=1,N)
      READ(14,1002)(CPT(I),I=1,N)
C
C  CALCOLI PER STAMPE DI CONTROLLO
C
      S=0.
      SO=0.
      PI=3.141592
      ROUO2=10950.
      H=0.
      DO 15 I=1,N
      H=H+AL(I)
      SUP(I)=AL(I)*BAR*2.*PI*RGUI
      S=S+SUP(I)
      SO=CPT(I)+SO
   15 CONTINUE
      VOL=RUO2*RUO2*PI*H*BAR
      WEI=ROUO2*VOL
C
C      CALCOLO DEI COEFFICIENTI DI RIPARTIZIONE DELLA
C      POTENZA TERMICA LUNGO LE CELLE ASSIALI
C      SE CPT(I)=0. ==>DISTRIBUZIONE COSINUSOIDALE
C      SE CPT(I)>0. ==>DISTRIBUZIONE ASSEGNATA DA FILE 14
C
C                        * II *
C                     *    II    *
C                   *      II      *
C                 *        II        *
C               *          II          *
C              *           II            *
C             *            II             *
C            *             II              *
C      _____I______________II_______________I______
C          -L/2                            L/2
C
C
      IF(SO.GT.1.E-3)GO TO 35
C
C  LE LUNGHEZZE (1-N)SI CONSIDERANO
C  DAL BASSO VERSO L'ALTO
C
       H2=-H/2.
       ALI=H2
       DO 30 I=1,N
       ALF=ALI+AL(I)
       CPT(I)=(SIN(PI*ALF/H)-SIN(PI*ALI/H))/2.
       ALI=ALF
   30 CONTINUE
C
C  MEMORIZZAZIONE DEI DATI
C
   35 DATI(ID2)=N
      DO 40 I=1,N
      DATI(ID2+I)=W0*H0/(T0*ROUO2*PI*RUO2*RUO2*AL(I)*BAR)
      K=ID2+N
      DATI(K+I)=CPT(I)
      J=ID2+2*N
      DATI(J+I)=SUP(I)
   40 CONTINUE
      ID2=ID2+3*N
      DATI(ID2+1)=1./(ROUO2*RUO2*RUO2)
      ID2=ID2+1
C
C      STAMPA DEI DATI
C
      WRITE(6,3000)
      WRITE(6,3001)WEI,VOL,S
 3000 FORMAT(/10X,'MASSA DEL COMBUSTIBILE     VOLUME     SUPERFICIE')
 3001 FORMAT(15X,E12.5,5X,E12.5,3X,E12.5)
      WRITE(6,3002)
 3002 FORMAT(//5X,'CELLA  LUNGHEZZA  SUPERFICIE  POTENZA TERM. GENER.'/)
      DO 50 I=1,N
      WRITE(6,3003)I,AL(I),SUP(I),CPT(I)
 3003 FORMAT(5X,I4,5X,F6.2,5X,F6.1,10X,F6.3)
   50 CONTINUE
C
C  COSTANTI DI NORMALIZZAZIONE
C
      N3=3*N
      DO 60 I=1,N3
      CNXYU(IV1+I-1)=T0
   60 CONTINUE
      K=IV1+N3-1
      DO 70 I=1,N
      CNXYU(K+I)=W0*H0
   70 CONTINUE
      K=K+N+1
      CNXYU(K)=W0*H0
      DO 80 I=1,N
      CNXYU(K+I)=T0
   80 CONTINUE
C
C  TOLLERANZE STANDARD(1.E-4)
C
      RETURN
      END
      SUBROUTINE CUO2C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
       DATA SccsID/'@(#)cuo2.f	3.1\t 3.1\t 9/5/94'/          
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
      PARAMETER (MAX=10)
      DIMENSION 
     $  TF(MAX,3),TG(MAX),Q(MAX),CF(MAX,3),COND(MAX,3),HUG(MAX)
     $  ,SUP(MAX),CPT(MAX),B(MAX)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C*****POTENZA CEDUTA ALLA GUAINA
C*****CONVENZIONE DI SEGNO : POSITIVA==>USCENTE DALLA GUAINA
C*****MODIF. 28/9/82         GUAINA====>MODULO META
C*****     ISIGN = -1     (PER CAMBIARE CONVENZIONE PORRE ISIGN=1)
C
      ISIGN=-1
      N=DATI(IPD)
      M=3
      N3=3*N
      N4=4*N
      GO TO (1,20,20),IFUN
C
C  TOPOLOGIA JACOBIANO
C
    1 DO10 I=1,N
      K=(I-1)*M+1
C
C EQUAZIONI DIFFERENZIALI
C
      AJAC(K,N4+1   )=1.
      AJAC(K,K      )=1.
      AJAC(K,K+1    )=1.
      AJAC(K+1,K    )=1.
      AJAC(K+1,K+1  )=1.
      AJAC(K+1,K+2  )=1.
      AJAC(K+1,N4+1 )=1.
      AJAC(K+2,N4+1 )=1.
      AJAC(K+2,K+2  )=1.
      AJAC(K+2,N3+I )=1.
      AJAC(K+2,K+1  )=1.
C
C  EQUAZIONI ALGEBRICHE
C
      AJAC(N3+I,K   )=1.
      AJAC(N3+I,K+1 )=1.
      AJAC(N3+I,K+2 )=1.
      AJAC(N3+I,N3+I)=1.
      AJAC(N3+I,N4+I+1)=1.
   10 CONTINUE
      RETURN
C
C  DECODIFICA VARIABILI
C
   20 K=IXYU-1
      K3=K+N3
      K4=K+N4+1
      DO 30 I=1,N
      DO 25 L=1,3
      J=(I-1)*M+L
      TF(I,L)=XYU(K+J)
   25 CONTINUE
      Q(I)=XYU(K3+I)
      TG(I)=XYU(K4+I)
   30 CONTINUE
      PT=XYU(K4)
C
C  CALCOLO DEI CALORI SPECIFICI UO2(CF)
C          DELLE CONDUCIBILITA'
C          DEL COEFF. DI SCAMBIO INTERC.-GUAINA
C
      DO 40 I=1,N
      DO 35 J=1,3
      T=TF(I,J)*T0
      CF(I,J)=FCUO21(T)
      IF(J.EQ.3)GO TO 35
      TT=TF(I,J+1)*T0
      TM=(T+TT)/2.
      COND(I,J)=FCUO22(TM)
   35 CONTINUE
      T=TF(I,3)*T0
      HUG(I)=FCUO23(T)*T0/(W0*H0)
   40 CONTINUE
C
C  DECODIFICA DEI DATI
C
      DO  50 I=1,N
      B(I)=DATI(IPD+I)
      K=IPD+N
      CPT(I)=DATI(K+I)
      J=IPD+2*N
      SUP(I)=DATI(J+I)
   50 CONTINUE
      AA=DATI(IPD+N3+1)
C
      IF(IFUN.EQ.3)GO TO 70
C
C  CALCOLO DERIVATE E RESIDUI
C
      DO 60 I=1,N
      K=(I-1)*M+1
      RNI(K)    =8.*AA*COND(I,1)/CF(I,1)*(TF(I,2)-TF(I,1))
     $           +B(I)*CPT(I)*PT/CF(I,1)
      RNI(K+1) =-4.*AA*COND(I,1)/CF(I,2)*(TF(I,2)-TF(I,1))
     $         +12.*AA*COND(I,2)/CF(I,2)*(TF(I,3)-TF(I,2))
     $           +B(I)*CPT(I)*PT/CF(I,2)
      RNI(K+2)=-24.*AA*COND(I,2)/CF(I,3)*(TF(I,3)-TF(I,2))
     $           +B(I)*CPT(I)*PT/CF(I,3)
     $           -B(I)*4.*Q(I)/CF(I,3)*ISIGN
C
      RNI(N3+I)= ISIGN*Q(I)-HUG(I)*SUP(I)*(TF(I,3)-TG(I))
   60 CONTINUE
      RETURN
C
C  CALCOLO DELLO JACOBIANO
C      SI TRASCURANO LE DIPENDENZE DI  CF,COND,HUG DALLA TEMPERATURA
C
   70 DO 80 I=1,N
C***EQUAZIONI DIFFERENZIALI
      K=(I-1)*M+1
      AJAC(K,N4+1     )=B(I)*CPT(I)/CF(I,1)
      AJAC(K,K        )=-8.*AA*COND(I,1)/CF(I,1)
      AJAC(K,K+1      )=-AJAC(K,K)
      AJAC(K+1,N4+1   )=B(I)*CPT(I)/CF(I,2)
      AJAC(K+1,K      )= 4.*AA*COND(I,1)/CF(I,2)
      AJAC(K+1,K+1)=-4.*AA*COND(I,1)/CF(I,2)-12.*AA*COND(I,2)/CF(I,2)
      AJAC(K+1,K+2    )=12.*AA*COND(I,2)/CF(I,2)
      AJAC(K+2,N4+1   )=B(I)*CPT(I)/CF(I,3)
      AJAC(K+2,K+1    )=24.*AA*COND(I,2)/CF(I,3)
      AJAC(K+2,K+2    )=-AJAC(K+2,K+1)
      AJAC(K+2,N3+I   )= -B(I)*4./CF(I,3)*ISIGN
C
C***EQUAZIONI ALGEBRICHE
C
      AJAC(N3+I,K+2   )= HUG(I)*SUP(I)
      AJAC(N3+I,N3+I  )= -1.*ISIGN
      AJAC(N3+I,N4+I+1)=-AJAC(N3+I,K+2)
  80  CONTINUE
      RETURN
      END
C
C
      FUNCTION FCUO21(T)
C
C**CALCOLO DEL CALORE SPECIFICO UO2
C     RIF.: RAPPORTO  EDF (TB 71-9) ==>URANIUM DIOXIDE UO2 -USAEC
C        FCUO21(J/KG/K)  T(K)
C
      FCUO21=4186.8/270.*(18.45+.002431*T-2.272E5/(T*T))
      RETURN
      END
C
C
      FUNCTION FCUO22(T)
C
C**CALCOLO DELLA CONDUCIBILITA' UO2
C     RIF.: RAPPORTO  EDF (TB 71-9) ==>GENERAL ELECTRIC GEAP 5493
C        FCUO22(W/M/K)  T(K)
C
      FCUO22=1./(.0322+.0002497*T)+.641576E-10*T*T*T
      RETURN
      END
C
C
      FUNCTION FCUO23(T)
C
C**CALCOLO DEL COEFFICIENTE DI SCAMBIO INTERC.-GUAINA
      FCUO23=10000.
      RETURN
      END
C
C
C******************************************************************************
C
      SUBROUTINE CUO2D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $ XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
C
C
C~FORAUS_CUO2~C
C
C FORTRAN AUSILIARIO DEL MODULO BARRE DI COMBUSTIBILE NUCLEARE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLE FUNCTIONS: ******************
C            FCUO21
C            FCUO22
C            FCUO23
C_______________________________________________________________________________
C_____________FUNCTION FCUO21(T)
C**calcolo del calore specifico uo2
C (puo` essere funzione della temperatura)
C       FCUO21  calore specifico del biossido di uranio (J/KG/K)
C       T       temperatura (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO21(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO21(T)                              !DBLE
C       RETURN
C       END
C_______________________________________________________________________________
C_____________FUNCTION FCUO22(T)
C**calcolo della conducibilita' uo2
C (puo` essere funzione della temperatura)
C        FCUO22  conducibilita` uo2  (W/M/K)
C        T       temperatura  (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO22(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO21(T)                              !DBLE
C       RETURN
C       END
C_______________________________________________________________________________
C_____________FUNCTION FCUO23(T)
C**calcolo del coefficiente di scambio intercapedine-guaina
C (puo` essere funzione della temperatura)
C        FCUO23  coefficiente di scambio (W/M**2)
C        T       temperatura  (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO23(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO21(T)                              !DBLE
C       RETURN
C       END
C~FORAUS_CUO2~C
