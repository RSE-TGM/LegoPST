C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE CND0I3 (IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/CND000/IBLOC,NSIL,NSOL,NDIL,NCOL
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'CND0'/
      CALL CND0I4(IOB,MOD)
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A,'- **** MODULO ',A,' - ',A)
      NSTATI =   2
      NUSCIT =   6
      NINGRE = 2*(1+NSIL+NSOL+NDIL+NCOL+1)
C
      WRITE(IFO,3000)IOB
      WRITE(IFO,3001)IOB
      WRITE(IFO,3002)IOB
      WRITE(IFO,3003)IOB
      WRITE(IFO,3404)IOB
      WRITE(IFO,3004)IOB
      WRITE(IFO,3005)IOB
      WRITE(IFO,3006)IOB
      WRITE(IFO,3007)IOB
      WRITE(IFO,3008)IOB
C
 3000 FORMAT('PCND',A4,2X,'--US-- PRESSIONE NEL CONDENSATORE      ')
 3001 FORMAT('LCND',A4,2X,'--US-- LIVELLO   NEL CONDENSATORE      ')
 3002 FORMAT('TMFT',A4,2X,'--UA-- TEMPERATURA MEDIA METALLO USCITA
     $FASCI TUBIERI           ')
 3003 FORMAT('HURF',A4,2X,'--UA-- ENTALPIA REFRIGERANTE USCITA
     $FASCI TUBIERI           ')
 3404 FORMAT('HVCN',A4,2X,'--UA-- ENTALPIA VAPORE                 ')
 3004 FORMAT('HLCN',A4,2X,'--UA-- ENTALPIA CONDENSATO             ')
 3005 FORMAT('PFCN',A4,2X,'--UA-- PRESSIONE SUL FONDO DEL
     $CONDENSATORE            ')
 3006 FORMAT('%LCN',A4,2X,'--UA-- LIVELLO MISURATO                ')
 3007 FORMAT('WTUR',A4,2X,'--IN-- PORTATA DEL VAPORE SCARICATO DALLA
     $ TURBINA PRINCIPALE    ')
 3008 FORMAT('HTUR',A4,2X,'--IN-- ENTALPIA DEL VAPORE SCARICATO DALLA
     $ TURBINA PRINCIPALE    ')
C
      DO J=1,NSIL
        WRITE(IFO,3030)
     $ 'WS',J,IOB,'IN','STEAM INLET LINE N.',J,
     $                 ' STEAM MASS FLOW RATE',
     $ 'HS',J,IOB,'IN','STEAM INLET LINE N.',J,
     $                 ' STEAM ENTHALPY'
      END DO
C
      DO J=1,NSOL
        WRITE(IFO,3030)
     $ 'WO',J,IOB,'IN','STEAM OUTLET LINE N.',J,
     $                 ' STEAM MASS FLOW RATE',
     $ 'HO',J,IOB,'IN','STEAM OUTLET LINE N.',J,
     $                 ' REVERSE FLOW STEAM ENTHALPY'
      END DO
C
      DO J=1,NDIL
        WRITE(IFO,3030)
     $ 'WD',J,IOB,'IN','DRAIN INLET LINE N.',J,
     $                 ' DRAIN MASS FLOW RATE',
     $ 'HD',J,IOB,'IN','DRAIN INLET LINE N.',J,
     $                 ' DRAIN ENTHALPY'
      END DO
C
      DO J=1,NCOL
        WRITE(IFO,3030)
     $ 'WC',J,IOB,'IN','CONDENSATE OUTLET LINE N.',J,
     $                 ' CONDENSATE MASS FLOW RATE',
     $ 'HC',J,IOB,'IN','CONDENSATE OUTLET LINE N.',J,
     $                 ' REVERSE FLOW CONDENSATE ENTHALPY (WC<0)'
      END DO
C
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('WRFG',A4,2X,'--IN-- PORTATA REFRIGERANTE            ')
C
      WRITE(IFO,3010)IOB
 3010 FORMAT('HIRF',A4,2X,'--IN-- ENTALPIA REFRIGERANTE INGRESSO
     1 FASCI TUBIERI       ')
C
C
C     WRITE(IFO,3040)
 3030 FORMAT(1A2,I2,1A4,'  --',A2,'-- ',A,I2,A)
 3040 FORMAT(2A4,'  --',A2,'-- ',A)
      RETURN
      END
C      
C      
C      
      SUBROUTINE CND0I4 (IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/CND000/IBLOC,NSIL,NSOL,NDIL,NCOL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      PARAMETER(MAXNSIL=20,MAXNSOL=5,MAXNDIL=20,MAXNCOL=5)
C
      WRITE(6,100) MAXNSIL
  100 FORMAT(10X,'WATER STEAM CONDENSER'/
     $       10X,'NUMBER OF STEAM INLET LINES [00 -',I3,'] ?')
  20  CONTINUE
      READ(5,*) NSIL
      IF(NSIL.LT.0.OR.NSIL.GT.MAXNSIL) THEN
      WRITE(6,112) NSIL,MAXNSIL
  112 FORMAT(10X,'ERROR - NUMBER OF STEAM INLET LINES =',I3,/,
     $       10X,'Number of steam inlet lines out of range',/,
     $       10X,'Please reassigne data in range [00 -',I3,']')
      GOTO 20
      ENDIF
C
      WRITE(6,101) MAXNSOL
  101 FORMAT(10X,'WATER STEAM CONDENSER'/
     $       10X,'NUMBER OF STEAM OUTLET LINES [00 -',I3,'] ?')
  10  CONTINUE
      READ(5,*) NSOL
      IF(NSOL.LT.0.OR.NSOL.GT.MAXNSOL) THEN
      WRITE(6,102) NSOL,MAXNSOL
  102 FORMAT(10X,'ERROR - NUMBER OF STEAM OUTLET LINES =',I3,/,
     $       10X,'Number of steam outlet lines out of range',/,
     $       10X,'Please reassigne data in range [00 -',I3,']')
      GOTO 10
      ENDIF
C
      WRITE(6,107) MAXNDIL
  107 FORMAT(10X,'WATER STEAM CONDENSER'/
     $       10X,'NUMBER OF DRAIN INLET LINES [01 -',I3,'] ?')
  13  CONTINUE
      READ(5,*) NDIL
      IF(NDIL.LE.0.OR.NDIL.GT.MAXNDIL) THEN
      WRITE(6,108) NDIL,MAXNDIL
  108 FORMAT(10X,'ERROR - NUMBER OF DRAIN INLET LINES =',I3,/
     $       10X,'Number of drain intlet lines out of range',/
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 13
      ENDIF
C
      WRITE(6,201) MAXNCOL
  201 FORMAT(10X,'WATER STEAM CONDENSER'/
     $       10X,'NUMBER OF CONDENSATE OUTLET LINES [01 -',I3,'] ?')
  14  CONTINUE
      READ(5,*) NCOL
      IF(NCOL.LE.0.OR.NCOL.GT.MAXNCOL) THEN
      WRITE(6,202) NCOL,MAXNCOL
  202 FORMAT(10X,'ERROR - NUMBER OF CONDENSATE OUTLET LINES =',I3,/
     $       10X,'Number of condensate outlet lines out of range',/
     $       10X,'Please reassigne data in range [01 -',I3,']')
      GOTO 14
      ENDIF
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
      RETURN
      END
C
C
C
      SUBROUTINE CND0I2 (IFUN, VAR, MX1, IV1, IV2, XYU, DATI, ID1, ID2,
     $             IBL1, IBL2, IER, CNXYU, TOL)
C
C-------------------------------------------------------------------
C
C    N.S.I.L. =  Number of Steam Inlet Lines
C    N.S.O.L. =  Number of Steam Outlet Lines
C    N.D.I.L. =  Number of Drain Inlet Lines
C    N.C.O.L. =  Number of Condensate Outlet Lines
C
C--------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
      PARAMETER(MAXNSIL=20,MAXNSOL=5,MAXNDIL=20,MAXNCOL=5)
      PARAMETER(MAXNCEL=10)
C
      DIMENSION VAR(MX1, *), XYU(*), DATI(*), CNXYU(*), TOL(*)
      DIMENSION H(MAXNCEL),TMI(MAXNCEL)
C
      INTEGER IFUN, MX1, VAR
C
      REAL WSI(MAXNSIL),HSI(MAXNSIL),WSO(MAXNSOL),HSO(MAXNSOL)
      REAL WDI(MAXNDIL),HDI(MAXNDIL),WCE(MAXNCOL),HCE(MAXNCOL)
C
      COMMON /NORM/ P0, H0, T0,  W0,RO0, AL0, V0, DP0
C
      INTEGER ID2, IV1
C
C      REAL ANTUB
C      REAL DIAE
C      REAL DIAI
C      REAL ALUNG
C      REAL TYP
C      REAL VCAV
C      REAL ZERY
C      REAL VY
C      REAL GY
C      REAL SEZY
C      REAL ROM
C      REAL CPMET
C      REAL COND
C      REAL CSCM
C      REAL CSMF
C
      DATA PIGR,G/3.1415926,9.80665/
C
C     ----- CONDENSATORE   MODELLO CON CAVITA' IN EQUILIBRIO
C
      GO TO (100, 200), IFUN
C
  100 CONTINUE
C
      WRITE(14,500)'N.S.I.L.','N.S.O.L.','N.D.I.L.',
     $             'N.C.O.L.'     
C  
      WRITE (14, 500)'NTUB    ','DIAE    ','DIAI    ','LUNG    ',
     $'TYPE_CAV','VOL.CAV.','ZERO_Y  ','VOL_Y   ','GAMMA_Y ','SEZ_Y   ',
     $'ROM     ','CP MET. ','COND.MET','NCEL    '
C
      RETURN
C
C     -----  LETTURA E MEMORIZZAZIONE DATI
C
  200 CONTINUE
C
      READ (14, 501)
C
      READ(14,501) XNSIL,XNSOL,XNDIL
      READ(14,501) XNCOL
C
      READ (14, 501) ANTUB    , DIAE     , DIAI     , ALUNG    ,
     $ TYP      , VCAV     , ZERY     , VY       , GY       , SEZY     ,
     $ ROM      , CPMET    , COND     , ANCEL
C
 500  FORMAT (3(4X, A8, ' =',10X, '*'))
 501  FORMAT (3(14X, F10.0, 1X))
C
C
      NSIL=XNSIL
      NSOL=XNSOL
      NDIL=XNDIL
      NCOL=XNCOL
C
C     -----  COSTANTI DI NORMALIZZAZIONE
C
      CNXYU(IV1)     =  P0
      CNXYU(IV1+  1) =  1.
      CNXYU(IV1+  2) =  T0
      CNXYU(IV1+  3) =  H0
      CNXYU(IV1+  4) =  H0 
      CNXYU(IV1+  5) =  H0 
      CNXYU(IV1+  6) =  P0
      CNXYU(IV1+  7) =  1.
C
C---- Input Variables
C
      CNXYU(IV1+  8) =  W0
      CNXYU(IV1+  9) =  H0
C      
      IV1P9 = IV1+9
C      
C     CNXYU(IV1+  9) =  W0
C     CNXYU(IV1+ 10) =  H0     
C     CNXYU(IV1+ 11) =  W0
C     CNXYU(IV1+ 12) =  W0
C     CNXYU(IV1+ 13) =  H0
C     CNXYU(IV1+ 14) =  W0
C     CNXYU(IV1+ 15) =  W0
C     CNXYU(IV1+ 16) =  W0
C     CNXYU(IV1+ 17) =  H0
C     CNXYU(IV1+ 18) =  W0
C     CNXYU(IV1+ 19) =  H0
C
C
      NSIL2=2*NSIL
C
      DO I=1,NSIL2,2
         CNXYU(IV1P9+I) = W0
         CNXYU(IV1P9+I+1) = H0
      END DO
C
C
      IV1PA = IV1P9+NSIL2
C
      NSOL2=2*NSOL
C
      DO I=1,NSOL2,2
         CNXYU(IV1PA+I) = W0
         CNXYU(IV1PA+I+1) = H0
      END DO
C
      IV1PB = IV1PA+NSOL2
C
      NDIL2=2*NDIL
C
      DO I=1,NDIL2,2
         CNXYU(IV1PB+I) = W0
         CNXYU(IV1PB+I+1) = H0
      END DO
C
      IV1PC=IV1PB+NDIL2
C
      NCOL2=2*NCOL
C
      DO I=1,NCOL2,2
         CNXYU(IV1PC+I) = W0
         CNXYU(IV1PC+I+1) = H0
      END DO
C
      IV1PD=IV1PC+NCOL2
C
C
      CNXYU(IV1PD+1) = W0
      CNXYU(IV1PD+2) = H0
C
C
C   CALCOLO STAZIONARIO
C
CC&MARCH  INIZIO MODIFICA MARCH 22/9/92
C
      P        = XYU(IV1)
      Y        = XYU(IV1 +  1)
      TM       = XYU(IV1 +  2)
      HURF     = XYU(IV1 +  3)
C     HLS      = XYU(IV1 +  4)
      HVCA     = XYU(IV1 +  4)
      HLCA     = XYU(IV1 +  5)
      PF       = XYU(IV1 +  6)
      YP       = XYU(IV1 +  7)
C
C
C---- Input Variables
C      
      WTUR     = XYU(IV1 +  8)
      HTUR     = XYU(IV1 +  9)
C
C     WVV      = XYU(IV1 +  9)
C     HVVI     = XYU(IV1 + 10)
C     WEC      = XYU(IV1 + 11)
C     WDR      = XYU(IV1 + 12)
C     HDR      = XYU(IV1 + 13)
C     WLS      = XYU(IV1 + 14)
C     WVS      = XYU(IV1 + 15)
C     WRC      = XYU(IV1 + 16)
C     HRC      = XYU(IV1 + 17)
C     WCF      = XYU(IV1 + 18)
C     HI       = XYU(IV1 + 19)
C
C
C
      DO I=1,NSIL2,2
        K=INT(I/2.)+1
        WSI(K)=XYU(IV1P9+I)
        HSI(K)=XYU(IV1P9+I+1)
      END DO
C
      DO I=1,NSOL2,2
        K=INT(I/2.)+1
        WSO(K)=XYU(IV1PA+I)
        HSO(K)=XYU(IV1PA+I+1)
      END DO
C
      DO I=1,NDIL2,2
        K=INT(I/2.)+1
        WDI(K)=XYU(IV1PB+I)
        HDI(K)=XYU(IV1PB+I+1)
      END DO
C
      DO I=1,NCOL2,2
        K=INT(I/2.)+1
        WCE(K)=XYU(IV1PC+I)
        HCE(K)=XYU(IV1PC+I+1)
      END DO
C
C
      WRFG=XYU(IV1PD+1)
      HIRF=XYU(IV1PD+2)
C
C CALCOLO DATI GEOMETRICI
C
      NCEL=ANCEL+.1
      PINT=PIGR*ANTUB
      TSEZ=.25*PINT*DIAI**2
      VI=TSEZ*ALUNG/ANCEL
      DIAM=.5*(DIAE+DIAI)
      CTM=.25*PINT*(DIAE**2-DIAI**2)*ROM*CPMET*ALUNG/ANCEL
      ALNEI=.5*ALOG(DIAE/DIAI)
      ALNEM=.5*ALOG(DIAE/DIAM)
      ALNMI=.5*ALOG(DIAM/DIAI)
C
C COEFFICIENTE DI SCAMBIO LATO MANTELLO COSTANTE
C
      CTES=25000.
C
C PRESSIONE LATO TUBI COSTANTE
C
      PCI=300000.
C
      CALL SATUR(P,2,HLS,HVS,1)
      CALL SATUR(P,7,TSAT,AUS,1)
C
C INIZIALIZZAZIONE LIVELLO MISURATO
C
      IF (YP.LE.0.)  XYU(IV1+7)=0.01
C
C
C INIZIALIZZAZIONE STANDARD
C
C
C--- calcolo termini noti delle equazioni di conservazione dell'energia
C    del vapore e del liquido
C
      WSIT=0.
      WSIRT=0.
      WHSI=0.
      DO J=1,NSIL
        IF (WSI(J).GT.0.) THEN
          WSIT=WSIT+WSI(J)
          WHSI=WHSI+WSI(J)*HSI(J)
        ELSE
          WSIRT=WSIRT-WSI(J)
        ENDIF
      END DO
C
      WSOT=0.
      WSORT=0.
      WHSOR=0.
      DO J=1,NSOL
         IF (WSO(J).LT.0.) THEN
           WSORT=WSORT-WSO(J)
           WHSOR=WHSOR+ABS(WSO(J))*HSO(J)
         ELSE
           WSOT=WSOT+WSO(J)
         ENDIF
      END DO
C
      WDIT=0.
      WDIRT=0.
      WHDI=0.
      DO J=1,NDIL
         IF (WDI(J).GT.0.) THEN 
           WDIT=WDIT+WDI(J)
           WHDI=WHDI+WDI(J)*HDI(J)
         ELSE
          WDIRT=WDIRT-WDI(J)
         ENDIF
      END DO
C
      WCET=0.
      WCERT=0.
      WHCER=0.
      DO J=1,NCOL
         IF (WCE(J).LT.0.) THEN
           WCERT=WCERT-WCE(J)
           WHCER=WHCER+ABS(WCE(J))*HCE(J)
         ELSE
           WCET=WCET+WCE(J)
         ENDIF
      END DO
C
C
      SW=WTUR+WSIT+WDIT+WSORT+WCERT-WSIRT-WSOT-WDIRT-WCET
C
      IF (WTUR.GT.0) THEN
        SHIN=WTUR*HTUR+WHSI+WHDI+WHSOR+WHCER
        SHOUT=(WSIRT+WSOT)*HVCA+(WDIRT+WCET)*HLCA
      ELSE
        SHIN=WHSI+WHDI+WHSOR+WHCER
        SHOUT=(ABS(WTUR)+WSIRT+WSOT)*HVCA+(WDIRT+WCET)*HLCA
      ENDIF
C      
C
C INIZIALIZZAZIONE CON PORTATA DI REFRIGERANTE NULLA
C
      IF (WRFG.LE.0.) THEN
        HURF=HLCA
        SR=SHEV(PCI,HURF,1)
        TMRF=TEV(PCI,SR,1)
        DO I=1,NCEL
          H(I)=HURF
	  TMI(I)=TMRF
        END DO
      ELSE 
C
C STIMA DI HU SE NON VIENE ASSEGNATO UN VALORE DI TENTATIVO
C
        IF (HURF.LE.0.) THEN
          Q=SHIN-SHOUT
          HURF=HIRF+Q/WRFG
        ELSE
          Q=WRFG*(HURF-HIRF)
        ENDIF
C
        SR=SHEV(PCI,HURF,1)
        TF=TEV(PCI,SR,1)
        CPLR=CPEV(PCI,SR,0.,1.,1)
        WCFS=MAX(WRFG,10.)
        CALL GAM03(GAMMA,DGAM,WCFS,TSEZ,DIAI,PCI,TF)
        CSX=PINT/(1./(DIAE*CTES)+ALNEI/COND+1./(DIAI*GAMMA))
C
        WCP=WRFG*CPLR
        WCH=WCP/CSX
C
        EL=EXP(ALUNG/WCH)
        ALUNG=ALUNG/ANCEL
C
C STIMA DELLA DISTRIBUZIONE DI POTENZA E DI ENTALPIA LUNGO I TUBI
C
        DO I=1,NCEL-1
          EX=EXP(I*ALUNG/WCH)
          QC=Q*EL*(EX-1.)/(EX*(EL-1.))
          H(I)=HIRF+QC/WRFG
	  SRCI=SHEV(PCI,H(I),1)
	  TMI(I)=TEV(PCI,SRCI,1)
        END DO
C
        H(NCEL)=HURF
	TMI(NCEL)=TF
C
      ENDIF
C
C TERMINE INIZIALIZZAZIONE
C
C BETA : FATTORE PESO PER IL CALCOLO DELLA TEMPERATURA DI SCAMBIO
C
      BETA=0.3
C
      XYU(IV1+ 3)=HURF
C
      DATI(ID2)     = ANTUB
      DATI(ID2+  1) = DIAE
      DATI(ID2+  2) = DIAI
      DATI(ID2+  3) = ALUNG
      DATI(ID2+  4) = TYP
      DATI(ID2+  5) = VCAV
      DATI(ID2+  6) = ZERY
      DATI(ID2+  7) = VY
      DATI(ID2+  8) = GY
      DATI(ID2+  9) = SEZY
      DATI(ID2+ 10) = ROM
      DATI(ID2+ 11) = CPMET
      DATI(ID2+ 12) = COND
      DATI(ID2+ 13) = VI
      DATI(ID2+ 14) = CTM
      DATI(ID2+ 15) = ANCEL
      DATI(ID2+ 16) = ALNEI
      DATI(ID2+ 17) = ALNEM
      DATI(ID2+ 18) = ALNMI
      DATI(ID2+ 19) = TSEZ
      DATI(ID2+ 20) = PCI
      DATI(ID2+ 21) = CTES
      DATI(ID2+ 22) = BETA
      DATI(ID2+ 23) = NSIL
      DATI(ID2+ 24) = NSOL
      DATI(ID2+ 25) = NDIL
      DATI(ID2+ 26) = NCOL
C
C
      ID2 = ID2+ 26
C
      DO I=1,NCEL
        DATI(ID2+I)=H(I)
        DATI(ID2+NCEL+I)=TMI(I)
      END DO
C
      ID2 = ID2+ 2*NCEL
C
CC&MARC FINE MODIFICA MARCH 22/9/1992
C
      RETURN
      END
C
C
C
      SUBROUTINE CND0C1 (IFUN, AJAC, MX5, IXYU, XYU, IPD,
     $   DATI, RNI, IBLI, IBL2)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      INTEGER IFUN, MX5, IPD
      DIMENSION AJAC(MX5, *), XYU(*), DATI(*), RNI(*)
C
      EXTERNAL CND0
C
      INTEGER I, J, NSTATI, NUSCIT, NINGRE, IXYU
C
C     ----- CONDENSATORE   MODELLO CON CAVITA' IN EQUILF IO
C
      NSIL=DATI(IPD+ 23) 
      NSOL=DATI(IPD+ 24)
      NDIL=DATI(IPD+ 25) 
      NCOL=DATI(IPD+ 26) 
C
      NSTATI =   2
      NUSCIT =   6
      NINGRE =  2*(NSIL+NSOL+NDIL+NCOL+2)
      NEQ=NSTATI+NUSCIT
      NVAR=NEQ+NINGRE
C
      GOTO (100, 200, 300), IFUN
C     -----  TOPOLOGIA JACOBIANO
C
 100  DO 11 I= 1,NEQ
      DO 21 J= 1,NVAR
      AJAC(I,J) = 1.
 21   CONTINUE
 11   CONTINUE
      RETURN
C
C     -----  CALCOLO RESIDUI
C
 200  CALL CND0 (IFUN, IXYU, XYU, IPD, DATI, RNI)
      RETURN
C
C     -----  CALCOLO JACOBIANO NUMERICO
C
 300  CONTINUE
      EPS = 1.E-3
      EPSLIM = 1.E-7
      CALL NAJAC (AJAC, (MX5), IXYU, XYU, IPD, DATI, RNI,
     $      NSTATI, NUSCIT, NINGRE, EPS, EPSLIM, CND0)
C
      RETURN
      END
C
C-------------------------------------------------------------------------------
C
C
C-------------------------------------------------------------------------------
C
C
      SUBROUTINE CND0 (IFUN, IXYU, XYU, IPD, DATI, RNI)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION XYU(*), DATI(*), RNI(*)
C
      PARAMETER(MAXNSIL=20,MAXNSOL=5,MAXNDIL=20,MAXNCOL=5)
      PARAMETER(MAXNCEL=10)
C
      INTEGER IFUN, IXYU, IPD
C
      REAL WSI(MAXNSIL),HSI(MAXNSIL),WSO(MAXNSOL),HSO(MAXNSOL)
      REAL WDI(MAXNDIL),HDI(MAXNDIL),WCE(MAXNCOL),HCE(MAXNCOL)
C
      COMMON /NORM/ P0, H0, T0, W0, RO0, AL0, V0, DP0
      COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
      COMMON/REGIME/KREGIM
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT                   !SNGL
C      COMMON/INTEG1/TSTOP,TEMPO,DTINT,CDT,ALFADT,NPAS                   !DBLE
      DIMENSION H(MAXNCEL),TMI(MAXNCEL),TFI(MAXNCEL)
C
      LOGICAL KREGIM
C      REAL P
C      REAL Y
C      REAL TM
C      REAL HU
C      REAL HLS
C      REAL WV
C      REAL HVI
C      REAL WVV
C      REAL HVVI
C      REAL WEC
C      REAL WDR
C      REAL HDR
C      REAL WLS
C      REAL WVS
C      REAL WRC
C      REAL HRC
C      REAL WCF
C      REAL HI
C
C      REAL ANTUB
C      REAL DIAE
C      REAL DIAI
C      REAL ALUNG
C      REAL TYP
C      REAL VCAV
C      REAL ZERY
C      REAL VY
C      REAL GY
C      REAL SEZY
C      REAL ROM
C      REAL CPMET
C      REAL COND
C
      DATA PIGR,G/3.1415926,9.80665/
C
C     ----- CONDENSATORE   MODELLO CON EQUIL
C
C     -----  DECODIFICA VARIABILI E DATI
C
      ANTUB    = DATI(IPD)
      DIAE     = DATI(IPD +  1)
      DIAI     = DATI(IPD +  2)
      ALUNG    = DATI(IPD +  3)
      TYP      = DATI(IPD +  4)
      VCAV     = DATI(IPD +  5)
      ZERY     = DATI(IPD +  6)
      VY       = DATI(IPD +  7)
      GY       = DATI(IPD +  8)
      SEZY     = DATI(IPD +  9)
      ROM      = DATI(IPD + 10)
      CPMET    = DATI(IPD + 11)
      COND     = DATI(IPD + 12)
      VI       = DATI(IPD + 13)
      CTM      = DATI(IPD + 14)
      ANCEL    = DATI(IPD + 15)
      ALNEI    = DATI(IPD + 16)
      ALNEM    = DATI(IPD + 17)
      ALNMI    = DATI(IPD + 18)
      TSEZ     = DATI(IPD + 19)
      PCI      = DATI(IPD + 20)
      CTES     = DATI(IPD + 21)
      BETA     = DATI(IPD + 22)
      NSIL     = DATI(IPD + 23)
      NSOL     = DATI(IPD + 24)
      NDIL     = DATI(IPD + 25)
      NCOL     = DATI(IPD + 26)
C
      NCEL=ANCEL+.1
C
      DO I=1,NCEL
        H(I)     = DATI(IPD + 26 + I)
        TMI(I)   = DATI(IPD + 26 + I + NCEL)
      END DO
C
      NSIL2=2*NSIL
      NSOL2=2*NSOL
      NDIL2=2*NDIL
      NCOL2=2*NCOL
C
      P        = XYU(IXYU)*P0
      Y        = XYU(IXYU +  1)
      TMFT     = XYU(IXYU +  2)*T0
      HURF     = XYU(IXYU +  3)*H0
      HVCA     = XYU(IXYU +  4)*H0
      HLCA     = XYU(IXYU +  5)*H0
      PF       = XYU(IXYU +  6)*P0
      YP       = XYU(IXYU +  7)
      WTUR     = XYU(IXYU +  8)*W0
      HTUR     = XYU(IXYU +  9)*H0
C
C     WVV      = XYU(IXYU +  9)
C     HVVI     = XYU(IXYU + 10)
C     WEC      = XYU(IXYU + 11)
C     WDR      = XYU(IXYU + 12)
C     HDR      = XYU(IXYU + 13)
C     WLS      = XYU(IXYU + 14)
C     WVS      = XYU(IXYU + 15)
C     WRC      = XYU(IXYU + 16)
C     HRC      = XYU(IXYU + 17)
C     WCF      = XYU(IXYU + 18)
C     HI       = XYU(IXYU + 19)
C
C
      IXYUP9=IXYU+9
C
      DO I=1,NSIL2,2
        K=INT(I/2.)+1
        WSI(K)=XYU(IXYUP9+I)*W0
        HSI(K)=XYU(IXYUP9+I+1)*H0
      END DO
C
      IXYUPA=IXYUP9+NSIL2
C
      DO I=1,NSOL2,2
        K=INT(I/2.)+1
        WSO(K)=XYU(IXYUPA+I)*W0
        HSO(K)=XYU(IXYUPA+I+1)*H0
      END DO
C
      IXYUPB=IXYUPA+NSOL2
C
      DO I=1,NDIL2,2
        K=INT(I/2.)+1
        WDI(K)=XYU(IXYUPB+I)*W0
        HDI(K)=XYU(IXYUPB+I+1)*H0
      END DO
C
      IXYUPC=IXYUPB+NDIL2
C
      DO I=1,NCOL2,2
        K=INT(I/2.)+1
        WCE(K)=XYU(IXYUPC+I)*W0
        HCE(K)=XYU(IXYUPC+I+1)*H0
      END DO
C
      IXYUPD=IXYUPC+NCOL2
C
      WRFG=XYU(IXYUPD+1)*W0
      HIRF=XYU(IXYUPD+2)*H0
C
C
      CALL CND0ST(P,HLS,HVS,ROL,ROV,TSAT,DRLDP,DRVDP,DHLDP,DHVDP)
C
C
C--- calcolo termini noti delle equazioni di conservazione dell'energia
C    del vapore e del liquido
C
      WSIT=0.
      WSIRT=0.
      WHSI=0.
      DO J=1,NSIL
        IF (WSI(J).GT.0.) THEN
          WSIT=WSIT+WSI(J)
          WHSI=WHSI+WSI(J)*HSI(J)
        ELSE
          WSIRT=WSIRT-WSI(J)
        ENDIF
      END DO
C
      WSOT=0.
      WSORT=0.
      WHSOR=0.
      DO J=1,NSOL
         IF (WSO(J).LT.0.) THEN
           WSORT=WSORT-WSO(J)
           WHSOR=WHSOR+ABS(WSO(J))*HSO(J)
         ELSE
           WSOT=WSOT+WSO(J)
         ENDIF
      END DO
C
      WDIT=0.
      WDIRT=0.
      WHDI=0.
      DO J=1,NDIL
         IF (WDI(J).GT.0.) THEN 
           WDIT=WDIT+WDI(J)
           WHDI=WHDI+WDI(J)*HDI(J)
         ELSE
          WDIRT=WDIRT-WDI(J)
         ENDIF
      END DO
C
      WCET=0.
      WCERT=0.
      WHCER=0.
      DO J=1,NCOL
         IF (WCE(J).LT.0.) THEN
           WCERT=WCERT-WCE(J)
           WHCER=WHCER+ABS(WCE(J))*HCE(J)
         ELSE
           WCET=WCET+WCE(J)
         ENDIF
      END DO
C
C
      SW=WTUR+WSIT+WDIT+WSORT+WCERT-WSIRT-WSOT-WDIRT-WCET
C
      IF (WTUR.GT.0) THEN
        SHIN=WTUR*HTUR+WHSI+WHDI+WHSOR+WHCER
        SHOUT=(WSIRT+WSOT)*HVCA+(WDIRT+WCET)*HLCA
      ELSE
        SHIN=WHSI+WHDI+WHSOR+WHCER
        SHOUT=(ABS(WTUR)+WSIRT+WSOT)*HVCA+(WDIRT+WCET)*HLCA
      ENDIF
C      
C
C
      UMBETA=1.-BETA
C
      PINT=PIGR*ANTUB
C
C
C CALCOLO TEMPERATURA DI USCITA TUBI
C
      SR=SHEV(PCI,HURF,1)
      TFEX=TEV(PCI,SR,1)
C
C CALCOLO COEFF. DI SCAMBIO LIMINARE LATO TUBI
C
      WCFF=WRFG
      WCFS=MAX(WCFF,10.)
C
      CALL GAM03(GAMMA,DGAM,WCFS,TSEZ,DIAI,PCI,TFEX)
C
C
C CALCOLO PRODOTTO COEFF. DI SCAMBIO * SUPERFICIE
C CSTOT  FRA FLUIDO LATO MWRCANTELLO E LATO TUBI
C CSE    FRA FLUIDO LATO MANTELLO E CENTRO PARETE TUBI
C CSI    FRA CENTRO PARETE TUBI E FLUIDO NEI TUBI
C
      CSTOT=PINT*ALUNG/(1./(DIAE*CTES)+ALNEI/COND+1./(DIAI*GAMMA))
      CSE=PINT*ALUNG/(1./(DIAE*CTES)+ALNEM/COND)
      CSI=PINT*ALUNG/(ALNMI/COND+1./(DIAI*GAMMA))
C
C CALCOLO DEL REGIME STAZIONARIO
C
      IF (KREGIM) THEN
C
C  QQ    POTENZA TOTALE
C  QC    POTENZA DI CELLA
C  TFIN  TEMPERATURA DEL REFRIGERANTE ENTRANTE NELLA CELLA
C  TFU   TEMPERATURA DEL REFRIGERANTE USCENTE DALLA CELLA
C  HIN   ENTALPIA DEL REFRIGERANTE ENTRANTE NELLA CELLA
C  HUC   ENTALPIA DEL REFRIGERANTE USCENTE DALLA CELLA
C  HIS   ENTALPIA DEL REFRIGERANTE ENTRANTE NELLA CELLA ALLA
C         ITERAZIONE PRECEDENTE
C  TMM   TEMPERATURA DEL CENTRO DELLA PARETE DEL TUBO NELLA CELLA
C
       QQ=0.
       DO 10 J=2,NCEL
        I=NCEL+2-J
C
        IF (I.EQ.NCEL) THEN
         HUC=HURF
         SR=SHEV(PCI,HUC,1)
         TFU=TEV(PCI,SR,1)
        ELSE
         HUC=HIN
         TFU=TFIN
        ENDIF
C
        HIS=H(I-1)
C
        IF (ITERT.EQ.0) THEN
         SR=SHEV(PCI,HIS,1)
         TFIN=TEV(PCI,SR,1)
        ENDIF
C
        CPLR=CPEV(PCI,SR,0.,1.,1)
C
        HIN=(WRFG*HUC-CSTOT*(TSAT-BETA*(TFIN-HIS/CPLR)-UMBETA*TFU))/
     $      (WRFG-CSTOT*BETA/CPLR)
C
        SR=SHEV(PCI,HIN,1)
        TFIN=TEV(PCI,SR,1)
C
        QC=CSTOT*(TSAT-BETA*TFIN-UMBETA*TFU)
C
        TMM=(CSE*TSAT+CSI*(BETA*TFIN+UMBETA*TFU))/(CSE+CSI)
C
        QQ=QQ+QC
C
        IF (IFUN.EQ.2) THEN
         DATI(IPD+26+I-1)=HIN
         DATI(IPD+26+I+NCEL)=TMM
        ENDIF
C
C
   10  CONTINUE
C
       SR=SHEV(PCI,HIRF,1)
       TFIX=TEV(PCI,SR,1)
C
       QC=CSTOT*(TSAT-BETA*TFIX-UMBETA*TFIN)
       QQ=QQ+QC
C
       TMM=(CSE*TSAT+CSI*(BETA*TFIX+UMBETA*TFIN))/(CSE+CSI)
C
       IF (IFUN.EQ.2) THEN
        DATI(IPD+26+NCEL)=HURF
        DATI(IPD+26+NCEL+1)=TMM
       ENDIF
C
C
C  CALCOLO DEI RESIDUI
C
       RNI(1)=(SHIN-SHOUT-WRFG*(HURF-HIRF))/(W0*H0)
       RNI(2)=SW/W0
       RNI(3) =  TMM/T0-TMFT/T0
C
       IF (WRFG.GT.10.) THEN
        RNI(4) = HIRF/H0+QQ/(WRFG*H0)-HURF/H0
       ELSE
        RNI(4) = QQ/(W0*H0)
       ENDIF
C
       RNI(5) =  HVS/H0-HVCA/H0
       RNI(6) =  HLS/H0-HLCA/H0
       RNI(7) =  PF/P0-P/P0-(G*ROL*Y)/P0
       CALL CND0TY(TYP,SEZY,Y,ZERY,GY,VY,VL,DVLDY,YPER)
       RNI(8) =  YP-YPER
C
      ELSE
C
C
C  CALCOLO DEL TRANSITORIO
C
C
      IF (IFUN.EQ.3.OR.ITERT.GT.0.) GO TO 104
C
C
C  HIN    ENTALPIA INGRESSO CELLA ALL' ISTANTE T+DT
C  HIP    ENTALPIA INGRESSO CELLA ALL' ISTANTE T
C  TFIN   TEMPERATURA INGRESSO CELLA ALL' ISTANTE T+DT
C  TFIP   TEMPERATURA INGRESSO CELLA ALL' ISTANTE T
C  TFI(I) TEMPERATURA USCITA CELLA ALL' ISTANTE T
C  H(I)   ENTALPIA USCITA CELLA ALL' ISTANTE T
C  TMI(I) TEMPERATURA PARETE CELLA ALL' ISTANTE T
C
      DO 100 I=1,NCEL
       IF (I.EQ.1) THEN
        HIN=HIRF
        HIP=HIN
        HAUS=HIN
        SR=SHEV(PCI,HIN,1)
        TFIN=TEV(PCI,SR,1)
        TFIP=TFIN
       ELSE
        HIP=HAUS
        HIN=H(I-1)
        TFIP=TFI(I-1)
       ENDIF
       HAUS=H(I)
C
C
       SR=SHEV(PCI,H(I),1)
       TF=TEV(PCI,SR,1)
       TFI(I)=TF
       RF=ROEV(PCI,SR,1)
       CPLR=CPEV(PCI,SR,0.,1.,1)
C
C
       TAUH=VI*RF
C
       TT1=CDT*(WRFG*(HIP-H(I))+CSI*(TMI(I)-BETA*TFIP-UMBETA*TFI(I)))
       TT2=CDT*(CSE*(TSAT-TMI(I))-CSI*(TMI(I)-BETA*TFIP-UMBETA*TFI(I)))
C
       CA1=CDT*WRFG
       C11=TAUH+CDT*(WRFG+CSI*UMBETA/CPLR)
       C12=-CDT*CSI
       C21=C12*UMBETA/CPLR
       C22=CTM+CDT*(CSE+CSI)
       CB1=CSI*(BETA*TFIN+UMBETA*(TFI(I)-H(I)/CPLR))
       TTN1=TT1-CDT*CB1+TAUH*H(I)+CA1*HIN
       TTN2=TT2+CDT*(CSE*TSAT+CB1)+CTM*TMI(I)
       H(I)=(C22*TTN1-C12*TTN2)/(C11*C22-C12*C21)
       TMI(I)=(TTN2-C21*H(I))/C22
C
       SR=SHEV(PCI,H(I),1)
       TFIN=TEV(PCI,SR,1)
C
C
       DATI(IPD+26+I)=H(I)
       DATI(IPD+26+I+NCEL)=TMI(I)
C
  100 CONTINUE
C
  104 CONTINUE
C
      CALL CND0TY(TYP,SEZY,Y,ZERY,GY,VY,VL,DVLDY,YPER)
      CM11=DVLDY*(ROL-ROV)
      CM12=VL*DRLDP+(VCAV-VL)*DRVDP
      CM21=DVLDY*(ROL*HLCA-ROV*HVCA)
      CM22=VL*(ROL*DHLDP+HLCA*DRLDP)+(VCAV-VL)*(ROV*DHVDP+HVCA*DRVDP)-
     $VCAV
      DET=CM11*CM22-CM12*CM21
      TN1=SW
C
      QQ=0.
      DO I=1,NCEL
        QQ=QQ+CSE*(TSAT-TMI(I))
      ENDDO
C
      TN2=SHIN-SHOUT-QQ
C
      RNI(1) =  (CM11*TN2-CM21*TN1)/(DET*P0)
      RNI(2) =  (CM22*TN1-CM12*TN2)/DET
      RNI(3) =  (TMFT-TMI(NCEL))/T0
      RNI(4) =  (HURF-H(NCEL))/H0
      RNI(5) =  (HVS-HVCA)/H0
      RNI(6) =  (HLS-HLCA)/H0
      RNI(7) =  (PF-P-G*ROL*Y)/P0
      CALL CND0TY(TYP,SEZY,Y,ZERY,GY,VY,VL,DVLDY,YPER)
      RNI(8) =  YP-YPER
C
      ENDIF
C
CC&MARC FINE MODIFICA MARCH 24/3/93
C
C  ATTENZIONE AI CAMBIAMENTI DEI NOMI DEI SOTTOPROGRAMMI
C
C   VSATR     E' DIVENTATO     CND0ST
C   CNDTYP    E' DIVENTATO     CND0TY
C
C
      RETURN
      END
      SUBROUTINE CND0ST(P,HL,HV,ROL,ROV,TS,DRLDP,DRVDP,DHLDP,DHVDP)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CALL SATUR(P,2,HL,HV,1)
      CALL SATUR(P,3,ROL,ROV,1)
      CALL SATUR(P,7,TS,AUS,1)
      PP=0.99*P
      CALL SATUR(PP,2,HLP,HVP,1)
      CALL SATUR(PP,3,RLP,RVP,1)
      DRLDP=100.*(ROL-RLP)/P
      DRVDP=100.*(ROV-RVP)/P
      DHLDP=100.*(HL-HLP)/P
      DHVDP=100.*(HV-HVP)/P
C
      RETURN
      END
C
C
C
C
C
C
      SUBROUTINE CND0TY(TYP,SEZY,Y,ZERY,GY,VY,VL,DVLDY,YPER)
C
C     **********CAVITA  CONDENSATORE DI VAPORE**********
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      IF(SEZY.LE.0.) THEN
      CALL   CND0LIV(TYP,Y,VL,DVLDY,YPER)
      ELSE
      YPER = (Y-ZERY)/GY*100.
      IF(Y.GE.ZERY)GO TO 10
      AMY = VY/ZERY
      VL = AMY*Y
      DVLDY = AMY
      GO TO 20
   10 VL = VY+SEZY*(Y-ZERY)
      DVLDY = SEZY
   20 ENDIF
      RETURN
      END
      SUBROUTINE CND0LIO(Y,RCAV,HLCAV,VL,DVLDY)
C
C Questa routine puo` essere chiamata in CND0LIV per
C calcolare il volume occupato in un cilindro orizzontale
C e DVLDY
C
C NOTI:
C     Y livello
C     RCAV  raggio del cilindro
C     HLCAV lunghezza del cilindro
C
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      ALFA  = ACOS((RCAV-Y)/RCAV)
      VL  = RCAV**2.*(ALFA-COS(ALFA)*SIN(ALFA))*HLCAV
C
      DVLDY  = 2.*RCAV*SIN(ALFA)*HLCAV
      IF(DVLDY.LT..1E-5)DVLDY = 0.
C
      RETURN
      END
CC
CC
      SUBROUTINE CND0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $   XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
CC
CC
C~FORAUS_CND0~C
C
C FORTRAN AUSILIARIO DEL MODULO CONDENSATORE DI VAPORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE CND0LIV(TYP,Y,VL,DVLDY,YPER)
C
C  La subroutine CND0LIV, in funzione dei valori TYP e Y
C  deve fornire  VL, DVLDY e YPER.
C
C  Parametri in ingresso:  TYP, Y
C  Parametri in uscita:    VL, DVLDY, YPER
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato TYPE_CAV nel file F14 (vedi scheda D1)  viene
C              utilizzato per distinguere le  diverse  geometrie  delle  cavita`
C              trattate dal modulo CND0 presenti contemporaneamente in un model-
C              lo matematico. Viene di solito usato all'interno della subroutine
C              come puntatore;
C
C  Y         = rappresenta la misura del livello totale nella cavita`in metri;
C
C  VL        = volume occupato dalla zona liquida in m**3;
C
C  DVLDY     = derivata del volume del liquido rispetto al livello;
C
C  YPER      = livello di liquido nel range di misura in %.
C
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  CND0LIV(TYP,Y,VL,DVLDY,YPER)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_CND0~C
