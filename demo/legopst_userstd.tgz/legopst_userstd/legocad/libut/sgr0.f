C**********************************************************************
C modulo sgr0.f
C tipo 
C release  3.1
C data 9/5/94
C reserver @(#)gvrs.f	3.1
C**********************************************************************
C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
C--------------------------------------------------------------------------------
C
C                  Casam 29 settembre 2010
C
C     Inibito il calcolo con pressione a monte come uscita
C
C       modifiche precedute da una riga di commento segnata da [ ......]
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/SGR001/IBLOC
      COMMON/SGR002/NCEL,NPAR
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      CHARACTER*1 IWP,IPIU
      DATA MOD/'SGR0'/
      DATA IPIU/'+'/
C
C
C   COLONNA DI FLUIDO SCAMBIANTE CON DUE PARETI 
C   OGNUNA DELLE QUALI CON SUPERFICIE PARI ALLA META` DEL TOTALE
C   -MIN 2 MAX 12 CELLE ASSIALI
C
C
C
C
      CALL SGR0I4(IOB,MOD)
C
C
C
      NSTATI= NCEL+1
      NUSCIT= 5*NCEL+1
      NINGRE= 2*NCEL+4
C
C
      READ(IBLOC,'(A1)')IWP
C
C  [ ........ aggiunta l'istruzione WP=1.
C
C      WP=0.
C      IF(IWP.EQ.IPIU)WP=1.
C
      WP=1.
C   ........................................]
C
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HU',I2,A4,2X,'--US-- ENTALPIA DI USCITA CELLA ',I2,
     1' DEL CANALE BOLLENTE GV')
   20 CONTINUE
C
      WRITE(IFO,3001) NCEL,IOB,NCEL
 3001 FORMAT('PU',I2,A4,2X,'--US-- PRESSIONE DI USCITA CELLA ',I2,
     1' DEL CANALE BOLLENTE GV')
C
      IF(WP.EQ.0.)WRITE(IFO,3002)IOB
      IF(WP.EQ.1.)WRITE(IFO,3007)IOB
 3002 FORMAT('PIRI',A4,2X,'--UA-- PRESSIONE IN INGRESSO ',
     1' AL CANALE BOLLENTE GV')
 3007 FORMAT('WIRI',A4,2X,'--UA-- PORTATA IN INGRESSO ',
     1' AL CANALE BOLLENTE GV')
C
      DO 30 K=1,NCEL
      WRITE(IFO,3003)K,IOB,K
 3003 FORMAT('Q1',I2,A4,2X,'--UA-- POTENZA DA PARETE 1 TUBI',
     1' A U GV E CELLA ',I2,' CANALE BOLLENTE')
   30 CONTINUE
C
      DO 31 K=1,NCEL
      WRITE(IFO,4003)K,IOB,K
 4003 FORMAT('Q2',I2,A4,2X,'--UA-- POTENZA DA PARETE 2 TUBI',
     1' A U GV E CELLA ',I2,' CANALE BOLLENTE')
   31 CONTINUE
C
      DO K=1,NCEL
      WRITE(IFO,3004)K,IOB,K
 3004 FORMAT('TL',I2,A4,2X,'--UA-- Temperatura liquido',
     1' CELLA ',I2,' CANALE BOLLENTE')
      WRITE(IFO,4004)K,IOB,K
 4004 FORMAT('G1',I2,A4,2X,'--UA-- Coeff. Scambio PARETE 1',
     1' Tubi A U - CELLA ',I2,' CANALE BOLLENTE')
      WRITE(IFO,5004)K,IOB,K
 5004 FORMAT('G2',I2,A4,2X,'--UA-- Coeff. Scambio PARETE 2',
     1' Tubi A U - fluido CELLA ',I2,' CANALE BOLLENTE')
      END DO
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HIRI',A4,2X,'--IN-- ENTALPIA FLUIDO IN INGRESSO', 
     1' AL CANALE BOLLENTE GV')
C
      IF(WP.EQ.0.)WRITE(IFO,3011)IOB
      IF(WP.EQ.1.)WRITE(IFO,3012)IOB
 3011 FORMAT('WIRI',A4,2X,'--IN-- PORTATA IN INGRESSO ',
     1' AL CANALE BOLLENTE GV')
 3012 FORMAT('PIRI',A4,2X,'--IN-- PRESSIONE IN INGRESSO ',
     1' AL CANALE BOLLENTE GV')
C
      WRITE(IFO,3008)NCEL,IOB,NCEL
 3008 FORMAT('WU',I2,A4,2X,'--IN-- PORTATA DI USCITA CELLA ',I2,
     1' DEL CANALE BOLLENTE GV')
C
      DO 40 K=1,NCEL
      WRITE(IFO,3009)K,IOB,K
 3009 FORMAT('T1',I2,A4,2X,'--IN-- TEMPERATURA PARETE 1 DELLA CELLA ',
     1I2,' DEI TUBI A U DEL GV')
   40 CONTINUE
C
      DO 41 K=1,NCEL
      WRITE(IFO,4009)K,IOB,K
 4009 FORMAT('T2',I2,A4,2X,'--IN-- TEMPERATURA PARETE 2 DELLA CELLA ',
     1I2,' DEI TUBI A U DEL GV')
   41 CONTINUE
C
      WRITE(IFO,3010)IOB
 3010 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO DELLA ',
     1'COLONNA BOLLENTE DEL GV')
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0I4(IOB,MOD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/SGR001/IBLOC
      COMMON/SGR002/NCEL,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      CHARACTER*4 MODU
      CHARACTER*1 ICA,IMEN,IPIU
      CHARACTER*1 IBL
C
      DATA IBL/' '/
      DATA IPIU/'+'/
      DATA IMEN/'-'/
C
      MAX=12
C
C
C
    1 WRITE(6,2000) MAX
 2000 FORMAT(//10X,'EVAPORATORE LATO FLUIDO '//
     $ 10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
      IF(NCEL.GE.2.AND.NCEL.LE.MAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
C
C
    5 CONTINUE
C
C
C    [......... Commentata selezione .........
C
C      WRITE(6,2999)
C 2999 FORMAT(//10X,'ASSEGNA UN CARATTERE'
C     $ /5X,' - USCITA IN PRESSIONE A MONTE ===> BLANK '
C     $ /5X,' - USCITA IN PORTATA A MONTE  ====>  + ')
C      READ(5,3001)ICA 
C      IF(ICA.EQ.IPIU)GO TO 10
C      IF(ICA.EQ.IBL)GO TO 10
C      GO TO 5
C
C   ....................................................]
C
 3001 FORMAT(A)       
   10 CONTINUE
C      
      WRITE(MODU,1001)ICA,MOD
 1001 FORMAT(A1,A3)
      IF(ICA.EQ.IBL)MODU=MOD
      WRITE(IBLOC,1000)MODU,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0I1(IFUN,K,IBLOC1,IBLOC2,NSTATI,NUSCIT,NINGRE)
C                                                                       
C-----STAMPA SIGNIFICATO STATI,USCITE,INGRESSI                          
C                                                                       
C
C   COLONNA DI FLUIDO : VERSIONE 3 (SEP-1982)
C   -MEDIE INTEGRALI
C   -MIN 2 MAX 12 CELLE ASSIALI
C
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      MAX=12
      GO TO(1,10),IFUN
C
C-----DEFINIZIONE NUMERO STATI,USCITE,INGRESSI
C
    1 WRITE(6,1000) MAX
 1000 FORMAT(//10X,'RISER G. V. A 2 PARETI METALLICHE SIMMMETRICHE'/
     $ 10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,1001) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.MAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
C
    5 NSTATI= NCEL+1
      NUSCIT= 2*NCEL+1
      NINGRE= 2*NCEL+4
      WRITE(6,2999)                                                     
 2999 FORMAT(5X,'IL NOME ALFANUMERICO DA ATTRIBUIRE AL BLOCCO'          
     $ /5X,'PERMETTE ANCHE DI DEFINIRE LA SUA VARIABILE DI USCITA'      
     $ /5X,'SECONDO LA CONVENZIONE :'                                   
     $ /5X,'    '                                                       
     $ /5X,'1 - USCITA IN PRESSIONE DI INGRESSO ====> NOME LIBERO'      
     $ /5X,'    '                                                       
     $ /5X,'2 - USCITA IN PORTATA DI INGRESSO ======> NOME PRECEDUTO'   
     $ /5X,'                                          DA UN  +')        
      RETURN                                                            
C                                                                       
   10 CONTINUE
C
C-----STAMPA SIGNIFICATO STATI,USCITE,INGRESSI
C
      IF(K.GT.NCEL)GO TO 12
      IF(K.EQ.1) WRITE(6,3011)
 3011 FORMAT(//20X,'VARIABILI DI STATO'//)
      WRITE(6,3000)K
 3000 FORMAT(14X,'ENTALPIA DI USCITA CELLA ',I3)
      GO TO 50
C
   12 IF(K.GT.NCEL+1)GO TO 14
      WRITE(6,3001) NCEL
 3001 FORMAT(14X,'PRESSIONE DI USCITA CELLA ',I3)
      GO TO 50
C
   14 IF(K.GT.NCEL+2)GO TO 16
      WRITE(6,3012)
 3012 FORMAT(//20X,'VARIABILI ALGEBRICHE DI USCITA'//)
      WRITE(6,3002)
 3002 FORMAT(14X,'PRESSIONE (0 PORTATA) DI INGRESSO CELLA  1 ')
      GO TO 50
C
   16 IF(K.GT.3*NCEL+2)GO TO 20
      K1=K-NCEL-2
      IPAR=K1/NCEL +1
      K1=K1-NCEL*(IPAR-1)
      WRITE(6,3003)K1,IPAR
 3003 FORMAT(14X,'POTENZA ASSORBITA CELLA ',I3,'  PARETE ',I2)
      GO TO 50
C
   20 IF(K.GT.3*NCEL+3)GO TO 24
      WRITE(6,3013)
 3013 FORMAT(//20X,'VARIABILI DI INGRESSO'//)
      WRITE(6,3005)
 3005 FORMAT(14X,'ENTALPIA DI INGRESSO CELLA 1 ')
      GO TO 50
C
   24 IF(K.GT.3*NCEL+4)GO TO 26
 3007 FORMAT(14X,'PORTATA (O PRESSIONE) DI INGRESSO CELLA 1 ')
      WRITE(6,3007)
      GO TO 50
C
   26 IF(K.GT.3*NCEL+5)GO TO 28
      WRITE(6,3008)NCEL
 3008 FORMAT(14X,'PORTATA DI USCITA CELLA ',I3)
      GO TO 50
C
   28 IF(K.GT.5*NCEL+5)GO TO 30
      K1=K-3*NCEL-5
      IPAR=K1/NCEL+1
      K1=K1-NCEL*(IPAR-1)
      WRITE(6,3009)K1,IPAR
 3009 FORMAT(14X,'TEMPERATURA METALLO CELLA ',I3,'  PARETE ',I2)
      GO TO 50
C
   30 WRITE(6,3010)
 3010 FORMAT(14X,'COEFFICIENTE DI ATTRITO ')
C
   50 RETURN
      END
C
C----------------------------------------------------------------------------
C
C
C----------------------------------------------------------------------------
C
      SUBROUTINE SGR0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,
     $                  IBLOC2,IER,CNXYU,TOL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12)
      INTEGER VAR
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
C
      DIMENSION NTUB(MAX),DIA(MAX),HLU(MAX),DZE(MAX),CRIG(MAX)
      REAL TDIA(MAX),TLEN(MAX)
      CHARACTER*4 NI,ISPA,NT,ND,NL,NZ,NR
      CHARACTER*3 NA
      CHARACTER*4 NOMAPP
C
C-- [ ...........................................................
C
      CHARACTER*6 PTN,PTD,PTL
C
C--  ............................................................]
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      DATA GAM0 /1000./
C
C------ [ .......................................................]
C
C           Modificata introduzione dati per specializzare il
C           canale alla zona cilindrica interna di un generatore
C           di vapore a circolazione naturale, a sviluppo verticale
C           per reattori di tipo PWR
C
C     DATA NA/'IWP'/,NI/'ITAU'/,ISPA/'    '/,PIGR/3.1415926/
C     DATA NT/'NTUB'/,ND/'DIAI'/,NL/'LUNG'/,NZ/'DELZ'/,NR/'CRIG'/
C
      DATA PTN/'TubsNb'/,PTD/'TubExD'/,PTL/'TubLen'/
C
      DATA NA/'IWP'/,NI/'ITAU'/,ISPA/'    '/,PIGR/3.1415926/
      DATA NT/'NTUB'/,ND/'DIAI'/,NL/'LUNG'/,NZ/'DELZ'/,NR/'CRIG'/
C
C------ [ .......................................................]
C
C
      NCEL=((IV2-IV1+1)-6)/8
C
      GO TO (1,10),IFUN
C
C-----SCRITTURA SIMBOLI DEI DATI
C
    1 CONTINUE
C
C-- [ ...........................................................
C
CC      DO 5 I=1,NCEL
CC      WRITE(14,1002)I
CC 1002 FORMAT('*   DATI DELLA CELLA ',I3,'*',55X)
CC      WRITE(14,1003) NT,I,ND,I,NL,I,NZ,I,NR,I
CC 1003 FORMAT(3(4X,A4,I4,' =',10X,'*'),5X)
CC    5 CONTINUE
C
C
        DO I=1,NCEL
C         WRITE(14,"('*   -----')")
          WRITE(14,1002)I
 1002     FORMAT('*   VOLUMETRIC NODE ',I2,'  *',55X)
C         WRITE(14,"('*   -')")
          WRITE(14,"('*      Riser channel data')")
          WRITE(14,1013) ND,I,NL,I,NZ,I,NR,I
C         WRITE(14,"('*   -')")
          WRITE(14,"('*      Tubes data')")
          WRITE(14,1013) PTN,I,PTD,I,PTL,I
 1013     FORMAT(3(4X,A7,I1,' =',10X,'*'),5X)
          WRITE(14,"('*   -')")
        END DO
C
C--  ...........................................................]
C
C
      RETURN
C
C-----LETTURA DEI DATI
C
   10 READ(14,1004)
 1004 FORMAT(3(14X,F10.0,1X),5X)
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C    ITAU=2 ==> PROPRIETA' MEDIE CALCOLATE ALL'USCITA DELLE CELLE
      ITAU=TAU
      ITAU=2
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C
C
C
C-- [ ...........................................................
C
CC     DO 15 I=1,NCEL
CC      READ(14,1004)
CC      READ(14,1004) TUB ,DIA(I),HLU(I),DZE(I),CRIG(I)
CC      NTUB(I)=TUB
CC   15 CONTINUE
C
      DO I=1,NCEL
        READ(14,1004)
        READ(14,1004)
        READ(14,1004) DIA(I),HLU(I),DZE(I),CRIG(I)
        READ(14,1004)
        READ(14,1004) TUB,TDIA(I),TLEN(I)
        READ(14,1004)
C
        NTUB(I)=TUB
      END DO
C
      DO 20 I=1,NCEL
        IF(NTUB(I).GT.0) GOTO 20
        NTUB(I)=NTUB(I-1)
        DIA(I)=DIA(I-1)
        HLU(I)=HLU(I-1)
        DZE(I)=DZE(I-1)
        CRIG(I)=CRIG(I-1)
        TDIA(I)=TDIA(I-1)
        TLEN(I)=TLEN(I-1)
   20 CONTINUE
C                                                                       
C
C--  ...........................................................]
C
C     RICONOSCIMENTO DI IWP                                             
C                                                                       
C      DECODE(1,2222,IBLOC1)IWP                                          
C 2222 FORMAT(A1,3X)  
C
C    [................ assegnato IWP=1 fisso
C
CC-----   inizio modifica istruzione di DECODE   -----
C      WRITE (NOMAPP,'(A4)')IBLOC1
C      IWP=0
C      IF(NOMAPP(1:1).EQ.'+')IWP=1
CC-----    fine modifica istruzione di DECODE    -----
C
      IWP=1
C
C   ..............................................]
C
C-----MEMORIZZAZIONE  DATI GEOMETRICI
C
      DATI(ID2)=NCEL
      DATI(ID2+1)=IWP
      DATI(ID2+2)=ITAU
C
      ID2 = ID2+2
C
      DO 25 I=1,NCEL
      K=ID2+7*(I-1)
C
C   [..............................................
C
CC      S=PIGR*DIA(I)*HLU(I)*NTUB(I)
CC      V=S*DIA(I)/4.
CC      A=V/HLU(I)
C
        S=PIGR*TDIA(I)*TLEN(I)*NTUB(I)
        A=PIGR*(DIA(I)*DIA(I)-TDIA(I)*TDIA(I)*NTUB(I))/4.
        V=A*HLU(I)
        HDIAM=4.*A/(PIGR*TDIA(I)*NTUB(I))
C
C   ..............................................]
C
      DATI(K+1)=V
      DATI(K+2)=S
      DATI(K+3)=A
CC     DATI(K+4)=DIA(I)
      DATI(K+4)=HDIAM
CC      DATI(K+5)=2*HLU(I)/(DIA(I)*A*A)*(W0*W0/P0)
      DATI(K+5)=2*HLU(I)/(HDIAM*A*A)*(W0*W0/P0)
      DATI(K+6)=DZE(I)/P0*9.81
      DATI(K+7)=CRIG(I)
   25 CONTINUE
C
      ID2 = ID2+7*NCEL
C
C-----MEMORIZZAZIONE PRESSIONI INTERMEDIE (DISTR.LINEARE)
C
      VU=XYU(IV1+NCEL+1)
      VI=XYU(IV1+6*NCEL+3)
      PU=XYU(IV1+NCEL)
      PI=IWP*VI+(1-IWP)*VU
      DP=(PI-PU)/NCEL
C
      DO 30 I=2,NCEL
      K=I-1
      DATI (ID2+ K)=(PI-(I-1)*DP)/P0
   30 CONTINUE
C
      ID2=ID2+NCEL-1
C
C-----RISERVA AREA PER COEFF. DI SCAMBIO (NCEL+1)
C
      ID2=ID2+2*NCEL+2
C
C-----COSTANTI DI NORMALIZZAZIONE
C
      DO 35 I=1,NCEL
      CNXYU(IV1+I-1)=H0
   35 CONTINUE
C
      CNXYU(IV1+NCEL)=P0
      CNXYU(IV1+NCEL+1)=(1-IWP)*P0+IWP*W0
      K=IV1+NCEL+1
      NCEL2=2*NCEL
C
      DO 40 I=1,NCEL2
      CNXYU(K+I)=W0*H0
   40 CONTINUE
C
      K=K+NCEL2
      DO I=1,3*NCEL,3
       CNXYU(K+I)=T0
       CNXYU(K+I+1)=GAM0
       CNXYU(K+I+2)=GAM0
      END DO
C
      CNXYU(K+3*NCEL+1)=H0
      CNXYU(K+3*NCEL+2)=IWP*P0+(1-IWP)*W0
      CNXYU(K+3*NCEL+3)=W0
      K=K+3*NCEL+3
C
      DO 50 I=1,NCEL2
      CNXYU(K+I)=T0
   50 CONTINUE
C
      CNXYU(K+NCEL2+1)=1.
C
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.
C
C     (DEFAULT)
C
C-----STAMPE
C
      WRITE(6,3000)
C
      DO 60 I=1,NCEL
      K=ID1+2+7*(I-1)
      V= DATI(K+1)
      S= DATI(K+2)
      A= DATI(K+3)
      D=DATI(K+4)
      C=DATI(K+7)
      WRITE(6,3001) I,V,S,A,D,C
   60 CONTINUE
C
      RETURN
 3000 FORMAT(6X,'CELLA',4X,'VOLUME      SUP.INT.    SEZIONE     ',
     $           'DIAM.INT.   COEFF.RIG.'//)
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,
     $                  IBLOC2)
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*80 SccsID
       DATA SccsID/'@(#)gvrs.f	3.1\t 3.1\t 9/5/94'/          
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      DIMENSION G1(MAX2),G2(MAX2),CXYU(MAX3)
      COMMON/SGR0C0/TL(MAX),HTC1(MAX),HTC2(MAX)
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
      COMMON/REGIME/KREGIM
      LOGICAL KREGIM
C
      NCEL=DATI(IPD)
      NEQ=6*NCEL+2
      NVAR=8*NCEL+6
      ISTA=SGR0_ISTA02(IFUN)
C
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2
 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))
C
      GO TO (10,30,30),IFUN
C
C-----TOPOLOGIA JACOBIANO
C
   10 DO 20 I=1,NEQ
C
      DO 20 J=1,NVAR
      AJAC(I,J)=1.
   20 CONTINUE
C
      RETURN
C
C-----DECODIFICA VARIABILI E DATI
C
   30 CALL SGR0_DE02 (XYU,IXYU,DATI,IPD)
C
C-----CALCOLO COEFFICIENTI DERIVATE H,P
C
      IF(.NOT.KREGIM) CALL SGR0_TA02
C
C-----CALCOLO DEI RESIDUI
C
      CALL SGR0_RE02 (IFUN,RNI)
C
C-----MEMORIZZAZIONE PRESSIONI INTERMEDIE
C
      K2=IPD+2+7*NCEL
      NN=NCEL-1
C
      DO 45 I=1,NN
      DATI (K2+I)=P(I+1)
   45 CONTINUE
C
C-----MEMORIZZAZIONE COEFF. DI SCAMBIO
C
      K4=IPD+1+8*NCEL
      NNN=NCEL+1
C
      DO 50 I=1,NNN
      DATI(K4+I)=CSCA1(I)
      DATI(K4+NNN+I)=CSCA2(I)
   50 CONTINUE
C
      IF(IFUN.EQ.3) GOTO 60
C
      IF (ISTA.NE.0) CALL SGR0_STA02
      RETURN
C
C-----CALCOLO DELLO JACOBIANO
C     IN MODO NUMERICO
C
   60 CONTINUE
C 
      NEQDIF=NCEL+1
C
      DO 65 I=1,NEQDIF
      G1(I)=RNI(I)
   65 CONTINUE
C
      NE1=NEQDIF+1
C
      DO 70 I=NE1,NEQ
      G1(I)=-RNI(I)
   70 CONTINUE
C
      DO 100 I=1,NVAR
      EPS=XYU(IXYU+I-1)*.001
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA APR. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C temperature di parete
      IF((I.GE.NEQ+4).AND.(I.LE.NEQ+3+2*NCEL)) EPS=1.E-5
      IF(ABS(EPS).LT.1.E-6)EPS=1.E-6
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA APR. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      DO 75 J=1,NVAR
      CXYU(J)=XYU(IXYU+J-1)
      IF(J.EQ.I)CXYU(J)=CXYU(J)+EPS
   75 CONTINUE
      CALL SGR0_DE02(CXYU,1,DATI,IPD)
C
      CALL SGR0_RE02(IFUN,RNI)
C
      DO 80 J=1,NEQDIF
      G2(J)=RNI(J)
   80 CONTINUE
C
      DO 85 J=NE1,NEQ
      G2(J)=-RNI(J)
   85 CONTINUE
C
      DO 90 J=1,NEQ
      AJAC(J,I)=(G2(J)-G1(J))/EPS
   90 CONTINUE
  100 CONTINUE
C
      RETURN
      END
C
C----------------------------------------------------------------------------------
C
C
C
C----------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_RE02 (IFUN,RNI)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION RNI(*)
C
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/SGR0C0/TL(MAX),HTC1(MAX),HTC2(MAX)
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/REGIME/KREGIM
      LOGICAL KREGIM
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      DATA ALFA/0./
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      DATA GAM0 /1000./
C
      N01FL=1
C
      NNN=NCEL+1
C
      CALL SGR0_F02
C
      IF(KREGIM) GOTO 5
C
      CALL SGR0_A02
      CALL SGR0_SOL02
C
C-----CALCOLO DELLE PORTATE INTERMEDIE (NCEL-2)
C
      DO 10 J=2,NCEL
      I=NCEL+2-J
      W(I)=W(I+1)+TAUW(I)*DX(I-1)+TAUWH(I)*DX(I)+TAUWP(I)*DX(NNN)
  10  CONTINUE
      GO TO 12
C
   5  DO 11 J=2,NCEL
      I=NCEL+2-J
      W(I)=W(I+1)
  11  CONTINUE
C
C-----CALCOLO PRESSIONI INTERMEDIE (NCEL-2) E PROPR. DI CELLA
C
   12 DO 20 I=1,NCEL
      K=NCEL-I+1
      PUC=P(K+1)*P0
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C
C    ALFA=0 ==> PROPRIETA' MEDIE CALCOLATE ALL'USCITA DELLE CELLE
C
      HC(K)=(ALFA*H(K)+(1.-ALFA)*H(K+1))*H0
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      S(K)=SHEV(PUC,HC(K),N01FL)
      R(K)=ROEV(PUC,S(K),N01FL)
      T(K)=TEV(PUC,S(K),N01FL)
      TITO(K)=YEV(PUC,S(K),N01FL)
      IF(K.EQ.1) GOTO 20
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA OTT. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      P(K)=P(K+1)+CKF(K)*CF*ABS(W(K))*W(K)/R(K)+R(K)*DZG(K)
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA OTT. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  20  CONTINUE
C
C-----RESIDUO PERDITE DI CARICO
C
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA OTT. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      RNI(NNN+1)=P(2)-P(1)+CKF(1)*CF*ABS(W(1))*W(1)/R(1)
     $+R(1)*DZG(1)
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA OTT. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C
C-----CALCOLO DEI CALORI ASSORBITI
C
      CALL SGR0_QSCA02 (IFUN)
C
C-----ALTRI RESIDUI
C
      IF(KREGIM) GOTO 25
C
      DO 30 I=1,NNN
      RNI(I)=DX(I)
   30 CONTINUE
      GO TO 32
C
  25  DO 31 I=1,NNN
      RNI(I)=F(I)
   31 CONTINUE
C
   32 K=NNN+1
C
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA APR. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      DO 35 I=1,NCEL
C--Spelta      RNI(K+I)=TM1(I)-T(I)/T0-Q1(I)*W0*H0/(T0*CSCA1(I)*SUP(I)/2.)
C--Spelta     RNI(K+NCEL+I)=TM2(I)-T(I)/T0-Q2(I)*W0*H0/(T0*CSCA2(I)*SUP(I)/2.)
C
C----- Modifica per facilitare convergenza - Casam 29 settembre 2010
C
C--Casam      RNI(K+I)=0.5*CSCA1(I)*SUP(I)*(TM1(I)*T0-T(I))/(W0*H0)-Q1(I)
C--Casam      RNI(K+NCEL+I)=0.5*CSCA2(I)*SUP(I)*(TM2(I)*T0-T(I))/(W0*H0)-Q2(I)
C
C----[ modificato segno per compatibilit� con EXCH, Casam 5 ottobre 2010
C
      RNI(K+I)=0.5*CSCA1(I)*SUP(I)*(T(I)-TM1(I)*T0)/(W0*H0)-Q1(I)
      RNI(K+NCEL+I)=0.5*CSCA2(I)*SUP(I)*(T(I)-TM2(I)*T0)/(W0*H0)-Q2(I)
C
   35 CONTINUE
C
C  20  QEX1(I)=CSCA1(I)*SUP(I)*(TM1(I)*T0-T(I))/(CNORM*2.)
C      QEX2(I)=CSCA2(I)*SUP(I)*(TM2(I)*T0-T(I))/(CNORM*2.)
C      DO 35 I=1,NCEL
C      RNI(K+I)=QEX1(I)-Q1(I)
C      RNI(K+NCEL+I)=QEX2(I)-Q2(I)
C   35 CONTINUE
C>>>>>>>>>>>>>>>>>>>>>>>>>> S.SPELTA APR. 1987<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C
      J=1
      DO I=1,3*NCEL,3
        RNI(3*NCEL+2+I)=(T(J)-TL(J))/T0
        RNI(3*NCEL+2+I+1)=(HTC1(J)/CSCA1(J)-1.)/GAM0
        RNI(3*NCEL+2+I+2)=(HTC2(J)/CSCA2(J)-1.)/GAM0
        J=J+1
      END DO
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_DE02(XYU,IXYU,DATI,IPD)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DIMENSION XYU(*),DATI(*)
C
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/SGR0C0/TL(MAX),HTC1(MAX),HTC2(MAX)
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
C
      DATA GAM0 /1000./
C
      NNN=NCEL+1
C
      ITAU=DATI(IPD+2)
      IWP=DATI(IPD+1)
      VU=XYU(IXYU+NCEL+1)
      VI=XYU(IXYU+NEQ+1)
      P(1)=IWP*VI+(1-IWP)*VU
      W(1)=(1-IWP)*VI+IWP*VU
      H(1)=XYU(IXYU+NEQ)
      P(NNN)=XYU(IXYU+NCEL)
      W(NNN)=XYU(IXYU+NEQ+2)
      CF=XYU(IXYU+8*NCEL+5)
C
      K0=IXYU+NCEL+1
      K1=IXYU+NEQ+2
      K2=IPD+2+7*NCEL
      M3=IXYU+2*NCEL+1
      M4=IXYU+NEQ+NCEL+2
C
      DO 40 I=1,NCEL
      H(I+1)=XYU(IXYU+I-1)
      Q1(I)=XYU(K0+I)
      Q2(I)=XYU(M3+I)
      TM1(I)=XYU(K1+I)
      TM2(I)=XYU(M4+I)
      K3=IPD+2+(I-1)*7
      V(I)=DATI(K3+1)
      SUP(I)=DATI(K3+2)
      AREA(I)=DATI(K3+3)
      DIAM(I)=DATI(K3+4)
      CKF(I)=DATI(K3+5)
      DZG(I)=DATI(K3+6)
      CRIG(I)=DATI(K3+7)
      IF(I.EQ.NCEL) GOTO 40
      P(I+1)=DATI(K2+I)
   40 CONTINUE
C
      J=1
      DO I=1,3*NCEL,3
        TL(J)=XYU(IXYU+3*NCEL+1+I)*T0
        HTC1(J)=XYU(IXYU+3*NCEL+1+I+1)*GAM0
        HTC2(J)=XYU(IXYU+3*NCEL+1+I+2)*GAM0
	J=J+1
      END DO
C
      K4=IPD+1+8*NCEL
C
      DO 50 I=1,NNN
      CSCA1(I)=DATI(K4+I)
      CSCA2(I)=DATI(K4+NNN+I)
   50 CONTINUE
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_F02
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
C
C-----COSTRUZIONE ELEMENTI VETTORE F DEL SISTEMA A*DX=F
C
      NNN=NCEL+1
      F(NNN)=W(1)-W(NNN)
C
C
C----[ modificato segno per compatibilit� con EXCH, Casam 5 ottobre 2010
C
      DO 10 I=1,NCEL
C     F(I)=W(1)*(H(I)-H(I+1))+Q1(I)+Q2(I)
      F(I)=W(1)*(H(I)-H(I+1))-Q1(I)-Q2(I)
   10 CONTINUE
C
C----  .................................................................]
C
C
      IF(ISTA.GE.3) WRITE(6,103) (F(I),I=1,NNN)
C
      RETURN
C
  103 FORMAT(//1X,'VETTORE F',//1X,11(E11.4,1X))
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_SOL02
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
C
C-----RISOLVE RISPETTO A DX IL SISTEMA A*DX=F CON GAUSS
C
      NNN=NCEL+1
C
      DO 20 I=1,NCEL
      I1=I+1
C
      DO 15 J=I1,NNN
      A(J,NNN)=A(J,NNN)-A(I,NNN)*A(J,I)/A(I,I)
      F(J)=F(J)-F(I)* A(J,I)/A(I,I)
   15 CONTINUE
   20 CONTINUE
C
      DX(NNN)=F(NNN)/A(NNN,NNN)
C
      DO 25 I=1,NCEL
      K=NNN-I
      DX(K)=(F(K)-A(K,NNN)*DX(NNN))/A(K,K)
   25 CONTINUE
C
      IF(ISTA.GE.3) WRITE(6,104) (DX(I),I=1,NNN)
C
      RETURN
C
  104 FORMAT(//1X,'VETTORE DX',//1X,11(E11.4,1X))
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_A02
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
C
C-----CALCOLO ELEMENTI MATRICE A DEL SISTEMA A*DX=F
C
      NNN=NCEL+1
C
      DO 1 I=1,NNN
C
      DO 2 K=1,NNN
      A(I,K)=0.
  2   CONTINUE
  1   CONTINUE
C
      A(1,1)=TAUH(1)
      A(1,NNN)=TAUP(1)
      SUM=TAUWP(1)
C
      DO 10 I=2,NCEL
      J=I-1
      A(I,NNN)=TAUP(I)+SUM*(H(I)-H(I+1))
      SUM=SUM+TAUWP(I)
      A(I,I)=TAUH(I)
      A(I,J)=TAUWH(J)*(H(I)-H(I+1))+TAU(I)
      IF (I.EQ.2) GOTO 10
      J=I-2
C
      DO 20 K=1,J
      A(I,K)=(TAUWH(K)+TAUW(K+1))*(H(I)-H(I+1))
  20  CONTINUE
  10  CONTINUE
C
      NN=NCEL-1
      A(NNN,NNN)=SUM
      A(NNN,NCEL)=TAUWH(NCEL)
C
      DO 30 J=1,NN
      A(NNN,J)=TAUWH(J)+TAUW(J+1)
  30  CONTINUE
C
      IF(ISTA-3) 90,40,40
C
  40  WRITE(6,101)
C
      DO 50 I=1,NNN
      WRITE(6,102) (A(I,J),J=1,NNN)
  50  CONTINUE
C
  90  RETURN
C
  101 FORMAT(//1X,'MATRICE A',/)
  102 FORMAT(/1X,11(E11.4,1X))
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_TA02
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0
C
C   CALCOLO TAU : SIMPSON+FORMULE SATURAZ.
C
C      ITAU=1 : CALCOLO TAU PER PADE'
C      ITAU=2 : CALCOLO TAU CON L'IPOTESI DHM/DT=DHU/DT
C
C
      DO 100 I=1,NCEL
C
      CALL SGR0_HPTAU(AI0,AI1,AI2,AK0,AK1,AK2,P(I+1)*P0,H(I)*H0,
     $                H(I+1)*H0)
C
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C    ITAU=2 ==> PROPRIETA' MEDIE CALCOLATE ALL'USCITA DELLE CELLE
C    ITAU=1 ==> PROPRIETA' MEDIE DIPENDENTI DA INGRESSO E USCITA CELLA
C
C    IN QUESTA VERSIONE SI USA  ITAU=2 
C    per attivare l'effetto di  ITAU=1 :
C                   1) porre ITAU=1
C                   2) togliere il commento alle 2 istruzioni seguenti
C
C      IF((ITAU.EQ.2).OR.I.EQ.1) GOTO 80
C      GOTO 90
C>>>>>>>>>>>>>>>>>>>> SPELTA marzo 1988 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
C
   80 AI1=AI0
      AK1=AK0
C
   90 TAU(I)=V(I)*((AI0-AI1)-H(I+1)*H0*(AK0-AK1))/W0
      TAUH(I)=V(I)*(AI1-H(I+1)*H0*AK1)/W0
      TAUP(I)=V(I)*(AI2-H(I+1)*H0*AK2)*P0/(W0*H0)
      TAUW(I)=V(I)*(AK0-AK1)*H0/W0
      TAUWH(I)=V(I)*AK1*H0/W0
      TAUWP(I)=V(I)*AK2*P0/W0
  100 CONTINUE
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_STA02
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      NATF=1
C
      NNN=NCEL+1
C
      GOTO (30,20,20) , ISTA
C
C
  20  WRITE(6,201)
C
      DO 21 I=1,NCEL
      WRITE(6,202) I,TAU(I),TAUH(I),TAUP(I),TAUW(I),
     $             TAUWH(I),TAUWP(I)
  21  CONTINUE
C
  30  WRITE(6,301)
C
      WW=W(1)*W0
      HH=H(1)*H0
      PP=P(1)*P0
      IM1=0
      WRITE(6,302)IM1,WW,HH,PP
C
      DO 31 I=2,NNN
      IM1=I-1
      WW=W(I)*W0
      HH=H(I)*H0
      PP=P(I)*P0
      PM=(PP+P(IM1)*P0)/2.
      TI=TITO(IM1)
      RI=R(IM1)
      AV=V(IM1)*RI*TI
      AW=V(IM1)*RI*(1.-TI)
      UM=(WW+W(IM1)*W0)/(2.*RI*AREA(IM1))
      WRITE(6,303) IM1,WW,HH,PP,TI,RI,AW,AV,UM
  31  CONTINUE
      WRITE(6,6000)
      DO 40 I=1,NCEL
      TT=T(I)-273.15
      TMM1=TM1(I)*T0-273.15
      CC1=CSCA1(I)
      QQ1=QEX1(I)*W0*H0
      TMM2=TM2(I)*T0-273.15
      CC2=CSCA2(I)
      QQ2=QEX2(I)*W0*H0
      WRITE(6,303)I,TT,TMM1,CC1,QQ1,TMM2,CC2,QQ2
 6000 FORMAT(//1X,'CELLA',4X,'TEMP.MEDIA',4X,'TEMP.PAR.1',3X,
     $ 'COEFF.SC.PAR.1',3X,'POT.ASS.PAR.1',3X,'TEMP.PAR.2',3X,
     $ 'COEFF.SC.PAR.2',3X,'POT.ASS.PAR.1'//)
   40 CONTINUE
C
      RETURN
C
  201 FORMAT(//1X,'CELLA',4X,'TAU',11X,'TAUH',10X,'TAUP',10X,
     $      'TAUW',10X,'TAUWH',9X,'TAUWP'//)
  202 FORMAT(1X,I3,5X,6(E12.5,2X)/)
  301 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',
     $       6X,'TIT.MEDIO',5X,'DENS.MEDIA',4X,'MASSA LIQ. ',3X,
     $       'MASSA GAS',4X,'VELOCITA MEDIA'//)
  302 FORMAT(1X,I3,5X,3(E12.5,2X))
  303 FORMAT(1X,I3,5X,8(E12.5,3X))
C
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      FUNCTION SGR0_ISTA02(IFUN)
      COMMON/REGIME/KREGIM
      COMMON/PARPAR/NUL(6),KSTP,ITERT
      LOGICAL KREGIM
C
C-----SGR0_ISTA02=0,1,2,3,11,12,13
C
      SGR0_ISTA02=1
C
      IF(IFUN.NE.2) GOTO 70
      IF(SGR0_ISTA02.EQ.0) GOTO 90
      IF(SGR0_ISTA02.GT.10) GOTO 80
C
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) GOTO 90
      IF(KREGIM) GOTO 90
C
  70  SGR0_ISTA02=0
      GOTO 90
  80  SGR0_ISTA02=SGR0_ISTA02-10
  90  RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_QSCA02(IFUN)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (MAX=12,MAX1=MAX+1,MAX2=3*MAX+2,MAX3=4*MAX+6)
C
      COMMON/PA02/NCEL,NEQ,ITAU,ISTA
      COMMON/TE02/H(MAX1),P(MAX1),W(MAX1),Q1(MAX),Q2(MAX),VU,CF,IWP
      COMMON/CA02/TM1(MAX),TM2(MAX),QEX1(MAX),QEX2(MAX),
     $             CSCA1(MAX1),CSCA2(MAX1),
     $             T(MAX),S(MAX),R(MAX),TITO(MAX),HC(MAX)
      COMMON/DA02/V(MAX),SUP(MAX),AREA(MAX),DIAM(MAX),
     $              CKF(MAX),DZG(MAX),CRIG(MAX)
      COMMON/DY02/TAU(MAX),TAUH(MAX),TAUP(MAX),TAUW(MAX),TAUWH(MAX),
     $              TAUWP(MAX),A(MAX1,MAX1),F(MAX1),DX(MAX1)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      IGAM=SGR0_IGA02(IFUN)
      CNORM=W0*H0
C
      DO 30 I=1,NCEL
C
      IF(IGAM.EQ.0) GOTO 20
C
      G=W(I+1)*W0/AREA(I)
      GASS=ABS(G)
      CALL SGR0_GAM02(P(I+1)*P0,HC(I),S(I),T(I),R(I),TITO(I),TM1(I)*T0
     $           ,DIAM(I),CRIG(I),GASS,HTC)
      CSCA1(I)=HTC
      CALL SGR0_GAM02(P(I+1)*P0,HC(I),S(I),T(I),R(I),TITO(I),TM2(I)*T0
     $           ,DIAM(I),CRIG(I),GASS,HTC)
      CSCA2(I)=HTC
C
C----[ modificato segno per compatibilit� con EXCH, Casam 5 ottobre 2010
C
C  20  QEX1(I)=CSCA1(I)*SUP(I)*(TM1(I)*T0-T(I))/(CNORM*2.)
C      QEX2(I)=CSCA2(I)*SUP(I)*(TM2(I)*T0-T(I))/(CNORM*2.)
C
  20  QEX1(I)=CSCA1(I)*SUP(I)*(T(I)-TM1(I)*T0)/(CNORM*2.)
      QEX2(I)=CSCA2(I)*SUP(I)*(T(I)-TM2(I)*T0)/(CNORM*2.)
  30  CONTINUE
C
C--------------- fine modifica ---------------------------]
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_HPTAU(AI0,AI1,AI2,AK0,AK1,AK2,P,H1,H2)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DATA DHMIN/10.E3/
C
      N01FL=1
      HI=MIN(H1,H2)
      HU=MAX(H1,H2)
      DH=HU-HI
C
      IF(DH.GT.DHMIN) GOTO 100
C
C---ESPRESSIONI ASINTOTICHE
C
      SU=SHEV(P,HU,N01FL)
      ROU=ROEV(P,SU,N01FL)
      DRODHU=BEV(P,SU,N01FL)/TEV(P,SU,N01FL)
      DRODPU=1./A2EV(P,SU,N01FL)-DRODHU/ROU
C
      AI0=ROU+HU*DRODHU
      AI1=0.5*AI0
      AI2=HU*DRODPU-1.
      AK0=DRODHU
      AK1=0.5*AK0
      AK2=DRODPU
      GOTO 300
C
C---CALCOLO INTEGRALI
C
  100 IF(P.GT.221.2E5) GOTO 11
C
      CALL SATUR(P,2,HWS,HVS,N01FL)
      IF(HU-HVS) 1,1,2
   1  IF(HU-HWS) 7,7,8
   8  IF(HI-HWS) 10,9,9
   9  CONTINUE
C
C **  MISCELA **
C
      CALL SGR0_SATTAU(AI3,AI4,AK3,AK4,ROU,P,HU,HWS,HVS,1)
      CALL SGR0_SATTAU(BI3,BI4,BK3,BK4,ROI,P,HI,HWS,HVS,0)
      AI3=AI3-BI3
      AI4=AI4-BI4
      AK3=AK3-BK3
      AK4=AK4-BK4
      GOTO 20
  10  CONTINUE
C
C **  ACQUA-MISCELA **
C
      CALL SGR0_SATTAU(AI3,AI4,AK3,AK4,ROU,P,HU,HWS,HVS,1)
      SI=SHEV(P,HI,N01FL)
      ROI=ROEV(P,SI,N01FL)
      DROPI=1./A2EV(P,SI,N01FL)-BEV(P,SI,N01FL)/ROI/TEV(P,SI,N01FL)
      CALL SGR0_DRSHEV(P,2,DROPU,RWS)
      CALL SGR0_SIMTAU(BI3,BI4,BK3,BK4,P,HI,ROI,DROPI,HWS,RWS,DROPU)
      AI3=AI3+BI3
      AI4=AI4+BI4
      AK3=AK3+BK3
      AK4=AK4+BK4
      GOTO 20
   2  IF(HI-HVS) 3,4,4
   3  IF(HI-HWS) 6,5,5
   4  CONTINUE
C
C  ** MONOFASE (VAPORE) **
C
   7  CONTINUE
C
C  ** MONOFASE (ACQUA) **
C
  11  CONTINUE
C
C  ** MONOFASE (SOPRACRITICO) **
C
      SI=SHEV(P,HI,N01FL)
      ROI=ROEV(P,SI,N01FL)
      DROPI=1./A2EV(P,SI,N01FL)-BEV(P,SI,N01FL)/ROI/TEV(P,SI,N01FL)
      SU=SHEV(P,HU,N01FL)
      ROU=ROEV(P,SU,N01FL)
      DROPU=1./A2EV(P,SU,N01FL)-BEV(P,SU,N01FL)/ROU/TEV(P,SU,N01FL)
      CALL SGR0_SIMTAU(AI3,AI4,AK3,AK4,P,HI,ROI,DROPI,HU,ROU,DROPU)
      GOTO 20
   6  CONTINUE
C
C  ** ACQUA-MISCELA-SURRISCALDATO **
C
      CALL SGR0_SATTAU(AI3,AI4,AK3,AK4,ROU,P,HVS,HWS,HVS,1)
      SI=SHEV(P,HI,N01FL)
      ROI=ROEV(P,SI,N01FL)
      DROPI=1./A2EV(P,SI,N01FL)-BEV(P,SI,N01FL)/ROI/TEV(P,SI,N01FL)
      CALL SGR0_DRSHEV(P,2,DROPU,RWS)
      CALL SGR0_SIMTAU(BI3,BI4,BK3,BK4,P,HI,ROI,DROPI,HWS,RWS,DROPU)
      CALL SGR0_DRSHEV(P,3,DROPI,RVS)
      SU=SHEV(P,HU,N01FL)
      ROU=ROEV(P,SU,N01FL)
      DROPU=1./A2EV(P,SU,N01FL)-BEV(P,SU,N01FL)/ROU/TEV(P,SU,N01FL)
      CALL SGR0_SIMTAU(CI3,CI4,CK3,CK4,P,HVS,RVS,DROPI,HU,ROU,DROPU)
      AI3=AI3+BI3+CI3
      AI4=AI4+BI4+CI4
      AK3=AK3+BK3+CK3
      AK4=AK4+BK4+CK4
      GOTO 20
   5  CONTINUE
C
C  ** MISCELA-SURRISCALDATO **
C
      CALL SGR0_SATTAU(AI3,AI4,AK3,AK4,ROI,P,HVS,HWS,HVS,1)
      CALL SGR0_SATTAU(BI3,BI4,BK3,BK4,ROI,P,HI,HWS,HVS,0)
      CALL SGR0_DRSHEV(P,3,DROPI,RVS)
      SU=SHEV(P,HU,N01FL)
      ROU=ROEV(P,SU,N01FL)
      DROPU=1./A2EV(P,SU,N01FL)-BEV(P,SU,N01FL)/ROU/TEV(P,SU,N01FL)
      CALL SGR0_SIMTAU(CI3,CI4,CK3,CK4,P,HVS,RVS,DROPI,HU,ROU,DROPU)
      AI3=AI3-BI3+CI3
      AI4=AI4-BI4+CI4
      AK3=AK3-BK3+CK3
      AK4=AK4-BK4+CK4
C
  20  CONTINUE
C
      AI0=(ROU*HU-ROI*HI)/DH
      AI1=(ROU*HU*HU-ROI*HI*HI-AI3)/DH**2-HI*AI0/DH
      AI2=AI4/DH-1.
      AK0=(ROU-ROI)/DH
      AK1=(ROU*HU-ROI*HI-AK3)/DH**2-HI*AK0/DH
      AK2=AK4/DH
C
  300 CONTINUE
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_SIMTAU(AI3,AI4,AK3,AK4,P,HA,ROA,DROPA,HB,ROB,
     $                       DROPB)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      N01FL=1
      DH6=(HB-HA)/6.
      HG=0.5*(HA+HB)
      SG=SHEV(P,HG,N01FL)
      ROG=ROEV(P,SG,N01FL)
      DROPG=1./A2EV(P,SG,N01FL)-BEV(P,SG,N01FL)/ROG/TEV(P,SG,N01FL)
C
      AI3=(HA*ROA+4.*HG*ROG+HB*ROB)*DH6
C
      AI4=(HA*DROPA+4.*HG*DROPG+HB*DROPB)*DH6
C
      AK3=(ROA+4.*ROG+ROB)*DH6
C
      AK4=(DROPA+4.*DROPG+DROPB)*DH6
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_SATTAU(AI3,AI4,AK3,AK4,RO,P,H,HWS,HVS,IFUN)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      N01FL=1
      IF(IFUN.EQ.0) GOTO 5
C
      CALL SATUR(P,3,RWS,RVS,N01FL)
      CALL SGR0_DRSHEV(P,1,AW,AV)
C
      VWS=1./RWS
      VVS=1./RVS
      VR=VVS-VWS
      R=HVS-HWS
      RAPP=R/VR
      DVPW=-AW-VWS/RAPP
      DVPV=-AV-VVS/RAPP
C
   5  VOL=VWS+(H-HWS)/RAPP
      RO=1./VOL
C
      AK3=RAPP*LOG(RWS/RO)
C
      AI3=RAPP*(H-HWS)+AK3*(HWS-VWS*RAPP)
C
      A=RAPP*(RWS-RO)
      B=RAPP*(AK3-VWS*A)
C
      AK4=-A*DVPW-B*(DVPV-DVPW)/R
C
      C=B+A*HWS
      E=RAPP**2*(VOL-VWS)+2.*AK3*(HWS-RAPP*VWS)+
     $  A*RAPP*(VWS-HWS/RAPP)**2
      D=RAPP*E-HWS*C
C
      AI4=-C*DVPW-D*(DVPV-DVPW)/R
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      FUNCTION SGR0_IGA02(IFUN)
      COMMON/REGIME/KREGIM
      COMMON/PARPAR/NUL(6),KSTP,ITERT
      LOGICAL KREGIM
C
C-----SGR0_IGA02=0 NON CALCOLA IL COEFFICIENTE DI SCAMBIO  GV RISER
C-----SGR0_IGA02=1 CALCOLA IL COEFFICIENTE DI SCAMBIO GV RISER
C
    1 SGR0_IGA02=1
  20  RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_GAM02(P,H,S,T,R,TITO,TM,DH,CRIG,G,HTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      REAL MU,LAM                                                       !SNGL
C      DOUBLE PRECISION MU,LAM                                           !DBLE
      NFL=1                                                  
      CALL SATUR(P,7,TSAT,ZOT,NFL)                           
      IF(TM.GT.TSAT) GO TO 1                                     
      CALL SATUR(P,3,ROW,ROV,NFL)                            
      RWV=ROW/ROV                                            
      CP=CPEV(P,S,TITO,1.,NFL)                               
      MU=ETEV(P,T,R,RWV,TITO,1.,NFL)                         
      LAM=ALEV(P,T,R,RWV,TITO,1.,NFL)                        
      HTC=SGR0_DITBOE02(G,DH,CP,MU,LAM)                                 
      RETURN                                                     
 1    CALL SGR0_THOM02(P,TM,HTC)                                        
      RETURN                                                     
      END                                                        
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      REAL FUNCTION SGR0_DITBOE02(G,D,CP,MU,LAM)                             !SNGL
C      DOUBLE PRECISION FUNCTION SGR0_DITBOE02(G,D,CP,MU,LAM)                 !DBLE
C                                                                
C>>>>>>>>    DITTUS BOELTER                                      
C                                                                
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      REAL MU,LAM                                                       !SNGL
C      DOUBLE PRECISION MU,LAM                                           !DBLE
      RE=G*D/MU                                                  
      PR=CP*MU/LAM                                               
      SGR0_DITBOE02=.02*LAM*RE**.8*PR**.4/D                             
      RETURN                                                     
      END                                                        
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_THOM02(P,TW,HTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COEF=2.
    1 NFL=1
      CALL SATUR(P,7,TSAT,ZOT,NFL)
      DT=(TW-TSAT)
C      
      PP=P/1.E5
      HTC=1975.*COEF*EXP(PP/43.43)*DT
C
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0_DRSHEV(P,NCAL,RES1,RES2)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      DATA DELTAS/.01/
      NATF=1
      CALL SATUR(P,3,ROWS,ROVS,NATF)
      CALL SATUR(P,1,SWS,SVS,NATF)
      GO TO (10,20,30),NCAL
   10 A2WS=A2EV(P,SWS+DELTAS,NATF)
      A2VS=A2EV(P,SVS-DELTAS,NATF)
      RES1=1./(ROWS*ROWS*A2WS)
      RES2=1./(ROVS*ROVS*A2VS)
      RETURN
   20 A2W=A2EV(P,SWS-DELTAS,NATF)
      BW=BEV(P,SWS-DELTAS,NATF)
      RES1=1./A2W-BW/(ROEV(P,SWS,NATF)*TEV(P,SWS,NATF))
      RES2=ROWS
      RETURN
   30 A2V=A2EV(P,SVS+DELTAS,NATF)
      BV=BEV(P,SVS+DELTAS,NATF)
      RES1=1./A2V-BV/(ROEV(P,SVS,NATF)*TEV(P,SVS,NATF))
      RES2=ROVS
      RETURN
      END
C
C--------------------------------------------------------------------------------
C
C
C
C--------------------------------------------------------------------------------
C
C
      SUBROUTINE SGR0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $   XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
CC
