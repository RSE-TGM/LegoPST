C**********************************************************************
C modulo fum0.f
C tipo 
C release 1.2
C data 10/23/95
C Puertollano project libut reserver @(#)fum0.f	1.2
C**********************************************************************
C**********************************************************************
C modulo fum0.f
C tipo 
C release 5.1
C data 3/29/95
C reserver @(#)fum0.f	5.1
C**********************************************************************
C
C         ===========================================
C
C            *****  CONDOTTO FUMI  *****
C            VERSIONE MODIFICATA DA SPELTA (NOV 91)
C
C         ===========================================
C
      SUBROUTINE FUM0I3(IFO,IOB,DEBL)
C--------------------------------------------------------------------
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (NCMAX=9)
      PARAMETER (NSMAX=6)
      COMMON/FUM099/NUCEL,NUME(NCMAX),NSUT
      COMMON/FUM001/IBLOC
      COMMON/FUM002/NUCXX,NPAR
C--------------------------------------------------------------------
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'FUM0'/
C
C
C           FUMI
C   MIN 1 MAX 9 CELLE
C   MIN 1 MAX 6 PARETI SCAMBIANTI PER OGNI CELLA
C
C
      CALL FUM0I4(IOB,MOD)
C
      NSTATI= 0
      NUSCIT= 2*NSUT+1
      NINGRE= NSUT+6
C
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULE ',A4,' - ',A)
C
      WRITE(IFO,3000) IOB
 3000 FORMAT('TUF ',A4,2X,'--UA-- OUTLET FLUE GAS TEMPERATURE')
C
      DO  K=1,NUCEL
	DO J=1,NUME(K)
          WRITE(IFO,3001)J,K,IOB,J,K
 3001     FORMAT('TF',I1,I1,A4,2X,
     $  '--UA-- (Met. Wall ',I1,') FLUE GAS MEAN TEMP. INSIDE CELL',I1)
          WRITE(IFO,3002)J,K,IOB,J,K
 3002     FORMAT('GF',I1,I1,A4,2X,
     $  '--UA-- (Met. Wall ',I1
     $,')THERMAL EXCHANGE COEFFICIENT IN CELL',I1)
        END DO
      END DO
C
      WRITE(IFO,3003)IOB
      WRITE(IFO,3004)IOB
      WRITE(IFO,3005)IOB
      WRITE(IFO,3006)IOB
      WRITE(IFO,3007)IOB
      WRITE(IFO,3008)IOB
 3003 FORMAT('WIF ',A4,2X,'--IN-- INLET FLOW RATE OF FLUE GAS')
 3004 FORMAT('TIF ',A4,2X,'--IN-- INLET FLUE GAS TEMPERATURE')
 3005 FORMAT('FAS ',A4,2X,'--IN-- GRITNESS FACTOR OF THE TUBES')
 3006 FORMAT('%CO2',A4,2X,
     $  '--IN-- PARTIAL PRESSURE OF CO2 IN FLUE GAS (IN PERCENT)')
 3007 FORMAT('%PH2',A4,2X,
     $  '--IN-- PARTIAL PRESSURE OF H2O IN FLUE GAS (IN PERCENT)')
 3008 FORMAT('%H2O',A4,2X,
     $  '--IN-- MASSIC FRACTION OF H2O IN FLUE GAS (IN PERCENT)')
C
      DO K=1,NUCEL
	DO NM=1,NUME(K)
	  WRITE(IFO,3009) NM,K,IOB,NM,K
	ENDDO
      ENDDO
C
 3009 FORMAT('TM',I1,I1,A4,2X,
     $  '--IN-- TEMP. OF METAL SURF. ',I1,' FLUE GAS SIDE CELL ',I1)
C
      RETURN
      END
C=====================================================================
      SUBROUTINE FUM0I4(IOB,MOD)
C--------------------------------------------------------------------
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (NCMAX=9)
      PARAMETER (NSMAX=6)
      COMMON/FUM099/NUCEL,NUME(NCMAX),NSUT
      COMMON/FUM001/IBLOC
      COMMON/FUM002/NUCXX,NPAR
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C--------------------------------------------------------------------
C
    1 WRITE(6,2000) NCMAX
 2000 FORMAT(//10X,'FLUE GAS DUCT '//,
     $ 10X,'NUMBER OF CELLS (MIN. 1 - MAX. ',I1,') ?')
      READ(5,*) NUCEL
      IF(NUCEL.LT.1.OR.NUCEL.GT.NCMAX) THEN
	WRITE(6,2001) NUCEL
 2001   FORMAT(/10X,'ERROR  - N.CELLS=',I3,/)
	GO TO 1
      ENDIF
C
      NSUT=0
      DO J=1,NUCEL
2       WRITE(6,2032) J,NSMAX
	READ(5,*) NS
	IF(NS.LT.1.OR.NS.GT.NSMAX) THEN
	  WRITE(6,2033)
	  GOTO 2
	ENDIF
	NSUT=NSUT+NS
	NUME(J) = NS
      ENDDO
2032  FORMAT(2X,' NUMBER OF WALLS EXCHANGING WITH THE CELL ',I1,
     $          ' (1-',I1,')')
 2033 FORMAT(2X,' WRONG NUMBER. RETRY !!')
C
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
      RETURN
      END
C=====================================================================
      SUBROUTINE FUM0I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                  IBLOC1,IBLOC2,IER,CNXYU,TOL)
C--------------------------------------------------------------------
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (NCMAX=9)
      PARAMETER (NSMAX=6)
C--------------------------------------------------------------------
      INTEGER DUENSMAX
      INTEGER VAR
      CHARACTER*4 NT,ND,NL,ISPA,NLP,NLL,NAC,NFA,SUPER
      CHARACTER*4 VARCN
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)
      DIMENSION SUPES(NSMAX),NSUPC(NCMAX)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
      DATA PIGR/3.1415926/
      DATA NT,ND,NL,ISPA/'NTUB','DIAE','LUNG','    '/
      DATA NLP,NLL,NAC,NFA/'PASP','PASL','SCAN','FA  '/
      DATA SUPER/'SUP.'/
C
C - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
C
C ---- Recupero numero di celle attraverso decodifica dell'ultima
C ---- variabile di uscita
C
      WRITE (VARCN,'(A4)')VAR(IV1+NUSCIT-1,1)
      READ (VARCN(4:4),'(I1)')NUCEL
C
      GOTO (1,10),IFUN
C
C  SCRITTURA SIMBOLI DATI ------------- ( LG2 )
C
    1 CONTINUE
C
      DO 999 J=1,NUCEL
	WRITE(14,1031) J,NSMAX
	WRITE(14,1001) NT,J,ND,J,NL,J
	WRITE(14,1001) NLP,J,NLL,J,NAC,J
	WRITE(14,1001) NFA,J
	WRITE(14,1002) (SUPER,I,J,I=1,NSMAX)
  999 CONTINUE
C
 1001 FORMAT(3(4X,A4,'  C',I1,' =',10X,'*'))
 1002 FORMAT(3(4X,A4,I1,' C',I1,' =',10X,'*'))
 1029 FORMAT('*   ** NUMBER OF CELLS:',I2)
 1031 FORMAT('*   ----------------- CELL',I2,' -- MAX N. OF SURF. ',I1)
C
      RETURN
C
C--------------------------------LETTURA DATI ---- ( LG3 )
C
   10 CONTINUE
      READ(14,1004)
      DATI(ID1)  = NUCEL
      IDX=ID1+1
C
      DUENSMAX=2*NSMAX
      NST = 0
C===========================LOOP
      DO 9999 J=1,NUCEL
        READ(14,1004)
        READ(14,1004) TUB,DIAE,HLU
        READ(14,1004) PASP,PASL,SCAN
        READ(14,1004) FA
 1004   FORMAT(3(14X,F10.0,1X))
        NTUB=TUB
        READ(14,1004) (SUPES(IK),IK=1,NSMAX)
C
C___ LE SUPERFICI POSSONO AVERE VALORE NEGATIVO.
C    QUESTO SIGNIFICA CHE PER QUESTE SUPERFICI LO SCAMBIO
C    TERMICO CON I FUMI E` DI TIPO LONG_FLOW E VIENE QUINDI USATA
C    LA SUBROUTINE UCL12 PER IL CALCOLO DEL COEFFICIENTE DI SCAMBIO
C
        NSUP=0.
        SUTO=0.
        DO IK=1,NSMAX
          IF (ABS(SUPES(IK)).GT.0.) THEN
	    IF (SUPES(IK).GT.0.) THEN
C___ TYPSC=1. ==> SCAMBIO IN CROSS FLOW
	      TYPSC=1.
	    ELSE
C___ TYPSC=2. ==> SCAMBIO IN LONG FLOW
	      TYPSC=2.
	      SUPES(IK)=-SUPES(IK)
	    ENDIF
	    DATI(IDX+1+IK)      =SUPES(IK)
	    DATI(IDX+1+NSMAX+IK)=TYPSC
	    SUTO=SUTO+SUPES(IK)
	    NSUP=NSUP+1
          ELSE
	    DATI(IDX+1+IK)      =0.
	    DATI(IDX+1+NSMAX+IK)=1.
          ENDIF
        ENDDO
        NST = NST+NSUP
        NSUPC(J) = NSUP
C
C---------------------------------ELAB.+MEMO DATI
C
        SGAS=SCAN*(1.-DIAE/PASP)
        PASPD=PASP/DIAE
        PASLD=PASL/DIAE
        OPTL=RADL12(PASPD,PASLD,DIAE)
C
        DATI(IDX+1)      =NSUP
        DATI(IDX+DUENSMAX+2)=OPTL
        DATI(IDX+DUENSMAX+3)=FA
        DATI(IDX+DUENSMAX+4)=DIAE
        DATI(IDX+DUENSMAX+5)=SUTO
        DATI(IDX+DUENSMAX+6)=SGAS
        DATI(IDX+DUENSMAX+7)=HLU
C
        IDX=IDX+DUENSMAX+7
C=======================================================
C
 9999 CONTINUE
C
      DATI(ID1+1)=NST
      ID2=ID1+1+(7+DUENSMAX)*NUCEL+NUCEL
C
C--------------------------------COSTANTI DI NORMALIZZ.
C
      GAM0=1000.
      CNXYU(IV1)  =T0
      NSTC=0
      DO J=1,NUCEL
       DO JS=1,NSUPC(J)
 	 CNXYU(IV1+2*(NSTC+JS)-1)=T0
	 CNXYU(IV1+2*(NSTC+JS))=GAM0
	END DO
	NSTC=NSTC+NSUPC(J)
      END DO
C 
      IXX=IV1+2*NST
      CNXYU(IXX+1)=W0
      CNXYU(IXX+2)=T0
      CNXYU(IXX+3)=1.
      CNXYU(IXX+4)=1.
      CNXYU(IXX+5)=1.
      CNXYU(IXX+6)=1.
      IXX=IXX+6
C
      DO J=1,NST
	CNXYU(IXX+J)=T0
      ENDDO
C
C                  TOLLERANZE    (STANDARD)
C
      RETURN
      END
C
C
C=====================================================================
C
C
      SUBROUTINE FUM0C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $                    IBLOC1,IBLOC2)
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*100 SccsID
C
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*), XYU(*), DATI(*), RNI(*)
      PARAMETER (NCMAX=9)
      PARAMETER (NSMAX=6)
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      EXTERNAL FUM0
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'@(#)FUM0.f	1.2\t 1.2\t 10/23/95 Puerpro libut'/          
C
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
	GAM0=1000.
C
C-----------------------------  FUM0
C
      GOTO(10,20,30),IFUN
C
C=============================  TOPOLOGIA JACOBIANO
C
   10 CONTINUE
      NUCEL = DATI(IPD)
      NST   = DATI(IPD+1)
      NEQ   = 2*NST+1
      NVAR  = 6+NST+NEQ
C
      DO 15 I=1,NEQ
      DO 14 J=1,NVAR
      AJAC(I,J)=1.
   14 CONTINUE
   15 CONTINUE
C
      RETURN
C
C=============================  RESIDUI
C
   20 CONTINUE
C
      CALL FUM0(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
      RETURN
C
C=============================  JACOBIANO
C
   30 CONTINUE
C
      NUCEL = DATI(IPD)
      NST   = DATI(IPD+1)
      NEQ   = 2*NST+1
      NVAR  = 6+NST+NEQ
C
      NSTATI=0
      NUSCIT = NEQ
      NINGRE = NVAR-NEQ
      EPS   =1.E-3
      EPSLIM=1.E-4
C
      CALL NAJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $             NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,FUM0)
C
      RETURN
      END
C
C
C
C=====================================================================
C
      SUBROUTINE FUM0(IFUN,IXYU,XYU,IPD,DATI,RN)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      PARAMETER (NCMAX=9)
      PARAMETER (NSMAX=6)
      INTEGER DUENSMAX
      DIMENSION XYU(*),DATI(*),RN(*)
      REAL TFMC(NSMAX,NCMAX),GAMC(NSMAX,NCMAX)
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/REGIME/KREGIM
      LOGICAL KREGIM
      DATA BETA/0.3/
C
C-----------------------------DATI GENERALI
C
      GAM0=1000.
      Q0=W0*H0
C
      NUCEL= DATI(IPD)
      NST  = DATI(IPD+1)
      DUENSMAX=2*NSMAX
      ITU  = IPD+1+(7+DUENSMAX)*NUCEL
C
C----------------------------- GRANDEZZE GENERALI
C
      IWF  =2*NST+1
      ITFI =2*NST+2
      IFF  =2*NST+3
      ICO  =2*NST+4
      IH2  =2*NST+5
      IBW  =2*NST+6
C
      WF   =XYU(IXYU+IWF)*W0
C
      WFABS=ABS(WF)
C
      TFI0 =XYU(IXYU+ITFI)*T0
      FF   =XYU(IXYU+IFF)
      PCO2 =XYU(IXYU+ICO)/100.
      PH2O =XYU(IXYU+IH2)/100.
      H2OBW0=XYU(IXYU+IBW)
      H2OBW =XYU(IXYU+IBW)/100.
C
C-----------------------------LOOP SULLE CELLE
C
      ITM =6+2*NST
      IPC=IPD+1
C-----------------------------DATI E VARIABILI DI UNA CELLA
C
      NSTC=0
C
      DO 2000 ICE=1,NUCEL
C
        NS  =DATI(IPC+1)
        OPTL=DATI(IPC+DUENSMAX+2)
        FA  =DATI(IPC+DUENSMAX+3)
        DIAE=DATI(IPC+DUENSMAX+4)
        SUTO=DATI(IPC+DUENSMAX+5)
        SGAS=DATI(IPC+DUENSMAX+6)
        HLU =DATI(IPC+DUENSMAX+7)
C
        DO JS=1,NS
	  TFMC(JS,ICE)=XYU(IXYU+2*(NSTC+JS)-1)*T0
	  GAMC(JS,ICE)=XYU(IXYU+2*(NSTC+JS))*GAM0
C       	  write(6,*)'IXYU+2*(NSTC+JS)-1',IXYU+2*(NSTC+JS)-1
C       	  write(6,*)'IXYU+2*(NSTC+JS)',IXYU+2*(NSTC+JS)
	END DO
C-------------------------------------------
	TFM=TFMC(1,ICE)
	GAM=GAMC(1,ICE)
C-------------------------------------------
       IF(ICE.GT.1) THEN
	  HFI=HFU
	  TFI=TCU
	ELSE
	  TFI=TFI0
	  HFI=HTFU(TFI,H2OBW,1)
	ENDIF
C-------------------------------------------
	TEME=0.
	DO JK=1,NS
	  TMET=XYU(IXYU+ITM+JK)*T0
	  SUP   =DATI(IPC+1+JK)
	  TYPSC =DATI(IPC+1+JK+NSMAX)
	  TEME=TEME+TMET*SUP
	ENDDO
	TEME=TEME/SUTO
	  DELTF=TFM-TEME
C
	IF(KREGIM) GO TO 9
	IF(ITERT.GT.0.OR.IFUN.NE.2) GO TO 10
 9      CONTINUE
C
C-----CALCOLO IL COEFF. DI SCAMBIO
C
C   Limitazione del valore minimo della portata fumi per il caocolo del coefficiente di scambio
C
      IF(WFABS.LT.10.) WFABS=10.
C
C____ CALCOLO IL COEFF. DI SCAMBIO CONVETTIVO MEDIATO SU OGNI PARETE
	  UC=0.
	  UR=0.
	DO JK=1,NS
	  TMET  =XYU(IXYU+ITM+JK)*T0
	  SUP   =DATI(IPC+1+JK)
	  TYPSC =DATI(IPC+1+JK+NSMAX)
	  TFILM=0.5*(TFM+TMET)
C
	  IF(TYPSC.EQ.1.) THEN
C
C_____ SCAMBIO TERMICO IN CROSS-FLOW
C
	    CALL UC12(TFILM,WFABS,H2OBW0,SGAS,DIAE,FA,
     $                2,UCC,DUCDTF,DUCDTM)
	  ELSE
C
C_____ SCAMBIO TERMICO IN LONG-FLOW
C
	    PERB=SUP/HLU
	    DEQ =4.*SGAS/PERB
	    CALL UCL12(TFILM,TFM,WFABS,H2OBW0,SGAS,DEQ,UCC)
C
	  ENDIF
C
C___ IL COEFF. CONVETTIVO VIENE PESATO SULLE PARETI
C
	  UC= UC + UCC*SUP/SUTO
C
	ENDDO
C
C____ CALCOLO DEL COEFFICIENTE RADIATIVO
C
       CALL UR12(ABS(DELTF),TEME,PH2O,PCO2,OPTL,IFUN,UR,
     $           DURDTF,DURDTM,DURDPGAS)
C
C****** Correzione del coeff. di scambio radiativo (da verificare poi con
C                                                   calma...)
C****** Correzione al momento sospesa in attesa di una decisione definitiva
C
C       if(deltf.lt.10.) ur=0.
C******
C____  COEFFICIENTE COMPLESSIVO
       UTOT=(UC+UR)*FF
       DATI(ITU+ICE)=UTOT/GAM0
C
  10    CONTINUE
C
C___  CALCOLO RESIDUI
C
	UTOT=DATI(ITU+ICE)*GAM0
C
C______ TEST SULLA PORTATA DEI FUMI
C
C    Non si simula l'inversione di flusso dei fumi.
C    Per portate di fumi inferiori a 1.E-3 kg/s si assume portata nulla.
C
	IF (WF.LT.1.E-3.AND.KREGIM) THEN
C
C_____ PORTATA FUMI = 0.
C
	  TFC = TEME
C
          DO JS=1,NS
	    RN(1+2*(NSTC+JS)-1)=(TFM-TFC)/T0
	    RN(1+2*(NSTC+JS))=(GAM-UTOT)/GAM0
	  END DO
C
	  IF (ICE.EQ.NUCEL) THEN
	    TFU   =XYU(IXYU)
	    RN(1) =TFU-TFC/T0
	  ENDIF
C
	ELSE
C
C_____ PORTATA FUMI > 0.
C
	  QBANK=GAM*(TFM-TEME)
	  TCU  = TFM/(1.-BETA) -TFI*BETA/(1.-BETA)
	  HFU=HTFU(TCU,H2OBW,1)
C
     	  RN(1+2*NSTC+1) = (WF*(HFI-HFU)-QBANK*SUTO)/Q0
       	  RN(1+2*NSTC+2)=(GAM-UTOT)/GAM0
C      	  write(6,*)'1+2*NSTC+1',1+2*NSTC+1
C      	  write(6,*)'1+2*NSTC+2',1+2*NSTC+2
C
          DO JS=2,NS
            RN(1+2*(NSTC+JS)-1)=(TFMC(JS,ICE)-TFM)/T0
            RN(1+2*(NSTC+JS))=(GAMC(JS,ICE)-UTOT)/GAM0
C      	  write(6,*)'1+2*(NSTC+JS)-1',1+2*(NSTC+JS)-1
C      	  write(6,*)'1+2*(NSTC+JS)',1+2*(NSTC+JS)
	  END DO
C
	  IF (ICE.EQ.NUCEL) THEN
	    TFU   =XYU(IXYU)
	    RN(1) =TFU-TCU/T0
	  ENDIF
C
	ENDIF
C
        NSTC=NSTC+NS
	ITM =ITM+NS
	IPC=IPC+7+DUENSMAX
C
 2000 CONTINUE
C
      RETURN
      END
CC
      SUBROUTINE FUM0D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C
C-----CONDOTTO FUMI
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON / NORM / P0,H0,T0,W0,RO0,AL0,V0,DP0
      Q0 = W0*H0
      GAM0 = 1000.
C
      NCEL  = DATI(IPD)
      NST   = DATI(IPD+1)
      NEQ   = NST*2+1
      NVAR  = 6+NST+NEQ
      WF    = XYU(IXYU+2*NST+1)*W0
C
      DO I = 1,NEQ
	DO  J = 1,NVAR
	  ITOPVA(I,J) = 1
	END DO
      END DO
C
C-----CALCOLO DELLA TEMPERATURA DI USCITA DEI FUMI
      SIGNEQ(1) = 'OUTLET FLUE GAS TEMPERATURE COMPUTATION'
      UNITEQ(1) = 'K'
      COSNOR(1) = T0
C-----RN(1) = TFU-TFC/T0  (Portata nulla)
C-----RN(1) = TFU-TCU/T0  (Portata <> 0.)
C
C-----CALCOLO DELLA TEMPERATURA MEDIA DEI FUMI NELLA CELLA
      DO 10 I = 1,NCEL
      WRITE (SIGNEQ(1+I), 1001)
     $   'MEAN FLUE GAS TEMPERATURE INSIDE THE CELL', I
      IF (ABS(WF) .LT. 1.E-3) THEN
	UNITEQ(1+I) = 'K'
	COSNOR(1+I) = T0
      ELSE
	UNITEQ(1+I) = 'W'
	COSNOR(1+I) = Q0
      ENDIF
C-----RN(1+I) = (TFM-TFC)/T0                 (Portata nulla)
C-----RN(1+I) = (WF*(HFI-HFU)-QBANK*SUTO)/Q0 (Portata <> 0.)
   10 CONTINUE
C
 1001 FORMAT (A,I2)
C
C-----CALCOLO DEL COEFFICIENTE DI SCAMBIO TERMICO NELLA CELLA
      K = NCEL+1
      DO 20 I = 1,NCEL
      WRITE (SIGNEQ(K+I), 1001)
     $  'THERMAL EXCHANGE COEFFICIENT IN THE CELL', I
      SIGNEQ(K+I) = 'W/m^2/K'
      COSNOR(K+I) = GAM0
   20 CONTINUE
C-----RN(1+NCEL+I)=(GAM-UTOT)/GAM0
      RETURN
      END

