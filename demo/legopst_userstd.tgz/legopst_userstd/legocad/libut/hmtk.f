C**********************************************************************
C modulo hmtk.f
C tipo 
C release 5.3
C data 11/8/95
C reserver @(#)hmtk.f	5.3
C**********************************************************************
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
      SUBROUTINE HMTKI3(IFO,IOB,DEBL)
      COMMON/HMTK00/IBLOC,NE,NU
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'HMTK'/
C
C
C---Liquid Metal Tank with 'n'inlet lines and 'm' outlet lines
C---Metal wall and external heat transfer is taken into account
C
C
      CALL HMTKI4(IOB,MOD)
C
C
      NSTATI=3
      NUSCIT=3
      NINGRE=2*(NE+NU)+3
      NVAR=NUSCIT+NINGRE+NSTATI
C
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      WRITE(IFO,3000)IOB
 3000 FORMAT('HLLE',A4,2X,'--US-- Liquid Metal Enthalpy [J/kg]')
C
      WRITE(IFO,3001)IOB
 3001 FORMAT('MLLM',A4,2X,'--US-- Liquid Metal Mass  [kg]')
C
      WRITE(IFO,3002)IOB
 3002 FORMAT('TMWT',A4,2X,'--US-- Tank Metal Wall Temperature [�K]')
C
      WRITE(IFO,3003)IOB
 3003 FORMAT('LLLV',A4,2X,'--UA-- Liquid Metal LeVel [m]')
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('PLBT',A4,2X,
     $       '--UA-- Liquid Metal Pressure [Pa] at Tank bottom')
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('TLLT',A4,2X,'--UA-- Liquid Metal Temperature [�K]')
C
      DO 30 J=1,NE
	WRITE(IFO,3010)J,IOB,J
 3010   FORMAT('WE',I2,A4,2X,
     $    '--IN-- FLOW RATE IN THE ENTERING BRANCH N.',I2)
	WRITE(IFO,3015)J,IOB,J
 3015   FORMAT('HE',I2,A4,2X,
     $    '--IN-- ENTHALPY IN THE ENTERING BRANCH N.',I2)
   30 CONTINUE
C
      DO 40 J=1,NU
	WRITE(IFO,3020)J,IOB,J
 3020   FORMAT('WU',I2,A4,2X,
     $    '--IN-- FLOW RATE IN THE COMING OUT BRANCH N.',I2)
	WRITE(IFO,3025)J,IOB,J
 3025   FORMAT('HU',I2,A4,2X,
     $    '--IN-- ENTHALPY IN THE COMING OUT BRANCH N.',I2,' (W<0)')
   40 CONTINUE
      WRITE(IFO,3414)IOB
 3414 FORMAT('PTTZ',A4,2X,
     $  '--IN-- Pressure at Tank top zone [Pa]')
      WRITE(IFO,3415)IOB
 3415 FORMAT('TEST',A4,2X,
     $  '--IN-- FLUID TEMPERATURE OUTSIDE THE TANK')
      WRITE(IFO,3425)IOB
 3425 FORMAT('GEST',A4,2X,
     $  '--IN-- external Heat Transfer coefficient ')
C
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
      SUBROUTINE HMTKI4(IOB,MOD)
      COMMON/HMTK00/IBLOC,NE,NU
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
C
      MAX=40
C
   10 WRITE(6,101) MAX
  101 FORMAT(10X,'BRANCH POINT OF FLOW RATES'/
     $       10X,'NUMBER OF ENTERING BRANCHES (01 -',I3,') ?')
      READ(5,*) NE
      IF(NE.LE.0.OR.NE.GT.MAX) THEN
      WRITE(6,102) NE
  102 FORMAT(10X,'ERROR - N.ENT.=',I3,/)
      GOTO 10
      ENDIF
C
   15 WRITE(6,105) MAX
  105 FORMAT(10X,'NUMBER OF COMING OUT BRANCHES (01 -',I3,') ?')
      READ(5,*) NU
      IF(NU.LE.0.OR.NU.GT.MAX) THEN
      WRITE(6,106) NU
  106 FORMAT(10X,'ERROR - N.USC.=',I3,/)
      GOTO 15
      ENDIF
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
	SUBROUTINE HMTKI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
	DIMENSION VAR(MX1,1),XYU(1),DATI(1),CNXYU(1),TOL(1)
	PARAMETER (MAX=40)
        PARAMETER (GAM0=1000.,AM0=10000.)
	DIMENSION WE(MAX),WU(MAX),HE(MAX),HU(MAX)
C
	COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
C---COLLETTORE DI DISTRIBUZIONE A N TUBI
C
	GO TO(100,200),IFUN
C
  100   WRITE(14,500)'NU.TU.EN','NU.TU.US','SECTION ',
     1               'MASSA ME','CP MET. ','COND MET',
     1               'SPESSORE','SUP.  ES'
	RETURN
C
C---lettura e memorizzazione dati
C
  200   READ(14,502)
	READ(14,502) FNE,FNU,SECTION,CM,CPM,COND,SPESS,SUPES
C
  500   FORMAT(3(4X,A8,' =',10X,'*'))
  502   FORMAT(3(14X,F10.2,1X))
C
C______________________________________________
C
       NE=FNE
       NU=FNU
C
	CTMET=CM*CPM
	GAMET=2.*COND/SPESS
	DEQ=(VOLUME+SQRT(VOLUME**2+VOLUME*2.*SPESS*SUPES))*2./SUPES
	DATI(ID2  ) = NE
	DATI(ID2+1) = NU
	DATI(ID2+2) = SECTION
	DATI(ID2+3) = CTMET
        DATI(ID2+4) = AM0
C       DATI(ID2+5) = PK
C       DATI(ID2+6) = S
C       DATI(ID2+7) = P
C	DATI(ID2+8) = PRIF
	DATI(ID2+10)= GAMET
	DATI(ID2+11)= SUPES
C        DATI(ID2+12)= TM
C	DATI(ID2+13)= HRIF
C	DATI(ID2+14)= ISOLATO
	DATI(ID2+15)= DEQ
	DATI(ID2+16)= 1000.
C
	ID2 = ID2+16
C
C---costanti di normalizzazione
C
	CNXYU(IV1  ) = H0
	CNXYU(IV1+1) = AM0
	CNXYU(IV1+2) = T0
	CNXYU(IV1+3) = 1.
	CNXYU(IV1+4) = P0
	CNXYU(IV1+5) = T0
	NT=NE+NU
	I0=IV1+5
	DO J = 1,NT
	JW=2*J-1
	JH=JW+1
	CNXYU(I0+JW) = W0
	CNXYU(I0+JH) = H0
	ENDDO
	CNXYU(I0+2*NT+1) = P0
	CNXYU(I0+2*NT+2) = T0
	CNXYU(I0+2*NT+3) = GAM0 
C
	RETURN
	END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
	SUBROUTINE HMTKC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
	DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
C---COLLETTORE DI DISTRIBUZIONE A N TUBI
C   CALCOLO RESIDUI
C
	PARAMETER (MAX=40)
	DIMENSION WE(MAX),WU(MAX),HE(MAX),HU(MAX)
C
	COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
	COMMON/PARPAR/NUL(7),ITERT
	COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
	EXTERNAL HMTK
	LOGICAL KREGIM
	COMMON/REGIME/KREGIM
C
	NE=DATI(IPD)
	NU=DATI(IPD+1)
	NVAR=2*(NE+NU)+9
C
	GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100   DO I=1,6
	DO J =1,NVAR
	  AJAC(I,J) = 1.
	END DO
	END DO
	RETURN
C
C---calcolo residui
C
  200   CONTINUE
	CALL HMTK(IFUN,IXYU,XYU,IPD,DATI,RNI)
	RETURN
C
C---calcolo jacobiano
C
 300    CONTINUE
      NSTATI =3
      NUSCIT =3
      NINGRE =2*(NE+NU) +3
C
C---------calcolo jacobiano NUMERICO
C
      EPS   =1.E-3
      EPSLIM=1.E-4
      CALL NAJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,HMTK)
C
      RETURN
      END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
	SUBROUTINE HMTK(IFUN,IXYU,XYU,IPD,DATI,RNI)
	DIMENSION XYU(*),DATI(*),RNI(*)
C
C---COLLETTORE DI DISTRIBUZIONE A N TUBI
C   CALCOLO RESIDUI
C
	PARAMETER (MAX=40) 
        PARAMETER (GAM0=1000.,AM0=10000.)
	PARAMETER (GA=9.81)
	DIMENSION WE(MAX),WU(MAX),HE(MAX),HU(MAX)
C
	LOGICAL KREGIM
C
        REAL MLLM,LLLV,LMetal,MU
C
	COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
	COMMON/PARPAR/NUL(7),ITERT
	COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
	COMMON/REGIME/KREGIM
C
C____________ COEFFICIENTI PER DEFINIRE LO SCAMBIO FLUIDO PARETE
C             COPIATI DA GAMTERT
	DATA CCW/4.0125/,CCV/7.495/,AAW/0.0375/,AAV/0.0167E-5/
C
C---calcolo residui
C
C---decodifica dati
C
	NE   =DATI(IPD   )
	NU   =DATI(IPD+1 )
	SECTION  =DATI(IPD+2 )
	CTMET=DATI(IPD+3 )
C	PRIF = DATI(IPD+8)
	GAMET= DATI(IPD+10)
	SUPES= DATI(IPD+11)
C
C	HRIF = DATI(IPD+13)
C	ISOLATO=DATI(IPD+14)
	DEQ    =DATI(IPD+15)
C
C---decodifica variabili
C
	HLLE = XYU(IXYU  )*H0
	MLLM = XYU(IXYU+1)*AM0
	TMWT = XYU(IXYU+2)*T0
	LLLV = XYU(IXYU+3)
	PLBT = XYU(IXYU+4)*P0
	TLLT = XYU(IXYU+5)*T0
C
	I0=IXYU+5
	DO J = 1,NE
	  JW=2*J-1
	  JH=JW+1
	  WE(J) = XYU(I0+JW)*W0
	  HE(J) = XYU(I0+JH)*H0
	END DO
	I0=I0+2*NE
	DO J = 1,NU
	  JW=2*J-1
	  JH=JW+1
	  WU(J) = XYU(I0+JW)*W0
	  HU(J) = XYU(I0+JH)*H0
	END DO
C
	PTTZ  = XYU(IXYU+2*(NE+NU)+6)*P0
	TEST  = XYU(IXYU+2*(NE+NU)+7)*T0
	GAMES = XYU(IXYU+2*(NE+NU)+8)*GAM0
C
C
C----------------------------flussi dimassa ed energia
C
	SUME=0.
	SUMHE=0.
	SUMU=0.
	DO J= 1,NE
	  IF(WE(J).GT.0.)            THEN
	    SUME=SUME+WE(J)
	    SUMHE=SUMHE+WE(J)*HE(J)
				     ELSE
	    SUMU=SUMU+WE(J)
	  ENDIF
	END DO
	DO J= 1,NU
	  IF(WU(J).LT.0.)            THEN
	    SUME=SUME-WU(J)
	    SUMHE=SUMHE-WU(J)*HU(J)
				     ELSE
	    SUMU=SUMU-WU(J)
	  ENDIF
	END DO
C
C
C---------- Metal Density
      Mindex=2
C
      CALL HMTK_FLUID_PROP(MIndex,HLLE,TMetal,ROMetal,TK,MU,CP,BETAP,UQ)
C      TMetal=T_H_LEAD(HLLE)                                               
C      ROMetal=RO_T_LEAD(TMetal)                                            
CX      write(6,*)'ROMetal=',ROMetal,'PTTZ=',PTTZ                                              
C
C
C---------- Metal Volume
C
      VMetal=MLLM/ROMetal
C
C
C---------- Metal Level
C
      LMetal=VMetal/SECTION
C
C
C
	  GAMI= 10000.
C
	  GAMINT =SUPES*GAMI
      GAMEST =SUPES*GAMES
cx      write(6,*)'SUPES=',SUPES,'GAMES=',GAMES                                              
cx      write(6,*)'CTMET=',CTMET                                          
C
C
C----------------------------residui
C
C______ Liquid Metal Energy Conservation
C
      RNI(1)=((SUMHE-SUME*HLLE)-GAMINT*(TMetal-TMWT))/(W0*H0)
C
C
C______ Liquid Metal Mass Conservation
C
      RNI(2)=(SUME+SUMU)/W0
C
C
C______ Tank Metal Wall Energy Conservation
C
      RNI(3)= (GAMINT*(TMetal-TMWT)-GAMEST*(TMWT-TEST))/(CTMET*W0*H0)
C
C
C______ Liquid Metal Level
C
      RNI(4)= LLLV-LMetal
C
C
C______ Liquid Metal Pressure
C
      RNI(5)= (PLBT-GA*LMetal*ROMetal-PTTZ)/P0
C
C
C______ Liquid Metal Temperature
C
      RNI(6)= (TLLT-TMetal)/T0
C
      RETURN
      END
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMTK_FLUID_PROP(FluidType,H,T,RO,TK,MU,CP,BETAP,UQ)
C
      INTEGER FluidType
C
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C
      Select Case  (FluidType)
        Case (1)
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LEAD(T)
          BETAP=1.
          UQ=1.
CX          write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
        Case (2)
C         Case ('LBE')
          T=T_H_LBE(H)
          RO=RO_T_LBE(T)
          TK=TC_T_LBE(T)
          MU=MU_T_LBE(T)
          CP=CP_T_LBE(T)
          BETAP=BETAP_T_LBE(T)
          UQ=UQ_T_LBE(T)
cx          write(6,*)'Case LBE ','T=',T,' MU=',MU                                        
C       Case (3)
C         Case ('Sodium')
        Case Default
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LBE(T)
          BETAP=1.
          UQ=1.
C          write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
cx        write(6,*)'Propriet� fluidi'                                             
cx        write(6,*)'RO=',RO,' CP=',CP ,'BETAP=',BETAP                                              
cx        write(6,*)'UQ=',UQ                                              
      RETURN
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMTKD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      DO I = 1, NUSCIT
	DO J = 1, NUSCIT+NINGRE
	  ITOPVA (I,J) = 1
	ENDDO
      ENDDO

C
C-----Equazione n. 1 (algebrica):
C
      SIGNEQ(1) = 'FLUID ENERGY CONSERV. INSIDE THE MANIFOLD'
      UNITEQ(1) = 'W'
      COSNOR(1) = W0*H0
C
C-----Equazione n. 2 (algebrica):
C
      SIGNEQ(2) = 'FLUID MASS CONSERV. INSIDE THE MANIFOLD'
      UNITEQ(2) = 'kg'
      COSNOR(2) = W0
C
C-----Equazione n. 3 (algebrica):
C
      SIGNEQ(3) = 'TEMPERATURE OF MANIFOLD METAL WALL COMPUT.'
      UNITEQ(3) = 'K'
      COSNOR(3) = T0
C
      RETURN
      END
