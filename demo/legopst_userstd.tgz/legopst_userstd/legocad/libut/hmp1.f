C***********************************************************************
C*                                                                     *
C*                   CESI RICERCA    April 2008                        *
C*                                                                     *
C*                      Heavy Metal Pipe rel.1                         *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
      SUBROUTINE HMP1I3(IFO,IOB,DEBL)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      COMMON/HMP101/IBLOC
      COMMON/HMP102/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'HMP1'/
C
      CALL HMP1I4(IOB,MOD)
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
    5 NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
C
      DO 20 K=1,NCEL
      WRITE(IFO,3000)K,IOB,K
 3000 FORMAT('HM',I2,A4,2X,'--US-- ENTALPIA MEDIA FLUIDO', 
     1' CELLA ',I2,' TUBO')
   20 CONTINUE
C
      DO 30 K=1,NCEL-1
      WRITE(IFO,3001)K,IOB,K
 3001 FORMAT('PU',I2,A4,2X,'--US-- PRESSIONE FLUIDO', 
     1' USCITA CELLA ',I2,' TUBO')
   30 CONTINUE
      WRITE(IFO,3101)IOB
 3101 FORMAT('PITU',A4,2X,'--US-- PRESSIONE FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3102)IOB
 3102 FORMAT('WUTU',A4,2X,'--US-- PORTATA FLUIDO USCITA TUBO')
      DO 40 K=2,NCEL
      WRITE(IFO,3002)K,IOB,K
 3002 FORMAT('WI',I2,A4,2X,'--US-- PORTATA FLUIDO INGRESSO CELLA ',I2)
   40 CONTINUE
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3013)J,K,IOB,J,K
 3013     FORMAT('TL',I1,I1,A4,2X,'--UA-- Lead Temperature - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
          WRITE(IFO,3023)J,K,IOB,J,K
 3023     FORMAT('GL',I1,I1,A4,2X,'--UA-- Heat Transfer Coefficient - ', 
     1           ' Wall ',I1,' CELLA ',I1,' Channel')
        END DO
      END DO
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,3003)J,K,IOB,J,K
 3003     FORMAT('QT',I1,I1,A4,2X,'--UA-- POTENZA SCAMBIATA', 
     1           ' PARETE ',I1,' CELLA ',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3014)IOB
 3014 FORMAT('HITI',A4,2X,'--UA-- ENTALPIA FLUIDO IGRESSO TUBO - W<0' )
C
      WRITE(IFO,3004)IOB
 3004 FORMAT('HOLD',A4,2X,'--UA-- ENTALPIA FLUIDO USCITA TUBO' )
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('HILD',A4,2X,'--IN-- ENTALPIA FLUIDO INGRESSO TUBO')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('PUTU',A4,2X,'--IN-- PRESSIONE FLUIDO USCITA TUBO')
C
      WRITE(IFO,3007)IOB
 3007 FORMAT('WITU',A4,2X,'--IN-- PORTATA FLUIDO INGRESSO TUBO' )
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('HDLC',A4,2X,'--IN-- ENTALPIA FLUIDO USCITA TUBO',
     1' (INVERSIONE PORTATA)')
C
      DO K=1,NCEL
        DO J=1,NPAR
          WRITE(IFO,4003)J,K,IOB,J,K
 4003     FORMAT('TW',I1,I1,A4,2X,'--IN-- TEMPERATURA PARETE INTERNA ' 
     1           ,I1,' CELLA',I1,' TUBO')
        END DO
      END DO
C
      WRITE(IFO,3009)IOB
 3009 FORMAT('ATTR',A4,2X,'--IN-- COEFFICIENTE DI ATTRITO TUBO')
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1I4(IOB,MOD)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      COMMON/HMP101/IBLOC
      COMMON/HMP102/NCEL,NPAR
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
    1 WRITE(6,1000)NPMAX
 1000 FORMAT(//10X,'TUBAZIONE SENZA PARETE METALLICA CON SCAMBIO '//10X
     $ ,'NUMERO DI PARETI DI SCAMBIO PER OGNI CELLA (MAX = ',I2,') ?')
      READ(5,*) NPAR
      IF(NPAR.GE.1.AND.NPAR.LE.NPMAX)GO TO 3
      WRITE(6,1004) NPAR
 1004 FORMAT(/10X,'ERRORE - N. PARETI =',I3)
      GO TO 1
    3 CONTINUE
      WRITE(6,1003) NCMAX
 1003 FORMAT(//10X,'NUMERO DI CELLE (02 -',I3,') ?')
      READ(5,*) NCEL
 1001 FORMAT(I2)
      IF(NCEL.GE.2.AND.NCEL.LE.NCMAX)GO TO 5
      WRITE(6,1002) NCEL
 1002 FORMAT(/10X,'ERRORE  - N.CELLE=',I3,/)
      GO TO 1
    5 CONTINUE
C
      WRITE(IBLOC,5000)MOD,IOB
 5000 FORMAT(2A4)
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,IBLOC1,   
     $                  IBLOC2,IER,CNXYU,TOL)                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER VAR
      INTEGER CMSL,FluidIndex
      LOGICAL JPB,JPB1,JLEAD,JLBE,JLBE1,JNA,JNA1,JSODIUM
      DIMENSION VAR(MX1,2),XYU(*),DATI(*),CNXYU(*),TOL(*)               
      DIMENSION NTUB(NCMAX),DIAI(NCMAX),HLU(NCMAX),DZE(NCMAX)
      DIMENSION FLOWSEC(NCMAX),EHYD(NCMAX),VOL(NCMAX)
      DIMENSION RTNUMB(NCMAX),RODDIAM(NCMAX),RTLENG(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX),HeadLossIndex(NCMAX)              
      DIMENSION ROUGHNESS(NCMAX),HTCS(NCMAX),SUP(NPMAX,NCMAX)                                      
      DIMENSION ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),DB(NCMAX)                                
      DIMENSION GT(NCMAX),GD(NCMAX),GR(NCMAX)                       
      DIMENSION DELTAA(NCMAX),DD(NCMAX),HB(NCMAX),ASpacer(NCMAX)                             
      CHARACTER*6 NT,ND,NL,NZ,NR,SP(NPMAX)                                  
C      CHARACTER*6 NT,ND,NL,NZ,NR,SP                                 
      CHARACTER*6 RTN,RTD,RTL,RTP,RTDZ,HLC,FluidT,ROUGH                                
      CHARACTER*10 FluidType                                
      COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE                                
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0                            
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA FluidT/'Fluid '/
      DATA RTN/'RodsNb'/,RTD/'RodExD'/,RTL/'RodLen'/                 
      DATA RTP/'RodPit'/ ,RTDZ/'RodDZ '/                 
      DATA NT/'ChanNb'/,ND/'ChnExD'/,NL/'ChnLen'/,NZ/'ChanDZ'/                  
      DATA HLC/'HLossS'/ ,ROUGH/'Roughn'/              
      DATA NR/'HTCorS'/SP(1)/'HTSur1'/,SP(2)/'HTSur2'/,SP(3)/'HTSur3'/
      DATA SP(4)/'HTSur4'/,SP(5)/'HTSur5'/,SP(6)/'HTSur6'/
C                                                                       
C      WRITE(6,*) ' Inizio I2'
C-----------------------------------------------------                                                    
      NCEL=NSTATI/3                                                     
      NPAR=(NUSCIT-2)/NSTATI
C                                                                       
      NN0=IV1-1                                                         
      NN1=NCEL+IV1-1                                                    
      NN2=2*NCEL+IV1-1                                                  
      NN3=3*NCEL+IV1-1                                                  
      NEQ=NSTATI+NUSCIT                                          
C                                                                       
C      WRITE(6,*) 'NSTATI ',NSTATI,' NUSCIT ',NUSCIT,' NINGRE',NINGRE                                                    
C      WRITE(6,*) 'IFUN ',IFUN                                                  
C       WRITE(6,*) ' NPAR',NPAR
      GO TO (1,10),IFUN                                                 
C                                                                       
C-----SCRITTURA SIMBOLI DEI DATI                                        
C                                                                       
   1  CONTINUE                                                          
      WRITE(14,3700)
 3700 FORMAT ('*   Heavy Metal Selection : Lead, LBE, Sodium')
      WRITE(14,'(4X,A6,A4,10X,A1)')FluidT,'   =','*'
      WRITE(14,3800)
 3800 FORMAT ('*   -')
      WRITE(14,3900)
 3900 FORMAT ('*   Channel Model Selection :')
      WRITE(14,4000)                                                 
 4000 FORMAT ('*   0 --> Cilindrical pipe - Tubes bundle' )
      WRITE(14,4001)
 4001 FORMAT ('*   1 --> Parallel interstitial flow - tubes / ',
     $                      'fuel rods arranged in concentric annulus')                                                  
      WRITE(14,4002)
 4002 FORMAT ('*   2 --> Parallel interstitial flow - tubes / ',
     $                       'fuel rods arranged in triangular arrays')                                                  
      WRITE(14,4003)
 4003 FORMAT ('*   3 --> Parallel interstitial flow - tubes / ',
     $                           'fuel rods arranged in square arrays')                                                 
      WRITE(14,4004)
 4004 FORMAT (4X,'ChanMdSl =',10X,'*')
      DO 5 I=1,NCEL                                                     
        WRITE(14,4005)
 4005   FORMAT ('*   -')
        WRITE(14,1002)I                                                   
        WRITE(14,4006)
 4006   FORMAT ('*   Fuel rods data')
        WRITE(14,1013) RTN,I,RTD,I,RTL,I,RTP,I,RTDZ,I       
 1013   FORMAT(3(4X,A6,I2,' =',10X,'*'),5X)                               
        WRITE(14,4007)
 4007   FORMAT ('*   Heavy metal channel data')
        WRITE(14,1013) NT,I,ND,I,NL,I,NZ,I,ROUGH,I,NR,I
     $               ,(SP(J),I,J=1,NPAR)
C        WRITE(14,1014)(SP(J),I,J=1,NPAR) 
C 1014   FORMAT(3(4X,A6,I2,' =',10X,'*'),5X)                               
        WRITE(14,1013)HLC,I
        WRITE(14,4008)
 4008   FORMAT ('*   Local pressure drop data')
        WRITE(14,4009)
 4009 FORMAT ('*     1 - Entrance into a straight tube of constant ',
     $        'cross section')
        WRITE(14,4010)
 4010 FORMAT ('*         Th - [m] Thickness of the entrance ')
        WRITE(14,4011)
 4011 FORMAT ('*         B  - [m] Distance of the entrance from the '
     $                                                        ,'wall')
        WRITE(14,1100) 'Th ',I,' [m] =','B  ',I,' [m] ='
 1100 FORMAT(3(4X,A3,I1,A6,10X,'*'),5X)     
        WRITE(14,4012)
 4012 FORMAT ('*     2-5 - Changes of the stream direction ',
     $        '- single, S-shaped and U-shaped bends')
        WRITE(14,4013)
 4013 FORMAT ('*         Delta B - [�] angle of the bend ')
        WRITE(14,4014)
 4014 FORMAT ('*         RC0     - [m] average radius of curvature')
        WRITE(14,4015)
 4015 FORMAT ('*         Db      - [m] distance between the bends')
        WRITE(14,1101)I,I,I
 1101 FORMAT(4X,'Delta B',I1,' =',10X,'*',4X,'RC0 ',I1,'[m] =',10X,'*',
     $       4X,'Db ',I1,' [m] =',10X,'*',5X)
        WRITE(14,4016)
 4016 FORMAT ('*     6-8 - Flanged joint with gasket, Sudden expansion,'
     $        ,' Sudden contraction ')
        WRITE(14,4017)
 4017 FORMAT ('*         GT - [m] gasket thickness ')
        WRITE(14,4018)
 4018 FORMAT ('*         GD - [m] gasket diameter, Exp/Contr. diameter')
        WRITE(14,4019)
 4019 FORMAT ('*         GR - [m] gasket roughness')
       WRITE(14,1100)'GT ',I,' [m] =','GD ',I,' [m] =','GR ',I,' [m] ='      
        WRITE(14,4020)
 4020 FORMAT ('*     9 - Discharge from a tube onto a buffle - '
     $                                 ,'Straight wall diffuser')
        WRITE(14,4021)
 4021 FORMAT ('*         Delta D - [�] angle of the diffuser ')
        WRITE(14,4022)
 4022 FORMAT ('*         DD      - [m] diffuser diameter')
        WRITE(14,4023)
 4023 FORMAT ('*         HB      - [m] distance of the buffle from the '
     $                                                     ,'diffuser')
        WRITE(14,1102) I,I,I
 1102 FORMAT(4X,'Delta D',I1,' =',10X,'*',4X,'DD ',I1,' [m] =',10X,'*',
     $       4X,'HB ',I1,' [m] =',10X,'*',5X)
       WRITE(14,4024)
 4024 FORMAT ('*     10 - Flow through spacers (Rehme reference)')
       WRITE(14,4025)
 4025 FORMAT ('*         As - [mq] Spacer projected frontal area')
        WRITE(14,1103) I
 1103 FORMAT(4X,'As [mq]',I1,' =',10X,'*')
    5 CONTINUE                                                        
 1002 FORMAT('*   VOLUMETRIC NODE ',I2,'  *',55X)
 1003 FORMAT(3(4X,A8,' =',10X,'*'),5X)                               
C                                                                       
C      WRITE(6,*) ' uscita I2 con IFUN 1'                                                    
      RETURN                                                            
C                                                                      
C-----LETTURA DEI DATI                                                  
C 
   10 CONTINUE                                                                      
C      WRITE(6,*) ' sto leggendo F14 -0'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 -1'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 2 FluidType'                                                    
      READ(14,'(14X,A10)') FluidType                                                     
C      WRITE(6,*) ' sto leggendo F14 - 3' , FluidType                                                  
      READ(14,1004)                                                     
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 4' , FluidType                                                  
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 5'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 6 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 7 -'                                                    
      READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo F14 - 8 - CMSLD'                                                    
      READ(14,1004)CMSLD                                                  
C                                                                       
      DO 15 I=1,NCEL                                                    
C      WRITE(6,*) ' sto leggendo celle F14   CMSLD', CMSLD                                                   
        READ(14,1004)                                                     
        READ(14,1004)                                                     
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle in do F14'                                                    
        READ(14,1004) RTNUMB(I),RODDIAM(I),RTLENG(I),RODPITCH(I)
     $               ,RODTDZ(I)
C      WRITE(6,*) ' sto leggendo celle 2 F14'                                                    
        READ(14,1004)                                                     
        READ(14,1004) TUB ,DIAI(I),HLU(I),DZE(I)            
     $               ,ROUGHNESS(I),HTCS(I),(SUP(J,I),J=1,NPAR)                                
        READ(14,1004)HeadLossIndex(I)                  
        NTUB(I)=TUB                                                       
C      WRITE(6,*) ' sto leggendo celle 3 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 5 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 6 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 7 F14'                                                    
        READ(14,1004)ET(I),WD(I)                                                     
C      WRITE(6,*) ' ET(I),WD(I)',ET(I),WD(I)                                                   
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 9 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 10 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 11 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 12 F14'                                                    
        READ(14,1004)DELTA(I),RC0(I),DB(I)                                                     
C      WRITE(6,*) ' DELTA(I),RC0(I),DB(I)',DELTA(I),RC0(I),DB(I)                                                
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 15 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)GT(I),GD(I),GR(I)                                                     
C      WRITE(6,*) ' GT(I),GD(I),GR(I)',GT(I),GD(I),GR(I)                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 4 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 15 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)DELTAA(I),DD(I),HB(I)                                                     
C      WRITE(6,*) ' DELTAA(I),DD(I),HB(I)',DELTAA(I),DD(I),HB(I)                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 16 F14'                                                    
        READ(14,1004)                                                     
C      WRITE(6,*) ' sto leggendo celle 17 F14'                                                    
        READ(14,1004)ASpacer(I)                                            
   15 CONTINUE                                                          
C                                                                       
C      WRITE(6,*) ' sto caricando dati righe vuote'
      DO J=2,NCEL
        IF (RTNUMB(J).LE.0) THEN
          RTNUMB(J)=RTNUMB(J-1)                                                 
          RODDIAM(J)=RODDIAM(J-1)                                                 
          RTLENG(J)=RTLENG(J-1)                                                   
          RODPITCH(J)=RODPITCH(J-1)                                                   
          RODTDZ(J)=RODTDZ(J-1)                                                 
        END IF                                         
      END DO
C                                                    
      DO I=2,NCEL                                                    
        IF (NTUB(I).LE.0) THEN                                         
          NTUB(I)=NTUB(I-1)                                                 
          DIAI(I)=DIAI(I-1)                                                 
          HLU(I)=HLU(I-1)                                                   
          DZE(I)=DZE(I-1)                                                   
C          HeadLossIndex(I)=HeadLossIndex(I-1)
          ROUGHNESS(I)=ROUGHNESS(I-1)
          HTCS(I)=HTCS(I-1)                                                 
          DO J=1,NPAR
            IF (SUP(J,I-1).LE.0.) THEN 
              SUP(J,I-1)= PIGR*DIAI(I-1)*HLU(I-1)*NTUB(I-1)/NPAR
            END IF                                                 
            SUP(J,I)=SUP(J,I-1)                                               
          END DO
        END IF                                         
      END DO
C
C---- Fluid index assignement
C
C
C--- SELECT CASE on CHARACTER type not supported by GNU FORTRAN ----
C
C      Select Case  (FluidType)
C        Case ("PB","Pb","pB","pb")
C          FluidIndex=1
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Lead','lead')
C          FluidIndex=1
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('LBE','Lbe','lbe')
C          FluidIndex=2
C          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case ('Sodium','sodium','NA','Na','nA','na')
C          FluidIndex=3.
C          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
C          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
C        Case Default
C          FluidIndex=1
C          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
C          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
C          write(6,*)'WARNING!!! default case - Fluid Index   ='
C     $              ,FluidIndex                                             
C      End Select
CC                                           
C
       JPB=(FluidType.EQ.'PB'.OR.FluidType.EQ.'Pb')
       JPB1=(FluidType.EQ.'pB'.OR.FluidType.EQ.'pb')
       JLEAD=(FluidType.EQ.'Lead'.OR.FluidType.EQ.'lead')
       JLBE=(FluidType.EQ.'LBE'.OR.FluidType.EQ.'Lbe')
       JLBE1=(FluidType.EQ.'lbe')
       JSODIUM=(FluidType.EQ.'Sodium'.OR.FluidType.EQ.'sodium')
       JNA=(FluidType.EQ.'NA'.OR.FluidType.EQ.'Na')
       JNA1=(FluidType.EQ.'nA'.OR.FluidType.EQ.'na')
C
       IF (JPB.OR.JPB1.OR.JLEAD) THEN
          FluidIndex=1
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JLBE.OR.JLBE1) THEN
          FluidIndex=2
          write(6,'(18x,2A)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE IF (JNA.OR.JNA1.OR.JSODIUM) THEN
          FluidIndex=3.
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
       ELSE
          FluidIndex=1
          write(6,*)'WARNING!!! Working fluid is not assigned'                                        
          write(6,*)'WARNING!!! default case - working fluid = Lead'                                          
          write(6,*)'WARNING!!! default case - Fluid Index   ='
     $              ,FluidIndex                                             
       END IF                                             
CC                                           
C
C--- ---------------------------------------------------------------- ----
C
C------ General data calculation
C
C
      CMSL=INT(CMSLD)
C
      Select Case  (CMSL)
C
        Case (0)
C
          write(6,'(18x,2A)')'Channel model :  Cilindrical pipe'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            FLOWSEC(I)=PIGR/4.*DIAI(I)**2.*NTUB(I)
            PB=PIGR*DIAI(I)*NTUB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case (1)
C
          write(6,'(18x,2A)')'Channel model :  Concentric annulus'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            PIPES=PIGR/4.*DIAI(I)**2.*NTUB(I)
            RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            FLOWSEC(I)=PIPES-RODS
            PB=PIGR*DIAI(I)*NTUB(I)+PIGR*RODDIAM(I)*RTNUMB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case (2)
          write(6,'(18x,2A,I1)')'Fluid : ',FluidType                                          
          write(6,'(18x,1A,I1)')'Type  : ',FluidIndex                                             
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
C------ Equivalent HYdraulic Diameter
C
C
        Case (3)
C
          write(6,'(18x,2A)')'Channel model :  Tubes buldles - square',
     $                       ' array arranged'                                          
          write(6,'(18x,1A,I2)')'Channel Model Selection = ',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            PIPES=PIGR/4.*DIAI(I)**2.*NTUB(I)
            RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
            FLOWSEC(I)=PIPES-RODS
            PB=PIGR*DIAI(I)*NTUB(I)+PIGR*RODDIAM(I)*RTNUMB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
          END DO
C
        Case Default
C
          write(6,*)'WARNING!!! Channel model is not assigned'                                        
          write(6,*)'WARNING!!! default case - Channel model ='
     $             ,' Cilindrical pipe'                                          
          write(6,*)'WARNING!!! default case -'
     $             ,' Channel Model Selection =',CMSL                                             
C
          DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
            FLOWSEC(I)=PIGR/4.*DIAI(I)**2.*NTUB(I)
            PB=PIGR*DIAI(I)*NTUB(I)
            EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
            VOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Heat transfer surface
C
C            HTS(I)=PB**HLU(I)
C
          END DO
C
      End Select
C
C                                                                       
C
C                                                                       
C-----MEMORIZZAZIONE  DATI GEOMETRICI                                   
C                                                                       
      DATI(ID2)=NCEL                                                    
      DATI(ID2+1)=NPAR                                                  
C      WRITE(6,*) ' sto caricando vettore dati'                                                    
C                                                                       
      DO 25 I=1,NCEL                                                    
        K=ID2+(7+NPAR)*(I-1)+1                                                  
C        S=PIGR*DIAI(I)*HLU(I)*NTUB(I)                                     
C        V=S*DIAI(I)/4.                                                    
C        A=V/HLU(I)                                                        
C        DATI(K+1)=V                                                       
        DATI(K+1)=VOL(I)                                                      
        DATI(K+2)=HLU(I)                                                  
C        DATI(K+3)=A                                                       
        DATI(K+3)=FLOWSEC(I)                                                       
        DATI(K+4)=DIAI(I)                                                 
C        DATI(K+5)=2.*HLU(I)/(DIAI(I)*A*A)                                 
        DATI(K+5)=FluidIndex                                
        DATI(K+6)=DZE(I)                                             
        DATI(K+7)=HTCS(I)                                                 
        DO J=1,NPAR                                               
          DATI(K+7+J)=SUP(J,I)
        END DO                                                
C       write(6,*)'nel vettore dati HLU(',I,') =',HLU(I)                                              
   25 CONTINUE                                                          
C                                                                       
      ID2 = ID2+(7+NPAR)*NCEL+1                                               
C      ID2 = ID2+NCEL+1
      ID2 = ID2+NCEL
      DATI(ID2+1)=CMSLD                                             
      ID2 = ID2+1
      DO J=1,NCEL
        DATI(ID2+J)=RTNUMB(J)                                              
        DATI(ID2+NCEL+J)=RODDIAM(J)                                              
        DATI(ID2+2*NCEL+J)=RTLENG(J)                                                  
        DATI(ID2+3*NCEL+J)=RODPITCH(J)                                                
        DATI(ID2+4*NCEL+J)=RODTDZ(J)                                       
        DATI(ID2+5*NCEL+J)=HeadLossIndex(J)                                       
        DATI(ID2+6*NCEL+J)=NTUB(J)                                       
        DATI(ID2+7*NCEL+J)=ROUGHNESS(J)                                       
        DATI(ID2+8*NCEL+J)=ET(J)                                       
        DATI(ID2+9*NCEL+J)=WD(J)                                       
        DATI(ID2+10*NCEL+J)=DELTA(J)                                       
        DATI(ID2+11*NCEL+J)=RC0(J)                                       
        DATI(ID2+12*NCEL+J)=DB(J)                                       
        DATI(ID2+13*NCEL+J)=GT(J)                                     
        DATI(ID2+14*NCEL+J)=GD(J)                                       
        DATI(ID2+15*NCEL+J)=GR(J)                                       
        DATI(ID2+16*NCEL+J)=DELTAA(J)                                     
        DATI(ID2+17*NCEL+J)=DD(J)                                       
        DATI(ID2+18*NCEL+J)=HB(J)                                       
        DATI(ID2+19*NCEL+J)=ASpacer(J)                                       
      END DO
      ID2 = ID2+20*NCEL+1                                              
C      WRITE(6,*) ' sto caricando normalizzazioni'                                                    
C                                                                       
C-----COSTANTI DI NORMALIZZAZIONE                                       
C                                                                       
      DO I=1,NCEL                                                    
        CNXYU(NN0+I)=H0                                                   
        CNXYU(NN1+I)=P0                                                   
        CNXYU(NN2+I)=W0
      END DO                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*(I-1)*NPAR+2*J-1)=T0                                     
          CNXYU(NN3+2*(I-1)*NPAR+2*J)=GAM0
        END DO
      END DO                                      
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=W0*H0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ-2)=H0                                                     
      CNXYU(IV1+NEQ-1)=H0                                                   
C                                                                       
      CNXYU(IV1+NEQ)=H0                                                   
      CNXYU(IV1+NEQ+1)=P0                                                   
      CNXYU(IV1+NEQ+2)=W0                                                   
      CNXYU(IV1+NEQ+3)=H0                                                   
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
          CNXYU(IV1+NEQ+3+(I-1)*NPAR+J)=T0                                     
        END DO
      END DO                                      
C                                                                       
      CNXYU(IV1+NEQ+NPAR*NCEL+4)=1.                                         
C                                                                       
C-----TOLLERANZE PER LA SOLUZ. SIST.DIFF.ALG.                           
C                                                                       
C*******************************                                        
      DO 45 I=1,NCEL                                                    
        TOL(NCEL+I)=.01E5/P0                                              
        TOL(2*NCEL+I)=.1/W0                                               
   45 CONTINUE                                                          
C*******************************                                        
C                                                                       
C-----STAMPE                                                            
C                                                                       
C                                                                       
      GLOBDZ=0.
      GLOBLE=0.
      DO I=1,NCEL                                                    
        GLOBDZ=GLOBDZ+DZE(I)
        GLOBLE=GLOBLE+HLU(I)
      END DO
C
      WRITE(6,3000)                                                     
C                                                                       
      DO 60 I=1,NCEL                                                    
        K=ID1+(7+NPAR)*(I-1)+1                                                  
        V= DATI(K+1)                                                      
        S= DATI(K+2)                                                      
        A= DATI(K+3)                                                      
        D=DATI(K+4)                                                       
        C=DATI(K+6)                                                       
        WRITE(6,3001) I,V,S,A,D,C 
CX        do j=1,NPAR
CX          write(6,*)'sup(',j,',',i,')',sup(j,i)
CX        END DO                                        
   60 CONTINUE                                                          
C                                                                       
C
      WRITE(6,'(/,10X,A,2X,A,3X,A,F10.5,A,3X,A,F10.5,A)')IBLOC1,IBLOC2
     $                               ,'Global elevation ',GLOBDZ,' [m]'
     $                               ,'Global length ',GLOBLE,' [m]'                                                     
C                                                                       
      RETURN                                                            
 1004 FORMAT(3(14X,F10.0,1X),5X)                                        
 3000 FORMAT(6X,'CELLA',4X,'VOLUME     LUNGHEZZA    SEZIONE     ',      
     $           'DIAM.INT.  DISLIVELLO'//)                             
 3001 FORMAT(6X,I3,5X,5(E11.4,1X)/)                                     
 3010 FORMAT(6X,3E11.4/)                                                
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBLOC1,     
     $                  IBLOC2)                                         
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
C-----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       CHARACTER*80 SccsID
C
C---     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)                       
C
      COMMON/REGIME/KREGIM                                              
C
      COMMON/HMP1BLOCKS/IBLOC1X,IBLOC2X                                              
C
      EXTERNAL HMP1
C
C----     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
C
       DATA SccsID/'%W%\t %I%\t %G%'/          
C
C----     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
      IBLOC1X=IBLOC1
      IBLOC2X=IBLOC2
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
      NVAR=NEQ+NINGRE                                             
C                                                                       
      ISTA=HMP1ISTA05(IFUN)                                                 
C                                                                       
      GO TO (10,20,30),IFUN                                             
C
C---topologia jacobiano
C
   10 CONTINUE
C
      DO I=1,NEQ                                                     
        DO J=1,NVAR                                                    
          AJAC(I,J)=1.                                                      
        END DO
      END DO
C                                                          
      RETURN                                                            
C                                                                       
C
C---calcolo residui
C
   20 CONTINUE
C
      CALL HMP1 (IFUN,IXYU,XYU,IPD,DATI,RNI)                                   
C                                                                       
C-----EVENTUALI STAMPE                                                  
C                                                                       
      IF(ISTA.NE.0) WRITE(6,1001) IBLOC1,IBLOC2                         
 1001 FORMAT(///1X,9(1H*),'BLOCCO',2X,2A4,100(1H*))                     
      IF(ISTA.NE.0) CALL HMP1STAS05(ISTA)                                   
C                                                                       
      RETURN                                                            
C  
   30 CONTINUE
C
C---calcolo jacobiano
C
C      jacobiano numerico
C
C
      EPS    = 1.E-3
      EPSLIM = 1.E-5
C
      CALL HMP1JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $            NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,HMP1)
                  
C                                                                       
      RETURN                                                            
C                                                                       
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1JC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                  NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
            
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(50),CXYU(100),CCRN(50),CCXYU(100)
      EXTERNAL RESIDUI
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/WAD1NQ/NEQ
C
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)                                                  
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
      VARP=10./P0
C
      DO J=1,NCOL
        IF (J.GE.(NCEL+1).AND.J.LE.(2*NCEL).OR.J.EQ.(5*NCEL+4)) THEN
C
C--- se la variabile e` una pressione il suo incremento e` fisso,
C
          VAR=VARP
C
        ELSE 
          VAR=EPS*XYU(IXYU+J-1)
          IF(ABS(VAR).LT.EPSLIM) VAR=EPSLIM
        ENDIF
C
        DO K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR
        END DO
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        DO I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR)
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
        END DO
C
      END DO
C       DO I=1,NRIG
C          write(6,*)'equazione ',I
C         DO J=1,NCOL
C          write(6,*)'var ',j,'J ',AJAC(I,J)
C      END DO
C      END DO
C
      RETURN
      END
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1 (IFUN,IXYU,XYU,IPD,DATI,RNI)                             
C                                                                       
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      LOGICAL KREGIM                                                    
C
      INTEGER CMSL,FluidIndex,HLIndex
C
      REAL TK(NCMAX),QTCV(NCMAX),QCV(NPMAX,NCMAX),QTCDA(NCMAX)
      REAL QTCDB(NCMAX),HMVOL(NCMAX)
      REAL SW(NCMAX),SH(NCMAX),SP(NCMAX),GSPEED(NCMAX)
      REAL LHTC,MU(NCMAX),MUI,MUD,ROUGHNESS(NCMAX)
      REAL CP(NCMAX),BETAP(NCMAX),UQ(NCMAX)
      REAL A0(NCMAX),B0(NCMAX),B1(NCMAX),DET(NCMAX)                                   
C
      DIMENSION XYU(*),DATI(*),RNI(*)
C
      DIMENSION RTLENG(NCMAX)            
      DIMENSION RODPITCH(NCMAX),RODTDZ(NCMAX)             
      DIMENSION EHYD(NCMAX),HeadLossIndex(NCMAX)            
C
      COMMON/HMP1PARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/HMP1TERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/HMP1MEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/HMP1DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/HMP1PRESSDROP/ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),
     $                     DB(NCMAX),GT(NCMAX),GD(NCMAX),GR(NCMAX),
     $                     DELTAA(NCMAX),DD(NCMAX),HB(NCMAX)
      COMMON/HMP1LOCFC/RTNUMB(NCMAX),RODDIAM(NCMAX),SUBCHNUM(NCMAX)
     $                ,DIAI(NCMAX),ASpacer(NCMAX)
      COMMON/HMP1LACANES/ FRICF(NCMAX),FFXLD(NCMAX),CSILOC(NCMAX)
     $                   ,CFC(NCMAX),EHYD,MU                                  
C                                                                       
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
C                                                                       
C      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
C      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C                                                                       
      DATA GAM0/1000./                                              
      DATA PIGR/3.1415926/                                              
      DATA GA/9.81/                                              
C                                                                       
      NCEL=DATI(IPD)                                                    
      NPAR=DATI(IPD+1)
      NNN=NCEL+1                                                        
      NSTATI= 3*NCEL
      NUSCIT= 3*NPAR*NCEL+2
      NINGRE= NPAR*NCEL+5
      NEQ=NSTATI+NUSCIT                                               
C                                                                       
C--------- Data ------                                                         
C                                                                       
      DO I=1,NCEL                                                    
        K3=IPD+(7+NPAR)*(I-1)+1                                                 
        V(I)=DATI(K3+1)                                                   
        HLU(I)=DATI(K3+2)                                                 
C        AREA(I)=DATI(K3+3)                                                
        DIAI(I)=DATI(K3+4)                                                
C        CKF(I)=DATI(K3+5)                                                 
        FluidIndex=DATI(K3+5)                                                 
CX      write(6,*)'da vettore dati FluidIndex(',I,') =',FluidIndex                                              
C        write(6,*)'da vettore dati FluidIndex(',K3+5,') =',DATI(K3+5)                                              
        DZ(I)=DATI(K3+6)                                                 
        HTCS(I)=DATI(K3+7)                                                
        DO J=1,NPAR                                               
          SUP(J,I)=DATI(K3+7+J)
        END DO                                               
C        write(6,*)'da vettore dati HLU(',I,') =',HLU(I)                                              
      END DO                                               
C                                                    
      KD=IPD+(7+NPAR)*NCEL+1
C                                                  
C      KD=KD+NCEL+1
      KD=KD+NCEL
      CMSL=INT(DATI(KD+1))                                             
      KD=KD+1
CX          write(6,*)'CMSL =',CMSL
C                                              
      DO J=1,NCEL
        RTNUMB(J)=DATI(KD+J)                                              
        RODDIAM(J)=DATI(KD+NCEL+J)                                              
        RTLENG(J)=DATI(KD+2*NCEL+J)                                                  
        RODPITCH(J)=DATI(KD+3*NCEL+J)                                              
        RODTDZ(J)=DATI(KD+4*NCEL+J)                                      
        HeadLossIndex(J)=DATI(KD+5*NCEL+J)                                      
        SUBCHNUM(J)=DATI(KD+6*NCEL+J)                                      
        ROUGHNESS(J)=DATI(KD+7*NCEL+J)                                      
        ET(J)=DATI(KD+8*NCEL+J)                                       
        WD(J)=DATI(KD+9*NCEL+J)                                       
        DELTA(J)=DATI(KD+10*NCEL+J)                                       
        RC0(J)=DATI(KD+11*NCEL+J)                                       
        DB(J)=DATI(KD+12*NCEL+J)                                       
        GT(J)=DATI(KD+13*NCEL+J)                                     
        GD(J)=DATI(KD+14*NCEL+J)                                       
        GR(J)=DATI(KD+15*NCEL+J)                                       
        DELTAA(J)=DATI(KD+16*NCEL+J)                                     
        DD(J)=DATI(KD+17*NCEL+J)                                       
        HB(J)=DATI(KD+18*NCEL+J)                                       
        ASpacer(J)=DATI(KD+19*NCEL+J)                                       
      END DO
CX      DO J=1,NCEL
C          write(6,*)'RTNUMB (',J,')=',RTNUMB(J)                                              
C          write(6,*)'RTDIAM (',J,')=',RODDIAM(J)                                             
C          write(6,*)'RTLENG (',J,')=',RTLENG(J)                                             
C          write(6,*)'RTPITCH (',J,')=',RODPITCH(J)                                             
C          write(6,*)'RODTDZ (',J,')=',RODTDZ(J)                                             
CX          write(6,*)'HeadLossIndex (',J,')=',HeadLossIndex(J)                                             
C          write(6,*)'SUBCHNUM (',J,')=',SUBCHNUM(J)                                             
CX          write(6,*)'ROUGHNESS (',J,')=',ROUGHNESS(J)                                             
CX          write(6,*)'ET (',J,')=',ET(J)                                              
CX          write(6,*)'WD (',J,')=',WD(J)                                             
CX          write(6,*)'DELTA (',J,')=',DELTA(J)                                             
CX          write(6,*)'RC0 (',J,')=',RC0(J)                                             
CX          write(6,*)'DB (',J,')=',DB(J)                                             
CX          write(6,*)'GT (',J,')=',GT(J)                                             
CX          write(6,*)'GD (',J,')=',GD(J)                                             
CX          write(6,*)'GR (',J,')=',GR(J)                                             
CX          write(6,*)'DELTAA (',J,')=',DELTAA(J)                                             
CX          write(6,*)'DD (',J,')=',DD(J)                                             
CX          write(6,*)'HB (',J,')=',HB(J)                                             
CX      END DO
C                                                                       
C
C----   Output variables
C
      K5=IXYU-1                                                         
      K6=IXYU-1+NCEL                                                        
      K7=IXYU-1+2*NCEL                                                        
      K8=IXYU-1+3*NCEL                                                        
C
      DO I=1,NCEL                                                    
        HM(I)=XYU(K5+I)*H0                                                   
        P(I+1)=XYU(K6+I)*P0                                                  
        WI(I)=XYU(K7+I)*W0                                                    
        DO J=1,NPAR                                                    
          TLP(J,I)=XYU(K8+2*(I-1)*NPAR+2*J-1)*T0                                     
          GL(J,I)=XYU(K8+2*(I-1)*NPAR+2*J)*GAM0
          QT(J,I)=XYU(K8+2*NCEL*NPAR+(I-1)*NPAR+J)*W0*H0                                     
C          write(6,*)'TLP (',J,',',I,')=',TLP(J,I)                                              
C          write(6,*)'GL (',J,',',I,')=',GL(J,I)                                              
C          write(6,*)'QT (',J,',',I,')=',QT(J,I)                                              
        END DO                                                                                         
      END DO                                                                                         
      HITI=XYU(IXYU+NEQ-2)*H0                                             
      HOLD =XYU(IXYU+NEQ-1)*H0                                              
C
C----   Input variables
C
      HILD  =XYU(IXYU+NEQ)*H0                                                
      P(1)=XYU(IXYU+NEQ+1)*P0                                              
      WI(NNN)=XYU(IXYU+NEQ+2)*W0                                            
      HDLC=XYU(IXYU+NEQ+3)*H0                                                
C
C--- Scambio delle locazioni nei rispettivi vettori della pressione
C--- e della portata ingresso-uscita
C
      PSCAMBIO=P(NCEL+1)
      WSCAMBIO=WI(1)
      P(NCEL+1)=P(1)
      WI(1)=WI(NNN)
      P(1)=PSCAMBIO
      WI(NNN)=WSCAMBIO
C
C------
C
      DO I=1,NCEL
       DO J=1,NPAR                                                    
         TW(J,I)=XYU(IXYU+NEQ+3+(I-1)*NPAR+J)*T0                                    
C          write(6,*)'TW (',J,',',I,')=',TW(J,I)                                              
       END DO                                                                                         
      END DO                                                                                         
C
      CF=XYU(IXYU+NEQ+NPAR*NCEL+4)                                      
C        write(6,*)'CF =',CF                                              
C
C
C------ Equivalent HYdraulic Diameter, Liquid Metal Volume and Mass speed @*v
C
      SELECT CASE (CMSL)
C
         CASE (0)
C
            DO I=1,NCEL
              EHYD(I)=DIAI(I)
              FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
              HMVOL(I)=FLOWSEC(I)*HLU(I)
              GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
CX            write(6,*)'Case 0  ','EHYD (',I,')=',EHYD(I)                                             
CX            write(6,*)'Case 0  ','FLOWSEC (',I,')=',FLOWSEC(I)                                             
CX            write(6,*)'Case 0  ','HMVOL (',I,')=',HMVOL(I)                                             
CX            write(6,*)'Case 0  ','GSPEED (',I,')=',GSPEED(I)                                             
C$           CASE (1)
C$            RPITCH=RODPITCH(I)/RODDIAM(I)
C$            EHYD(I)=RODDIAM(I)*(2.*3.**0.5/PIGR*RPITCH**2.-1.)
C$            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
C$            SUBCHSEC=3.**0.5/4.*RODPITCH(I)*RODPITCH(I)
C$            FLOWSEC(I)=(SUBCHSEC-0.5*RODSEC)*SUBCHNUM(I)
C$            HMVOL(I)=FLOWSEC(I)*HLU(I)
C$            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C$        write(6,*)'FLOWSEC (',I,')=',FLOWSEC(I),'WI (',I,')=',WI(I)                                              
C$        write(6,*)'SUBCHNUM (',I,')=',SUBCHNUM(I)                                              
C$        write(6,*)'GSPEED (',I,')=',GSPEED(I)                                             
C$          CASE (2)
C$            RPITCH=RODPITCH(I)/RODDIAM(I)
C$            EHYD(I)=RODDIAM(I)*(4./PIGR*RPITCH**2.-1.)
C$            RODSEC=PIGR*RODDIAM(I)*RODDIAM(I)/4.
C$            SUBCHSEC=RODPITCH(I)*RODPITCH(I)
C$            FLOWSEC(I)=(SUBCHSEC-RODSEC)*SUBCHNUM(I)
C$            HMVOL(I)=FLOWSEC(I)*HLU(I)
C$            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
            END DO
C
C
         CASE (1)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
C            write(6,*)'Case 1  ','FLOWSEC (',I,')=',FLOWSEC(I)                                             
           END DO
C
C
         CASE (2)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
           END DO
C
C
         CASE (3)
C
           DO I=1,NCEL
C
C------ Equivalent HYdraulic Diameter
C
             PIPES=PIGR/4.*DIAI(I)**2.*SUBCHNUM(I)
             RODS=PIGR*RODDIAM(I)*RODDIAM(I)/4.*RTNUMB(I)
             FLOWSEC(I)=PIPES-RODS
             PB=PIGR*DIAI(I)*SUBCHNUM(I)+PIGR*RODDIAM(I)*RTNUMB(I)
             EHYD(I)=4.*FLOWSEC(I)/PB
C
C------ Control volume
C
             HMVOL(I)=FLOWSEC(I)*HLU(I)
C
C------ Mass speed
C
             GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
           END DO
C
         CASE DEFAULT
           DO I=1,NCEL
            EHYD(I)=DIAI(I)
            FLOWSEC(I)=PIGR*DIAI(I)*DIAI(I)/4.*SUBCHNUM(I)
            HMVOL(I)=FLOWSEC(I)*HLU(I)
            GSPEED(I)=ABS(WI(I))/FLOWSEC(I)                                                   
C
            write(6,*)'WARNING!!! Channel model is not assigned'                                        
            write(6,*)'WARNING!!! default case - Channel model ='
     $               ,' Cilindrical pipe'                                          
            write(6,*)'WARNING!!! default case -'
     $               ,' Channel Model Selection =',CMSL                                             
C
           END DO
C
        END SELECT
C
C
C
CC      DO I=1,NCEL
CC        CKF(I)=2.*HLU(I)/(EHYD(I)*FLOWSEC(I)*FLOWSEC(I))                                 
CC        write(6,*)'CKF (',I,')=',CKF(I)                                             
CC      END DO
C
C----------- Heavy Metal Physical properties
C
C-----------   TK ---> Thermal Conductivity                                                                      
C-----------   RO ---> Density                                                                      
C-----------   DRODH ---> d@/dh                                                                      
C                                    
      DO I=1,NCEL
C
C        write(6,*)'HMP1 HM (',I,')=',HM(I)                                            
        CALL HMP1_FLUID_PROP(FluidIndex,HM(I),TL(I),RO(I),TK(I),MU(I)
     $                      ,CP(I),BETAP(I),UQ(I))
C
C        TL(I)=T_H_LEAD(HM(I))
C        write(6,*)'HMP1 TL (',I,')=',TL(I)                                              
C        RO(I)=RO_T_LEAD(TL(I))                                            
C        write(6,*)'RO (',I,')=',RO(I)                                              
C        DRODH(I)=DRODH_LEAD(HM(I))
C        write(6,*)'DRODH (',I,')=',DRODH(I)                                              
C        TK(I)=TC_H_LEAD(HM(I))
C        MU(I)=MU_T_LEAD(TL(I))
CX       write(6,*)'TL(',I,')=',TL(I),' MU=',MU(I) ,'TK=',TK(I)                                              
CX       write(6,*)'RO(',I,')=',RO(I),' CP=',CP(I) ,'BETAP=',BETAP(I)                                              
CX       write(6,*)'UQ(',I,')=',UQ(I)                                              
      END DO                                  
C
C      TDLC=T_H_LEAD(HDLC)                                               
C      TILD=T_H_LEAD(HILD)                                               
CX      write(6,*)'Prima di FLUID_PROP FluidIndex= ',FluidIndex                                              
      CALL HMP1_FLUID_PROP(FluidIndex,HILD,TILD,ROI,TKI,MUI
     $                     ,CPI,BETAPI,UQI)
      CALL HMP1_FLUID_PROP(FluidIndex,HDLC,TDLC,ROD,TKD,MUD
     $                     ,CPD,BETAPD,UQD)
CX        write(6,*)'Dopo di FLUID_PROP '                                             
C
C
C----------- Friction factor
C                                                                       
      DO I=1,NCEL
        IF (GSPEED(I).NE.0.) THEN
          RE=ABS(GSPEED(I))*EHYD(I)/MU(I)
        ELSE
          RE=.0001*EHYD(I)/MU(I)
        END IF                                               
        FRICF0=0.3164/RE**0.25                                                
CX           write(6,*)'EHYD(',I,')=',EHYD(I),'RE=',RE                                              
C           write(6,*)'EHYD(',I,')=',EHYD(I)                                          
C
        SELECT CASE (CMSL)
C
          CASE (0)
C
CX        write(6,*)'Prima di MOODY_FF '                                          
            CALL HMP1_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                        ,FRICF(I))
            HLIndex=AINT(HeadLossIndex(I))                                              
CX        write(6,*)'Dopo di MOODY_FF HLIndex=',HLIndex                                          
            CALL HMP1_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I)
     $                      ,CSILOC(I))
            FFXLD(I)=FRICF(I)*HLU(I)/EHYD(I)                                          
            CFC(I)=FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
CX        write(6,*)'Dopo di LOC_FC '                                          
C
          CASE (1)
C
            IF (SUBCHNUM(I).EQ.1..AND.RTNUMB(I).EQ.1.) THEN
C
C----------- Concentric Annulus
C                                                                       
              CALL HMP1_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
              ICA=101
C
              CALL HMP1_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
              FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
              HLIndex=AINT(HeadLossIndex(I))                                              
C
              CALL HMP1_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
              CFC(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
             ELSE
C
              CALL HMP1_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
              ICA=101
C
              CALL HMP1_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
              FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
              HLIndex=AINT(HeadLossIndex(I))                                              
C
              CALL HMP1_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
              CFC(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)+CSILOC(I)                                            
C                                            
             END IF 
C                                            
          CASE (2)
C
C----------- Triangular Array
C                                                                       
             CALL HMP1_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
             ICA=101
C
             CALL HMP1_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
C             FFXLD(I)=XK2R*FRICF(I)*HLU(I)/EHYD(I)
C
             ATR=0.58*(1.-EXP(-70.*(RPITCH-1.)))+9.2*(RPITCH-1.)
             DELTATR=0.57+0.18*(RPITCH-1.)+0.53*(1-EXP(-ATR))
C
             FFXLD(I)=XK2R*FRICF(I)*DELTATR*HLU(I)/EHYD(I)
C
C             CFC(I)=FRICF0*DELTATR                                               
C
             HLIndex=AINT(HeadLossIndex(I))                                              
C
             CALL HMP1_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
             CFC(I)=XK2R*FRICF(I)*DELTATR*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
          CASE (3)
C
C----------- Square Array
C                                                                       
            CALL HMP1_MOODY_FF(ROUGHNESS(I),EHYD(I),GSPEED(I),MU(I)
     $                          ,FRICF(I))
C
            ICA=101
C
            CALL HMP1_LOC_FC(I,ICA,EHYD(I),WI(I),MU(I),XK2R)
C
            DELTASQ=0.59+0.19*(RPITCH-1.)+0.52*(1-EXP(10.*(RPITCH-1.)))
C
            FFXLD(I)=XK2R*FRICF(I)*DELTASQ*HLU(I)/EHYD(I)
C
            HLIndex=AINT(HeadLossIndex(I))                                              
C
            CALL HMP1_LOC_FC(I,HLIndex,EHYD(I),WI(I),MU(I),CSILOC(I))
C
            CFC(I)=XK2R*FRICF(I)*DELTASQ*HLU(I)/EHYD(I)+CSILOC(I)                                            
C
          CASE DEFAULT
            CFC(I)=FRICF0                                             
        END SELECT
      END DO        
C
C
C
C----------- Heat Transfer Coefficient
C                                                                       
C                                                                       
      DO I=1,NCEL                                                    
        DO J=1,NPAR                                                    
CX          write(6,*)'prima di IF HTCS(',I,')=',HTCS(I)                                              
          IF (HTCS(I).LT.0.) THEN
C            CALL HMP1_UHTC(HTCS(I),TL(I),RODPITCH(I),RODDIAM(I)
C     $                                    ,GSPEED(I),EHYD(I),LHTC(J,I))
          ELSE
CX           write(6,*)'prima di chiamare HMP1_HTC HTCS(',I,')=',HTCS(I)                                              
CXX        write(6,*)'prima di chiamare HMP1_HTC HM (',I,')=',HM(I)                                              
            CALL HMP1_HTC(HTCS(I),RODPITCH(I),RODDIAM(I),GSPEED(I)
     $                         ,EHYD(I),TK(I),MU(I),CP(I),LHTC(J,I))
CXX           write(6,*)'LHTC (',J,',',I,')=',LHTC(J,I)                                              
          END IF        
        END DO        
      END DO        
C
C
CXX        write(6,*)' Convective Heat Transfer'                                          
C----------- Convective Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        QTCV(I)=0.
        DO J=1,NPAR
          QCV(J,I)=LHTC(J,I)*SUP(J,I)*(TL(I)-TW(J,I))
          QTCV(I)=QTCV(I)+QCV(J,I)
        END DO        
      END DO        
C
CXX        write(6,*)' Conductive Heat Transfer'                                          
C
C----------- Conductive Heat Transfer
C                                                                       
C                                                                       
      DO I=1,NCEL
        IF (I.LT.NCEL) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I+1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I+1)/TK(I+1))
          QTCDA(I)=-GHTC*HTS*(TL(I)-TL(I+1))
C        write(6,*)'GHTC =',GHTC ,'HTS =',HTS ,'TL (',I,')=',TL(I)                                              
C        write(6,*)'TK (',I,')=',TK(I),'HLU (',I,')=',HLU(I)                                              
        ELSE
          QTCDA(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TDLC)/(HLU(I)/2.)
        END IF
        IF (I.GT.1) THEN
          HTS=MIN(FLOWSEC(I),FLOWSEC(I-1))
          GHTC=2./(HLU(I)/TK(I)+HLU(I-1)/TK(I-1))
          QTCDB(I)=-GHTC*HTS*(TL(I)-TL(I-1))
        ELSE
          QTCDB(I)=-TK(I)*FLOWSEC(I)*(TL(I)-TILD)/(HLU(I)/2.)
        END IF
      END DO        
C
C
CXX        write(6,*)' Conservation Equations'                                          
C---------- Conservation Equations' Constants and coefficient 
C
C---------- Sw ---->  Mass Conservation
C---------- Sp ---->  Momentum Conservation
C---------- Sh ---->  Energy Conservation
C
      DO I=1,NCEL
        A0(I)=HMVOL(I)*(1./UQ(I)+BETAP(I)/CP(I))
        B0(I)=RO(I)*HMVOL(I)*BETAP(I)/CP(I)
        B1(I)=RO(I)*HMVOL(I)
        DET(I)=A0(I)*B1(I)-B0(I)*HMVOL(I)
C
        SW(I)=WI(I)-WI(I+1)
        SIG2=FLOWSEC(I)*FLOWSEC(I)                                 
CX        write(6,*)'SIG2 (',I,')=',SIG2
        DPDARCY=CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
CX        write(6,*)'DPDARCY (',I,')=',DPDARCY
        IF (I.EQ.1) THEN
          SP(I)=(WI(I)*WI(I)/ROI-WI(I+1)*WI(I+1)/RO(I))/SIG2+P(I)-P(I+1)
     $          -CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
     $          -RO(I)*DZ(I)*GA
CX        write(6,*)'SP (',I,')=',SP(I)
        ELSE
          SP(I)=(WI(I)*WI(I)/RO(I-1)-WI(I+1)*WI(I+1)/RO(I))/SIG2
     $          -CF*CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
     $          +P(I)-P(I+1)-RO(I)*DZ(I)*GA
CX        write(6,*)'SP (',I,')=',SP(I)
        END IF
        IF (WI(I).GE.0.) THEN
          IF (I.EQ.1) THEN
            SHI=WI(I)*(HILD-HM(I))
          ELSE
            SHI=WI(I)*(HM(I-1)-HM(I))
          END IF
        ELSE
          SHI=0.
        END IF
C
        IF (WI(I+1).LE.0.) THEN
          IF (I.EQ.NCEL) THEN
            SHO=WI(I+1)*(HDLC-HM(I))
          ELSE
            SHO=WI(I+1)*(HM(I+1)-HM(I))
          END IF
        ELSE
          SHO=0.
        END IF
C
        SH(I)=SHI-SHO-QTCV(I)+QTCDA(I)+QTCDB(I)
C        SH(I)=SHI-QTCV(I)+QTCDA(I)+QTCDB(I)
      END DO
CZ      IF (IFUN.EQ.2.AND.ITERT.EQ.0) THEN
CZ        DO I=1,NCEL
CZ         write(6,*)'QTCDA(',I,')',QTCDA(I),'QTCDB(',I,')',QTCDB(I)
CZ        END DO
CZ      END IF
C
      NN2=2*NCEL
      NN3=3*NCEL
C
      IF (KREGIM) THEN                                         
        DO I=1,NCEL                                                    
          RNI(I)     =SH(I)/(W0*H0)                                     
          RNI(NCEL+I)=SP(I)/P0                                          
CXX          write(6,*)'RNI(NCEL+I)(',NCEL+I,')',RNI(NCEL+I)
          RNI(NN2+I) =SW(I)/W0                                          
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(GL(J,I)-LHTC(J,I))/GAM0         
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QT(J,I)-QCV(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0                
       ELSE
        DO I=1,NCEL                                                    
          RNI(I)     =(A0(I)*SH(I)+HMVOL(I)*SW(I))/(DET(I)*H0)                          
          RNI(NCEL+I)=(B0(I)*SH(I)+B1(I)*SW(I))/(DET(I)*P0)            
          RNI(NN2+I) =FLOWSEC(I)/HLU(I)*SP(I)/W0                           
          DO J=1,NPAR                                                   
            RNI(NN3+2*(I-1)*NPAR+2*J-1)=(TLP(J,I)-TL(I))/T0
            RNI(NN3+2*(I-1)*NPAR+2*J)=(LHTC(J,I)-GL(J,I))/GAM0          
            RNI(NN3+2*NCEL*NPAR+(I-1)*NPAR+J)=(QCV(J,I)-QT(J,I))/(W0*H0)
          END DO
        END DO
          RNI(3*NCEL+3*NPAR*NCEL+1)=(HITI-HM(1))/H0                     
          RNI(3*NCEL+3*NPAR*NCEL+2)=(HOLD-HM(NCEL))/H0      
C                                                                       
       END IF
C                                                                       
      RETURN                                                            
      END                                                               
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMP1_FLUID_PROP(FluidType,H,T,RO,TK,MU,CP,BETAP,UQ)
C
      INTEGER FluidType
C
      REAL MU,MU_T_LEAD,MU_T_LBE
C
      EXTERNAL T_H_LEAD,RO_T_LEAD,MU_T_LEAD,BETAP_T_LEAD,UQ_T_LEAD
      EXTERNAL T_H_LBE,RO_T_LBE,MU_T_LBE,BETAP_T_LBE,UQ_T_LBE
C
      Select Case  (FluidType)
        Case (1)
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LEAD(T)
          BETAP=1.
          UQ=1.
CX          write(6,*)'Case Lead ','T=',T,' MU=',MU                                              
        Case (2)
C         Case ('LBE')
          T=T_H_LBE(H)
          RO=RO_T_LBE(T)
          TK=TC_T_LBE(T)
          MU=MU_T_LBE(T)
          CP=CP_T_LBE(T)
          BETAP=BETAP_T_LBE(T)
          UQ=UQ_T_LBE(T)
C            write(6,*)'Case LBE ','T=',T,' MU=',MU                                        
C       Case (3)
C         Case ('Sodium')
        Case Default
C         Case ('Lead')
          T=T_H_LEAD(H)
          RO=RO_T_LEAD(T)
          TK=TC_T_LEAD(T)
          MU=MU_T_LEAD(T)
          CP=CP_T_LBE(T)
          BETAP=1.
          UQ=1.
C          write(6,*)'Case default ','T=',T,' MU=',MU                                              
      End Select
C
CX        write(6,*)'Propriet� fluidi'                                             
CX        write(6,*)'RO=',RO,' CP=',CP ,'BETAP=',BETAP                                              
CX        write(6,*)'UQ=',UQ                                              
      RETURN
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1_HTC(HTCS,PITCH,D,G,DH,K,MU,CP,LHTC)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C
C     HTCS  = Heat Transfer Correlation Selection code
C     HME   = Heavy Metal Enthalpy
C     THM   = Temperature of the Heavy Metal
C     PITCH = Lattice pitch
C     D     = Rod outside diameter
C     G     = Mass speed @�V
C     DH    = Hydraulic diameter
C     LHTC  = Lead Heat Transfer Coefficient
C
C
C
C     p = lattice pitch
C     D = rod outside diameter
C
C
C     Selection Code    Correlations for outside tube flow - triangular arrays
C                                                           
C                  1    V.M. Borishanski et al.  Nu=24.151*lg[-8.12 +12.76p/D-3.65(p/D)**2]+0.0174{1-exp[-6(p/D-1)]}(Pe-200)**0.9 
C                  2    H. Graber                Nu=0.25+6.2p/D+(0.32p/D-0.07)Pe**(0.8-0.024p/D)
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles with spacers
C                                                           
C                  3    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.09Pe**(0.64+0.264p/D) 
C
C
C     Selection Code    Correlations for outside tube flow - square arrays - rod bundles without spacers
C                                                           
C                  4    A.V. Zhukov              Nu=7.55p/D-14.(p/D)**-5]-0.07Pe**(0.64+0.264p/D) 
C
C
C
C     Selection Code    Correlations for outside tube flow - doesn't refer to any particular lattice
C                                                           
C                  5    H. Calamai et al.        Nu=4.+0.16(p/D)**5+0.33(p/D)**3.8(Pe/100.)**0.86
C
C
C     Selection Code    Correlations for inside tube flow 
C                                                           
C                  6    Kirillow - Stromquist    Nu=A+0.018Pe**0.8  
C                                                                | 4.5                  Pe < 1000
C                                                             A=<  5.4-0.0009Pe  1000 < Pe < 2000
C                                                                | 3.6                  Pe > 2000
C                                                           
C                  7    Lubarsky                 Nu=0.625Pe**0.4
C                                                                
C                  8    Seban - Shimazaki        Nu=5.+0.025Pe**0.8 - Pure liquid lead
C                  9                             Nu=3.3+0.014Pe**0.8 - without special purification 
C
C
C            default    Subbotin                 Nu=7.55p/D-20(p/D)**-13+(3.67/90)(p/D)**-2Pe**(0.19p/D+0.56)
C probably used in RELAP5/PARCS
C
      INTEGER HTCSC
C
      REAL LHTC,K,MU,NU
C
      HTCSC=INT(HTCS)
CXX      write(6,*)'HMP1 '
CXX      write(6,*)'HTCSC= ',HTCSC
CXX      write(6,*)' PITCH,D,G,DH,K,MU,CP,LHTC='                                              
CXX      write(6,*) PITCH,D,G,DH,K,MU,CP,LHTC                                             
C
      SELECT CASE (HTCSC)
        CASE (0)
          PD=1.
        CASE (1,2,3,4,5,6,7,8,9)
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pitch/Pin diameter not assigned'
	    write(6,*)'             Default value assumed 1.3'
            PD=1.3
	  ELSE
           PD=PITCH/D
	  END IF
        CASE DEFAULT 
	  IF (D.EQ.0.) THEN
	    write(6,*)' Warning !!! Pin diameter not assigned'
	    write(6,*)'             Default value assumed 0.01 m'
            PD=1.3
	  ELSE
            PD=PITCH/D
	  END IF
      END SELECT
CXX      write(6,*)'PD= ',PD
C
C      K=TC_T_LEAD(TL)
C      write(6,*)'TL=',THM,' K=',K                                              
C      write(6,*)' routine HTC     K=',K                                              
C
C      MU=MU_T_LEAD(TL)
C      write(6,*)' routine HTC     MU=',MU                                              
C
C      CP=CP_T_LEAD(TL)
C      write(6,*)'TL=',THM,' CP=',CP                                              
C      write(6,*)' routine HTC     CP=',CP                                              
C
      RE=G*DH/MU
CXX      write(6,*)'RE= ',RE
C
      PR=MU*CP/K      
CXX      write(6,*)'PR= ',PR
C
      PE=RE*PR     
CXX      write(6,*)' routine HTC     PE=',PE                                              
C
      SELECT CASE (HTCSC)
        CASE (0)
C          write(6,*)' routine HTC  case 0   PE=',PE                                              
C          write(6,*)' PITCH,D,G,DH,K,MU,CP,LHTC='                                              
C          write(6,*) PITCH,D,G,DH,K,MU,CP,LHTC                                             
          NU=0.625*PE**0.4
C          write(6,*)' routine HTC  case 0   Nu=',NU                                              
        CASE (1)
          A0TR=-8.12 +12.76*PD-3.65*PD**2.
          A1TR=-6.*(PD-1.)
          NU=24.151*LOG(A0TR)+0.0174*(1.-EXP(A1TR))*(PE-200.)**0.9
        CASE (2)
          NU=0.25+6.2*PD+(0.32*PD-0.07)*PE**(0.8-0.024*PD)
        CASE (3)
          NU=7.55*PD-14./PD**5.-0.09*PE**(0.64+0.264*PD)
        CASE (4)
          NU=7.55*PD-14./PD**5.-0.07*PE**(0.64+0.264*PD)
        CASE (5)
          NU=4.+0.16*PD**5.+0.33*PD**3.8*(Pe/100.)**0.86
        CASE (6)
          IF (PE.LT.1000.) AKS=4.5
          IF (PE.GE.1000..AND.PE.LE.2000.) THEN
            AKS=5.4+0.0009*PE
          END IF
          IF (PE.GT.2000.) AKS=3.6
          NU=AKS+0.018*PE**0.8
        CASE (7)
          NU=0.625*PE**0.4
        CASE (8)
          NU=5.+0.025*PE**0.8
        CASE (9)
          NU=3.3+0.014*PE**0.8
      CASE DEFAULT 
          NU=7.55*PD-20./PD**13.+3.67/(90.*PD**2.)*PE**(0.19*PD+0.56)
C      write(6,*)' RE=',RE,' PR=',PR,' PE=',PE  ,' NU=',NU                                            
      END SELECT
C
      LHTC=K/DH*NU
C      IF (LHTC.LT.0.1) LHTC=100.1
CXX      write(6,*)' LHTC=',LHTC                                              
C
      RETURN
      END
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE HMP1_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C  La subroutine CNDLIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  WAD1  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
      SUBROUTINE HMP1_MOODY_FF(ROUGHNESS,DIA,GSPEED,MU,FRICF)
C
C CALCOLA IL LIVELLO  IN UN CILINDRO ORIZZONTALE
C
C     Y  livello diviso 100
C     YTOT livello in metri
C     SEZ  superficie del pelo libero
C NOTI:
C     VCAV  volume occupato
C     RCAV  raggio del cilindro
C     HLCAV lunghezza del cilindro
C
C ESECUZIONE
C
C
      REAL MU
C
      COMMON/HMP1BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA EPSN/2.71828182845/,FRICMAX/0.1/,FRICMIN/0.008/
C
      RE=GSPEED*DIA/MU
C
      IF (RE.LT.600.) THEN
        WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
        WRITE(6,'(/,15X,A,E12.5,A,/,15X,A)')
     $          'Reynolds Number ',RE
     $         ,' lower than Moody chart minimum value for laminar flow'
     $         ,'Reynolds Number limited to 600.'
        RE=600.
	FRICF=64./RE
      ELSE
        IF (RE.GE.600.AND.RE.LE.2000.) THEN
	  FRICF=64./RE
	ELSE
	  IF (RE.GT.2000.AND.RE.LT.3500.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Critical Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
	  IF (RE.GE.3500.AND.RE.LT.15000.) THEN
            WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
            WRITE(6,'(/,15X,A,E12.5,A,/,15X,2A)')
     $          'Reynolds Number ',RE
     $         ,'in the Transition Zone of the Moody chart'
     $         ,'Friction factor calculated by the Colebrook'
     $         ,' interpolation formula'
          END IF
C
          FRICF0=0.3164/RE**0.25                                                
          ESD=ROUGHNESS/DIA
          FRICF=FRICF0
          IT=0
          Y=FRICF
	  DO WHILE (I.LE.100)
CXXX 1 CONTINUE
            IT=IT+1
C
C
C   RESIDUO
C
            RES=1./SQRT(Y)+2.*LOG10(ESD/3.7+2.51/(RE*SQRT(Y)))
C
CXXX          IF(ABS(RES).LT.1.E-4)GO TO 10
            IF (ABS(RES).LT.1.E-4) THEN
              FRICF=Y
              RETURN
	    END IF
	    
CXXX          IF(IT.GT.100)GO TO 20
C
C     JACOBIANO
C
            XLG=ESD/3.7+2.51/(RE*SQRT(Y))
C        write(6,*) 'prima di dXLGdY Y=', Y,'RE=', RE
            dXLGdY=-0.5*2.51/(RE*Y**1.5)
            DRESDY=-0.5/Y**1.5+2./XLG*dXLGdY*LOG10(EPSN)
C
C   ITERAZIONE
C
            DY=-1.*RES/DRESDY
            Y=Y+DY
            IF (Y.GT.1.E+02) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'over maximum allowable. '
              Y=1.E+02
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
            IF (Y.LT.1.E-06) THEN
              WRITE(6,'(/,15X,1A,4X,A,2X,A,/)')'Block',IBLOC1X,IBLOC2X
              WRITE(6,'(/,15X,A)')'Newton-Raphson iterative method for'
	      WRITE(6,'(15X,A)')'Moody friction factor calculation'
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor value ',Y
              WRITE(6,'(/,15X,A)')'under minimum allowable. '
              Y=1.E-06
              WRITE(6,'(/,15X,A,E12.5)')'Friction factor limited to ',Y
            END IF
CXXX          GO TO 1
          END DO
C
C   SOLUZIONE
C
CC   10 CONTINUE
          WRITE(6,1000)RES
CXXX   20 WRITE(6,1000)RES
 1000     FORMAT(//10X,'SUBROUTINE HMP1_MOODY_FF'/
     $        10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
          write(6,'(2A4)')IBLOC1X,IBLOC2X
CXXX      GO TO 10
        END IF
      END IF
      RETURN                                                            
      END
C
C
C-----------------------------------------------------------------------
C
C
C-----------------------------------------------------------------------
C
C
      SUBROUTINE HMP1_LOC_FC(VolIndex,HLIndex,TD,W,MU,CSILOC)
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      INTEGER HLIndex,VolIndex
C
      REAL CSILOC,MU,L0SUD0,K1,KRE,LDBD,LDBD0,LDBD1
C
      PARAMETER (NFGSUFS=4,NL0SUD0=8,NK1=NFGSUFS*NL0SUD0)
      PARAMETER (NCR0SUD0=4,NRE=12,NKRE=NCR0SUD0*NRE)
      PARAMETER (NCDUMMY=2,NCR0DBD0=21,NB1=NCDUMMY*NCR0DBD0)
      PARAMETER (NCDELTA=8,NVLDBD=16,NVA=NCDELTA*NVLDBD)
      PARAMETER (NCDELTA0=3,NVLDBD0=14,NVA0=NCDELTA0*NVLDBD0)
      PARAMETER (NCDELTA1=3,NVLDBD1=14,NVA1=NCDELTA1*NVLDBD1)
      PARAMETER (NCDELTA2=11,NV1A1=NCDUMMY*NCDELTA2)
      PARAMETER (NCDELTAA=6,NVHdDh=11,NVCSI=NCDELTAA*NVHdDh)
      PARAMETER (NREYNOLD=6,NVDdD0=11,NK2R=NREYNOLD*NVDdD0)
      PARAMETER (NETsDh=11,NVBsDh=11,NECSI=NETsDh*NVBsDh)
C
      DIMENSION TABFGSUFS(NFGSUFS),TABL0SUD0(NL0SUD0),TABNK1(NK1)
      DIMENSION TABDUMMY(NCDUMMY),TABR0DBD0(NCR0DBD0),TABB1(NB1)
      DIMENSION TABR0SUD0(NCR0SUD0),TABRE(NRE),TABKRE(NKRE)
      DIMENSION TABDELTA(NCDELTA),TABLDBD(NVLDBD),TABA(NVA)
      DIMENSION TABDELTA0(NCDELTA0),TABLDBD0(NVLDBD0),TABA0(NVA0)
      DIMENSION TABDELTA1(NCDELTA1),TABLDBD1(NVLDBD1),TABA1(NVA1)
      DIMENSION TABDELTA2(NCDELTA2),TAB1A1(NV1A1)
      DIMENSION TABDELTAA(NCDELTAA),TABHdDh(NVHdDh),TABCSI(NVCSI)
      DIMENSION TABREYNOLD(NREYNOLD),TABDdD0(NVDdD0),TABK2R(NK2R)
      DIMENSION TABETsDh(NETsDh),TABBsDh(NVBsDh),TABECSI(NECSI)
C
      COMMON/HMP1DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)          
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                 ,HTCS(NCMAX)                            
      COMMON/HMP1PRESSDROP/ET(NCMAX),WD(NCMAX),DELTA(NCMAX),RC0(NCMAX),
     $                     DB(NCMAX),GT(NCMAX),GD(NCMAX),GR(NCMAX),
     $                     DELTAA(NCMAX),DD(NCMAX),HB(NCMAX)
      COMMON/HMP1LOCFC/RTNUMB(NCMAX),RODDIAM(NCMAX),SUBCHNUM(NCMAX)
     $                ,DIAI(NCMAX),ASpacer(NCMAX)
      COMMON/HMP1BLOCKS/IBLOC1X,IBLOC2X                                              
C
      DATA PIG /3.141592/
C
C--------------------------------------------------------------------------
C--
C-- old interpolation coefficient for Rehme modified drag coefficient -----
C--
C--      DATA C0/4.68621626/,C1/-2.42827697/,C2/-0.809518313/,C3/2.50047/
C--
C--------------------------------------------------------------------------
C--
C-- interpolation coefficient for Rehme modified drag coefficient -----
C--
      DATA C0/-14.5172776/,C1/7.88567002/,C2/-1.38061547/,C3/23.4108852/
C--
C--------------------------------------------------------------------------
C
C
C
      DATA TABFGSUFS/1.6,2.3,3.2,4./
      DATA TABL0SUD0/0.0,0.5,0.6,0.7,0.8,1.,1.4,2./
      DATA TABNK1/1.0,  1.02, 1.01, 1.0,  1.0 , 1.0,  1.0,  1.0,
     $            1.0,  1.06, 1.03, 1.02, 1.01, 1.0,  1.0,  1.0, 
     $            1.0,  1.16, 1.10, 1.06, 1.04, 1.01, 1.0,  1.0,
     $            1.0,  1.20, 1.15, 1.10, 1.08, 1.04, 1.03, 1.0/
C
C
      DATA TABDUMMY/0.,1./
      DATA TABDELTA2 /0.,20.,30.,45.,60.,75.,90.,110.,130.,150.,180./
      DATA TAB1A1/0.,0.31,0.45,0.6,0.78,0.9,1.,1.13,1.2,1.28,1.4,
     $            0.,0.31,0.45,0.6,0.78,0.9,1.,1.13,1.2,1.28,1.4/
      DATA DUMMY /0.5/
C
C
      DATA TABR0DBD0/0.5,0.6,0.7,0.8,0.9,1.0,1.25,1.5,2.0,3.0,4.0,6.0
     $              ,8.0,10.,15.,20.,25.,30.,35.,40.,50./
      DATA TABB1/1.18,0.77,0.51,0.37,0.28,0.21,0.19,0.17,0.15,0.12,0.11,
     $           0.09,0.07,0.07,0.06,0.05,0.05,0.04,0.04,0.03,0.03
     $          ,1.18,0.77,0.51,0.37,0.28,0.21,0.19,0.17,0.15,0.12,0.11,
     $           0.09,0.07,0.07,0.06,0.05,0.05,0.04,0.04,0.03,0.03/
C
C
      DATA TABR0SUD0/0.5,0.65,0.75,1./
      DATA TABRE/0.1,0.14,0.2,0.3,0.4,0.6,0.8,1.,1.4,2.0,3.0,4.0/
      DATA TABKRE/1.4,1.33,1.26,1.19,1.14,1.09,1.06,1.04,1.,1.,1.,1.,
     $      1.67,1.58,1.49,1.4,1.34,1.26,1.21,1.19,1.17,1.14,1.06,1.,
     $      2.0 ,1.89,1.77,1.64,1.56,1.46,1.38,1.30,1.15,1.02,1. ,1.,
     $      2.0 ,1.89,1.77,1.64,1.56,1.46,1.38,1.30,1.15,1.02,1. ,1./
C
C
      DATA TABDELTA/0.,15.,30.,45.,60.,75.,90.,120./
      DATA TABLDBD/0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,16.,18.,20.,25.,
     $                                                         40.,50./
      DATA TABA/0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $ .2,.42,.6,.78,.94,1.16,1.2,1.15,1.08,1.05,1.02,1.,1.1,1.25,2.,2.,
     $ .4,.65,.88,1.16,1.2,1.18,1.12,1.06,1.06,1.15,1.28,1.4,
     $                                                    1.5,1.7,2.,2.,
     $ .6,1.06,1.2,1.23,1.2,1.08,1.03,1.08,1.17,1.3,1.42,1.55
     $                                                  ,1.65,1.8,2.,2.,
     $1.05,1.38,1.37,1.28,1.15,1.06,1.16,1.3,1.42,1.54,1.66,
     $                                             1.76,1.85,1.95,2.,2.,
     $1.5,1.58,1.46,1.3,1.27,1.3,1.37,1.47,1.57,1.68,1.75,1.8,
     $                                                  1.88,1.97,2.,2.,
     $1.7,1.67,1.4,1.37,1.38,1.47,1.55,1.63,1.7,1.76,1.82,1.
     $                                               88,1.92,1.98,2.,2.,
     $1.78,1.64,1.48,1.55,1.62,1.7,1.75,1.82,1.88,1.9,1.92,
     $                                             1.95,1.97,1.99,2.,2./
C
C
      DATA TABDELTA0 /0.,60.,90./
      DATA TABLDBD0  /0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,20.,25.,40.,50./
      DATA TABA0     /0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $     2.,1.9,1.5,1.35,1.3 ,1.2 ,1.25,1.5,1.63,1.73,1.85,1.95,2.,2.,
     $     2.,1.8,1.6,1.55,1.55,1.65,1.8 ,1.9,1.93,1.98,2.  ,2.  ,2.,2./
C
C
      DATA TABDELTA1 /0.,60.,90./
      DATA TABLDBD1  /0.0,1.,2.,3.,4.,6.,8.,10.,12.,14.,20.,25.,40.,50./
      DATA TABA1     /0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,
     $  1.5 ,1.15,1.05,1.1 ,1.2,1.3,1.35,1.46,1.57,1.73,1.85,1.95,2.,2.,
     $  1.37,0.95,1.1 ,1.25,1.35,1.45,1.45,1.45,1.5 ,1.6 ,1.7,1.9,2.,2./
C
C
      DATA TABDELTAA /0.,15.,30.,45.,60.,90./
      DATA TABHdDh  /0.1,0.15,0.2,0.25,0.3,0.4,0.5,0.6,0.7,1.,1.5/
      DATA TABCSI/0.00,0.00,0.00,0.00,0.00,0.00,1.37,1.20,1.11,1.00,1.,
     $            0.00,0.00,0.00,1.50,1.06,0.72,0.61,0.59,0.58,0.58,.58,
     $            0.00,0.00,1.23,0.79,0.66,0.64,0.66,0.66,0.67,0.67,.67,
     $            0.00,1.50,0.85,0.73,0.75,0.79,0.81,0.82,0.82,0.82,.82,
     $            0.00,0.98,0.76,0.80,0.90,0.96,1.0,1.01,1.02,1.02,1.02,
     $            1.50,0.72,0.74,0.83,0.89,0.94,0.96,0.98,1.00,1.00,1.0/
C
C
      DATA TABREYNOLD /1000.,2000.,1.E+04,1.E+05,1.E+06,1.E+07/
      DATA TABDdD0  /0.,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1.,1.2/
      DATA TABK2R 
     $        /1.,1.40,1.45,1.47,1.48,1.485,1.49,1.4925,1.495,1.5 ,1.5 ,                                                     
     $         1.,1.40,1.45,1.47,1.48,1.485,1.49,1.4925,1.495,1.5 ,1.5 ,
     $         1.,1.03,1.04,1.05,1.05,1.060,1.06,1.0700,1.070,1.07,1.07,
     $         1.,1.02,1.03,1.04,1.05,1.050,1.06,1.0600,1.060,1.06,1.06,
     $         1.,1.02,1.03,1.04,1.04,1.050,1.05,1.0500,1.050,1.06,1.06,
     $         1.,1.01,1.02,1.03,1.03,1.040,1.04,1.0400,1.050,1.05,1.05/
C
C
      DATA TABETsDh /0.,.004,.008,.012,.016,.02,.024,.03,.04,.05,1000./
      DATA TABBsDh  /0.,0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.3,0.5,100./
      DATA TABECSI  /.5,.57,.63,.68,.73,.80,.86,.92,.97,1.00,1.00,
     $               .5,.54,.58,.63,.67,.74,.80,.86,.90,0.94,0.94,
     $               .5,.53,.55,.58,.62,.68,.74,.81,.85,0.88,0.88,
     $               .5,.52,.53,.55,.58,.63,.68,.75,.79,0.83,0.83,
     $               .5,.51,.51,.53,.55,.58,.64,.70,.74,0.77,0.77,
     $               .5,.51,.51,.52,.53,.55,.60,.66,.69,0.72,0.72,
     $               .5,.5 ,.5 ,.51,.52,.53,.58,.62,.65,0.68,0.68,
     $               .5,.5 ,.5 ,.52,.52,.52,.54,.57,.59,0.61,0.61,
     $               .5,.5 ,.5 ,.51,.51,.51,.51,.52,.52,0.54,0.54,
     $               .5,.5 ,.5 ,.50,.50,.50,.50,.50,.50,0.50,0.50,
     $               .5,.5 ,.5 ,.50,.50,.50,.50,.50,.50,0.50,0.50/
C
C
C
      Select Case  (HLIndex)
C
        Case (1)
C
C         Entrance into a straight tube of constant cross section
C         rif. Idelchik pag.122
C
C           DIAI = Tube diameter
C           ET   = Entrance Thickness
C           WD   = Entrance Wall Distance
C
          BsDh=WD(VolIndex)/DIAI(VolIndex)
          ETsDh=ET(VolIndex)/DIAI(VolIndex)
C
          CALL LINTAB(TABETsDh,NETsDh,TABBsDh,NVBsDh,TABECSI,BsDh,ETsDh
     $               ,ECSI,Z1,Z2)
C
C---  Valore provvisorio per imbocco non raccordato e senza sporgenze
C---  b/D=0       rif. Idelchik pag.122
C
CCC          CSILOC=0.5
          CSILOC=ECSI
CC          write(6,*)'CSI locale ','TD=',TD,' ET(VolIndex)=',ET(VolIndex)                                           
CC          write(6,*)'CSI locale ','WD(VolIndex)=',WD(VolIndex)                                           
CC          write(6,*)'CSI locale ','DIAI(VolIndex)=',DIAI(VolIndex)                                           
CC          write(6,*)'CSI locale ','BsDh=',BsDh,' ETsDh=',ETsDh                                           
CC          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C
        Case (2,3,4,5)
C
C         Bends at R0/D0 < 3. and 0< delta < 180�, L0/Dh > 10
C
C         (It is calculated only the local term CSIloc=Krough*Kre*A*B*C)
C                 
C           DELTA [�]= bend angle
C           TD       = bend diameter
C           RC0/TD   = relative radius of curvature (R0SUD0)
C           CSIP     = local coefficient for smooth pipe
C           CSIC     = contraction coefficient
C           CL       = linear loss coefficient
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
          FS=FLOWSEC(VolIndex)
          GSPEED=ABS(W)/FS
          RE=GSPEED*TD/MU
C          DELTA=90.
C          RX0=0.05154+0.0495/2.
          R0SUD0=RC0(VolIndex)/TD             
C          R0SUD0=.8             
C          A=A0+A1*sind(DELTA(VolIndex))+A2*(DELTA(VolIndex))**A3
C          write(6,*)'Case Bend ','DELTA=',DELTA(VolIndex),'sind(DELTA)='
c     $               ,sind(DELTA(VolIndex)),'A=',A                                       
          CALL LINTAB(TABDUMMY,NCDUMMY,TABDELTA2,NCDELTA2,TAB1A1
     $                ,DELTA(VolIndex),DUMMY,AA,Z1,Z2)
CX          write(6,*)'Case Bend ','DELTA(',VolIndex,')=',DELTA(VolIndex)
CX     $             ,'da lintab AA=',AA
C
C          B=B0/(R0SUD0**B1)+B2/(R0SUD0**B3)
C          write(6,*)'Case Bend ','R0SUD0=',R0SUD0,'B=',B
C
          CALL LINTAB(TABDUMMY,NCDUMMY,TABR0DBD0,NCR0DBD0,TABB1,R0SUD0
     $                ,DUMMY,B1,Z1,Z2)
C          write(6,*)'Case Bend ','R0SUD0=',R0SUD0,'da lintab B1=',B1
C
C
C   !!!  For a circular o square cross section C=1.
C
          C=1.
          CSIP=AA*B1*C
C
C          REN=0.1
C          R0SUD0=0.55
C           DO I=1,55
          REN=1.E-05*RE
C
          CALL LINTAB(TABR0SUD0,NCR0SUD0,TABRE,NRE,TABKRE,REN,R0SUD0
     $                ,KRE,Z1,Z2)
C
          CSILOC=KRE*CSIP
CX          write(6,*)'Case Bend ','RC0=',RC0(VolIndex),' R0SUD0=',R0SUD0                                  
CX          write(6,*)'Case Bend ','AA=',AA,' B1=',B1,'CSIP =',CSIP                                        
CX          write(6,*)'Case Bend ','REN=',REN,' KRE=',KRE                                     
CX          write(6,*)'Case Bend ','Z1=',Z1,' Z2=',Z2                                           
C          write(6,*)'Case Bend ','TABR0SUD0=',TABR0SUD0,' TABRE=',TABRE                                           
CX          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
CX          write(6,*)'Case Bend 2 3 4 5 ','CSILOC=',CSILOC                                    
C          REN=REN+0.1
C          R0SUD0=R0SUD0+1.
C          END DO
C
C
          Select Case  (HLIndex)
            Case (3)
C         Doubly curved - S-shaped bend - flow in one plane
C
C           DELTA=45.
              LDBD=DB(VolIndex)/TD
C           DO I=1,55
C          write(6,*)'CSI locale ',' TABLdbD=',TABLDBD                                          
              CALL LINTAB(TABDELTA,NCDELTA,TABLDBD,NVLDBD,TABA,LDBD
     $                   ,DELTA(VolIndex),A,Z1,Z2)
C          CSILOC=K1*(CSIE+CSIC+CL)
C          write(6,*)'CSI locale ','TABDELTA=',TABDELTA,' TABLdbD='
C     $                                                          ,TABLDBD                                          
C          write(6,*)'CSI locale ','NVLdbD=',NVLDBD,'TABA=',TABA                                            
C          write(6,*)'CSI locale ',' DELTA=',DELTA(VolIndex) 
C     $             ,'LdbD=',LDBD,' A=',A                                      
C          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C           LDBD=LDBD+1.
C          END DO
              CSILOC=0.5*A*CSILOC
C          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
C          write(6,*)'Case Bend 3 ','CSILOC=',CSILOC                                    
            Case (4)
C         Doubly curved - S-shaped bend - flow in two mutually perpendicular planes
C
C           DELTA0=90.
              LDBD0=DB(VolIndex)/TD
C           DO I=1,55
              CALL LINTAB(TABDELTA0,NCDELTA0,TABLDBD0,NVLDBD0,TABA0
     $                   ,LDBD0,DELTA(VolIndex),A0,Z1,Z2)
C        write(6,*)'CSI locale ','DELTA0=',DELTA(VolIndex)
C     $           ,'LDBD0=',LDBD0,'A0=',A0                                      
C          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
              CSILOC=0.5*A0*CSILOC
C          write(6,*)'Case Bend 4 ','CSILOC=',CSILOC                                    
C           LDBD0=LDBD0+1.
C          END DO
C
C
            Case (5)
C         Doubly curved - U-shaped bend - flow in one plane
C
C           DELTA1=90.
              LDBD1=DB(VolIndex)/TD
C           DO I=1,55
              CALL LINTAB(TABDELTA1,NCDELTA1,TABLDBD1,NVLDBD1,TABA1
     $                   ,LDBD1,DELTA(VolIndex),A1,Z1,Z2)
C        write(6,*)'CSI locale ','DELTA0=',DELTA(VolIndex)
C     $           ,'LDBD0=',LDBD1,'A1=',A1                                      
C           LDBD1=LDBD1+1.
C          END DO
CX          write(6,*)'Case Bend ','HLIndex=',HLIndex                                    
              CSILOC=0.5*A1*CSILOC
CX          write(6,*)'Case Bend 5 ','CSILOC=',CSILOC                                    
            Case Default
          End Select
C
C
        Case (6,7,8)
C
C         Flanged joint with gasket
C
C           TD   = Tube diameter
C           FS   = main stream flow section
C           GT   = Gasket thickness
C           GD   = Gasket diameter
C           FG   = Gasket flow section
C           CSIE = Expansion coefficient
C           CSIC = Contraction coefficient
C           CL   = Linear loss coefficient
C             
C          TD=0.0495
C          GT=0.0045
C          GD=0.0699
C          GROUGH=2.53E-06
          GROUGH=GR(VolIndex)
C
          Select Case  (HLIndex)
            Case (6)
C 20 novembre              FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
C              write(6,*)'DIAI(VolIndex) =',DIAI(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIE=(1-FS/FG)**2.
              CSIC=0.5*(1-FS/FG)**(3./4.)
              GASPEED=ABS(W)/FG
              CALL HMP1_MOODY_FF(GROUGH,GD(VolIndex),GASPEED,MU,GF)
               CL=GT(VolIndex)/GD(VolIndex)*GF
              FGSUFS=FG/FS
              L0SUD0=GT(VolIndex)/GD(VolIndex)
              CALL LINTAB(TABFGSUFS,NFGSUFS,TABL0SUD0,NL0SUD0,TABNK1,
     $                L0SUD0,FGSUFS,K1,Z1,Z2)
              CSILOC=K1*(CSIE+CSIC+CL)
CXX          write(58,'(2A4)')IBLOC1X,IBLOC2X                                             
CXX          write(58,*)'FLOWSEC(VolIndex)=',FLOWSEC(VolIndex)                                              
CXX          write(58,*)'CSI locale ','PIG*TD*TD/4.=',PIG*TD*TD/4.                                             
CX          write(6,*)'CSI locale ','FGSUFS=',FGSUFS,' L0SUD0=',L0SUD0                                             
CX          write(6,*)'CSI locale ','GF=',GF,' CL=',CL,' K1=',K1                                              
C          write(6,*)'CSI locale ','Z1=',Z1,' Z2=',Z2                                           
C          write(6,*)'CSI locale ','CSILOC=',CSILOC                                            
C
            Case (7)
C
C         Sudden expansion
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIE=(1-FS/FG)**2.
              CSILOC=CSIE
            Case (8)
C
C         Sudden contraction
C
C 20 novembre 2007  FS=PIG*TD*TD/4.
              FS=FLOWSEC(VolIndex)
              FG=PIG*GD(VolIndex)*GD(VolIndex)/4.
              CSIC=0.5*(1-FG/FS)**(3./4.)
              CSILOC=CSIC
          End Select
C
C
C
        Case (9)
C
C         Discharge from a tube (channel) onto a baffle
C               Straight wall diffuser at l/D =1.
C
           HdDh=HB(VolIndex)/TD
C
              CALL LINTAB(TABDELTAA,NCDELTAA,TABHdDh,NVHdDh,TABCSI
     $                   ,HdDh,DELTAA(VolIndex),CSI,Z1,Z2)
CX        write(6,*)'CSI locale ','DELTAA=',DELTA(VolIndex)
CX     $           ,'HdDh=',HdDh,'CSI=',CSI                                      
              CSILOC=CSI
C
C
C
        Case (10)
C
C            Flow through spacers (Rehme reference)
C
          GSPEED=ABS(W)/FLOWSEC(VolIndex)
          RE=GSPEED*TD/MU
          RENOR=RE/2000.
CXX         write(6,*)'Rehme GSPEED',GSPEED,'RE=',RE,'TD=',TD,'MU=',MU 
CXX         write(6,*)'RENOR ',RENOR
          IF (RENOR.LT.1.)RENOR=1.5
          CvRehme=C0*((LOG(RENOR))**(1./C1))+(LOG(RENOR)**C2)+C3
C
          CSILOC=CvRehme*(ASpacer(VolIndex)/FLOWSEC(VolIndex))**2.
C
CXX        write(6,*)'RENOR ',RENOR,'CvRehme=',CvRehme
CXX     $           ,'FLOWS=',FLOWS                                    
C
C
        Case (11)
C
C         simmetric turn through 180� in one plane (with pumping)
C
C
C
        Case (101)
C
C         Parallel interstitial flow - Concentric Annulus
CC
          PIPES=SUBCHNUM(VolIndex)*PIG/4.*DIAI(VolIndex)**2.
          RODS=RTNUMB(VolIndex)*PIG/4.*RODDIAM(VolIndex)**2.
          PIPEWP=PIG*DIAI(VolIndex)*SUBCHNUM(VolIndex)
          RODWP=PIG*RODDIAM(VolIndex)*RTNUMB(VolIndex)
          FLOWS=PIPES-RODS
          PB=PIPEWP+RODWP
          EQHYD=4.*FLOWS/PB
C        write(6,*)'RODDIAM(',VolIndex,')',RODDIAM(VolIndex),'TD=',TD
C     $           ,'EQHYD=',EQHYD                                     
C        write(6,*)'PIPES ',PIPES,'RODS=',RODS
C     $           ,'FLOWS=',FLOWS                                    
C
C------ Mass speed
C
          ANSPEED=ABS(W)/FLOWS                                                  
          RE=ANSPEED*EQHYD/MU
          DdD0=RODDIAM(VolIndex)/DIAI(VolIndex)
          CALL LINTAB(TABREYNOLD,NREYNOLD,TABDdD0,NVDdD0,TABK2R
     $                                        ,DdD0,RE,CSI,Z1,Z2)
          CSILOC=CSI
C        write(6,*)'ANSPEED ',ANSPEED,'RE=',RE,'DdD0=',DdD0
C     $           ,'EQHYD=',EQHYD,'CSI=',CSI                                      
C
        Case Default
C                   No local Head loss
C
          CSILOC=0.
CX         write(6,*)'Case default ','CSILOC=',CSILOC                                          
      End Select
CX       write(6,*)'Dopo Select  HLIndex =',HLIndex
C
      RETURN
      END
C
C
C
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      FUNCTION HMP1ISTA05(IFUN)                                             
      COMMON/REGIME/KREGIM                                              
      COMMON/PARPAR/NUL(6),KSTP,ITERT                                   
      LOGICAL KREGIM                                                    
C                                                                       
C------ISTA=0,1                                                         
C                                                                       
      HMP1ISTA05=0                                                          
      IF(KREGIM) HMP1ISTA05=1                                               
      IF((KSTP.EQ.1).AND.(ITERT.EQ.0)) HMP1ISTA05=1                         
      RETURN                                                            
      END                                                               
C
C
C***********************************************************************
C*                                                                     *
C*                                                                     *
C*                                                                     *
C*                                                                     *
C***********************************************************************
C
C
      SUBROUTINE HMP1STAS05(ISTA)                                           
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
      PARAMETER (NCMAX=9,NPMAX=6)
C
      REAL LHTC,FSPEED(NCMAX+1),MU(NCMAX)  
C
      DIMENSION  EHYD(NCMAX),REIN(NCMAX)
C
      COMMON/HMP1PARS05/VU,CF,NCEL,NPAR,NEQ
      COMMON/HMP1TERS05/P(NCMAX+1),WI(NCMAX+1),RO(NCMAX+1)
     $                 ,HILD,HOLD,HDLC,HITI                  
      COMMON/HMP1MEDS05/HM(NCMAX),TW(NPMAX,NCMAX),TL(NCMAX)
     $                 ,TLP(NPMAX,NCMAX),QT(NPMAX,NCMAX)
     $                 ,DRODH(NCMAX),LHTC(NPMAX,NCMAX)
     $                 ,GL(NPMAX,NCMAX)                 
      COMMON/HMP1DATS05/V(NCMAX),HLU(NCMAX),FLOWSEC(NCMAX)      
     $                 ,SUP(NPMAX,NCMAX),CKF(NCMAX),DZ(NCMAX)
     $                  ,HTCS(NCMAX)                           
      COMMON/HMP1LACANES/ FRICF(NCMAX),FFXLD(NCMAX),CSILOC(NCMAX)
     $                   ,CFC(NCMAX),EHYD,MU                                  
C
      COMMON/HMP1BLOCKS/IBLOC1X,IBLOC2X                                              
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0                             
C
      WRITE(6,1001)                                                     
      DO 10 I=1,NCEL                                                    
      G=WI(I)/FLOWSEC(I)                                                    
      FSPEED(I)=G/RO(I)                                                    
      REIN(I)=G*EHYD(I)/MU(I)
      AM=RO(I)*FLOWSEC(I)*HLU(I)                                          
      T=TL(I)-273.16                                                    
      WRITE(6,1002) I,WI(I),HM(I),P(I+1),AM,RO(I),G,T          
   10 CONTINUE                                                          
      DO 20 J=1,NPAR                                                    
      WRITE(6,1003) J,J,J                                               
      DO 20 I=1,NCEL                                                    
      T=TW(J,I)-273.16                                                  
      WRITE(6,1004) I,T,LHTC(J,I),QT(J,I)                             
   20 CONTINUE
C
      FFXLDTOT=0.
      CSILOCTOT=0.
      DARCYTOT=0.
      AVERSPEED=0.
      AVREIN=0.
      DO I=1,NCEL
        SIG2=FLOWSEC(I)*FLOWSEC(I)                                 
        DPDARCY=CFC(I)*WI(I)*ABS(WI(I))/(2.*RO(I)*SIG2)
        WRITE(6,*)                                                      
        WRITE(6,*)                                                      
        WRITE(6,*)' Control volume ',I
        WRITE(6,*)                                                      
        WRITE(6,*)'            Fluid reference speed [m/s] :',FSPEED(I)
        WRITE(6,*)'                     Reinolds number RE :',REIN(I)
        WRITE(6,*)'                Moody friction factor f :',FRICF(I)
        WRITE(6,*)'                                 f(L/D) :',FFXLD(I)
        WRITE(6,*)'      Local pressure drop coefficient K :',CSILOC(I)
        WRITE(6,*)'    Darcy pressure drop [f(L/D)+K]@VV/2 :',DPDARCY
        AVREIN=AVREIN+REIN(I)/FLOAT(NCEL)
        AVERSPEED=AVERSPEED+FSPEED(I)/FLOAT(NCEL)
        FFXLDTOT=FFXLDTOT+FFXLD(I)
        CSILOCTOT=CSILOCTOT+CSILOC(I)
        DARCYTOT=DARCYTOT+DPDARCY
      END DO
C
      WRITE(6,*)                                                      
      WRITE(6,*)' Global values'                                                      
      WRITE(6,*)                                                      
      WRITE(6,*)'              Fluid average speed [m/s] :',AVERSPEED
      WRITE(6,*)'              Average Reinolds number RE:',AVREIN
      WRITE(6,*)'                                 f(L/D) :',FFXLDTOT
      WRITE(6,*)'      Local pressure drop coefficient K :',CSILOCTOT
      WRITE(6,*)'    Darcy pressure drop [f(L/D)+K]@VV/2 :',DARCYTOT
C
      FCTOT=FFXLDTOT+CSILOCTOT
      WRITE(34,1005)IBLOC1X,IBLOC2X,FFXLDTOT,CSILOCTOT,FCTOT,AVERSPEED                                                      
     $              ,AVREIN                                                      
1005  FORMAT('Block ',2A4,5x,'f(L/D)',F12.6,5x,'Form loss coefficient K'
     $       ,F12.6,5x,'f(L/D)+K',F12.6,5x,'Average speed [m/s]',F12.6
     $       ,5x,'Average Reinolds number RE  ',F15.6 )
C
      RETURN                                                            
 1001 FORMAT(//1X,'CELLA',4X,'PORTATA',8X,'ENTALPIA',7X,'PRESSIONE',    
     $       6X,'MASSA TOT.',5X,'DENS.MEDIA',4X,            
     $       'PORT.SPEC.',6X,'TEMPERATURA',4X//)                        
 1002 FORMAT(1X,I3,5X,8(E12.5,3X))                                      
 1003 FORMAT(//1X,'CELLA',4X,'TEMP.PAR.',I2,7X,'COEFF.SCAMBIO',I2,      
     $       3X,'POT. TERM.',I2,7X//)                                   
 1004 FORMAT(1X,I3,5X,8(E12.5,6X))                                      
      END                                                               
C
C
C
      SUBROUTINE HMP1D1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,
     $  XYU,IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C-----SIGNIFICATO DELLE VARIABILI DI USCITA
C     SIGNEQ = Descrizione dell'equazione  (in stazionario) - 50 car.
C     UNITEQ = Unita' di misura del residuo - 10 car.
C     COSNOR = Costante di normalizzazione del residuo in stazionario
C     ITOPVA = Topologia dello jacobiano di regime - matrice di INTEGER
C
C     CAVITA' ARIA LIQUIDO VAPORE
C
      CHARACTER*8 BLOCCO, SYMVAR(*), UNITEQ(*)*10, SIGNEQ(*)*50
      DIMENSION XYU(*), DATI(*), COSNOR(*), ITOPVA(MXT,*)
C
      COMMON /NORM/ P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      RETURN
      END
C
C
C~FORAUS_HMP1~C 
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE HMP1_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]   
C    
C__________ SE VUOI CHE LA SUBROUTINE HMP1_UHTC SIA CHIAMATA DA HMP1
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   HTCS < 0.
C
C  La subroutine fornisce al modulo HMP1 il coefficiente di scambio 
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]          
C   H     entalpia specifica del fluido           [J/kg]        
C   S     entropia specifica del fluido           [J/kg/C] 
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]     
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   HTCS  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato 
C         come si vuole.
C         RICORDATI CHE HTCS E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]   
C   Q     potenza totale scambiata                [W]           
C   SUP   superficie di scambio                   [m**2]        
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE HMP1_UHTC(P,H,S,TF,RO,TP,DIA,HTCS,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_HMP1~C 

