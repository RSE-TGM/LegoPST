C**********************************************************************
C modulo temp.f
C tipo 
C release 1.3
C data 12/18/97
C Puertollano project libut reserver @(#)temp.f	1.3
C**********************************************************************
C
C*********************************************************************
C*                                                                   *
C*                 TEMP: Temperature calculation                     *
C*                                                                   *
C*                                                                   *
C*                  C.I.S.E.      April 5th 1995                     *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
C --------------------------------------------------------------------
C
C Il modulo TEMP simula il funzionamento dello strumento di misura
C della temperatura del fluido di lavoro, costituito da:
C 
C -     Un pozzetto cavo saldato al supporto metallico (Collettore,...)
C
C -     Una termocoppia inserita nel pozzetto ed a contatto con la parte 
C       inferiore di questo attraverso una guaina.
C
C I "Volumi di controllo" utilizzati per la modellazione del fenomeno
C termico sono i seguenti:
C
C -1-   "POZZETTO":
C       E' la parte di pozzetto compresa tra la superficie interna del
C       collettore e l'insieme "guaina/termocoppia".
C       Il "POZZETTO" scambia con il fluido, con il supporto metallico
C       e con la restante parte del pozzetto a contatto con l'insieme 
C       "guaina/termocoppia, mentre e' supposto adiabatico verso il proprio 
C       interno.
C
C -2-   "TERMINALE":
C       E' la parte posta al termine del pozzetto, e quindi a contatto con
C       l'insieme "guaina/termocoppia".
C       Il "TERMINALE" scambia con il fluido, con il "POZZETTO" e con
C       l'insieme "guaina/termocoppia".
C
C -3-   "TERMOCOPPIA":
C       E' costituita dall'insieme "guaina/termocoppia".
C       La "TERMOCOPPIA" scambia con il "TERMINALE".
C
C L'ipotesi semplificativa di maggior significato e' la seguente:
C
C -     La parte di pozzetto inserita e saldata al supporto metallico,
C       non direttamente esposta al flusso termico del fluido di lavoro,
C       viene mantenuta all'equilibrio isotermico dalla parete metallica
C       del collettore.
C  
C --------------------------------------------------------------------
C
C
       SUBROUTINE TEMPI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     1                 IBL1,IBL2,IER,CNXYU,TOL)
C
       DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
       LOGICAL KREGIM
       REAL LUNGTE,LUNGPO
       CHARACTER*4 IBL1,IBL2,NOMMOD,NBLOCK
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
C
       COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
C
       PARAMETER(GAM0=1000.,TYP0=1.,SEC0=100.,FLAG0=1.)
C
C---Temperature 
C
C LUNGPO = Lunghezza Pozzetto
C RINTPO = Raggio interno Pozzetto     
C REXTPO = Raggio esterno Pozzetto
C DENSPO = Densita` del metallo delle pareti del Pozzetto
C CONDPO = Conducibilita` termica del metallo delle pareti del Pozzetto
C CASPPO = Calore specifico del metallo delle pareti del Pozzetto
C LUNGTE = Lunghezza Terminale 
C RINTTE = Raggio interno Terminale
C REXTTE = Raggio esterno Terminale
C DENSTC = Densita` del metallo della termocoppia
C CONDTC = Conducibilita` termica del metallo della termocoppia
C CASPTC = Calore specifico del metallo della termocoppia
C
      GO TO(100,200), IFUN
C
  100 WRITE(14,500)'RINTTE  ','RINTPO  ','REXTTE  ',
     $             'REXTPO  ','LUNGTE  ','LUNGPO  ',
     $             'CONDTC  ','CONDPO  ','CASPTC  ',
     $             'CASPPO  ','DENSTC  ','DENSPO  '
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
C
      RETURN
C
C---Read and storage data
C
 200  CONTINUE
C
       READ(14,507)NOMMOD,NBLOCK
 507  FORMAT(20X,A4,A4)
C
      IF (NOMMOD.NE.IBL1.OR.NBLOCK.NE.IBL2) THEN
         WRITE(6,3000)NOMMOD,NBLOCK
 3000    FORMAT(1X,
     $          '**** ERROR :   The module TEMP reads DATA referred'
     $         ,' to another MODULE or another BLOCK.'
     $          //30X,'CHECK the data section referred to:',
     $          //40X,'Module :  ',A,/40X,'Block  :  ',A)
         IER=1
      ELSE
         READ(14,501) RINTTE, RINTPO, REXTTE, 
     $                REXTPO, LUNGTE, LUNGPO,
     $                CONDTC, CONDPO, CASPTC,
     $                CASPPO, DENSTC, DENSPO
C
 501  FORMAT(3(14X,F10.0,1X))
C
C Caricamento nel vettore DATI() dei parametri dimensionali presenti
C nel file F14.DAT
C
         DATI(ID2)   = RINTTE
         DATI(ID2+1) = RINTPO
         DATI(ID2+2) = REXTTE
         DATI(ID2+3) = REXTPO
         DATI(ID2+4) = LUNGTE
         DATI(ID2+5) = LUNGPO
         DATI(ID2+6) = CONDTC
         DATI(ID2+7) = CONDPO
         DATI(ID2+8) = CASPTC
         DATI(ID2+9) = CASPPO
         DATI(ID2+10)= DENSTC
         DATI(ID2+11)= DENSPO
C
C  Inizializzazione dei dati interni
C
C  Il modulo TEMP fa uso di coefficenti interni utili per la soluzione
C  del sistema di equazioni.
C  Questi vengono memorizzati nel vettore DATI() poiche' e' possibile
C  evitarne il calcolo ad ogni passo di integrazione qualora l'utente
C  non modifichi la tipologia dello strumento di misura selezionato.
C  Questi coefficenti sono in numero di 10 (4 "dimensionali" ed
C  equivalenti a resistenze e capacita' termiche e 6 "adimensionali"
C  necessari per la soluzione implicita del sistema algebrico) e
C  vengono banalmente inizializzati a 0 in questa fase.
C  Altri 2 elementi di DATI() vengono utilizzati per la memorizzazione
C  dei diametri esterni del "TERMINALE" e del "POZZETTO".
C 
         DO K = 12,21,1
            DATI(ID2+K) = 0.
         ENDDO
C
         DATI(ID2+22) = 2*REXTTE
         DATI(ID2+23) = 2*REXTPO
C
C  E' infine necessario memorizzare nel vettore DATI() la tipologia
C  selezionata dall'utente il passo precedente per verificare la
C  eventuale richiesta di cambiamento della stessa.
C  Il valore iniziale assume il significato di "primo passo di
C  integrazione" utile per eseguire il calcolo dei coefficenti
C  indipendentemente dalla modifica della richiesta di tipologia.
C
         DATI(ID2+24) = -1.
C
C
C--- Normalization values  storage
C
         DATI(ID2+25) = GAM0
         DATI(ID2+26) = TYP0
         DATI(ID2+27) = SEC0
         DATI(ID2+28) = FLAG0
C
         ID2 = ID2 + 28    
C
C---  Storage for variables
C
         ID2 = ID2 + 6
C
      ENDIF
C
C
C
C--- Normalization values
C
       CNXYU(IV1  ) = T0
       CNXYU(IV1+1) = T0
       CNXYU(IV1+2) = T0
       CNXYU(IV1+3) = T0
       CNXYU(IV1+4) = GAM0
       CNXYU(IV1+5) = GAM0
       CNXYU(IV1+6) = TYP0
       CNXYU(IV1+7) = P0
       CNXYU(IV1+8) = H0
       CNXYU(IV1+9) = W0
       CNXYU(IV1+10) = SEC0
       CNXYU(IV1+11) = FLAG0
       CNXYU(IV1+12) = T0
C
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TEMPC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
       CHARACTER*100 SccsID
       DATA SccsID/'@(#)temp.f	1.3\t 1.3\t 12/18/97 Puerpro libut'/
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
       DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
C
       LOGICAL KREGIM
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
       COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
       COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
       COMMON/NEQUAZ/NEQMOD
C
C
C---Temperature 
C
       NEQMOD=0
C
C
       GO TO(100,200,300),IFUN
C
C--- Jacobian matrix
C
  100  CONTINUE
       RETURN
C
C--- Remainder computation
C
  200  CALL TEMP(IFUN,IXYU,XYU,IPD,DATI,RNI)
       RETURN
C$*$
  300  CONTINUE
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TEMP(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
       DIMENSION XYU(*),DATI(*),RNI(*)
C
C
       LOGICAL KREGIM
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
       COMMON/INTEGR/TSTOP,TEMPO,DTRE,NPAS,CDT
       COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
       REAL PI
C
C  Dichiarazioni dei PARAMETRI
C
       REAL TFLUIDO,TMISURA,TTERMIN,TPOZZ,COEFTER,COEFPOZ
       REAL DTYP,PFLD,HFLD,WFLD,AREAEQ,TSUPP
       LOGICAL ACTIVE
C
C  Dichiarazioni delle variabili interne
C
      REAL ENTRFL,TITFL,DENSFL,CPFL,VISCFL,CONDFL,VELFL
      REAL RINTTE,RINTPO,REXTTE,REXTPO,LUNGTE,LUNGPO,
     $       CONDTC,CONDPO,CASPTC,CASPPO,DENSTC,DENSPO,
     $       DEXTTE,DEXTPO
      REAL R1,R1H,R2,R2H,R3,R4,R5,C1,C2,C3
      REAL A,B,C,D,E,F,G,H,I,L
      REAL NUM,DEN,DTYPOLD
      REAL TMISURAP,TTERMINP,TPOZZP
      REAL CORRBIRD
      LOGICAL EXPLIC
C
       PARAMETER (PI=3.14159265)
C
       DATA NFL /1/
C
C--- TEMPERATURE 
C   
C--- Remainder computation
C
C--- Variables and data decodification
C
       GAM0  = DATI(IPD+25)
       TYP0  = DATI(IPD+26)
       SEC0  = DATI(IPD+27)
       FLAG0 = DATI(IPD+28)
C
       TFLUIDO = XYU(IXYU   )*T0
       TMISURA = XYU(IXYU+1 )*T0 
       TTERMIN = XYU(IXYU+2 )*T0 
       TPOZZ   = XYU(IXYU+3 )*T0
       COEFTER = XYU(IXYU+4 )*GAM0 
       COEFPOZ = XYU(IXYU+5 )*GAM0 
       DTYP    = XYU(IXYU+6 )*TYP0
       PFLD    = XYU(IXYU+7 )*P0 
       HFLD    = XYU(IXYU+8 )*H0 
       WFLD    = XYU(IXYU+9 )*W0 
       AREAEQ  = XYU(IXYU+10)*SEC0 
C      ACTIVE  = XYU(IXYU+11)*FLAG0
       ACTIVE  = XYU(IXYU+11)*FLAG0.GE.0.99
       TSUPP   = XYU(IXYU+12)*T0 
C
C$*$
C
C--- Remainder computation
C
C
C-- Remainder n.1 (algebric equation)   ******* 
C
C
C-----  Pressure and Enthalpy out of range protection  (beginning)
C
      PTAV=PFLD
      HTAV=HFLD
C
      IF(PTAV.LE.610.8) THEN
        PTAV=610.8
        IF(HTAV.LT.0.) HTAV=0.
        IF(HTAV.GT.4055.11E+03) HTAV=4055.11E+03
      ELSE
        IF(PTAV.GE.400.E+05) THEN
          PTAV=400.E+05
          IF(HTAV.LT.39.7452E+03) HTAV=39.7452E+03
          IF(HTAV.GT.3971.71E+03) HTAV=3971.71E+03
        ELSE
          IF(HTAV.LT.0.) THEN
            STAV=STEV(PTAV,275.16,1.,NFL)
            HTAV=HEV(PTAV,STAV,NFL)
C            HTAV=0.
          ELSE
            STAV=STEV(PTAV,1023.16,1.,NFL)
            HMAX=HEV(PTAV,STAV,NFL)
            IF(HTAV.GT.HMAX) HTAV=HMAX
C            IF(HTAV.GT.3971.71E+03) HTAV=3971.71E+03
          ENDIF
        ENDIF
      ENDIF
C
C-----  Pressure and Enthalpy out of range protection  (end)
C
C
C
      IF ( KREGIM .OR. (.NOT.ACTIVE) ) THEN
C
C Viene banalizzata la soluzione ponendo le 3 temperature di interesse
C TMISURA,TTERMIN e TPOZZ al valore della temperatura fisica del fluido
C TFLUIDO.
C In questo modo si evita di eseguire le chiamate alle tavole del vapore
C necessarie per il calcolo del coefficente di scambio.
C D'altra parte, l'errore che si commette rispetto al calcolo effettivo
C della soluzione di regime e' piccolo, considerando i valori relativi 
C delle resistenze termiche in gioco almeno per fluido in moto.
C
C
         ENTRFL   = SHEV(PTAV,HTAV,NFL)         
         TFLUIDO  = TEV (PTAV,ENTRFL,NFL) - 273.15
         TMISURA  = TFLUIDO
         TTERMIN  = TFLUIDO
         TPOZZ    = TFLUIDO
         COEFTER  = 0.
         COEFPOZ  = 0.
C
      ELSE IF ( (.NOT.KREGIM) .AND. ACTIVE ) THEN
C
C Verifica della tipologia selezionata dall'utente
C
         DTYPOLD = DATI(IPD+24)
C
         IF ( (DTYPOLD.EQ.-1.) .OR. (DTYPOLD.NE.DTYP) ) THEN
C
C Caricamento in DATI() della tipologia selezionata al passo corrente
C
       DATI(IPD+24) = DTYP
C
C Calcolo, in funzione della tipologia selezionata, dei coefficenti
C (a)dimensionali per la soluzione del sistema, e caricamento degli
C stessi nel vettore DATI()
C
C Assegnamento dei parametri dimensionali.
C "Per default" vengono assegnati i parametri assegnati dall'utente
C nel file F14.DAT e memorizzati nel vettore DATI():
C
       RINTTE = DATI(IPD)
       RINTPO = DATI(IPD+1)
       REXTTE = DATI(IPD+2)
       REXTPO = DATI(IPD+3)
       LUNGTE = DATI(IPD+4)
       LUNGPO = DATI(IPD+5)
       CONDTC = DATI(IPD+6)
       CONDPO = DATI(IPD+7)
       CASPTC = DATI(IPD+8)
       CASPPO = DATI(IPD+9)
       DENSTC = DATI(IPD+10)
       DENSPO = DATI(IPD+11)
C
       IF (DTYP.EQ.1.) THEN
C
C Strumento di misura di tipo 1:
C --------------------------------------------------------
C " Pozzetto tipo III / tipo IA  +  Termocoppia standard "
C --------------------------------------------------------
C
        RINTTE = 0.003
        RINTPO = 0.005
        REXTTE = 0.0095
        REXTPO = 0.01075
        LUNGTE = 0.035
        LUNGPO = 0.1
        CONDTC = 1.
        CONDPO = 39.1
        CASPTC = 1140.
        CASPPO = 597.
        DENSTC = 3650.
        DENSPO = 7900.
C
       ELSE IF (DTYP.EQ.2.) THEN
C
C Strumento di misura di tipo 2:
C ---------------------------------------------------------------
C " Pozzetto tipo II (Impiego normale)  +  Termocoppia standard "
C ---------------------------------------------------------------
C
        RINTTE = 0.003
        RINTPO = 0.005
        REXTTE = 0.0135
        REXTPO = 0.01475
        LUNGTE = 0.035
        LUNGPO = 0.1
        CONDTC = 1.
        CONDPO = 39.1
        CASPTC = 1140.
        CASPPO = 597.
        DENSTC = 3650.
        DENSPO = 7900.
C
       ELSE IF (DTYP.EQ.3.) THEN
C
C Strumento di misura di tipo 3:
C --------------------------------------------------------------
C " Pozzetto tipo IIC (Risposta rapida)  +  Termocoppia rapida "
C --------------------------------------------------------------
C
        RINTTE = 0.00175
        RINTPO = 0.00325
        REXTTE = 0.00525
        REXTPO = 0.010625
        LUNGTE = 0.035
        LUNGPO = 0.1
        CONDTC = 1.
        CONDPO = 39.1
        CASPTC = 1140.
        CASPPO = 597.
        DENSTC = 3650.
        DENSPO = 7900.
C
       ENDIF           
C
       DEXTTE = REXTTE*2
       DEXTPO = REXTPO*2
C
C Calcolo dei dati modellistici (RESISTENZE E CAPACITA' TERMICHE)
C
       R1 = ALOG(REXTTE*SQRT(2.)/
     $                    SQRT(REXTTE**2+(0.7289*RINTTE)**2))/
     $               (2*PI*LUNGTE*CONDPO)
C
       R2 = ALOG(REXTPO*SQRT(2.)/
     $                    SQRT(REXTPO**2+RINTPO**2))/
     $               (2*PI*LUNGPO*CONDPO)
C
       R3 = ALOG(SQRT(REXTTE**2+(0.7289*RINTTE)**2)/
     $                    (0.7289*RINTTE*SQRT(2.)))/
     $               (2*PI*LUNGTE*CONDPO) +
     $               ALOG(SQRT(2.))/(2*PI*LUNGTE*CONDTC)
C
       R4 = (LUNGTE/2)/(PI*(REXTTE**2-(0.7289*RINTTE)**2)*
     $                          CONDPO) +
     $               (LUNGPO/2)/(PI*(REXTPO**2-RINTPO**2)*CONDPO)
C
       R5 = (LUNGPO/2)/(PI*(REXTPO**2-RINTPO**2)*CONDPO)
C
       C1 = DENSPO*CASPPO*PI*(REXTPO**2-RINTPO**2)*LUNGPO
C
       C2 = DENSTC*CASPTC*PI*((0.7289*RINTTE)**2)*LUNGTE
C
       C3 = DENSPO*CASPPO*PI*(REXTTE**2-(0.7289*RINTTE)**2)
     $               *LUNGTE
C
C Calcolo dei coefficenti del sistema di equazioni algebrico (soluzione
C implicita del sistema differenziale lineare del terzo ordine) 
C indipendenti dal coefficente di scambio convettivo
C
       A = -1 / (C2*R3)
       B =  1 / (C2*R3)
       C =  1 / (C3*R3)
       E =  1 / (C3*R4)
       G =  1 / (C1*R4)
       L =  1 / (C1*R5)
C
C Caricamento nel vettore DATI() dei coefficenti adimensionali
C calcolati e dei dati modellistici (RESISTENZE E CAPACITA' TERMICHE)
C necessari al calcolo dei coefficenti adimensionali dipendenti dal
C coefficente di scambio convettivo
C
       DATI(IPD+12) = A
       DATI(IPD+13) = B
       DATI(IPD+14) = C
       DATI(IPD+15) = E
       DATI(IPD+16) = G
       DATI(IPD+17) = L
       DATI(IPD+18) = R1
       DATI(IPD+19) = R2
       DATI(IPD+20) = C1
       DATI(IPD+21) = C2
       DATI(IPD+22) = DEXTTE
       DATI(IPD+23) = DEXTPO
C
         ELSE
C
C La tipologia selezionata non e' cambiata rispetto al passo di tempo
C precedente.
C Prelievo dal vettore DATI() dei 10 coefficenti (a)dimensionali utili
C per la soluzione del sistema
C
       A  = DATI(IPD+12)
       B  = DATI(IPD+13)
       C  = DATI(IPD+14)
       E  = DATI(IPD+15)
       G  = DATI(IPD+16)
       L  = DATI(IPD+17)
       R1 = DATI(IPD+18)
       R2 = DATI(IPD+19)
       C1 = DATI(IPD+20)
       C2 = DATI(IPD+21)
       DEXTTE = DATI(IPD+22)
       DEXTPO = DATI(IPD+23)
C
         ENDIF
C
C Soluzione del sistema dinamico in 3 stati
C -----------------------------------------
C
C Calcolo del valore fisico della temperatura del fluido
C
         ENTRFL  = SHEV(PTAV,HTAV,NFL)          
         TFLUIDO = TEV (PTAV,ENTRFL,NFL) - 273.15
C
C Calcolo delle proprieta' termodinamiche del fluido di lavoro
C
         TITFL = YEV(PTAV,ENTRFL,NFL)
C
         IF (TITFL.LE.0.) THEN
C
C          Termocoppia in acqua:
C          Analizzando le varie condizioni del fluido di lavoro
C          nell'impianto termoelettrico, vengono assunti i seguenti
C          valori costanti dei coefficenti termodinamici [m.k.s.].
C
       DENSFL = 900.
       CPFL   = 4374.
       VISCFL = 1.75E-4
       CONDFL = 0.6755
C
         ELSE IF (TITFL.GE.1.) THEN
C
C          Termocoppia in vapore:
C          valori dei coefficenti termodinamici [m.k.s.].
C
       DENSFL = ROEV(PTAV,ENTRFL,NFL)
       CPFL   = CPEV(PTAV,ENTRFL,TITFL,0.57,NFL)
       VISCFL = 2.72E-5
       CALL SATUR (PTAV,3,ROAS,ROVS,NFL)
       CONDFL = ALEV(PTAV,TFLUIDO+273.15,DENSFL,
     $                        ROAS/ROVS,TITFL,0.57,NFL)
C
         ELSE IF ( (TITFL.GT.0.) .AND. (TITFL.LT.1.) ) THEN
C
C          Termocoppia in fluido bifase:
C          valori dei coefficenti termodinamici [m.k.s.].
C
       DENSFL = ROEV(PTAV,ENTRFL,NFL)
       CPFL   = CPEV(PTAV,ENTRFL,TITFL,0.57,NFL)
       CALL SATUR (PTAV,3,ROAS,ROVS,NFL)
       VISCFL = ETEV(PTAV,TFLUIDO+273.15,DENSFL,
     $                        ROAS/ROVS,TITFL,0.57,NFL)
       CONDFL = ALEV(PTAV,TFLUIDO+273.15,DENSFL,
     $                        ROAS/ROVS,TITFL,0.57,NFL)
C
         ENDIF
C
C Calcolo della velocita' del fluido di lavoro
C
      IF(AREAEQ.GT.1.E-5) THEN
        VELFL = ABS ( WFLD / (DENSFL*AREAEQ) )
      ELSE
        VELFL = 2.
      ENDIF
C
C Calcolo dei coefficenti di scambio convettivo secondo la correlazione
C empirica valida per la geometria in esame proposta da:
C "TRANSPORT PHENOMENA" - Bird, Stewart, Lightfoot.
C
         COEFTER = DENSFL**(0.5)   * CPFL**(0.333) * VISCFL**(-0.1666) *
     $               CONDFL**(0.666) * 0.5662 *
     $               DEXTTE**(-0.5)  * VELFL**(0.5)
C   
         COEFPOZ = DENSFL**(0.5)   * CPFL**(0.333) * VISCFL**(-0.1666) *
     $               CONDFL**(0.666) * 0.5662 *
     $               DEXTPO**(-0.5)  * VELFL**(0.5)
C
C Correzione dei valori dei coefficenti di scambio convettivo secondo
C un termine proporzionale tarato in base alle prove empiriche eseguite
C sulle tremocoppie standard ENEL con pozzetto tipo III:
C "Costante di Tempo" = 12 sec con acqua ad 1 m/sec.
C
         CORRBIRD = 0.4
         COEFTER = COEFTER * CORRBIRD
         COEFPOZ = COEFPOZ * CORRBIRD 
C
         COEFTER = AMAX1(COEFTER,100.)
         COEFPOZ = AMAX1(COEFPOZ,100.)
C   
C Calcolo delle "RESISTENZE CONVETTIVE"
C
         R1H = 1 / (COEFTER * PI * DEXTTE * LUNGTE)      
         R2H = 1 / (COEFPOZ * PI * DEXTPO * LUNGPO)
C
C Calcolo dei coefficenti adimensionali dipendenti dai coefficenti
C di scambio convettivo
C
         F = 1 / (C3*(R1+R1H))           
         I = 1 / (C1*(R2+R2H))
         D = - (F + C + E)
         H = - (I + G + L)
C
         EXPLIC = .TRUE.
C
         IF (EXPLIC) THEN
C
C Soluzione esplicita del sistema algebrico in 3 stati.
C
       TSUPP    = TSUPP - 273.15
       TTERMINP = TTERMIN
       TMISURAP = TMISURA
       TPOZZP   = TPOZZ
C
       TMISURA = (DTRE*A+1)*TMISURAP + DTRE*B*TTERMINP
       TTERMIN = DTRE*C*TMISURAP + (DTRE*D+1)*TTERMINP +
     $                    DTRE*E*TPOZZP + DTRE*F*TFLUIDO
       TPOZZ   = DTRE*G*TTERMINP + (DTRE*H+1)*TPOZZP +
     $                    DTRE*I*TFLUIDO + DTRE*L*TSUPP
C
         ELSE IF (.NOT.EXPLIC) THEN
C
C Soluzione implicita del sistema algebrico in 3 stati.
C
       TSUPP    = TSUPP - 273.15
       TTERMINP = TTERMIN
       TMISURAP = TMISURA
       TPOZZP   = TPOZZ
C
       NUM = TMISURAP * (DTRE*C)   * (1-DTRE*H) +
     $                TTERMINP * (1-DTRE*A) * (1-DTRE*H) +
     $                TPOZZP   * (DTRE*E)   * (1-DTRE*A) +
     $                TFLUIDO  * ( (DTRE**2)*E*I*(1-DTRE*A) +
     $                             DTRE*F*(1-DTRE*A)*(1-DTRE*H) ) +
     $                TSUPP    * (DTRE**2)*E*L*(1-DTRE*A)
C
       DEN = (1-DTRE*A)*(1-DTRE*H)-(DTRE**2)*B*C*(1-DTRE*H) -
     $                 DTRE*D*(1-DTRE*A)*(1-DTRE*H) -
     $                 (DTRE**2)*E*G*(1-DTRE*A)
C
       TTERMIN = NUM / DEN
C
       TPOZZ   = (DTRE*G*TTERMIN + DTRE*I*TFLUIDO +
     $                     DTRE*L*TSUPP + TPOZZP) / (1-DTRE*H)
C
       TMISURA = (DTRE*B*TTERMIN + TMISURAP) / (1-DTRE*A)
C
         ENDIF
C
      ENDIF
C
C
C
       IF (KREGIM) THEN
          IF(ITERT.EQ.-1)THEN
            XYU(IXYU   )=(TFLUIDO+273.15)/T0
            XYU(IXYU+1 )=TMISURA/T0 
            XYU(IXYU+2 )=TTERMIN/T0 
            XYU(IXYU+3 )=TPOZZ/T0
            XYU(IXYU+4 )=COEFTER/GAM0 
            XYU(IXYU+5 )=COEFPOZ/GAM0 
            DATI(IPD+28+1)=(TFLUIDO+273.15)/T0
            DATI(IPD+28+2)=TMISURA/T0
            DATI(IPD+28+3)=TTERMIN/T0
            DATI(IPD+28+4)=TPOZZ/T0
            DATI(IPD+28+5)=COEFTER/GAM0
            DATI(IPD+28+6)=COEFPOZ/GAM0
          ELSE
            RETURN
          ENDIF
       ELSE
          IF(ITERT.EQ.0)THEN
            DATI(IPD+28+1)=(TFLUIDO+273.15)/T0
            DATI(IPD+28+2)=TMISURA/T0
            DATI(IPD+28+3)=TTERMIN/T0
            DATI(IPD+28+4)=TPOZZ/T0
            DATI(IPD+28+5)=COEFTER/GAM0
            DATI(IPD+28+6)=COEFPOZ/GAM0
            RNI(1 )=DATI(IPD+28+1)
            RNI(2 )=DATI(IPD+28+2)
            RNI(3 )=DATI(IPD+28+3)
            RNI(4 )=DATI(IPD+28+4)
            RNI(5 )=DATI(IPD+28+5)
            RNI(6 )=DATI(IPD+28+6)
          ELSE
            RNI(1 )=DATI(IPD+28+1)
            RNI(2 )=DATI(IPD+28+2)
            RNI(3 )=DATI(IPD+28+3)
            RNI(4 )=DATI(IPD+28+4)
            RNI(5 )=DATI(IPD+28+5)
            RNI(6 )=DATI(IPD+28+6)
          ENDIF
       ENDIF
C
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TEMPI3(IFO,IOB,DEBL)
C
       COMMON/TEMP00/IBLOC,NCEL,NPAR
       CHARACTER*80 DEBL
       CHARACTER*8 IBLOC
       CHARACTER*4 IOB
       CHARACTER*4 MOD
       DATA MOD/'TEMP'/
C
       CALL TEMPI4(IOB,MOD)
       NSTATI = 0
       NUSCIT = 6
       NINGRE = 7
       WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999  FORMAT(A,2X,'BL.-',A4,'- **** REGOL. ',A4,' - ',A)
C
C
C ------------------------------------------------------------------
C                             USCITE DEL MODULO
C ------------------------------------------------------------------
C
C       TFLUIDO :       Temperatura modellistica del fluido di lavoro
C       TMISURA :       Temperatura della "TERMOCOPPIA"
C       TTERMIN :       Temperatura del "TERMINALE"
C       TPOZZ   :       Temperatura del "POZZETTO"
C       COEFTER :       Coeffiente di scambio "FLUIDO/TERMINALE"
C       COEFPOZ :       Coeffiente di scambio "FLUIDO/POZZETTO"
C
C ------------------------------------------------------------------
C
       WRITE(IFO,3001)IOB
 3001  FORMAT('TFLD',A4,2X,
     $'--UA--     FLUID TEMPERATURE [K]                         ')
       WRITE(IFO,3002)IOB
 3002  FORMAT('XFMT',A4,2X,
     $'--UA--     FLUID MEASURED TEMPERATURE [C]                ')
       WRITE(IFO,3003)IOB
 3003  FORMAT('XWTL',A4,2X,
     $'--UA--     THERMOCOUPLE WELL TEMPERATURE [C] -LOWER SECT.')
       WRITE(IFO,3004)IOB
 3004  FORMAT('XWTU',A4,2X,
     $'--UA--     THERMOCOUPLE WELL TEMPERATURE [C] -UPPER SECT.')
       WRITE(IFO,3005)IOB
 3005  FORMAT('GTER',A4,2X,
     $'--UA--     WELL THER. EXCH. COEFF. [W/sqm s] -LOWER SECT.')
       WRITE(IFO,3006)IOB
 3006  FORMAT('GPOZ',A4,2X,
     $'--UA--     WELL THER. EXCH. COEFF. [W/sqm s] -UPPER SECT.')
C --------------------------------------------------------------
C                             INGRESSI DEL MODULO
C --------------------------------------------------------------
C
C       ITYP    :       Tipologia dello strumento
C                       0 --->  Dati geometrici dal file F14.DAT
C                       1 --->  Pozzetto III / IA + TC standard
C                       2 --->  Pozzetto II       + TC standard
C                       3 --->  Pozzetto IIC      + TC rapida
C       PFLD   :       Pressione del fluido di lavoro
C       HFLD     :       Entalpia del fluido di lavoro
C       WFLD    :       Portata del fluido di lavoro
C       AREAEQ  :       Area equivalente del collettore
C       ACTIVE  :       Flag di attivazione
C       TSUPP   :       Temperatura del supporto metallico
C
C --------------------------------------------------------------
C
C
       WRITE(IFO,3007)IOB
 3007  FORMAT('ITYP',A4,2X,
     $'--IN--     DEVICE TYPE                                   ')
       WRITE(IFO,3008)IOB
 3008  FORMAT('PFLD',A4,2X,
     $'--IN--     FLUID PRESSURE [Pa]                           ')
       WRITE(IFO,3009)IOB
 3009  FORMAT('HFLD',A4,2X,
     $'--IN--     FLUID ENTHALPY [J/kg K]                       ')
       WRITE(IFO,3010)IOB
 3010  FORMAT('WFLD',A4,2X,
     $'--IN--     FLUID MASS FLOW [kg/s]                        ')
       WRITE(IFO,3011)IOB
 3011  FORMAT('ESEC',A4,2X,
     $'--IN--     EQUIVALENT FLUID CROSS-SECTION [sqm]          ')
       WRITE(IFO,3012)IOB
 3012  FORMAT('AFLG',A4,2X,
     $'--IN--     ACTIVATION FLAG [-]                           ')
       WRITE(IFO,3013)IOB
 3013  FORMAT('TSUP',A4,2X,
     $'--IN--     THERMOCOUPLE STAND TEMPERATURE [K]            ')
      RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TEMPI4(IOB,MOD)
       COMMON/TEMP00/IBLOC,NCEL,NPAR
       CHARACTER*8 IBLOC
       CHARACTER*4 IOB
       CHARACTER*4 MOD
C
C
       WRITE(IBLOC,1000)MOD,IOB
 1000  FORMAT(2A4)
C
       RETURN
       END
CC
      SUBROUTINE TEMPD1(BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,IX
     $YU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
      RETURN
      END
