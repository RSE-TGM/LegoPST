C                                                                       
C                                                                       
C*************************** T_H_LEAD ************************************
C                                                                       
C    HLEAD = Liquid Lead specific enthalpy [J/kg]                                                                   
C    T_H_LEAD = Liquid Lead Temperature    [K�]                                                                
C                                                                       
C
C    Range [64.5 kJ/kg - 494.3 kJ/kg]
C
C    Reference:
C                                                    
C    L. V. Gurvich et al., 
C    'Thermodynamic Properties of Individual Substances'
C     Fourth Edition, Volume 2 Parts 1 and 2, Hemisphere Pub. Corp. N.Y. (1991).
C   
C     Inverted function via linear regression
C     
C*************************** T_H_LEAD ************************************
C                                                                       
      REAL FUNCTION T_H_LEAD(HLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION T_H_LEAD(HLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
      REAL HLEAD,HLEAD0,A,B,C,D,E,F                                !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
      DATA HLEAD0 /200000./,A/19.6633555/,B/-152.465621/,C/362.497308/
      DATA                  D/1101.25492/,E/-7.23610022/,F/235.141821/
C
      X=HLEAD/HLEAD0
C
      T_H_LEAD=A*X**4.+B*X**3.+C*X**2.+D*X+E/X+F
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C*************************** RO_T_LEAD ************************************
C                                                                       
C    TLEAD = Liquid Lead Temperature         [K�]                                                                
C    TLEADM = Lead melting point Temperature [K�]                                                                  
C    RO_T_LEAD= Liquid Lead density          [kg/m3]
C
C    Range [601 K� - 1823 K�]
C
C
C
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C                                                                       
C*************************** RO_T_LEAD ************************************
C                                                                       
      REAL FUNCTION RO_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION RO_T_LEAD(TLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
      REAL TLEAD,TLEADM,A,B,C                                      !SNGL
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
      DATA TLEADM /600.65/,A/8.6E-08/,B/-12.46E-04/,C/10.661/
C
      X=TLEAD-TLEADM
C
      RO_T_LEAD=1.E+03*(A*X*X+B*X+C)
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C*************************** DRODH_LEAD ************************************
C                                                                       
C    HLEAD = Liquid Lead specific enthalpy   [J/kg]                                                                   
C    T_H_LEAD = Liquid Lead Temperature      [K�]                                                                
C    TLEAD = Liquid Lead Temperature         [K�]                                                                
C    TLEADM = Lead melting point Temperature [K�]                                                                  
C    RO_T_LEAD= Liquid Lead density          [kg/m3]
C
C    Range [873.16 K� - 1673.16 K�]                                                     
C                                                                       
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C                                          
C    Ro(T) = 11.44E+03 - 1.35*T + 8.6E-5*T*T     [kg/m3]
C
C    T(h)  =  T_H_LEAD
C
C    dRo(T(h))   dRo(T)   dT
C    --------- = ------ * --
C       dh         dT     dh
C
C                                                                       
C*************************** DRODH_LEAD ************************************
C                                                                       
      REAL FUNCTION DRODH_LEAD(HLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION DRODH_LEAD(HLEAD)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
      DATA HLEAD0 /200000./,A/19.6633555/,B/-152.465621/,C/362.497308/
      DATA                  D/1101.25492/,E/-7.23610022/,F/235.141821/
      DATA A0/- 1.35/,B0/8.6E-5/
C
      X=HLEAD/HLEAD0
      TLEAD=A*X**4.+B*X**3.+C*X**2.+D*X+E/X+F
C
      DRODT=A0+B0*TLEAD
C
      DTDH=(4.*A*X*X*X+3.*B*X*X+2.*C*X+D-E/(X*X))/HLEAD0
C
      DRODH_LEAD=DRODT*DTDH
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** DRODT_LEAD ************************************
C                                                                       
C    HLEAD = Liquid Lead specific enthalpy   [J/kg]                                                                   
C    T_H_LEAD = Liquid Lead Temperature      [K�]                                                                
C    TLEAD = Liquid Lead Temperature         [K�]                                                                
C    TLEADM = Lead melting point Temperature [K�]                                                                  
C    RO_T_LEAD= Liquid Lead density          [kg/m3]
C
C    Range [601 K� - 1823 K�]
C                                                                       
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C                                          
C    Ro(T) = 10.661E+03 - 1.246*(T-TLEADM) + 8.6E-5*(T-TLEADM)*(T-TLEADM)  [kg/m3]
C
C
C                                                                       
C*************************** DRODT_LEAD ************************************
C                                                                       
      REAL FUNCTION DRODT_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION DRODT_LEAD(TLEAD)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
      DATA TLEADM /600.65/,A/8.6E-05/,B/-12.46E-01/,C/10.661E+03/
C
      X=TLEAD-TLEADM
C
      DRODT_LEAD=2.*A*X+B
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** H_T_LEAD ************************************
C                                                                       
C    TLEAD     = Liquid Lead Temperature   [K�]                                                                    
C    H_T_LEAD  = Liquid Lead enthalpy      [J/kg]                                                                
C    AW        = Lead atomic weight        [g/mol]
C
C     TLEAD < 600.65 K� - Solid phase
C     TLEAD > 600.65 K� - Liquid phase
C
C
C    Reference:
C                                                    
C    L. V. Gurvich et al., 
C    'Thermodynamic Properties of Individual Substances'
C     Fourth Edition, Volume 2 Parts 1 and 2, Hemisphere Pub. Corp. N.Y. (1991).
C     
C                                                                       
C*************************** H_T_LEAD ************************************
C                                                                       
      REAL FUNCTION H_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION CP_T_LEAD(TLEAD)                  !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
C
C     AW = Lead atomic weight  [g/mol]
C
C     TLEAD < 600.65 K� - Solid phase
C     TLEAD > 600.65 K� - Liquid phase
C     
C
      REAL AW,A,B,C
C
      DATA AW /207.2/, A0 /24.489/, B0 /4.477E-03/, C0 /4.52E+04/
      DATA D0 /7850.973/
      DATA A/36.287/,B/5.14E-03/,C/3.158E+05/,D/1.371E-06/,E/1.0875E-10/
      DATA F /7389.27/
C
C
      IF (TLEAD.LT.600.65) THEN
        H_T_LEAD=1.E+03*(A0*TLEAD+B0*TLEAD**2.+C0/TLEAD-D0)/AW
      ELSE
        H_T_LEAD=1.E+03*(A*TLEAD-B*TLEAD**2.+C/TLEAD+D*TLEAD**3.
     $                  -E*TLEAD**4.-F)/AW
      END IF
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** CP_T_LEAD ************************************
C                                                                       
C    TLEAD     = Liquid Lead Temperature   [K�]                                                                    
C    CP_T_LEAD = Liquid Lead Heat Capacity [J/(kg�K�)]                                                                
C    AW        = Lead atomic weight        [kg/mol]
C
C     TLEAD < 600.65 K� - Solid phase
C     TLEAD > 600.65 K� - Liquid phase
C
C
C    Reference:
C                                                    
C    L. V. Gurvich et al., 
C    'Thermodynamic Properties of Individual Substances'
C     Fourth Edition, Volume 2 Parts 1 and 2, Hemisphere Pub. Corp. N.Y. (1991).
C     
C                                                                       
C*************************** CP_T_LEAD ************************************
C                                                                       
      REAL FUNCTION CP_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION CP_T_LEAD(TLEAD)                  !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
C
C     AW = Lead atomic weight  [kg/mol]
C
C     TLEAD < 600.65 K� - Solid phase
C     TLEAD > 600.65 K� - Liquid phase
C     
C
      REAL AW,A,B,C
C
      DATA AW /207.2E-03/,A0/24.489/,B0/8.954E-03/,C0/4.52E+04/
      DATA A/36.287/,B/10.28E-03/,C/3.158E+05/,D/4.113E-06/,E/4.35E-10/
C
C
      IF (TLEAD.LT.600.65) THEN
        CP_T_LEAD=(A0+B0*TLEAD-C0/TLEAD**2.)/AW
      ELSE
        CP_T_LEAD=(A-B*TLEAD-C/TLEAD**2.+D*TLEAD**2.-E*TLEAD**3.)/AW
      END IF
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** TC_H_LEAD ************************************
C                                                                       
C    HLEAD     = Liquid Lead specific enthalpy    [J/kg]                                                                   
C    TLEAD     = Liquid Lead Temperature          [K�]                                                                    
C    TLEADM    = Lead melting point Temperature   [K�]                                                                  
C    TC_H_LEAD = Liquid Lead Thermal Conductivity [W/(m�K�)]                                                                
C                                                                       
C    Range [600.65 �K - 1325 �K]
C
C
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C
C*************************** TC_H_LEAD ************************************
C                                                                       
      REAL FUNCTION TC_H_LEAD(HLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION T_H_LEAD(HLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
      REAL HLEAD,A,B                                               !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
      DATA TLEADM /600.65/,A/15./,B/0.75E-02/
C
      TLEAD=T_H_LEAD(HLEAD)
C
      TC_H_LEAD=A+B*(TLEAD-TLEADM)
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** TC_T_LEAD ************************************
C                                                                       
C    TLEAD     = Liquid Lead Temperature          [�K]                                                                    
C    TLEADM    = Lead melting point Temperature   [�K]                                                                  
C    TC_H_LEAD = Liquid Lead Thermal Conductivity [W/(m��K)]                                                                
C                                                                       
C    Range [600.65 �K - 1325 �K]
C
C
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C
C*************************** TC_T_LEAD ************************************
C                                                                       
      REAL FUNCTION TC_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION T_T_LEAD(TLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      REAL HLEAD,HLEAD0,A,B,C                                      !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
      DATA TLEADM /600.65/,A/15./,B/0.75E-02/
C
      TC_T_LEAD=A+B*(TLEAD-TLEADM)
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C*************************** MU_T_LEAD ************************************
C                                                                       
C    TLEAD    = Liquid lead temperature                     [�K]                                                                
C    MU_T_LEAD= Liquid lead dynamic viscosity               [Pa*s]
C    Q        = apparent activation energy for viscous flow [J/mol]
C    R        = Gas Molar Constant                          [J/(mol*K�)]
C
C    Range [601 K� - 1400 K�]
C
C
C
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C                                                                       
C*************************** MU_T_LEAD ************************************
C                                                                       
      REAL FUNCTION MU_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION MU_T_LEAD(TLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
      REAL TLEAD,A,Q,R                                             !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
      DATA A/0.412E-03/,Q/9.71E+03/,R/8.31451/
C
      MU_T_LEAD=A*EXP(Q/(R*TLEAD))
C
      RETURN                                                            
      END                                                               
C-----------------------------------------------------------------------
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C*************************** BETAP_T_LEAD ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature    [K]                                                                
C    BETAP_T_LBE = Liquid LBE Thermal expansion coefficient [1/K]
C
C    Range [400 K - 1300 K]  Estmated error 0.8%
C
C    Bp=-(1/Ro)(dRo/dT) - (isobaric)
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** BETAP_T_LBE ************************************
C                                                                       
      REAL FUNCTION BETAP_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION BETAP_T_LEAD(TLEAD)               !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
C---da modificare      IF (TLBE.GT.8000.)THEN
C      
C---da modificare        write(6,*)' Warning --------------------------------'
C---da modificare        write(6,*)' '
C---da modificare        write(6,*)' Warning Temperature =',TLBE,' > 8000. K'
C---da modificare        write(6,*)' '
C---da modificare        write(6,*)' Warning Thermal expansion coefficient Bp'
C---da modificare        write(6,*)' '
C---da modificare        write(6,*)'         limited to Bp(8000.K)'
C
C---da modificare        BETAP_T_LBE = 1./(8383.2-8000.)
C---da modificare      ELSE
C---da modificare        BETAP_T_LBE = 1./(8383.2-TLBE)
C---da modificare      END IF
C
      write(6,*)' attenzione function BETAP_T_LEAD non definita '
      RETURN                                                            
      END                                                               
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C*************************** UQ_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature [K]                                                                
C    UQ_T_LBE = Liquid LBE square of the sound velocity Uq  [m2/s2]
C    U        = Liquid LBE sound velocity                [m/s]
C
C    Range [400 K - 1300 K]  Estmated error ?
C
C    Uq=1/(dRo/dP) - (isoentropic)
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** UQ_T_LBE ************************************
C                                                                       
      REAL FUNCTION UQ_T_LEAD(TLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION UQ_T_LEAD(TLEAD)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
C---da modificare       IF (TLBE.GT.1300.)THEN
C---da modificare         write(6,*)' Warning --------------------------------'
C---da modificare         write(6,*)' '
C---da modificare         write(6,*)' Warning Temperature =',TLBE,' > 1300. K'
C---da modificare        write(6,*)' '
C---da modificare       END IF
C
C---da modificare       U=1773.+0.1049*TLBE-2.873E-04*TLBE*TLBE
C
C---da modificare       UQ_T_LBE = U*U
C
      write(6,*)' attenzione function UQ_T_LEAD non definita '
      RETURN                                                            
      END                                                               


