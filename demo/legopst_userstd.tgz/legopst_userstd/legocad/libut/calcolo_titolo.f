C*********************************************************************
C*                                                                   *
C*                 TITL: Calcolo titolo in vapore                    *
C*                                                                   *
C*                                                                   *
C*             Modulo di regolazione rivisto da Pagani               *
C*                                                                   *
C*             secondo le direttive di Spelta (1/6/94)               *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TITLI2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     1                 IBL1,IBL2,IER,CNXYU,TOL)
C
       DIMENSION VAR(MX1,1),XYU(1),DATI(1),CNXYU(1),TOL(1)
C
       LOGICAL KREGIM
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
C
       COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
C

C
C---TITOLO 
C
       GO TO(100,200), IFUN
C
  100  RETURN
C
C---lettura e memorizzazione dati
C
  200  READ(14,501)
C
  500  FORMAT(3(4X,A8,' =',10X,'*'))
  501  FORMAT(3(14X,F10.0,1X))
C
C
C---costanti di normalizzazione
C
       CNXYU(IV1  ) = 1
       CNXYU(IV1+1) = P0
       CNXYU(IV1+2) = H0
C
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TITLC1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
       DIMENSION AJAC(MX5,1),XYU(1),DATI(1),RNI(1)
C
C
       LOGICAL KREGIM
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
       COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
       COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
       COMMON/NEQUAZ/NEQMOD
C
C
C---TITOLO 
C
       NEQMOD=0
C
C
       GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100  CONTINUE
       RETURN
C
C---calcolo residui
C
  200  CALL TITL(IFUN,IXYU,XYU,IPD,DATI,RNI)
       RETURN
C$*$
  300  CONTINUE
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TITL(IFUN,IXYU,XYU,IPD,DATI,RNI)
C
       DIMENSION XYU(1),DATI(1),RNI(1)
C
C
       LOGICAL KREGIM
       COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
       COMMON/REGIME/KREGIM
       COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT
       COMMON/PARPAR/NPER,NVPLT,NVSTP,NSTPLT,NSTSTP,KPLT,KSTP,ITERT
C
       REAL  ATIT,PRES,HENT,TITOLO
C
C
C---TITOLO 
C   calcolo residui
C
C---decodifica variabili e dati
C
       ATIT     = XYU(IXYU   ) 
       PRES     = XYU(IXYU+1 )*P0 
       HENT     = XYU(IXYU+2 )*H0 
C
C$*$
C
C---calcolo residui
C
C
C--residuo n.1 (equazione algebrica)   ******* 
C
C$$$$$$-------------  CASAM  3 Novembre 1994 -----------
C
C-----  Protezione per pressioni ed entalpie fuori range
C
        PTAV=P
        IF(PTAV.LT.610.8) THEN
          PTAV=610.8
        ELSE IF(PTAV.GT.221.2E+05) THEN
          PTAV=221.2E+05
        ENDIF
C
C       CALL SATUR(PRES, 2, HL, HV, 1)
       CALL SATUR(PTAV, 2, HL, HV, 1)
C
C$$$$$$------  CASAM  3 Novembre  1994 ----------- FINE
C
       TITOLO = (HENT-HL)/(HV-HL)
       IF (KREGIM) THEN
          XYU(IXYU) = TITOLO
       ELSE
          RNI(1) = TITOLO
       ENDIF
C
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TITLI3(IFO,IOB,DEBL)
C
       COMMON/TITL00/IBLOC,NCEL,NPAR
       CHARACTER*80 DEBL
       CHARACTER*8 IBLOC
       CHARACTER*4 IOB
       CHARACTER*4 MOD
       DATA MOD/'TITL'/
C
       CALL TITLI4(IOB,MOD)
       NSTATI = 0
       NUSCIT = 1
       NINGRE = 2
       WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999  FORMAT(A,2X,'BL.-',A4,'- **** REGOL. ',A4,' - ',A)
       WRITE(IFO,3001)IOB
 3001  FORMAT('ATIT',A4,2X,
     &57H--UA--     TITOLO CANALE BOLLENTE                         )
       WRITE(IFO,3002)IOB
 3002  FORMAT('PRES',A4,2X,
     &57H--IN--     PRESSIONE                                      )
       WRITE(IFO,3003)IOB
 3003  FORMAT('HENT',A4,2X,
     &57H--IN--     ENTALPIA                                       )
       RETURN
       END
C*********************************************************************
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*                                                                   *
C*********************************************************************
       SUBROUTINE TITLI4(IOB,MOD)
       COMMON/TITL00/IBLOC,NCEL,NPAR
       CHARACTER*8 IBLOC
       CHARACTER*4 IOB
       CHARACTER*4 MOD
C
C
       WRITE(IBLOC,1000)MOD,IOB
 1000  FORMAT(2A4)
C
       RETURN
       END
      SUBROUTINE TITLD1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
C
C----significato delle variabili di uscita
C   SIGNEQ = DESCRIZIONE DELL'EQUAZIONE (IN STAZIONARIO) - 50 CAR.
C   UNITEQ = UNITA` DI MISURA DEL RESIDUO - 10 CAR.
C   COSNOR = COSTANTE DI NORMALIZZAZIONE DEL RESIDUO IN STAZIONARIO
C   ITOPVA = TOPOLOGIA JACOBIANO DI REGIME - matrice di INTEGER
C
C----Calcolo  Titolo in vapore    
C
      COMMON/NORM/P0,H0,T0,W0,R0,AL0,V0,DP0
      CHARACTER *8 BLOCCO, SYMVAR(*)
      CHARACTER *(*) SIGNEQ(*), UNITEQ(*)
      DIMENSION DATI(*), XYU(*), COSNOR(*), ITOPVA(MXT,*)
C
       RETURN
       END
