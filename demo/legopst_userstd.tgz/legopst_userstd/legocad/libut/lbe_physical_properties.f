C                                                                       
C                                                                       
C*************************** T_H_LBE ************************************
C                                                                       
C    HLBE    = Liquid LBE specific enthalpy [J/kg]                                                                   
C    T_H_LBE = Liquid LBE Temperature       [K]                                                                
C                                                                       
C
C    Range [64.5 kJ/kg - 494.3 kJ/kg]
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C     
C     Inverted function via non linear regression
C     
C*************************** T_H_LBE ************************************
C                                                                       
      REAL FUNCTION T_H_LBE(HLBE)
C                                                               !SNGL
C      DOUBLE PRECISION FUNCTION T_H_LBE(HLBE)                  !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                     !DBLE
C      DOUBLE PRECISION HLBE                                    !DBLE
C
      REAL HLBE,HLBE0,A,B,C,D               
      REAL AWLBE,A0,B0,C0,D0
C
      LOGICAL DOIT
C
      DATA HLBE0 /200000./,A/1615.3/,B/18.439/,C/-2.6357/,D/-57.49/
C
      DATA Tm /397.7/
      DATA AWLBE /208.18/
      DATA A0/8142.4238/,B0/33.1025/,C0/5.6628E-03/,D0/1.4823E-06/
C
C
      X=HLBE/HLBE0
C
      IF (X.EQ.0.) THEN
        T_H_LBE0=298.15
      ELSE
        T_H_LBE0=A*X+B/X**2.+C/X**3.+D
      END IF
C
C
C     NEWTON-RAPHSON method
C
      T=T_H_LBE0-Tm
C
C     H_T_LBE=1.E+03*(A+B*T-C*T**2.+D*T**3.)/AWLBE
C 
      DOIT=.TRUE.
C
      IT=0
C
      DO WHILE (DOIT)
        RES=1.-1.E+03*(A0+B0*T-C0*T**2.+D0*T**3.)/(AWLBE*HLBE)
        IF(ABS(RES).LT.1.E-4) DOIT=.FALSE.
        IF (IT.GT.100) THEN
          DOIT=.FALSE.
          WRITE(6,1000)RES
 1000     FORMAT(//10X,'Function T_H_LBE (HLBE)'/
     $    10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
        END IF
C
C------ Jacobian
C
        DRESDT=-1.E+03*(B0-2.*C0*T+3.*D0*T**2.)/(AWLBE*HLBE)
C
C------ Iterations
C
        DT=-1.*RES/DRESDT
        T=T+DT
        IT=IT+1
      END DO
C
C------ Solution
C
      T_H_LBE=T+Tm
C      write(6,*)'Iterazioni per T in funzione di H',IT
C      write(6,*)'HLBE (J/kg) = ',HLBE
C      write(6,*)' T = ',T,' T_H_LBE (K) = ',T_H_LBE
C      write(6,*)' T_H_LBE (�C) = ',(T_H_LBE-273.16)
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C*************************** RO_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature   [K�]                                                                
C    RO_T_LBE = Liquid Lead-Bismuth Eutectic density       [kg/m3]
C
C    Range [403 K� - 1300 K�]  Estimated error +/- 0.8%
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** RO_T_LBE ************************************
C                                                                       
      REAL FUNCTION RO_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION RO_T_LBE(LBE)                     !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
      REAL TLBE
C
      RO_T_LBE = 11096. - 1.3236*TLBE
C      write(6,*)' RO_T_LBE = ',RO_T_LBE,' T_LBE (K) = ',TLBE
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C*************************** DRODH_LEAD ************************************
C                                                                       
C    HLEAD = Liquid Lead specific enthalpy   [J/kg]                                                                   
C    T_H_LEAD = Liquid Lead Temperature      [K�]                                                                
C    TLEAD = Liquid Lead Temperature         [K�]                                                                
C    TLEADM = Lead melting point Temperature [K�]                                                                  
C    RO_T_LEAD= Liquid Lead density          [kg/m3]
C
C    Range [873.16 K� - 1673.16 K�]                                                     
C                                                                       
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C                                          
C    Ro(T) = 11.44E+03 - 1.35*T + 8.6E-5*T*T     [kg/m3]
C
C    T(h)  =  T_H_LEAD
C
C    dRo(T(h))   dRo(T)   dT
C    --------- = ------ * --
C       dh         dT     dh
C
C                                                                       
C*************************** DRODH_LEAD ************************************
C                                                                       
CC    REAL FUNCTION DRODH_LEAD(HLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION DRODH_LEAD(HLEAD)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
CC    DATA HLEAD0 /200000./,A/19.6633555/,B/-152.465621/,C/362.497308/
CC    DATA                  D/1101.25492/,E/-7.23610022/,F/235.141821/
CC    DATA A0/- 1.35/,B0/8.6E-5/
C
CC    X=HLEAD/HLEAD0
CC    TLEAD=A*X**4.+B*X**3.+C*X**2.+D*X+E/X+F
C
CC    DRODT=A0+B0*TLEAD
C
CC    DTDH=(4.*A*X*X*X+3.*B*X*X+2.*C*X+D-E/(X*X))/HLEAD0
C
CC    DRODH_LEAD=DRODT*DTDH
C
CC    RETURN                                                            
CC    END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** DRODT_LBE ************************************
C                                                                       
C    TLBE      = Liquid Lead-Bismuth Eutectic Temperature              [K�]                                                                
C    RO_T_LBE  = Liquid Lead-Bismuth Eutectic density                  [kg/m3]
C    DRODT_LBE = derivative of LBE density with respect to Temperature [kg/m3/K]
C
C    Range [403 K� - 1300 K�]  Estimated error +/- 0.8%
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C    Ro(T) = 11096.-1.3236*T  [kg/m3]
C
C
C       dRo(T)   
C    --------- = -1.3236   [kg/(m3 K)]
C       dT        
C
C                                                                       
C*************************** DRODT_LEAD ************************************
C                                                                       
      REAL FUNCTION DRODT_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION DRODT_LEAD(TLEAD)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
      DRODT_LBE = -1.3236
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** H_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature       [K]                                                                    
C    H_T_LBE  = Liquid Lead-Bismuth Eutectic specific enthalpy [J/kg]                                                                
C    AWPb     = Lead atomic weight     (207.2)                 [g/mol]
C    AWBi     = Bismuth atomic weight  (208.98)                [g/mol]
C    AWLBE    = LBE  atomic weight     (208.18)                [g/mol]
C    MFPb     = Lead mole fraction     (0.447)                 [p.u.]
C    MFBi     = Bismuth mole fraction  (0.553)                 [p.u.]
C    
C    LBE composition Pb 44.5 wt% - Bi 55.5 wt%
C    LBE composition Pb 0.447 - Bi 0.553 mole fraction
C
C
C    AWLBE = MFPb*AWPb + MFBi*AWBi = 0.447*207.2 + 0.553*208.98    
C
C
C    Range [400 K� - 2000 K�]  
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C     
C    Ts = 298.15 [K]  Standard state temperature
C
C    Tm = 397.7  [K]  Melting temperature
C
C    H(T)-H(Ts)  = -5.296E-04*T*T + 29.5182*T - 3513.2      [J/mol]
C
C    H(Tm)-H(Ts) = -5.296E-04*397.7*397.7 + 29.5182*397.7 - 3513.2
C                = 8142.4238                                [J/mol]
C                                                
C    H(T)-H(Tm)  = 33.1025(T-Tm)-5.6628E-03(T-Tm)(T-Tm)+1.4823E-06(T-Tm)(T-Tm)(T-Tm)
C                                                
C    H(T)-H(Ts)  = 8142.4238+33.1025(T-Tm)-5.6628E-03(T-Tm)(T-Tm)+1.4823E-06(T-Tm)(T-Tm)(T-Tm)
C
C    [H(T)-H(Ts)][J/kg] = [H(T)-H(Ts)][J/mol] / AWLBE[mol/kg]
C
C    H(Ts)= 0
C                                                                       
C*************************** H_T_LBE ************************************
C                                                                       
      REAL FUNCTION H_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION H_T_LBE(TLBE)                     !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
C
      REAL AWLBE,A,B,C
C
      DATA Tm /397.7/
      DATA AWLBE /208.18/
      DATA A/8142.4238/,B/33.1025/,C/5.6628E-03/,D/1.4823E-06/
C
C
      T=TLBE-Tm
C
      H_T_LBE=1.E+03*(A+B*T-C*T**2.+D*T**3.)/AWLBE
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** CP_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature  [K�]                                                                
C    CP_T_LBE = Liquid LBE Isobaric Specific Heat         [J/(kg�K�)]                                                                
C
C    Range [430 K� - 605 K�]  Estmated error +/- 7%   ?
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C     
C                                                                       
C*************************** CP_T_LBE ************************************
C                                                                       
      REAL FUNCTION CP_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION CP_T_LEAD(TLEAD)                  !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      DOUBLE PRECISION TLEAD                                      !DBLE
C
C
C
        CP_T_LBE = 159. - 2.72E-02*TLBE + 7.12E-06*TLBE*TLBE
C
      RETURN                                                            
      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** TC_H_LEAD ************************************
C                                                                       
C    HLEAD     = Liquid Lead specific enthalpy    [J/kg]                                                                   
C    TLEAD     = Liquid Lead Temperature          [K�]                                                                    
C    TLEADM    = Lead melting point Temperature   [K�]                                                                  
C    TC_H_LEAD = Liquid Lead Thermal Conductivity [W/(m�K�)]                                                                
C                                                                       
C    Range [600.65 �K - 1325 �K]
C
C
C    Reference:
C                                                    
C    V. Imbeni, C. Martini, S. Masini and G. Palombarini
C    'Stato dell�arte sulle Propriet� Chimico-fisiche del Pb e Pb-Bi'
C    ENEA - Istituto di Metallurgia dell�Universit� di Bologna - (Italia), 1999
C
C*************************** TC_H_LEAD ************************************
C                                                                       
CC      REAL FUNCTION TC_H_LEAD(HLEAD)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION T_H_LEAD(HLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
CC      REAL HLEAD,A,B                                             !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
CC      DATA TLEADM /600.65/,A/15./,B/0.75E-02/
C
CC      TLEAD=T_H_LEAD(HLEAD)
C
CC      TC_H_LEAD=A+B*(TLEAD-TLEADM)
C
CC      RETURN                                                            
CC      END                                                               
C                                                                       
C                                                                       
C                                                                       
C*************************** TC_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature  [K�]                                                                
C    TC_H_LBE = Liquid LBE Thermal Conductivity           [W/(m�K)]                                                                
C                                                                       
C    Range [403 K - 1100 K]  Estmated error +/- 5%   ?
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C
C*************************** TC_T_LBE ************************************
C                                                                       
      REAL FUNCTION TC_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION T_T_LEAD(TLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C      REAL HLEAD,HLEAD0,A,B,C                                      !SNGL
C      DOUBLE PRECISION HLEAD                                      !DBLE
C
C
      TC_T_LBE = 3.61 + 1.517E-02*TLBE - 1.741E-06*TLBE*TLBE
C
      RETURN                                                            
      END                                                               
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C*************************** MU_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature  [K�]                                                                
C    MU_T_LBE = Liquid LBE dynamic viscosity              [Pa*s]
C
C    Range [400 K - 1100 K]  Estmated error +/- 5% 
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** MU_T_LEAD ************************************
C                                                                       
      REAL FUNCTION MU_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION MU_T_LEAD(TLEAD)                   !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
      MU_T_LBE = 4.94E-04 * EXP(754.1/TLBE)
C
      RETURN                                                            
      END                                                               
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C*************************** BETAP_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature    [K]                                                                
C    BETAP_T_LBE = Liquid LBE Thermal expansion coefficient [1/K]
C
C    Range [400 K - 1300 K]  Estmated error 0.8%
C
C    Bp=-(1/Ro)(dRo/dT) - (isobaric)
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** BETAP_T_LBE ************************************
C                                                                       
      REAL FUNCTION BETAP_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION BETAP_T_LBE(TLBE)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
      IF (TLBE.GT.8000.)THEN
C      
        write(6,*)' Warning --------------------------------'
        write(6,*)' '
        write(6,*)' Warning Temperature =',TLBE,' > 8000. K'
        write(6,*)' '
        write(6,*)' Warning Thermal expansion coefficient Bp'
        write(6,*)' '
        write(6,*)'         limited to Bp(8000.K)'
C
        BETAP_T_LBE = 1./(8383.2-8000.)
      ELSE
        BETAP_T_LBE = 1./(8383.2-TLBE)
      END IF
C
      RETURN                                                            
      END                                                               
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C                                                                       
C                                                                       
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C*************************** UQ_T_LBE ************************************
C                                                                       
C    TLBE     = Liquid Lead-Bismuth Eutectic Temperature [K]                                                                
C    UQ_T_LBE = Liquid LBE square of the sound velocity Uq  [m2/s2]
C    U        = Liquid LBE sound velocity                [m/s]
C
C    Range [400 K - 1300 K]  Estmated error ?
C
C    Uq=1/(dRo/dP) - (isoentropic)
C
C
C
C    Reference:
C                                                    
C    "Handbook on Lead-bismuth Eutectic Alloy and Lead Properties,
C    Materials Compatibility, Thermal-hydraulics and Technologies"
C    OECD Nuclear Energy Agency, 2007
C                                                                       
C*************************** UQ_T_LBE ************************************
C                                                                       
      REAL FUNCTION UQ_T_LBE(TLBE)
C                                                                  !SNGL
C      DOUBLE PRECISION FUNCTION UQ_T_LBE(TLBE)                 !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                        !DBLE
C
      IF (TLBE.GT.1300.)THEN
        write(6,*)' Warning --------------------------------'
        write(6,*)' '
        write(6,*)' Warning Temperature =',TLBE,' > 1300. K'
        write(6,*)' '
      END IF
C
      U=1773.+0.1049*TLBE-2.873E-04*TLBE*TLBE
C
      UQ_T_LBE = U*U
C
      RETURN                                                            
      END                                                               

