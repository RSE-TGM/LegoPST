C modulo rsc1.f
C tipo 
C release 0.0
C data 18/11/2003
C Puertollano project libut reserver @(#)rsc1.f	1.1
C**********************************************************************
C
C
C 
C
C**********************************************************************
C
      SUBROUTINE RSC1I3(IFO,IOB,DEBL)
      COMMON/RSC100/IBLOC,NE,NDI,NUS,NUW
      CHARACTER*80 DEBL
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      DATA MOD/'RSC1'/
C
C   Simplified Heat Exchanger Shell side model
C
      CALL RSC1I4(IOB,MOD)
C
      NZDSH=3
      NZCND=4
      NZDSC=3
      NZON=NZDSH+NZCND+NZDSC
C
      WRITE(IFO,2999)IBLOC,IOB,MOD,DEBL
 2999 FORMAT(A,2X,'BL.-',A4,'- **** MODULO ',A4,' - ',A)
C
      WRITE(IFO,3000)IOB
 3000 FORMAT('PWSS',A4,2X,'--US-- SHELL SIDE WATER PRESSURE')
C
      WRITE(IFO,3001)(I,IOB,I,I=1,NZDSH)
 3001 FORMAT('HSD',I1,A4,2X
     $      ,'--US-- STEAM ENTHALPY DESUPERHEATING ZONE ',I1)
C
      WRITE(IFO,3002)IOB
 3002 FORMAT('HVRS',A4,2X,'--US-- STEAM ENTHALPY CONDENSING ZONE ')
C
      WRITE(IFO,3005)IOB
 3005 FORMAT('MLRS',A4,2X,'--US-- LIQUID MASS')
C
      WRITE(IFO,3006)IOB
 3006 FORMAT('HLRS',A4,2X,'--US-- LIQUID ENTHALPY')
C
      WRITE(IFO,3007)(I,IOB,I,I=1,NZDSC)
 3007 FORMAT('HLC',I1,A4,2X
     $      ,'--US-- LIQUID ENTHALPY SUBCOOLING ZONE ',I2)
C
      WRITE(IFO,3008)IOB
 3008 FORMAT('TAMS',A4,2X,'--US-- SHELL METAL AVERAGE TEMPERATURE')
C
      WRITE(IFO,3009)(I,IOB,I,I=1,NZON)
 3009 FORMAT('TM',I2,A4,2X,'--US-- TUBES WALL TEMPERAT. ZONE ',I2)
C
      WRITE(IFO,3010) (I,IOB,I,I=1,NZON)
 3010 FORMAT('HF',I2,A4,2X,'--US-- TUBES SIDE WATER ENTHALPY ZONE ',I2)
C
      WRITE(IFO,3011)IOB
 3011 FORMAT('TSWO',A4,2X,'--UA-- SUBCOOLED WATER OUTLET TEMPERATURE')
C
      WRITE(IFO,3012)IOB
 3012 FORMAT('TFWO',A4,2X,'--UA-- FEEDWATER OUTLET TEMPERATURE')
C
      WRITE(IFO,3013)IOB
 3013 FORMAT('LEVS',A4,2X,'--UA-- @#K@         WATER LEVEL')
C
      WRITE(IFO,3014)IOB
 3014 FORMAT('WFDW',A4,2X,'--UA-- FEEDWATER MASS FLOW RATE')
C
      DO J=1,NE
        WRITE(IFO,3015)J,IOB,J
        WRITE(IFO,3016)J,IOB,J
      ENDDO 
 3015 FORMAT('WS',I2,A4,2X,'--IN-- STEAM MASS FLOW RATE INLET  N.',I2)
 3016 FORMAT('HS',I2,A4,2X,'--IN-- STEAM ENTHALPY INLET BRANCH N.',I2)
C
C
      DO J=1,NDI
        WRITE(IFO,3017)J,IOB,J
        WRITE(IFO,3018)J,IOB,J
      ENDDO 
 3017 FORMAT('WDI',I1,A4,2X,'--IN-- DRAIN MASS FLOW RATE INLET N.',I1)
 3018 FORMAT('HDI',I1,A4,2X,'--IN-- DRAIN ENTHALPY INLET N.',I1)
C
      DO J=1,NUS
        WRITE(IFO,3019)J,IOB,J
        WRITE(IFO,3020)J,IOB,J
      ENDDO
 3019 FORMAT('WSO',I1,A4,2X,'--IN-- STEAM FLOW RATE OUTLET  N ',I1)
 3020 FORMAT('HSO',I1,A4,2X,'--IN-- STEAM ENTHALPY OUTLET N',I1,'(W<0)')
C
      DO J=1,NUW
        WRITE(IFO,3021)J,IOB,J
        WRITE(IFO,3022)J,IOB,J
      ENDDO
 3021 FORMAT('WDO',I1,A4,2X,'--IN-- DRAIN FLOW RATE OUTLET  N.',I1)
 3022 FORMAT('HDO',I1,A4,2X,'--IN-- DRAIN ENTHALPY OUTLET N',I1,'(W<0)')
C
      WRITE(IFO,3023)IOB
 3023 FORMAT('PFIN',A4,2X,'--IN-- FEEDWATER INLET PRESSURE')
C
      WRITE(IFO,3024)IOB
 3024 FORMAT('HFIN',A4,2X,'--IN-- FEEDWATER INLET ENTHALPY')
C
      WRITE(IFO,3025)IOB
 3025 FORMAT('PFOU',A4,2X,'--IN-- FEEDWATER OUTLET PRESSURE')
C
      WRITE(IFO,3026)IOB
 3026 FORMAT('HFOU',A4,2X
     $      ,'--IN-- REVERSE FLOW FEEDWATER OUTLET ENTHALPY W<0')
C
      WRITE(IFO,3027)IOB
 3027 FORMAT('FTFF',A4,2X,'--IN-- FEEDWATER TUBES FRICTION FACTOR')
C
      WRITE(IFO,3028)IOB
 3028 FORMAT('ADSH',A4,2X
     $      ,'--IN-- DESUPERHEATING HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3029)IOB
 3029 FORMAT('ACND',A4,2X
     $      ,'--IN-- CODENSING HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3030)IOB
 3030 FORMAT('ACSC',A4,2X
     $      ,'--IN-- SUBCOOLING HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3031)IOB
 3031 FORMAT('GSIF',A4,2X
     $      ,'--IN-- SHELL-INNER FLUID HEAT TRANSFER COEFFICIENT')
C
      WRITE(IFO,3032)IOB
 3032 FORMAT('ASSW',A4,2X
     $      ,'--IN-- SHELL-SUBCOOLED WATER HEAT TRANSFER ADJUSTER')
C
      WRITE(IFO,3033)IOB
 3033 FORMAT('TEST',A4,2X,'--IN-- EXTERNAL ENVIRONMENT TEMPERATURE')
C
      WRITE(IFO,3034)IOB
 3034 FORMAT('GEST',A4,2X,'--IN-- EXTERNAL HEAT TRANSFER COEFFICIENT')
C
C
      RETURN
      END
C***********************************************************************
      SUBROUTINE RSC1I4(IOB,MOD)
      PARAMETER (MAXIO=10,MAXCI=15)
      COMMON/RSC100/IBLOC,NE,NDI,NUS,NUW
      CHARACTER*8 IBLOC
      CHARACTER*4 IOB
      CHARACTER*4 MOD
      CHARACTER*2 IS
C
      NZON=10
C
      WRITE(6,101) MAXIO
  101 FORMAT(10X,'***** Simplified Heat Exchanger',
     $' Shell side model *****'//
     $       10X,'Inlet Branches Number [01 -',I3,'] ?')
    9 CONTINUE
      READ(5,*) NE
      IF(NE.LE.0.OR.NE.GT.MAXIO) THEN
         WRITE(6,102) NE,MAXIO
         GOTO 9
      ENDIF
  102 FORMAT(/10X,'%% ERROR %% -> assigned inlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')
C
C
      WRITE(6,103) MAXIO
  103 FORMAT(10X,'***** Simplified Heat Exchanger',
     $' Shell side model *****'//
     $       10X,'Inlet Drain Branches Number [00 -',I3,'] ?')
   10 CONTINUE
      READ(5,*) NDI
      IF(NDI.LT.0.OR.NDI.GT.MAXIO) THEN
         WRITE(6,104) NDI,MAXIO
         GOTO 10
      ENDIF
  104 FORMAT(/10X,'%% ERROR %% -> assigned drain inlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [0-',I3,']'//35X,' Please reassign it')
C
      WRITE(6,105) MAXIO
  105 FORMAT(10X,'Steam Outlet Branches Number [00 -',I3,'] ?')
   15 CONTINUE
      READ(5,*) NUS
      IF(NUS.LT.0.OR.NUS.GT.MAXIO) THEN
         WRITE(6,106) NUS,MAXIO
         GOTO 15
      ENDIF
  106 FORMAT(10X,'%% ERROR %% -> assigned outlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [0-',I3,']'//35X,' Please reassign it')
C
      WRITE(6,107) MAXIO
  107 FORMAT(10X,'Water Outlet Branches Number [01 -',I3,'] ?')
   16 CONTINUE
      READ(5,*) NUW
      IF(NUW.LT.0.OR.NUW.GT.MAXIO) THEN
         WRITE(6,108) NUW,MAXIO
         GOTO 16
      ENDIF
  108 FORMAT(10X,'%% ERROR %% -> assigned outlet branches
     $ number =',I3,//25X,4HIt's,' value must be in the range
     $ [1-',I3,']'//35X,' Please reassign it')

C
C     WRITE(6,109) MAXCI
C 109 FORMAT(10X,'Tubes Heat Exchange Zone Number [02 -',I3,'] ?')
C  17 CONTINUE
C     READ(5,*) NZON
C     IF(NZON.LE.0.OR.NZON.GT.MAXCI) THEN
C        WRITE(6,110) NZON,MAXCI
C        GOTO 17
C     ENDIF
C 110 FORMAT(10X,'%% ERROR %% -> assigned Tubes Heat Exchange',
C    $ /42X,'Zone Number =',I3,//25X,4HIt's,' value must be
C    $ in the range [2-',I3,']'//35X,' Please reassign it')
C
      WRITE(IBLOC,1000)MOD,IOB
 1000 FORMAT(2A4)
C
      RETURN
      END
C***********************************************************************
        SUBROUTINE RSC1I2(IFUN,VAR,MX1,IV1,IV2,XYU,DATI,ID1,ID2,
     $                    IBL1,IBL2,IER,CNXYU,TOL)
        DIMENSION VAR(MX1,*),XYU(*),DATI(*),CNXYU(*),TOL(*)
C
        PARAMETER (PI=3.14159)
        PARAMETER (MAXIO=10,MAXCI=15)
        PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
C       COMMON/AUSIL1/NSTATI,NUSCIT,NINGRE
        COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
C
C   Simplified Heat Exchanger Shell side model
C
        GO TO(100,200),IFUN
C
  100   WRITE(14,500)    'I.S.B.N.'
     1                  ,'I.D.B.N.'
     1                  ,'O.S.B.N.'
     1                  ,'O.D.B.N.'
     1                  ,'SH.O.D. '
     1                  ,'SH.THICK'
     1                  ,'SH.LENGH'
     1                  ,'SH.M.RO.'
     1                  ,'SH.CP.  '
     1                  ,'SH.COND.'
     1                  ,'D.C.I.  '
     1                  ,'TUB.NUMB'
     1                  ,'TUB.O.D.'
     1                  ,'TUB.THIC'
     1                  ,'TUB.LENG'
     1                  ,'TU.PITCH'
     1                  ,'T.SH.O.D'
     1                  ,'TU.M.RO.'
     1                  ,'TUB. CP.'
     1                  ,'TUB. K. '
     1                  ,'DSH.SURF'
     1                  ,'DSH.BF.S'
     1                  ,'CND.SURF'
     1                  ,'CND.BF.S'
     1                  ,'DSC.SURF'
     1                  ,'DSC.BF.S'
     1                  ,'U.H.T.C.'
     1                  ,'H.T.A.  '
        RETURN
C
C
C
C-----------'I.S.B.N.' - Inlet Steam Branch Number
C-----------'I.D.B.N.' - Inlet Drain Branch Number
C-----------'O.S.B.N.' - Outlet Steam Branch Number
C-----------'O.D.B.N.' - Outlet Drain Branch Number
C-----------'SH.O.D. ' - SHell Outside Diameter
C-----------'SH.THICK' - SHell THICKness
C-----------'SH.LENGH' - SHell LENGHT
C-----------'SH.M.RO.' - SHell Metal density
C-----------'SH.CP.  ' - SHell metal specific heat
C-----------'SH.COND.' - SHell metal CONDuctivity
C-----------'D.C.I.  ' - Diametro Cassa Interna
C-----------'TUB.NUMB' - TUBes NUMBer
C-----------'TUB.O.D.' - TUBes Outside Diameter
C-----------'TUB.THIC' - TUBes THICkness
C-----------'TUB.LENG' - TUBes LENGht
C-----------'TU.PITCH' - TUbes PITCH
C-----------'T.SH.O.D' - Tubes SHell Outside Diameter
C-----------'TU.M.RO.' - TUbes Metal density
C-----------'TUB. CP.' - TUBes Metal specific heat
C-----------'TUB. K. ' - TUBes metal conductivity
C-----------'DSH.SURF' - DeSuperHeating SURFace
C-----------'DSH.BF.S' - DeSuperHeating BuFfel Spacing
C-----------'CND.SURF' - CoNDensing SURFace
C-----------'CND.BF.S' - CoNDensing SBuFfel Spacing
C-----------'DSC.SURF' - Drain SubCooling SURFace
C-----------'DSC.BF.S' - Drain SubCooling BuFfel Spacing
C-----------'U.H.T.C.' - User Heat Transfer Coefficient
C-----------'H.T.A.  ' - Heat Transfer Arrangement 0 = counterflow; 1 = parallel
C
C
C---lettura e memorizzazione dati
C
  200   READ(14,502)
        READ(14,502)     FNE
     1                  ,FNDI
     1                  ,FNUS
     1                  ,FNUW
     1                  ,SHOD
     1                  ,SHTHICK
     1                  ,SHLENGH
     1                  ,SHRO
     1                  ,SHCP
     1                  ,SHCOND
     1                  ,DCI
     1                  ,FNTUB
     1                  ,TUBOD
     1                  ,TTHICK
     1                  ,TUBLENGH
     1                  ,TUBPITCH
     1                  ,TUBSHEETOD
     1                  ,TUBRO
     1                  ,TUBCP
     1                  ,TUBK
     1                  ,DSHSUP
     1                  ,DSHBUFSPAC
     1                  ,CNDSUP
     1                  ,CNDBUFSPAC
     1                  ,DSCSUP
     1                  ,DSCBUFSPAC
     1                  ,UHTC
     1                  ,HTA
C
  500 FORMAT(3(4X,A8,' =',10X,'*'))
  502 FORMAT(3(14X,F10.2,1X))
C
C______________________________________________
C
      NE=FNE
      NDI=FNDI
      NUS=FNUS
      NUW=FNUW
C     NZON=FNZON
      NZDSH=3
      NZCND=4
      NZDSC=3
      NZON=NZDSH+NZCND+NZDSC
      FNZON=FLOAT(NZON)
      NTUB=FNTUB
C
C--- Shell outside surface ---
C
      SHOS=PI*SHOD*SHLENGH
C
C--- Shell inside diameter ---
C
      SHID=SHOD-2.*SHTHICK
C
C--- Shell inside surface ---
C
      SHIS=PI*SHID*SHLENGH
C
C--- Volume beetwen shell and internal tank ---
C
      SHIV=PI*(SHID**2.-DCI**2.)*SHLENGH/4.
C
C--- Tank inner volume without tubes' volume ---
C
      TIVWT=PI*DCI**2.*SHLENGH/4.-FNTUB*PI*(TUBOD**2)*TUBLENGH/4.
C      TIVWT=TIVWT+SHIV
C
C
      IF (TIVWT.LE.0) THEN
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^    ERROR!!  ERROR!  ERROR!  ERROR!  ERROR!!    ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^  Tubes volume can''t be bigger then enclosure  ^^'
        WRITE(6,*)'^^                                                ^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^'
        WRITE(6,*)' '
        WRITE(6,*)' '
        WRITE(6,*)' '
        STOP
      ENDIF
C
C--- Internal tank flow cross-sectional area ---
C
C     FCSA=PI*(DCI**2.)/4.-NTUB*PI*(TUBOD**2.)/4.
      FCSA=0.5*(PI*(DCI**2.)/4.-2.*FNTUB*PI*(TUBOD**2.)/4.)
C
C--- Internal tank equivalent diameter ---
C
C     EQD=4.*FCSA/(PI*DCI+NTUB*PI*TUBOD)
      EQD=4.*FCSA/(FNTUB*PI*TUBOD)
C
C
C--- Desuperheating zone flow cross-sectional area ---
C
      DSHFCSA=0.5*TUBSHEETOD/TUBPITCH*(TUBPITCH-TUBOD)*DSHBUFSPAC
C
C--- Desuperheating zone equivalent diameter ---
C
      DSHPB=TUBSHEETOD/TUBPITCH*DSHBUFSPAC
      DSHEQD=4.*DSHFCSA/DSHPB
C
C
C--- Condensing zone flow cross-sectional area ---
C
      CNDFCSA=0.5*TUBSHEETOD/TUBPITCH*(TUBPITCH-TUBOD)*CNDBUFSPAC
CC
C--- Condensing zone equivalent diameter ---
C
      CNDPB=TUBSHEETOD/TUBPITCH*CNDBUFSPAC
      CNDEQD=4.*CNDFCSA/CNDPB
C

C--- Subcooling zone flow cross-sectional area ---
C
      DSCFCSA=0.5*TUBSHEETOD/TUBPITCH*(TUBPITCH-TUBOD)*DSCBUFSPAC
C
C--- Subcooling zone equivalent diameter ---
C
      DSCPB=TUBSHEETOD/TUBPITCH*DSCBUFSPAC
      DSCEQD=4.*DSCFCSA/DSCPB
C
C--- Shell metal mass ---
C
      SHMASS=SHRO*PI*(SHOD**2.-SHID**2.)/4.*SHLENGH
C
C--- Shell thermal capacity ---
C
      SHTC=SHCP*SHMASS
C
C--- Internal tank heat exchange surface per zone ---
C
      SSCIZ=PI*DCI*SHLENGH/FNZON
C
C--- Tubes' heat exchange surface per zone ---
C
      IF (TUBSUP.EQ.0.) THEN
         TUBZSURF=FNTUB*PI*TUBOD*TUBLENGH/FNZON
      ELSE
         TUBZSURF=TUBSUP/FNZON
C
C--- Average tubes' outside diameter ----
C
         TUBOD=TUBSUP/(PI*FNTUB*TUBLENGH)
      ENDIF
C
C
C--- Feedwater tubes flow cross-sectional area ---
C
      FTCSA=FNTUB*PI*((TUBOD-2.*TTHICK)**2.)/4.
C
C--- Feedwater tubes equivalent diameter ---
C
      FTEQD=4.*FTCSA/(FNTUB*PI*(TUBOD-2.*TTHICK))
C
C
      WRITE(6,11)
   11 FORMAT(/10X,24H----  Shell's Data  ----)
      WRITE(6,12)SHOD,SHTHICK,SHLENGH,SHID
   12 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Shell lenght',13X,'Inside diameter',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],23X,3H[m]//,10X,
     $       4(G15.6,10X))
      WRITE(6,13)SHOS,SHIS,(TIVWT+SHIV),SHMASS
   13 FORMAT(///10X,'Outside surface',10X,'Inside surface',
     $       11X,'Inside volume',12X,'Metal mass',/16X,
     $       4H[m2],19X,4H[m2],22X,4H[m3],20X,4H[kg]//,10X,
     $       4(G15.6,10X))
      WRITE(6,14)FCSA,EQD
   14 FORMAT(///10X,'Flow cross-sectional area',
     $       10X,'Equivalent diameter',/,20X,
     $       4H[m2],30X,3H[m]//,10X,
     $       2(G15.6,20X))
      WRITE(6,1)
    1 FORMAT(/////10X,23H----  Tubes' Data  ----)
      WRITE(6,*) ' '
      WRITE(6,2)TUBOD,TTHICK,TUBLENGH,NTUB
    2 FORMAT(/10X,'Outside diameter',9X,'Wall thickness',
     $       11X,'Tubes lenght',13X,'Tubes number',/16X,
     $       3H[m],21X,3H[m],22X,3H[m],21X,3H[-],//,10X,
     $       3(G15.6,10X),1I5)
      WRITE(6,*) ' '
      WRITE(6,3)TUBZSURF*NZON,TUBZSURF,NZON
    3 FORMAT(/10X,'Heat Exchange Surface',9X,
     $       'Heat Exchange Surface per Zone',
     $       11X,'Zone number',/19X,
     $       4H[m2],30X,4H[m2],28X,3H[-],//,12X,
     $       2(G15.6,20X),1I5)
C
C---  Come fattore di normalizzazione della massa di liquido 
C     nella cavita` si utilizza il valore della massa nell'ipotesi
C     di cavit� alla pressione di 100. bar, fluido in condizioni di saturazione
C     e volume di liquido pari al 50% del volume libero della cavita`
C
C     AML0 = @V/2 = 688.4*0.5*V
C
      AML0=688.4*0.5*(TIVWT+SHIV)
C
      DATI(ID2  ) = NE  
      DATI(ID2+1) = NUS
      DATI(ID2+2) = NUW
      DATI(ID2+3) = SHOS
      DATI(ID2+4) = SHIS
      DATI(ID2+5) = TIVWT
      DATI(ID2+6) = FCSA
      DATI(ID2+7) = EQD
      DATI(ID2+8) = SHTC
      DATI(ID2+9) = NZDSH
      DATI(ID2+10)= NTUB
      DATI(ID2+11)= TUBOD
      DATI(ID2+12)= TUBLENGH
      DATI(ID2+13)= DSHSUP
      DATI(ID2+14)= CNDSUP
      DATI(ID2+15)= UHTC
      DATI(ID2+16)= SHID
      DATI(ID2+17)= SHLENGH
      DATI(ID2+18)= SHIV
      DATI(ID2+19)= AML0
      DATI(ID2+20)= NDI
      DATI(ID2+21)= SSCIZ
      DATI(ID2+22)= DSCSUP
      DATI(ID2+23)= NZCND
      DATI(ID2+24)= NZDSC
      DATI(ID2+25)= FTCSA
      DATI(ID2+26)= FTEQD
      DATI(ID2+27)= TTHICK
      DATI(ID2+28)= TUBRO
      DATI(ID2+29)= TUBCP
      DATI(ID2+30)= TUBK
      DATI(ID2+31)= DSHFCSA
      DATI(ID2+32)= DSHEQD
      DATI(ID2+33)= CNDFCSA
      DATI(ID2+34)= CNDEQD
      DATI(ID2+35)= DSCFCSA
      DATI(ID2+36)= DSCEQD
      DATI(ID2+37)= HTA
C
C
      ID2 = ID2+37+1
C
C---costanti di normalizzazione
C
      CNXYU(IV1  ) = P0
C
      DO I=1,NZDSH
        CNXYU(IV1+I) = H0
      END DO
C
      CNXYU(IV1+NZDSH+1) = H0
C
      CNXYU(IV1+NZDSH+2) = AML0
C
      CNXYU(IV1+NZDSH+3) = H0
C
      DO I=1,NZDSC
        CNXYU(IV1+NZDSH+3+I) = H0
      END DO
C
      CNXYU(IV1+NZDSH+NZDSC+4) = T0
C
      DO I=1,NZON
        CNXYU(IV1+NZDSH+NZDSC+4+I) = T0
      END DO
C
      DO I=1,NZON
	CNXYU(IV1+NZDSH+NZDSC+NZON+4+I)=H0
      END DO
C
      CNXYU(IV1+NZDSH+NZDSC+2*NZON+5) = T0
C
      CNXYU(IV1+NZDSH+NZDSC+2*NZON+6) = T0
C
      CNXYU(IV1+NZDSH+NZDSC+2*NZON+7) = 1.
C
      CNXYU(IV1+NZDSH+NZDSC+2*NZON+8) = W0
C
      NT=NE+NDI+NUS+NUW
C
      I0=IV1+NZDSH+NZDSC+2*NZON+8
C
      DO J = 1,NT
	JW=2*J-1
	JH=JW+1
	CNXYU(I0+JW) = W0
	CNXYU(I0+JH) = H0
      END DO
C
      CNXYU(I0+2*NT+1)=P0
      CNXYU(I0+2*NT+2)=H0
      CNXYU(I0+2*NT+3)=P0
      CNXYU(I0+2*NT+4)=H0
C
      CNXYU(I0+2*NT+5) = 0.01
      CNXYU(I0+2*NT+6) = 1.
      CNXYU(I0+2*NT+7) = 1.
      CNXYU(I0+2*NT+8) = 1.
      CNXYU(I0+2*NT+9) = GAM0
      CNXYU(I0+2*NT+10) = 1.
C
      CNXYU(I0+2*NT+11) = T0
      CNXYU(I0+2*NT+12) = GAM0
C
      RETURN
      END
C************************************************************************
C
      SUBROUTINE RSC1C1(IFUN,AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,IBL1,IBL2)
C
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RNI(*)
C
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/REGIME/KREGIM
C
      EXTERNAL RSC1
      LOGICAL KREGIM
C
C$$$$$     !!!!!!! INIZIO ISTRUZIONI PER SCCS !!!!!!!
      CHARACTER*100 SccsID
      DATA SccsID/'@(#)hess.f	1.1\t 1.1\t 12/19/97 Puerpro libut'/
C$$$$$     !!!!!!! FINE ISTRUZIONI PER SCCS !!!!!!!
C
C
C
C   Simplified Heat Exchanger Shell side model
C
C   CALCOLO RESIDUI
C
C
      NE  =DATI(IPD)
      NDI =DATI(IPD+20)
      NUS =DATI(IPD+1)
      NUW =DATI(IPD+2)
      NZDSH=DATI(IPD+9)
      NZCND=DATI(IPD+23)
      NZDSC=DATI(IPD+24)
      NSTATI=1+NZDSH+3+NZDSC+1+2*(NZDSH+NZCND+NZDSC)
      NUSCALG=4
      NUSCTOT=NSTATI+NUSCALG
      NINGRE=2*(NE+NDI+NUS+NUW)+12
      NVAR=NUSCTOT+NINGRE
C
        GO TO(100,200,300),IFUN
C
C---topologia jacobiano
C
  100   DO I=1,NUSCTOT
          DO J =1,NVAR
            AJAC(I,J) = 1.
          END DO
        END DO
        RETURN
C
C---calcolo residui
C
  200   CONTINUE
        CALL RSC1(IFUN,IXYU,XYU,IPD,DATI,RNI)
        RETURN
C
C---calcolo jacobiano 
C
 300    CONTINUE
C
      EPS   =1.E-4
      EPSLIM=1.E-5
      CALL RSC1JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
     $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,RSC1)
C       CALL NAJAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RNI,
C     $           NSTATI,NUSCALG,NINGRE,EPS,EPSLIM,RSC1)
C
       RETURN                
      END
C
C
      SUBROUTINE RSC1JAC(AJAC,MX5,IXYU,XYU,IPD,DATI,RN,
     $                 NSTATI,NUSCIT,NINGRE,EPS,EPSLIM,RESIDUI)
C
C--- routine ADATTATA per calcolo jacobiano numerico con DERIVATE +/-
C    con incrementi +/- EPS in p.u. ( valori minimi assoluti EPSLIM )
C    i residui devono essere calcolati dalla routine (da dich. EXTERNAL)
C    SUBROUTINE RESIDUI(IFUN,IXYU,XYU,IPD,DATI,RN)
C
      DIMENSION AJAC(MX5,*),XYU(*),DATI(*),RN(*)
      DIMENSION CRN(100),CXYU(100),CCRN(100),CCXYU(100),VAR(100)
      EXTERNAL RESIDUI
C
      PARAMETER (GAM0=1000.) !compatibile EXCH e FUMN
C
      COMMON/REGIME/KREGIM
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
C
      NRIG=NSTATI+NUSCIT
      NCOL=NSTATI+NUSCIT+NINGRE
C
C
C--- se la variabile e` una pressione
C    non viene limitato il suo incremento
C
C
      NE  =DATI(IPD)
      NDI =DATI(IPD+20)
      NUS =DATI(IPD+1)
      NUW =DATI(IPD+2)
C     NZON=DATI(IPD+9)
      NZDSH=DATI(IPD+9)
      AML0=DATI(IPD+19)
      NZCND=DATI(IPD+23)
      NZDSC=DATI(IPD+24)
      NZON=NZDSH+NZCND+NZDSC
      ILS=NZDSH+NZDSC+2*NZON+9
      I1LS=ILS+2*(NE+NDI+NUS+NUW)
C
      PR=XYU(IXYU)*P0
C
      VAR(1)=50./P0
C
      DO J=1,NZDSH
        VAR(1+J)=50./H0
      END DO
C
      VAR(1+NZDSH+1)=50./H0
C
      VAR(NZDSH+3)=0.01/AML0
C
      VAR(NZDSH+4)=50./H0
C
      DO J=1,NZDSC
        VAR(NZDSH+4+J)=50./H0
      END DO
C
      VAR(NZDSH+NZDSC+5)=1./T0
C
      DO J=1,NZON
        VAR(NZDSH+NZDSC+5+J)=1./T0
      END DO
C
      DO I=1,NZON
        VAR(NZDSH+NZDSC+5+NZON+I)=50./H0
      END DO
C
      VAR(NZDSH+NZDSC+2*NZON+6)=1./T0
C
      VAR(NZDSH+NZDSC+2*NZON+7)=1./T0
C
      VAR(NZDSH+NZDSC+2*NZON+8)=0.1
C
      VAR(NZDSH+NZDSC+2*NZON+9)=0.1/W0
C
      DO I1=ILS+1,I1LS,2
        VAR(I1)=0.1/W0
        VAR(I1+1)=50./H0
      END DO
C
      VAR(I1LS+1)=50./P0
      VAR(I1LS+2)=50./H0
      VAR(I1LS+3)=50./P0
      VAR(I1LS+4)=50./H0
C
      VAR(I1LS+5)=0.0001
      VAR(I1LS+6)=0.01
      VAR(I1LS+7)=0.01
      VAR(I1LS+8)=0.01
      VAR(I1LS+9)=1./GAM0
      VAR(I1LS+10)=0.01

      VAR(I1LS+11)=1./T0
      VAR(I1LS+12)=1./GAM0
C
      DO 30 J=1,NCOL
        DO 10 K=1,NCOL
          CXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CXYU(K)=CXYU(K)+VAR(J)
          CCXYU(K)=XYU(IXYU+K-1)
          IF(K.EQ.J) CCXYU(K)=CCXYU(K)-VAR(J)
   10   CONTINUE
C
C--- residui(ifun,ixyu,xyu,ipd,dati,rn)
C
C
        CALL RESIDUI(3,1,CCXYU,IPD,DATI,CCRN)
C
        CALL RESIDUI(3,1,CXYU,IPD,DATI,CRN)
C
        DO 20 I=1,NRIG
          AJAC(I,J)=(CRN(I)-CCRN(I))/(2.*VAR(J))
          IF(I.GT.NSTATI) AJAC(I,J)=-AJAC(I,J)
   20   CONTINUE
C
   30 CONTINUE
C
      RETURN
      END
C
C
C*********************************************************************
      SUBROUTINE RSC1(IFUN,IXYU,XYU,IPD,DATI,RNI)
      DIMENSION XYU(*),DATI(*),RNI(*)
C
C   Simplified Heat Exchanger Shell side model
C
      PARAMETER (MAXIO=10,MAXCI=15)
C     PARAMETER (GAM0=1000.)
      PARAMETER (SHIHEC=20.)
      PARAMETER (PMIN=0.15)
      PARAMETER (ALMIN=0.5)
C
      PARAMETER (TAUL=5.)
      PARAMETER (TAUV=5.)
      PARAMETER (ALFA=3.3)
      PARAMETER (BETA=0.1)
      PARAMETER (HSUR=50.)
C
      DIMENSION WS(MAXIO),WSO(MAXIO),WDO(MAXIO),WDI(MAXIO)
      DIMENSION WDLI(MAXIO),WDVI(MAXIO),HDLI(MAXIO),HDVI(MAXIO)
      DIMENSION HS(MAXIO),HSO(MAXIO),HDO(MAXIO),HVTAV(MAXCI),HDI(MAXIO)
      DIMENSION GAM(MAXCI),GTUB(MAXCI),TM(MAXCI),TFW(MAXCI)
      DIMENSION HSD(MAXCI),TW(MAXCI),TVZ(MAXCI),TSC(MAXCI),HF(MAXCI)
      DIMENSION XVZ(MAXCI),WVICND(MAXCI),WLICND(MAXCI),WEVLS(MAXCI)
      DIMENSION QCMDSH(MAXCI),QTUW(MAXCI),QDSH(MAXCI)
      DIMENSION DITBOE(MAXCI),HADAL(MAXCI),WVUDSH(MAXCI),WVUCND(MAXCI)
      DIMENSION SCDITBOE(MAXCI),QFDW(MAXCI),QKSC(MAXCI)
      DIMENSION SHDSH(MAXCI),SHCND(MAXCI),SHDSC(MAXCI),SHFDW(MAXCI)
      DIMENSION HSC(MAXCI),HLC(MAXCI),ROFW(MAXCI),TLS(MAXCI),QCMS(MAXCI)
      DIMENSION QCND(MAXCI),QDSC(MAXCI),WCDSH(MAXCI)
C
      REAL MVZ(MAXCI),MSC(MAXCI),MVZT,MLFW(MAXCI),MLSC(MAXCI)
      REAL LEVS,MLRS,MFWTOT,MVCND
C
      LOGICAL KREGIM,FML,COUNTERFLOW
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
C
      COMMON/REGIME/KREGIM
C
      COMMON/RSC1VAR0/SUMDVI,SWSOINV,SWSINV,WCP,SWSO,SUMDINV
      COMMON/RSC1VAR1/SUMDHVI,HVRS,SWSODHSOINV,HLS,QSHE,HW
      COMMON/RSC1VAR2/ROVRS,ROLRS,SH,SUMDLI,SWDOINV,SWDO,HLRS,TLRS
      COMMON/RSC1VAR3/TW,TMI,GTUB,GAM,CORR,TVZ,TVRS,TVRSV,TLRSV,GP
      COMMON/RSC1VAR4/LEVS,YTOT,WEV,GAM0,VLRS,MLRS
      COMMON/RSC1VAR5/SWDODHDOINV,SUMDHLI,QSUP,HSS,QTUW,QCM
      COMMON/RSC1VAR6/MVZT,WVI,HVI,WLI,HLI,MVZ,MSC
      COMMON/RSC1VAR7/SWS,SWSDHS,SUMDI,SUMDHI
      COMMON/RSC1VAR8/ROMFW,WFDW,PFIN,PFOU,MLFW,MLSC,FTFF
      COMMON/RSC1VAR9/SHDSH,SHCND,SHDSC,SHFDW,SHV,SHL,SMV,SML
      COMMON/RSC1VAR10/TBMDSHZ,TBMCNDZ,TBMDSCZ,HSC,TLS,TSC,TFW
      COMMON/RSC1VAR11/QDSH,QDSC,QCND,QFDW,QCMT,QCMST
      COMMON/RSC1DER0/DRODHVRS,DRODPVRS,DRODHLRS,DRODPLRS
      COMMON/PIPPO/WVUDSH,WVUCND,WCCND,WCDSHT
C
C
      GAM0=1000.
C
C
C---decodifica dati
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      NUW     = DATI(IPD+2)
      SHOS    = DATI(IPD+3)
      SHIS    = DATI(IPD+4)
      TIVWT   = DATI(IPD+5)
      FCSA    = DATI(IPD+6)
      EQD     = DATI(IPD+7)
      SHTC    = DATI(IPD+8)
      NZDSH   = DATI(IPD+9)
      NTUB    = DATI(IPD+10)
      TUBOD   = DATI(IPD+11)
      TUBLENGH= DATI(IPD+12)
      DSHSUP  = DATI(IPD+13)
      CNDSUP  = DATI(IPD+14)
      UHTC    = DATI(IPD+15)
      SHID    = DATI(IPD+16)
      SHLENGH = DATI(IPD+17)
      SHIV    = DATI(IPD+18)
      AML0    = DATI(IPD+19)
      NDI     = DATI(IPD+20)
      SSCIZ   = DATI(IPD+21)
      DSCSUP  = DATI(IPD+22)
      NZCND   = DATI(IPD+23)
      NZDSC   = DATI(IPD+24)
      FTCSA   = DATI(IPD+25)
      FTEQD   = DATI(IPD+26)
      TTHICK  = DATI(IPD+27)
      TUBRO   = DATI(IPD+28)
      TUBCP   = DATI(IPD+29)
      TUBK    = DATI(IPD+30)
      DSHFCSA = DATI(IPD+31)
      DSHEQD  = DATI(IPD+32)
      CNDFCSA = DATI(IPD+33)
      CNDEQD  = DATI(IPD+34)
      DSCFCSA = DATI(IPD+35)
      DSCEQD  = DATI(IPD+36)
      HTA     = DATI(IPD+37)
C
      NZON=NZDSH+NZCND+NZDSC
      FNZON=FLOAT(NZON)
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C----- Superfici di scambio per cella nelle divere zone
C
      DSHSUPZ=DSHSUP/FLOAT(NZDSH)
      CNDSUPZ=CNDSUP/FLOAT(NZCND)
      DSCSUPZ=DSCSUP/FLOAT(NZDSC)
C
C----- Lunghezza dei tubi corrispondente alla superficie di scambio
C----- per cella nelle divere zone
C
      DSHSUPLZ=DSHSUPZ/(3.1415*TUBOD*FLOAT(NTUB))
      CNDSUPLZ=CNDSUPZ/(3.1415*TUBOD*FLOAT(NTUB))
      DSCSUPLZ=DSCSUPZ/(3.1415*TUBOD*FLOAT(NTUB))
C
C----- Massa di metallo complessiva del fascio tubiero
C
      TUBID=TUBOD-2.*TTHICK
      TUBMASS=TUBRO*FLOAT(NTUB)*TUBLENGH*3.1415*(TUBOD**2.-TUBID**2.)/4.
C
C----- Superficie esterna complessiva del fascio tubiero
C
      TUBSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBOD
C
C----- Massa di metallo per cella nelle divere zone del fascio tubiero
C      proporzionale al rapporto fra superficie di scambio della zona
C      e superficie esterna complesiva
C
      TBMDSHZ=DSHSUPZ/TUBSURF*TUBMASS
      TBMCNDZ=CNDSUPZ/TUBSURF*TUBMASS
      TBMDSCZ=DSCSUPZ/TUBSURF*TUBMASS
C
C
C----- Superficie interna complessiva del fascio tubiero
C
      TUBINSURF=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID
C
C
C----- Superfici di scambio interno (lato acqua alimento) per cella nelle
C----- divere zone del fascio tubiero
C
      TBSDSHZ=3.1415*TUBID*DSHSUPLZ*FLOAT(NTUB)
      TBSCNDZ=3.1415*TUBID*CNDSUPLZ*FLOAT(NTUB)
      TBSDSCZ=3.1415*TUBID*DSCSUPLZ*FLOAT(NTUB)
C
C
C----- Volume interno complessivo del fascio tubiero
C
      TUBINVOL=FLOAT(NTUB)*TUBLENGH*3.1415*TUBID**2./4.
C
C
C----- Volume interno (lato acqua alimento) nelle divere zone del fascio tubiero
C
      TBVDSHZ=FLOAT(NTUB)*DSHSUPLZ*3.1415*TUBID**2./4.
      TBVCNDZ=FLOAT(NTUB)*CNDSUPLZ*3.1415*TUBID**2./4.
      TBVDSCZ=FLOAT(NTUB)*DSCSUPLZ*3.1415*TUBID**2./4.
C
C----- Volume lato shell nelle divere zone
C
      SHVDSHZ=DSHSUPZ/(DSHSUP+CNDSUP+DSCSUP)*(TIVWT+SHIV)
      SHVCNDZ=CNDSUPZ/(DSHSUP+CNDSUP+DSCSUP)*(TIVWT+SHIV)
      SHVDSCZ=DSCSUPZ/(DSHSUP+CNDSUP+DSCSUP)*(TIVWT+SHIV)
C
C----- Superficie interna shell nelle divere zone
C
      SHSDSHZ=DSHSUPZ/(DSHSUP+CNDSUP+DSCSUP)*SHIS
      SHSCNDZ=CNDSUPZ/(DSHSUP+CNDSUP+DSCSUP)*SHIS
      SHSDSCZ=DSCSUPZ/(DSHSUP+CNDSUP+DSCSUP)*SHIS
C
C
C---decodifica variabili
C
      PWSS = XYU(IXYU  )*P0
C
      DO I=1,NZDSH
        HSD(I) = XYU(IXYU+I)*H0
      END DO
C
      HVRS = XYU(IXYU+NZDSH+1)*H0
C
      MLRS = XYU(IXYU+NZDSH+2)*AML0
C
      HLRS = XYU(IXYU+NZDSH+3)*H0
C
      DO I=1,NZDSC
        HLC(I) = XYU(IXYU+NZDSH+3+I)*H0
      END DO
C
      TAMS = XYU(IXYU+NZDSH+NZDSC+4)*T0
C
      DO I=1,NZON
        TM(I) = XYU(IXYU+NZDSH+NZDSC+4+I)*T0
      END DO
C
      DO I=1,NZON
        HF(I)=XYU(IXYU+NZDSH+NZDSC+NZON+4+I)*H0
      ENDDO
C
      TVRSV = XYU(IXYU+NZDSH+NZDSC+2*NZON+5)*T0
C
      TLRSV = XYU(IXYU+NZDSH+NZDSC+2*NZON+6)*T0
C
      LEVS = XYU(IXYU+NZDSH+NZDSC+2*NZON+7)
C
      WFDW = XYU(IXYU+NZDSH+NZDSC+2*NZON+8)*W0
C
      I0=IXYU+NZDSH+NZDSC+2*NZON+8
C
      DO J = 1,NE
        JW=2*J-1
        JH=JW+1
        WS(J) = XYU(I0+JW)*W0
        HS(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NE
C
      DO J = 1,NDI
        JW=2*J-1
        JH=JW+1
        WDI(J) = XYU(I0+JW)*W0
        HDI(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NDI
C
      DO J = 1,NUS
        JW=2*J-1
        JH=JW+1
        WSO(J) = XYU(I0+JW)*W0
        HSO(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NUS
C
      DO J = 1,NUW
        JW=2*J-1
        JH=JW+1
        WDO(J) = XYU(I0+JW)*W0
        HDO(J) = XYU(I0+JH)*H0
      END DO
C
      I0=I0+2*NUW
C
      PFIN=XYU(I0+1)*P0
      HFIN=XYU(I0+2)*H0
      PFOU=XYU(I0+3)*P0
      HFOU=XYU(I0+4)*H0
C
      FTFF=XYU(I0+5)*0.01
      ADSH=XYU(I0+6)
      ACND=XYU(I0+7)
      ACSC=XYU(I0+8)
      GSIF=XYU(I0+9)*GAM0
      ASSW=XYU(I0+10)
C
      TEST = XYU(I0+11)*T0
      GEST = XYU(I0+12)*GAM0
C
      IF(PWSS.LT.2.5E5) THEN
        PPTOL=10./P0
      ELSE IF(PWSS.LT.10.E5) THEN
        PPTOL=50./P0
      ELSE
        PPTOL=100./P0
      ENDIF
C
      TOLIN(1)=PPTOL
C
C---- Portate di fluido in igresso
C
      SWS=0.
      SWSDHS=0.
      SWSINV=0.
C
      DO J= 1,NE
        IF(WS(J).GT.0.) THEN
          SWS=SWS+WS(J)
          SWSDHS=SWSDHS+WS(J)*HS(J)
        ELSE
          SWSINV=SWSINV-WS(J)
        ENDIF
      END DO
C
C
C
C---- Portate di vapore in uscita (ultima zona di scambio)
C
      SWSOINV=0.
      SWSODHSOINV=0.
      SWSO=0.
C
      DO J= 1,NUS
        IF(WSO(J).LT.0.) THEN
          SWSOINV=SWSOINV-WSO(J)
          SWSODHSOINV=SWSODHSOINV-WSO(J)*HSO(J)
        ELSE
          SWSO=SWSO+WSO(J)
        ENDIF
      END DO
C
C
C---- Portate di liquido in uscita (zona di raccolta drenaggi)
C
      SWDOINV=0.
      SWDODHDOINV=0.
      SWDO=0.
C
      DO J= 1,NUW
        IF(WDO(J).LT.0.) THEN
          SWDOINV=SWDOINV-WDO(J)
          SWDODHDOINV=SWDODHDOINV-WDO(J)*HDO(J)
        ELSE
          SWDO=SWDO+WDO(J)
        ENDIF
      END DO
C
C
C-----  Protezione per pressioni ed entalpie fuori range
C
      PVTAV=PWSS
C
      IF(PVTAV.LE.810.8) THEN
        PVTAV=810.8
      ELSE IF(PVTAV.GE.400.E+05) THEN
        PVTAV=400.E+05
      ENDIF
C
      DO I=1,NZDSH
        HVTAV(I)=HSD(I)
      END DO
C
      PVT=PWSS
      HVT=HVRS
C
      IF(PVT.LE.810.8) THEN
        PVT=810.8
      ELSE IF(PVT.GE.400.E+05) THEN
        PVT=400.E+05
      ENDIF
C
      PLTAV=PWSS
      HLTAV=HLRS
C
      IF(PLTAV.LE.810.8) THEN
        PLTAV=810.8
      ELSE IF(PLTAV.GE.400.E+05) THEN
        PLTAV=400.E+05
      ENDIF
C
      FML=MLRS.GE.0.01
C
C----------------------------flussi di massa ed energia
C
      IF(PVTAV.LT.221.E+05)THEN
         CALL SATUR(PVTAV,2,HLS,HSS,NFL)
         CALL SATUR(PVTAV,3,RLS,RSS,NFL)
         CALL SATUR(PVTAV,7,TVS,Z,NFL)
      ELSE
         PCRITICA=221.E+05
         CALL SATUR(PCRITICA,2,HLS,HSS,NFL)
         CALL SATUR(PCRITICA,3,RLS,RSS,NFL)
         CALL SATUR(PCRITICA,7,TVS,Z,NFL)
      ENDIF
C
C
      SUMDLI=0.
      SUMDHLI=0.
      SUMDVI=0.
      SUMDHVI=0.
      SUMDHI=0.
      SUMDINV=0.
      SUMDI=0.

      DO J= 1,NDI
        IF(WDI(J).GT.0.) THEN
          SUMDI=SUMDI+WDI(J)
          SUMDHI=SUMDHI+WDI(J)*HDI(J)
	  XDI=(HDI(J)-HLS)/(HSS-HLS)
          IF (XDI.LE.0.) THEN
            HDLI(J)=HDI(J)
            WDLI(J)=WDI(J)
            HDVI(J)=HSS
            WDVI(J)=0.
          ELSE
            IF (XDI.GE.1.) THEN
              HDLI(J)=HLS
              WDLI(J)=0.
              HDVI(J)=HDI(J)
              WDVI(J)=WDI(J)
            ELSE
              HDLI(J)=HLS
              WDLI(J)=WDI(J)*(1.-XDI)
              HDVI(J)=HSS
              WDVI(J)=WDI(J)-WDLI(J)
            END IF
          END IF
          SUMDLI=SUMDLI+WDLI(J)
          SUMDHLI=SUMDHLI+WDLI(J)*HDLI(J)
          SUMDVI=SUMDVI+WDVI(J)
          SUMDHVI=SUMDHVI+WDVI(J)*HDVI(J)
        ELSE
          SUMDINV=SUMDINV-WDI(J)
        ENDIF
      END DO
C
C
C---- Pressione media dell'acqua alimento nel fascio tubiero
C
      PMFDW=(PFIN+PFOU)/2.
C
C---- Stato termodinamico dell'acqua alimento, densit� media (Vi=cost.)
C
      MFWTOT=0.
C
      DO I=1,NZON
        SFW=SHEV(PMFDW,HF(I),NFL)
        TFW(I)=TEV(PMFDW,SFW,NFL)
        ROFW(I)=ROEV(PMFDW,SFW,NFL)
      END DO
C
C
C---- Massa di liquido nelle diverse zone del fascio tubiero
C
      IF (COUNTERFLOW) THEN
        DO I=1,NZDSC
          MLFW(I)=ROFW(I)*TBVDSCZ
          MFWTOT=MFWTOT+MLFW(I)
	END DO
C
        DO I=NZDSC+1,NZDSC+NZCND
          MLFW(I)=ROFW(I)*TBVCNDZ
          MFWTOT=MFWTOT+MLFW(I)
        END DO
C
        DO I=NZDSC+NZCND+1,NZON
          MLFW(I)=ROFW(I)*TBVDSHZ
          MFWTOT=MFWTOT+MLFW(I)
        END DO
      ELSE
        DO I=1,NZDSH
	  MLFW(I)=ROFW(I)*TBVDSHZ
          MFWTOT=MFWTOT+MLFW(I)
        END DO
C
        DO I=NZDSH+1,NZDSH+NZCND
	  MLFW(I)=ROFW(I)*TBVCNDZ
          MFWTOT=MFWTOT+MLFW(I)
        END DO
C
        DO I=NZDSH+NZCND+1,NZON
	  MLFW(I)=ROFW(I)*TBVDSCZ
          MFWTOT=MFWTOT+MLFW(I)
        END DO
      END IF
C
      ROMFW=MFWTOT/TUBINVOL
C
C--- Tubes Side Heat Exchange Coefficient
C
      DO I=1,NZON
          CALL RSC1DITBOE(PMFDW,HF(I),WFDW,FTCSA,FTEQD,DITBOE(I))
      END DO
C
C
C---- Stato termodinamico della condensa sottoraffreddata e massa di liquido
C
C
      WEVLST=0.
C
      DO I=1,NZDSC
        SDSC=SHEV(PLTAV,HLC(I),NFL)
        TLS(I)=TEV(PLTAV,SDSC,NFL)
        MLSC(I)=MLRS/FLOAT(NZDSC)
	XLS=(HLC(I)-HLS)/(HSS-HLS)
	XLS=MAX(XLS,0.)
	XLS=MIN(XLS,1.)
	WEVLS(I)=XLS*MLSC(I)/TAUL
C	WEVLS(I)=0.
        WEVLST=WEVLST+WEVLS(I)
      END DO
C
C
C--- Subcooling Side Heat Exchange Coefficient
C
      DO I=1,NZDSC
        CALL RSC1DITBOE(PLTAV,HLC(I),SWDO,DSCFCSA,DSCEQD,SCDITBOE(I))
      END DO
C
C----- Calcolo proprieta' zona di raccolta liquido
C
      SLRS=SHEV(PLTAV,HLTAV,NFL)
      TLRS=TEV(PLTAV,SLRS,NFL)
      ROLRS=ROEV(PLTAV,SLRS,NFL)
      XLRS=(HLRS-HLS)/(HSS-HLS)
      XLRS=MIN(XLRS,1.)
      XLRS=MAX(XLRS,0.)
C
C
C--- derivata della densita` dell'acqua fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h  -  nella zona liquida
C
      DRODPLRS=1./A2EV(PLTAV,SLRS,NFL)
     &        -1./(ROLRS*TLRS)*BEV(PLTAV,SLRS,NFL)
C
C
C--- derivata della densita` dell'acqua fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p  -  nella zona liquida
C
      DRODHLRS=BEV(PLTAV,SLRS,NFL)/TLRS
C
C
C----- Calcolo proprieta' zona di raccolta del vapore
C
      SVRS=SHEV(PVT,HVT,NFL)
      TVRS=TEV(PVT,SVRS,NFL)
      ROVRS=ROEV(PVT,SVRS,NFL)
      XVRS=YEV(PVT,SVRS,NFL)
      XVRS=(HVRS-HLS)/(HSS-HLS)
      XVRS=MIN(XVRS,1.)
      XVRS=MAX(XVRS,0.)
C
C
C--- derivata della densita` dell'acqua fatta rispetto alla pressione,
C    ad entalpia costante [d@l/dP]h  -  nella zona vapore
C
      DRODPVRS=1./A2EV(PVT,SVRS,NFL)
     &        -1./(ROVRS*TVRS)*BEV(PVT,SVRS,NFL)
C
C
C--- derivata della densita` dell'acqua fatta rispetto all'entalpia,
C    a pressione costante [d@l/dHl]p  -  nella zona vapore
C
      DRODHVRS=BEV(PVT,SVRS,NFL)/TVRS
C
C--- Reduction factor for low pressure
C
      GP=0.5*(1.+TANH(PVTAV/15000.-3.))
C      GP=1.
      WCDSHT=0.
C
      MVZT=0.
C
      DO I=1,NZDSH
C
        SVZ=SHEV(PVTAV,HVTAV(I),NFL)
        TVZ(I)=TEV(PVTAV,SVZ,NFL)
        ROVZ=ROEV(PVTAV,SVZ,NFL)
        XVZ(I)=(HSD(I)-HLS)/(HSS-HLS)
        XVZ(I)=MIN(XVZ(I),1.)
        XVZ(I)=MAX(XVZ(I),0.)
C
        MVZT=MVZT+SHVDSHZ*ROVZ
        MVZ(I)=SHVDSHZ*ROVZ
C
        WCDSH(I)=(1.-XVZ(I))*MVZ(I)/TAUV
        IF (WCDSH(I).LT.0.) WCDSH(I)=0.
        WCDSHT=WCDSHT+WCDSH(I)
C
C
C--- Shell Side Desuperheating zone Heat Exchange Coefficient
C
        CALL RSC1HADAL(PVTAV,HVTAV(I),SWS,DSHFCSA,DSHEQD,HADAL(I))
      END DO
C
C
C--- Shell Side Condensing zone properties
C
      WITOT=SWS+SUMDVI
C
      MVCND=SHVCNDZ*ROVRS*FLOAT(NZCND)
      WCCND=(1.-XVRS)*MVCND/TAUV
      MVZT=MVZT+MVCND
C
C
C--- Shell Side Condensing zone Heat Exchange Coefficient
C
      DO I=1,NZCND
        IF (UHTC.LE.0.) THEN
          CALL RSC1HTC(PVT,TVRS,XVRS,TM(NZON-NZDSH-I),CNDEQD,WITOT
     $                 ,CNDFCSA,TUBLENGH,TUBOD,UHTC,GTUB(I))
        ELSE
          CALL RSC1GAMUT(PVT,HVT,SVRS,TVRS,ROVRS,XVRS,TM(I),EQD,WITOT
     $                   ,FCSA,TUBLENGH,TUBOD,UHTC,GTUB(I))
        ENDIF
      END DO
C
C
C---- Calcolo potenze termiche scambiate  ---------------------------------------
C
C---- Scambio nella zona di desurriscaldamento - lato shell
C
      QDSHT=0.
      QCMDSHT=0.
C
      QCMT=0.
      QCMST=0.
C
      DO I=1,NZDSH
C
        IF (COUNTERFLOW) THEN
	  ITB=NZON-I+1
	ELSE
	  ITB=I
	END IF
C
        QDSH(I)=ADSH*HADAL(I)*DSHSUPZ*(TVZ(I)-TM(ITB))
        QCMDSH(I)=GSIF*SHSDSHZ*(TVZ(I)-TAMS)
C       QCMDSH(I)=0.
        QCMDSHT=QCMDSHT+QCMDSH(I)
        QDSHT=QDSHT+QDSH(I)
C
      END DO
C
C
C---- Scambio nella zona di condensazione - lato shell
C
      QCNDT=0.
C
      DO I=1,NZCND
        IF (COUNTERFLOW) THEN
	  ITB=NZON-NZDSH-I+1
	ELSE
	  ITB=I+NZDSH
	END IF
        QCND(I)=ACND*GP*GTUB(I)*CNDSUPZ*(TVRS-TM(ITB))
        QCNDT=QCNDT+QCND(I)
      END DO
C
      QCMCND=GSIF*SHSCNDZ*(TVRS-TAMS)*FLOAT(NZCND)
C     QCMCND=0.
C
C
C---- Scambio nella zona di sottoraffreddamento - lato shell
C----        Scambio convettivo
C
      QDSCT=0.
C
      DO I=1,NZDSC
C
        IF (COUNTERFLOW) THEN
	  ITB=NZON-NZDSH-NZCND-I+1
	ELSE
	  ITB=I+NZDSH+NZCND
	END IF
C
        QDSC(I)=ACSC*SCDITBOE(I)*DSCSUPZ*(TLS(I)-TM(ITB))
        QDSCT=QDSCT+QDSC(I)
C       QCMS(I)=SHIHEC*SHSDSCZ*(TLS(I)-TAMS)
        QCMS(I)=ASSW*SCDITBOE(I)*SHSDSCZ*(TLS(I)-TAMS)
C       QCMS(I)=0.
        QCMTOT=QCMT+QCMS(I)
      END DO
C
C----        Scambio conduttivo
C
      SKX=16.49E-03*FCSA/0.012
C
      DO I=1,NZDSC-1
        QKSC(I)=SKX*(TLS(I+1)-TLS(I))
C        QKSC(I)=0.
      END DO
      QKSC(NZDSC)=0.
C
C---- Scambio nella zona di sottoraffreddamento - lato tubi
C
      DO I=1,NZDSC
        QFDW(I)=DITBOE(I)*TBSDSCZ*(TM(I)-TFW(I))
C       QFDW(I)=0.
      END DO
C
C
C---- Scambio nella zona di condensazione - lato tubi
C
      DO I=NZDSC+1,NZDSC+NZCND
        QFDW(I)=DITBOE(I)*TBSCNDZ*(TM(I)-TFW(I))
C       QFDW(I)=0.
      END DO
C
C
C---- Scambio nella zona di desurriscaldamento - lato tubi
C
      DO I=NZDSC+NZCND+1,NZDSC+NZCND+NZDSH
        QFDW(I)=DITBOE(I)*TBSDSHZ*(TM(I)-TFW(I))
C       QFDW(I)=0.
      END DO
C
C
C---- calore scambiato fra parete esterna shell e ambiente
C
C     QSHE=GEST*SHOS*(TAMS-TEST)
      QSHE=GEST*SHOS*(TAMS-TEST)
C
C
C---- Calcolo livello riscaldatore
C
C---- Volume della zona occupata dal liquido
C     (liquido + tubi ricoperti dal liquido)
C
      VLRS=MLRS/ROLRS
      VTL=VLRS
C     VTL=MLRS/1000.
C
      CALL  RSC1LIO(VTL,SHID,SHLENGH,YC,YTOT,AREA)
C
C
C
C--- calcolo della portata di evaporazione nel volume del liquido
C
      WEV=XLRS*MLRS/TAUL
C
C
C--- calcolo della potenza termica scambiata fra liquido e vapore
C    attraverso la superficie di separazione
C
      IF (FML) THEN
        QSUP=HSUR*AREA*(TVRS-TLRS)
      ELSE
        QSUP=0.
      ENDIF
C      QSUP=0.
C
      QCMCNDL=GSIF*AREA*(TLRS-TAMS)
C     QCMCNDL=0.
C
C     QCMT=QCMDSHT+QCMCND+QCMCNDL
      QCMT=QCMDSHT+QCMCND+QCMCNDL+QCMTOT
C
C--- l'evaporazione superficiale viene trascurata
C
C
C--- calcolo dei termini noti delle equazioni di conservazione dell'energia
C
      SHDSH(1)=SWSDHS-SWS*HSD(1)-QDSH(1)-QCMDSH(1)-WCDSH(1)*(HLS-HVRS)
C
      DO I=2,NZDSH
       SHDSH(I)=SWS*(HSD(I-1)-HSD(I))-WCDSH(I)*(HLS-HVRS)
     &         -QDSH(I)-QCMDSH(I)
      END DO
C
C
C--- si trascura la portata di condensazione/evaporazione superficiale
C
C     WEV=0.
C
C--- calcolo dei termini noti delle equazioni di conservazione della massa
C
C
      SMV=SWS+SUMDVI+SWSOINV-SWSINV-SWSO-WCDSHT-WCCND+WEV+WEVLST
C
      SML=SUMDLI+WCDSHT+WCCND+SWDOINV-SUMDINV-SWDO-WEV-WEVLST
C
C
      SHV=SWSDHS-SWS*HVRS+SUMDHVI-SUMDVI*HVRS+SWSODHSOINV-SWSOINV*HVRS
     &     -WCCND*(HLS-HVRS)-WCDSHT*(HLS-HVRS)+(WEV+WEVLST)*(HSS-HVRS)
     &     -QDSHT-QCMDSHT-QCNDT-QCMCND-QSUP
C
      SHL=SUMDHLI-SUMDLI*HLRS+SWDODHDOINV-SWDOINV*HLRS-WEV*(HSS-HLRS)
     &    +WCCND*(HLS-HLRS)+WCDSHT*(HLS-HLRS)+QSUP-QCMCNDL+QKSC(1)
C
C
      SHDSC(1)=(SWDO+WEVLS(1))*(HLRS-HLC(1))-QDSC(1)-QKSC(1)-QCMS(1)
C
      DO I=2,NZDSC
        SHDSC(I)=(SWDO+WEVLS(I))*(HLC(I-1)-HLC(I))
     &           -QCMS(I)-QDSC(I)-QKSC(I-1)+QKSC(I)
      END DO
C
C
        SHFDW(1)=WFDW*(HFIN-HF(1))+QFDW(1)
	DO I=2,NZON
          SHFDW(I)=WFDW*(HF(I-1)-HF(I))+QFDW(I)
	END DO

C
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni
C
C
	  CALL RSC1NF(IFUN,IPD,DATI,RNI)
C
C
      RETURN
      END
C
C---------------------------------------------------------------------------------
C
C      Calcolo stazionario e transitorio per riscaldatore flussato e non vuoto
C      ( massa di liquido non nulla )
C
C---------------------------------------------------------------------------------
C
C
      SUBROUTINE RSC1NF(IFUN,IPD,DATI,RNI)
C
C
      DIMENSION DATI(*),RNI(*)
C
      PARAMETER (MAXIO=10,MAXCI=15)
C
      DIMENSION GAM(MAXCI),GTUB(MAXCI),TFW(MAXCI)
      DIMENSION TW(MAXCI),TVZ(MAXCI),TSC(MAXCI),TLS(MAXCI)
      DIMENSION QDSH(MAXCI),QDSC(MAXCI),WVUDSH(MAXCI),WVUCND(MAXCI)
      DIMENSION QCMDSH(MAXCI),QTUW(MAXCI),QCND(MAXCI)
      DIMENSION QFDW(MAXCI),HSC(MAXCI)
      DIMENSION SHDSH(MAXCI),SHCND(MAXCI),SHDSC(MAXCI),SHFDW(MAXCI)
C
      COMMON/NORM/P0,H0,T0,W0,RO0,AL0,V0,DP0
      COMMON/PARPAR/NUL(7),ITERT
      COMMON/INTEGR/TSTOP,TEMPO,DTINT,NPAS,CDT,ALFADT
      COMMON/TOLEG00/TOLIN(100)
      LOGICAL KREGIM,COUNTERFLOW
      COMMON/REGIME/KREGIM
C
      COMMON/RSC1VAR0/SUMDVI,SWSOINV,SWSINV,WCP,SWSO,SUMDINV
      COMMON/RSC1VAR1/SUMDHVI,HVRS,SWSODHSOINV,HLS,QSHE,HW
      COMMON/RSC1VAR2/ROVRS,ROLRS,SH,SUMDLI,SWDOINV,SWDO,HLRS,TLRS
      COMMON/RSC1VAR3/TW,TMI,GTUB,GAM,CORR,TVZ,TVRS,TVRSV,TLRSV,GP
      COMMON/RSC1VAR4/LEVS,YTOT,WEV,GAM0,VLRS,MLRS
      COMMON/RSC1VAR5/SWDODHDOINV,SUMDHLI,QSUP,HSS,QTUW,QCM
      COMMON/RSC1VAR6/MVZT,WVI,HVI,WLI,HLI,MVZ,MSC
      COMMON/RSC1VAR7/SWS,SWSDHS,SUMDI,SUMDHI
      COMMON/RSC1VAR8/ROMFW,WFDW,PFIN,PFOU,MLFW,MLSC,FTFF
      COMMON/RSC1VAR9/SHDSH,SHCND,SHDSC,SHFDW,SHV,SHL,SMV,SML
      COMMON/RSC1VAR10/TBMDSHZ,TBMCNDZ,TBMDSCZ,HSC,TLS,TSC,TFW
      COMMON/RSC1VAR11/QDSH,QDSC,QCND,QFDW,QCMT,QCMST
      COMMON/RSC1DER0/DRODHVRS,DRODPVRS,DRODHLRS,DRODPLRS
      COMMON/PIPPO/WVUDSH,WVUCND,WCCND,WCDSHT
C
      REAL MVZ(MAXCI),MSC(MAXCI),MVZT,MLFW(MAXCI),MLSC(MAXCI)
      REAL LEVS,MLRS
C
C
      NE      = DATI(IPD  )
      NUS     = DATI(IPD+1)
      NUW     = DATI(IPD+2)
      SHOS    = DATI(IPD+3)
      SHIS    = DATI(IPD+4)
      TIVWT   = DATI(IPD+5)
      FCSA    = DATI(IPD+6)
      EQD     = DATI(IPD+7)
      SHTC    = DATI(IPD+8)
      NZDSH   = DATI(IPD+9)
      NTUB    = DATI(IPD+10)
      TUBOD   = DATI(IPD+11)
      TUBLENGH= DATI(IPD+12)
      DSHSUP  = DATI(IPD+13)
      CNDSUP  = DATI(IPD+14)
      UHTC    = DATI(IPD+15)
      SHID    = DATI(IPD+16)
      SHLENGH = DATI(IPD+17)
      SHIV    = DATI(IPD+18)
      AML0    = DATI(IPD+19)
      NDI     = DATI(IPD+20)
      SSCIZ   = DATI(IPD+21)
      DSCSUP  = DATI(IPD+22)
      NZCND   = DATI(IPD+23)
      NZDSC   = DATI(IPD+24)
      FTCSA   = DATI(IPD+25)
      FTEQD   = DATI(IPD+26)
      TTHICK  = DATI(IPD+27)
      TUBRO   = DATI(IPD+28)
      TUBCP   = DATI(IPD+29)
      TUBK    = DATI(IPD+30)
      HTA     = DATI(IPD+37)
C
      NZON=NZDSH+NZCND+NZDSC
C
      IF (HTA.LE.0.) THEN
        COUNTERFLOW=.TRUE.
      ELSE
        COUNTERFLOW=.FALSE.
      END IF
C
C--- Calcolo dei termini delle perdite di carico dell'acqua alimento
C
      CDPFDW=0.5*TUBLENGH/(FTEQD*FTCSA**2.*ROMFW)
C
C--- Calcolo dei coefficienti e dei termini noti delle equazioni
C
      A11=MVZT/(ROVRS*ROVRS)*DRODHVRS
      A12=VLRS/ROLRS*DRODHLRS
      A13=MVZT/(ROVRS*ROVRS)*DRODPVRS+VLRS/ROLRS*DRODPLRS
      A21=MVZT
      A23=-MVZT/ROVRS
      A32=MLRS
      A33=-VLRS
C
      AV11=MVZT
      AV12=-(SHIV+TIVWT)
      AV21=(SHIV+TIVWT)*DRODHVRS
      AV22=(SHIV+TIVWT)*DRODPVRS
      DETV=AV11*AV22-AV12*AV21
C
      TN1V=SHV
      TN2V=SMV+SML
C
C--- Calcolo del determinate
C
      DET=A21*A32*A13-A23*A32*A11-A12*A21*A33
C
C--- Calcolo dei termini noti delle equazioni
C
C
      SKX=16.49E-03*FCSA/0.012
C     SKX=0.
C
      TN1=SMV/ROVRS+SML/ROLRS
      TN2=SHV
      TN3=SHL
C
C--- Calcolo della derivata della pressione  dP/dt
C
      DPDT=(A21*A32*TN1-TN2*A32*A11-A12*A21*TN3)/DET
      DPDTV=(AV11*TN2V-AV21*TN1V)/DETV
C
C
C--- Calcolo della derivata dell'entalpia del vapore  dHv/dt
C
      DHVDT=(TN2*A32*A13+A12*A23*TN3-A23*A32*TN1-A12*TN2*A33)/DET
      DHVDTV= (TN1V*AV22-TN2V*AV12)/DETV
C
C--- Calcolo della derivata dell'entalpia del liquido  dHl/dt
C
      DHLDT=(A11*TN2*A33+A21*TN3*A13-A23*TN3*A11-TN1*A21*A33)/DET
      DHLDTV=SHL/(MLRS+MVZT)
C
C
C
C
C___ Pressione nel riscaldatore
C
      IF (KREGIM) THEN
        RNI(1)= SMV/W0
      ELSE
        RNI(1)=DPDT/P0
      END IF
C        RNI(1)=DPDT/P0
C
C
C___ Entalpia vapore zona di desurriscaldamento
C
      DO I=1,NZDSH
        RNI(1+I)=SHDSH(I)/(MVZ(I)*H0)
      END DO
C
C
C___ Entalpia vapore zona di condensazione
C
        RNI(NZDSH+2)= DHVDT/H0
C
C
C___ Massa di liquido raccolto sul fondo
C
        RNI(NZDSH+3)=SML/AML0
C
C
C___ Entalpia liquido raccolto sul fondo
C
         RNI(NZDSH+4)=DHLDT/H0
C
C
C___ Entalpia liquido sottoraffreddato
C
      DO I=1,NZDSC
        RNI(NZDSH+4+I)=SHDSC(I)/(MLSC(I)*H0)
      END DO
C
C
C___ Temperatura metallo parete shell
C
      RNI(NZDSH+NZDSC+5)=(QCMT-QSHE)/(SHTC*T0)
C
C
C___ Temperatura metallo fascio tubiero
C
      DO I=1,NZDSC
        IF (COUNTERFLOW) THEN
	  ISH=NZDSC-I+1
 	ELSE
 	  ISH=NZDSH+NZCND+I
  	END IF
        IF (KREGIM) THEN
          RNI(NZDSH+NZDSC+5+I)=(QDSC(ISH)-QFDW(I))/(W0*H0)
        ELSE
          RNI(NZDSH+NZDSC+5+I)=(QDSC(ISH)-QFDW(I))/(TBMDSCZ*T0)
        END IF
      END DO
      DO I=1,NZCND
        IF (COUNTERFLOW) THEN
	  ISH=NZCND-I+1
 	ELSE
 	  ITB=NZDSH+I
 	END IF
        IF (KREGIM) THEN
          RNI(NZDSH+2*NZDSC+5+I)=(QCND(ISH)-QFDW(NZDSC+I))/(W0*H0)
        ELSE
          RNI(NZDSH+2*NZDSC+5+I)=(QCND(ISH)-QFDW(NZDSC+I))/(TBMCNDZ*T0)
        END IF
      END DO
C
      DO I=1,NZDSH
        IF (COUNTERFLOW) THEN
	  ISH=NZDSH-I+1
 	ELSE
 	  ITB=I
 	END IF
        IF (KREGIM) THEN
          RNI(NZON+NZDSC+5+I)=(QDSH(ISH)-QFDW(NZDSC+NZCND+I))/(W0*H0)
        ELSE
        RNI(NZON+NZDSC+5+I)=(QDSH(ISH)-QFDW(NZDSC+NZCND+I))/(TBMDSHZ*T0)
        END IF
      END DO
C
C
C___ Entalpia acqua alimento
C
      DO I=1,NZON
        RNI(NZON+NZDSC+NZDSH+5+I)= SHFDW(I)/(MLFW(I)*H0)
      END DO
C
C
C___ Temperatura vapore fra mantello e cassa interna
C
      RNI(2*NZON+NZDSC+NZDSH+6)=(TVRSV-TLS(NZDSC))/T0
C
C
C___ Temperatura liquido raccolto sul fondo
C
C
      RNI(2*NZON+NZDSC+NZDSH+7)=(TLRSV-TFW(NZON))/T0
C
C
C___ Livello acqua
C
      RNI(2*NZON+NZDSC+NZDSH+8)=LEVS-YTOT
C
C
C___ Portata acqua alimento nel fascio tubiero
C
      IF ((PFIN-PFOU).GE.0.) THEN
        S=1.
      ELSE
        S=-1.
      END IF
C
      RNI(2*NZON+NZDSC+NZDSH+9)=
C    &             (PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/(W0*W0)
C    &             (S*(ABS(PFIN-PFOU))**0.5-WFDW*(FTFF*CDPFDW)**0.5)/W0
C    &             (S*(ABS(PFIN-PFOU)/CDPFDW)**0.5-WFDW*(FTFF)**0.5)/W0
     &             (PFIN-PFOU-FTFF*CDPFDW*WFDW*ABS(WFDW))/P0
C
C
C
      RETURN
      END
C---------------------------------------------------------------------------------
C************************************************************************
      SUBROUTINE RSC1D1 (BLOCCO,NEQUAZ,NSTATI,NUSCIT,NINGRE,SYMVAR,XYU,
     $                   IXYU,DATI,IPD,SIGNEQ,UNITEQ,COSNOR,ITOPVA,MXT)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      RETURN
      END
C************************************************************************
      SUBROUTINE RSC1HTC(P,T,TIT,TP,D,W,SEZ,LTUB,DETB,UHTC,HTCC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Heat transfert correlations:
C
C    Condensation correlation
C
C Note
C      ALPHA = interpolation term for film temperature
C         XT = interpolation term between heat transfert coefficient for
C              laminar nonrippling and turbulent condensate flow
C
      PARAMETER (G=9.81)
      PARAMETER (ALPHA=1.)
      PARAMETER (GCONST=4570.) !GAMMA costante di condensazione
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL LTUB
      REAL HTCC,LUNG,LF,MF
C
      NFL=1
C
      VERT=0.
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
      TF=ALPHA*T+(1.-ALPHA)*TP
C
      MF=ETEV(P,TF,ROW,RWV,TIT,0.5,NFL)
      MF=AMAX1(9.216E-06,MF)
      LF=ALEV(P,TF,ROW,RWV,TIT,0.5,NFL)
      LF=AMAX1(16.49E-03,LF)
      DHVAP=HVS-HLS
      DTWALL=AMAX1(1.,ABS(T-TP))
C
C      IF (UHTC.EQ.0.) THEN
C        HTCC=GCONST
C      ELSE
        IF (VERT.EQ.0.) THEN
          COE=0.7235  !tubi orizzontali
          LUNG=DETB
        ELSE
          COE=0.94    !tubi verticali
          LUNG=LTUB
        ENDIF
C
        GCTURB=0.003*(((LF**3)*(ROW**2)*G*DTWALL*LUNG)/
     $                 (MF**3*DHVAP))**0.5
C
        GCLAM=COE*(((LF**3)*(ROW**2)*G*DHVAP)/(MF*LUNG*DTWALL))**0.25
C
        HTCC=0.5*(GCLAM+GCTURB)
C
C      ENDIF
C
C
C     HTC=HAD
C     HTC=DB
      HTCC=MAX(HTCC,HTSTAT)
C
      RETURN
      END
C
C
C
      SUBROUTINE RSC1LIO(VCAV,DCAV,HLCAV,Y,YTOT,SEZ)
C
C CALCOLA IL LIVELLO  IN UN CILINDRO ORIZZONTALE
C
C     Y  livello diviso 100
C     YTOT livello in metri
C     SEZ  superficie del pelo libero
C NOTI:
C     VCAV  volume occupato
C     DCAV  diametro del cilindro
C     HLCAV lunghezza del cilindro
C
C ESECUZIONE
C
      RCAV=DCAV/2.
      Y0=Y
      VMAX=RCAV*RCAV*3.141592*HLCAV
      IF(VCAV.LT.VMAX)GO TO 99
      YTOT=2*RCAV
      Y=YTOT/100.
      SEZ=0.
      RETURN
   99 IF(VCAV.GT.1.E-3)GO TO 98
      YTOT=0.
      Y=0.
      SEZ=0.
      RETURN
C
C     CALCOLO IETERATIVO SECONDO NEWTON-RAPHSON
C
   98 IT=0
      Y=RCAV
    1 IT=IT+1
C
C ALFA: ANGOLO AL CENTRO DEL SEGMENTO CIRCOLARE
C
      ALFA=ACOS((RCAV-Y)/RCAV)
      AST=RCAV**2.*ALFA-RCAV*(RCAV-Y)*SIN(ALFA)
C
C
C   RESIDUO
C
      RES=VCAV-HLCAV*AST
C
      IF(ABS(RES).LT.1.E-4)GO TO 10
      IF(IT.GT.100)GO TO 20
C
C     JACOBIANO
C
      DALFA=1./(RCAV*SQRT(1.-((RCAV-Y)/RCAV)**2.))
      DASOT=RCAV**2.*DALFA+RCAV*SIN(ALFA)+COS(ALFA)*RCAV*
     $ DALFA*(Y-RCAV)
      DVDY=DASOT*HLCAV
C
C   ITERAZIONE
C
      DY=RES/DVDY
      Y=Y+DY
      GO TO 1
C
C   SOLUZIONE
C
   10 CONTINUE
      YTOT=Y
      SEZ=HLCAV*2*SQRT(2*RCAV*Y-Y*Y)
      Y=Y/100.
      RETURN
   20 WRITE(6,1000)RES
 1000 FORMAT(//10X,'SUBROUTINE RSC1LCO'/
     $  10X,'SUPERATO ITERAZ. MAX - RESIDUO = ',E12.5//)
      GO TO 10
      END
C
C************************************************************************
      SUBROUTINE RSC1DITBOE(P,H,W,SEZ,D,DBHTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Dittus-Boelter Heat transfert correlation
C
C
C
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL MU,LAM
C
      NFL=1
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      SFW=SHEV(P,H,NFL)
      TFW=TEV(P,SFW,NFL)
      RO=ROEV(P,SFW,NFL)
C
      TIT=YEV(P,SFW,NFL)
C
      CP=CPEV(P,SFW,TIT,0.5,NFL)
      MU=ETEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,TFW,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
      RE=ABS(W)*D/(SEZ*MU)
      PR=CP*MU/LAM
      DBHTC=.023*LAM*RE**.8*PR**.4/D+HTSTAT
C
      RETURN
      END
C
C
C************************************************************************
      SUBROUTINE RSC1HADAL(P,H,W,SEZ,D,HADHTC)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)
C
C************** Hadaller Heat transfert correlation
C
C
C
      PARAMETER (HTSTAT=5.) !GAMMA statico
      REAL MU,LAM
C
      NFL=1
C
      IF(P.LT.221.2E5) THEN
       CALL SATUR(P,3,ROW,ROV,NFL)
       CALL SATUR(P,2,HLS,HVS,NFL)
       CALL SATUR(P,7,TSAT,ZOT,NFL)
       RWV=ROW/ROV
      ELSE
       TSAT=647.3
       RWV=1.
      ENDIF
C
      S=SHEV(P,H,NFL)
      T=TEV(P,S,NFL)
      RO=ROEV(P,S,NFL)
C
      TIT=YEV(P,S,NFL)
C
      CP=CPEV(P,S,TIT,0.5,NFL)
      MU=ETEV(P,T,RO,RWV,TIT,0.5,NFL)
      MU=AMAX1(9.216E-06,MU)
      LAM=ALEV(P,T,RO,RWV,TIT,0.5,NFL)
      LAM=AMAX1(16.49E-03,LAM)
      RE=ABS(W)*D/(SEZ*MU)
      PR=CP*MU/LAM
      HADHTC=.008348*LAM*RE**.8774*PR**.6112/D+HTSTAT
C
      RETURN
      END
C
C
C
C~FORAUS_RSC1~C
C
C      SUBROUTINE RSC1GAMUT(PWSS,HSD(I),SVZ(I),TVZ(I),ROVZ(I),XVZ(I),
C     $                      TMI,EQD,TUBDISP,SWS,FCSA,
C     $                      TUBLENGH,TUBOD,UHTC,GAMMA,VWMASS,TIVWT)
C      GAMMA = 5000.
C      RETURN
C      END
C
C~FORAUS_RSC1~C
C
