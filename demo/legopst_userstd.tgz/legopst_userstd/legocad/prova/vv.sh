#!/bin/bash
viewval WVAL1___
viewval HOUT1___
viewval HUSI1___
viewval PIVA1___
viewval HVIN1___
viewval PUVA1___
viewval HDSI1___
viewval ALZA1___
