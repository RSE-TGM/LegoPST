C
C~FORAUS_CFH0~C
C
       SUBROUTINE CFH0_USR_THTC(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
           WRITE(6,*) 'ATTENZIONE: fornire routine CFH0USRDITBOE!!'  
C      DITBOE=14000.
       STOP
       END
C
C
       SUBROUTINE CFH0_USR_SHTC(P,H,W,SEZ,D,HADHTC)
         WRITE(6,*) 'ATTENZIONE: fornire routine CFH0HADALUT!!'  
C      HADHTC = 5000.
       STOP
       END
C
C~FORAUS_CFH0~C
C
C
C~FORAUS_CNDN~C
      SUBROUTINE CNDLIV(TYP,Y,VL,DVLDY,YPER)
      WRITE(6,*) 'ATTENZIONE: fornire routine CNDLIV!!'  
      STOP
      END
C~FORAUS_CNDN~C
C
C
C~FORAUS_DRIS~C
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE DRISGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]
C
C__________ SE VUOI CHE LA SUBROUTINE DRISGAMUT SIA CHIAMATA DA TUBS
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   CRIG < 0.
C
C  La subroutine fornisce al modulo TUBS il coefficiente di scambio
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]
C   H     entalpia specifica del fluido           [J/kg]
C   S     entropia specifica del fluido           [J/kg/C]
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]
C   TITOL titolo della miscela
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   CRIG  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato
C         come si vuole.
C         RICORDATI CHE CRIG E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]
C   Q     potenza totale scambiata                [W]
C   SUP   superficie di scambio                   [m**2]
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE DRISGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C
C
      SUBROUTINE DRISGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C
      WRITE(6,*) 'ATTENZIONE: fornire routine DRISGAMUT!!'
      STOP
      END
C
C
C~FORAUS_DRIS~C
C
C~FORAUS_DSR0~C
C
      SUBROUTINE DSR0HADALUT(PVTAV,HVTAV,SWS,FCSA,EQD,HADAL)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR0HADALUT  ****'
      RETURN
      END
C
C     SUBROUTINE DSR0HADALUT(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL)
C
C      HADAL = 500.
C      RETURN
C      END
C
C~FORAUS_DSR0~C
C
C
C
C~FORAUS_DSR0~C
C
      SUBROUTINE DSR0USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR0USRDITBOE ****'
      RETURN
      END
C
C     SUBROUTINE DSR0USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
C
C      DITBOE = 500.
C      RETURN
C      END
C
C~FORAUS_DSR0~C
C
C
C~FORAUS_DSR2~C
C
      SUBROUTINE DSR2HADALUT(PVTAV,HVTAV,SWS,FCSA,EQD,HADAL)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR2'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR2HADALUT  ****'
      RETURN
      END
C
C     SUBROUTINE DSR2HADALUT(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL)
C
C      HADAL = 500.
C      RETURN
C      END
C
C~FORAUS_DSR2~C
C
C
C~FORAUS_DSR2~C
C
      SUBROUTINE DSR2USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR2'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR2USRDITBOE ****'
      RETURN
      END
C
C     SUBROUTINE DSR2USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
C
C      DITBOE = 500.
C      RETURN
C      END
C
C~FORAUS_DSR2~C
C
C
C~FORAUS_DSH0~C
C
      SUBROUTINE DSH0HADALUT(PVTAV,HVTAV,SWS,FCSA,EQD,HADAL)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSH0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSH0HADALUT  ****'
      RETURN
      END
C
C     SUBROUTINE DSH0HADALUT(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL)
C
C      HADAL = 500.
C      RETURN
C      END
C
C~FORAUS_DSH0~C
C
C
C
C~FORAUS_DSH0~C
C
      SUBROUTINE DSH0USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSH0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSH0USRDITBOE ****'
      RETURN
      END
C
C     SUBROUTINE DSH0USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
C
C      DITBOE = 500.
C      RETURN
C      END
C
C~FORAUS_DSH0~C
C
C~FORAUS_DSR1~C
C
      SUBROUTINE DSR1HADALUT(PVTAV,HVTAV,SWS,FCSA,EQD,HADAL)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR1HADALUT  ****'
      RETURN
      END
C
C     SUBROUTINE DSR1HADALUT(PVTAV,HVTAV(I),SWS,FCSA,EQD,HADAL)
C
C      HADAL = 500.
C      RETURN
C      END
C
C~FORAUS_DSR0~C
C
C
C
C~FORAUS_DSR0~C
C
      SUBROUTINE DSR1USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO DSR0'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** DSR1USRDITBOE ****'
      RETURN
      END
C
C     SUBROUTINE DSR1USRDITBOE(PMFDW,HF,WFDW,FTCSA,FTEQD,DITBOE)
C
C      DITBOE = 500.
C      RETURN
C      END
C
C~FORAUS_DSR1~C
C
C
C~FORAUS_EXCH~C
      SUBROUTINE EXCHGAMUT(PMI,HM,SM,TF,ROM,TITOL, 
     $                     TPI,DIAI,CRIG,G,QTI,SS,GAMMA)        
      WRITE(6,*) 'ATTENZIONE: fornire routine EXCHGAMUT!!'  
      STOP
      END
C~FORAUS_EXCH~C
C~FORAUS_EXCY~C
      SUBROUTINE EXCYGAMUT(PMI,HM,SM,TF,ROM,TITOL, 
     $                     TPI,DIAI,CRIG,G,QTI,SS,GAMMA)        
      WRITE(6,*) 'ATTENZIONE: fornire routine EXCYGAMUT!!'  
      STOP
      END
C~FORAUS_EXCY~C
C~FORAUS_EXCW~C
      SUBROUTINE EXCWGAMUT(PMI,HM,SM,TF,ROM,TITOL, 
     $                     TPI,DIAI,CRIG,G,QTI,SS,GAMMA)        
      WRITE(6,*) 'ATTENZIONE: fornire routine EXCWGAMUT!!'  
      STOP
      END
C~FORAUS_EXCW~C
C~FORAUS_VALV~C
      REAL FUNCTION AVNS10(Z,ALFA)
      WRITE(6,*) 'ATTENZIONE: fornire routine AVNS10!!' 
      STOP
      END
C
      REAL FUNCTION CFNS10(Z,A,CFA)
      WRITE(6,*) 'ATTENZIONE: fornire routine CFNS10!!'
      STOP
      END
C~FORAUS_VALV~C
C~FORAUS_CPOM~C
      SUBROUTINE DPU(TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
      WRITE(6,*) 'ATTENZIONE: fornire routine DPU!!'
      STOP
      END
C
C~FORAUS_CPOM~C
C~FORAUS_TANK~C
      SUBROUTINE TANKLIV(TYP,VLIV,Y,YTOT,AREA)
      WRITE(6,*) 'ATTENZIONE: fornire routine TANKLIV!!'  
      STOP
      END
C~FORAUS_TANK~C
C~FORAUS_TURG~C
      REAL FUNCTION TGXUTXFU10(QTGP,FTAMB)
      WRITE(6,*) 'ATTENZIONE: fornire routine TGXUTXFU10!!' 
      STOP
      END
C
      REAL FUNCTION TGXUTXFF14(POYX,FTAMB)          
      WRITE(6,*) 'ATTENZIONE: fornire routine TGXUTXFF14!!'
      STOP
      END
C~FORAUS_TURG~C
C~FORAUS_BPM0~C
      SUBROUTINE DPU_B0(TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,
     $                  Q,RO,OM,DP,CRES)
      WRITE(6,*) 'ATTENZIONE: fornire routine DPU_B0!!'
      STOP
      END
C~FORAUS_BPM0~C
C~FORAUS_BCN0~C
      SUBROUTINE BCNLIV(TYP,Y,VL,DVLDY,YPER)
      WRITE(6,*) 'ATTENZIONE: fornire routine BCNLIV!!'
      STOP
      END
C~FORAUS_BCN0~C
C
C~FORAUS_DEG0~C
C
      SUBROUTINE DEG0LIV(TYP,VLIV,Y,YTOT,AREA)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        WRITE(6,1000)
 1000   FORMAT(/10X,'*** ATTENZIONE ! FORNIRE LA SUBROUTINE UTENTE'
     $        ,' "DEG0LIV" OPPURE SEZ_Y > 0. NEL FILE 14 ***'/)
        STOP 'ESECUZIONE ARRESTATA DALLA SUBROUTINE "DEG0LIV" DI DEG0'
        END
C
C FORTRAN AUSILIARIO DEL MODULO CAVITA` LIQUIDO-VAPORE CON ARIA
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE DEG0LIV(TYP,VLIV,Y,YTOT,AREA)
C
C  La subroutine DEG0LIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  DEG0  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  DEG0LIV(TYP,VLIV,Y,YTOT,AREA)
C     RETURN
C     END
C
C~FORAUS_DEG0~C
C
C~FORAUS_WAD1~C
C
      SUBROUTINE WAD1LIV(TYP,VLIV,Y,YTOT,AREA)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        WRITE(6,1000)
 1000   FORMAT(/10X,'*** ATTENZIONE ! FORNIRE LA SUBROUTINE UTENTE'
     $        ,' "WAD1LIV" OPPURE SEZ_Y > 0. NEL FILE 14 ***'/)
        STOP 'ESECUZIONE ARRESTATA DALLA SUBROUTINE "WAD1LIV" DI WAD1'
        END
C
C FORTRAN AUSILIARIO DEL MODULO CAVITA` LIQUIDO-VAPORE CON ARIA
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE WAD1LIV(TYP,VLIV,Y,YTOT,AREA)
C
C  La subroutine WAD1LIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  WAD1  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  WAD1LIV(TYP,VLIV,Y,YTOT,AREA)
C     RETURN
C     END
C
C~FORAUS_WAD1~C
C
C~FORAUS_VAL0~C
      REAL FUNCTION VAL0AVNS10(Z,ALFA)
      WRITE(6,*) 'ATTENZIONE: fornire routine AVNS10!!' 
      STOP
      END
C
      REAL FUNCTION VAL0CFNS10(Z,A,CFA)
      WRITE(6,*) 'ATTENZIONE: fornire routine CFNS10!!'
      STOP
      END
C~FORAUS_VAL0~C
C~FORAUS_CND0~C
C
C FORTRAN AUSILIARIO DEL MODULO CONDENSATORE DI VAPORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE CND0LIV(TYP,Y,VL,DVLDY,YPER)
C
C  La subroutine CND0LIV, in funzione dei valori TYP e Y
C  deve fornire  VL, DVLDY e YPER.
C
C  Parametri in ingresso:  TYP, Y
C  Parametri in uscita:    VL, DVLDY, YPER
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato TYPE_CAV nel file F14 (vedi scheda D1)  viene
C              utilizzato per distinguere le  diverse  geometrie  delle  cavita`
C              trattate dal modulo CND0 presenti contemporaneamente in un model-
C              lo matematico. Viene di solito usato all'interno della subroutine
C              come puntatore;
C
C  Y         = rappresenta la misura del livello totale nella cavita`in metri;
C
C  VL        = volume occupato dalla zona liquida in m**3;
C
C  DVLDY     = derivata del volume del liquido rispetto al livello;
C
C  YPER      = livello di liquido nel range di misura in %.
C
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
      SUBROUTINE  CND0LIV(TYP,Y,VL,DVLDY,YPER)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      RETURN
      END
C
C~FORAUS_CND0~C
C~FORAUS_STAZ~C 
C
C****** SUBROUTINE DI ACQUISIZIONE DATI PER LA TURBINA ANSALDO DA 320 MW *****
C
       SUBROUTINE   DXSTAZ (TIPO,
     $              R,AALAM,UDVU,CCR,AETA,BETA,CEME,NVALV,
     $              CA,CCF,AUG,NIA,CAV,CK,NIP,CPV,NIPF,CPVF,ALFA,HRIF,
     $              PSHNOM,TSHNOM,VUNOM,WNOM,RAGGIO,DPVE,PSHF,TSHF,
     $              RCA,XF,WF,IAM)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
       DIMENSION   
     $              CA(16),CCF(16,3),AUG(16),NIA(16),CAV(16,3,4),
     $              NIP(16),CPV(16,10,4),CPVF(10,4),RCA(16),IAM(16)
C
C
C      SUBROUTINE DA COMPILARE ACURA DELL'UTENTE
C
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO STAZ'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE I DATI DI UNA TURBINA '
      WRITE(6,*)' DIVERSA DA QUELLE INCLUSE NEL MODULO'
      WRITE(6,*)' OVVERO : TOSI_320,TOSI_660,ANS_320'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE UTENTE' 
      WRITE(6,*)' *****   DXSTAZ   ****'
C   
      STOP 'ESECUZIONE ARRESTATA DALLA SUBROUTINE "DXSTAZ" DI STAZ'
C
      END
C
C FORTRAN AUSILIARIO DEL MODULO TURBINA STADIO AD AZIONE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O 
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C********************* ESEMPIO DI SUBROUTINE UTENTE **************************
C****** SUBROUTINE DI ACQUISIZIONE DATI PER LA TURBINA ANSALDO DA 320 MW *****
C
C       SUBROUTINE DXSTAZ(TIPO,
C     $              R,AALAM,UDVU,CCR,AETA,BETA,CEME,NVALV,
C     $              CA,CCF,AUG,NIA,CAV,CK,NIP,CPV,NIPF,CPVF,ALFA,HRIF,
C     $              PSHNOM,TSHNOM,VUNOM,WNOM,RAGGIO,DPVE,PSHF,TSHF,
C     $              RCA,XF,WF,IAM)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       DIMENSION   
C     $              CA(16),CCF(16,3),AUG(16),NIA(16),CAV(16,3,4),
C     $              NIP(16),CPV(16,10,4),CPVF(10,4),RCA(16),IAM(16)
C       DIMENSION   
C     $             D_CA(16),D_CCF(16,3),D_AUG(16),ID_NIA(16),
C     $             D_CAV(16,3,4),ID_NIP(16),D_CPV(16,10,4),
C     $             D_CPVF(10,4),D_RCA(16),ID_IAM(16)
C      CHARACTER*36 TIPO
C      CHARACTER*37 D_TIPO
CC
C      DATA D_TIPO/'      TURBINA ANSALDO DA 320 MW      '/
CC
CC
C      DATA D_PSHNOM,D_TSHNOM,D_VUNOM,D_WNOM,D_RAGGIO,D_CCR,D_AETA,
C     $     D_BETA,D_DPVE,D_PSHF,D_TSHF,D_XF,D_WF,ID_NVALV,ID_NIPF
CC
C     $/ 16670000.,   811.15  ,  50.      , 299.145   , .4826     , 
CC        PSHNOM      TSHNOM     VUNOM       WNOM       RAGGIO    
CC
C     $  .00002132,    -3.57  ,   3.228   ,  294000.  , 16670000. ,
CC          CCR         AETA      BETA        DPVE        PSHF
CC
C     $    811.15 ,      1.   ,  299.145  ,    4      ,    1      /
CC          TSHF         XF        WF        NVALV        NIPF
CC
C      DATA (ID_IAM(I),I=1,4)/1,2,1,2/
CC
CC                  CARICAMENTO VETTORE RCA
CC
C                     DATA (D_RCA(I),I=1,  4   )
CC                                     NVALV
CC
C     $/   1.    ,  .84037   , .84037  ,    1.     /
CC        (1)         (2)        (3)       (4)
CC
CC
CC                  CARICAMENTO VETTORE CCF
CC
C                DATA ((D_CCF(I,J),J=1,  3   ),I=1, 4 )
CC                                               NVALV
CC
C     $/   .14  ,  -.49   ,  .93    ,   .14   ,  -.49   ,  .93    ,
CC        (1,1)    (1,2)    (1,3)      (2,1)     (2,2)    (2,3)
C     $    .14  ,  -.49   ,  .93    ,   .14   ,  -.49   ,  .93    /
CC        (3,1)    (3,2)    (3,3)      (4,1)     (4,2)    (4,3)
CC
CC                  CARICAMENTO VETTORE AUG
CC
C                     DATA (D_AUG(I),I=1,  4   )
CC                                     NVALV
CC
C     $/.0063904,.0053541 , .0053541, .006394/
CC        (1)       (2)       (3)       (4)
CC
CC                  CARICAMENTO VETTORE NIA
CC
C                     DATA (ID_NIA(I),I=1,  4   )
CC                                     NVALV
CC
C     $/    2   ,    2    ,    2    ,   2    /
CC         (1)      (2)       (3)      (4)
CC
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 1
CC
C        DATA ((D_CAV(1,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(1)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/            
CC         z         a            b            c     
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 2
CC
C        DATA ((D_CAV(2,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(2)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/            
CC         z         a            b            c     
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 3
CC
C        DATA ((D_CAV(3,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(3)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/            
CC         z         a            b            c     
CC
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 4
CC
C        DATA ((D_CAV(4,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(4)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/            
CC         x         a            b            c     
CC
CC
CC                  CARICAMENTO VETTORE NIP
CC
C                     DATA (ID_NIP(I),I=1,  4  )
CC                                     NVALV
CC
C     $/   9   ,     7    ,    5    ,    3    /
CC        (1)       (2)       (3)       (4)
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 1
CC
C       DATA ((D_CPV(1,I02,L),L=1,4),I02=1,  9   )
CC                                NIP(1)
CC
CC
C     $/  .15   ,  1.2444444,     0.      ,    0.     ,                     
CC          x         a            b            c
C     $  .275   ,  -.574359 ,  .7401026   , -.07009231,                  
CC         x          a            b            c     
C     $  .35    ,  2.142857 , -.7392857   ,   .13125  ,                   
CC        x           a            b            c     
C     $  .45     ,     0.   ,     .83     ,  -.1555   ,                  
CC        x            a            b            c     
C     $  .575    , 2.246154 , -1.206308   , .3059923  ,                 
CC        x            a            b            c     
C     $  .725    , -1.777778,  3.711111   ,  -1.191111,
CC        x            a            b            c     
C     $  .8      , 19.285714, -26.210714  ,  9.430714 ,                  
CC        x            a            b            c     
C     $  .865    ,    -30.  ,    52.95    ,  -22.355  ,                  
CC        x            a            b            c     
C     $  1.05    ,     0.   ,       0.    ,      1.   /                      
CC         x           a            b            c     
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 2
CC
C       DATA ((D_CPV(2,I02,L),L=1,4),I02=1,  7   )
CC                                NIP(2)
CC
CC
C     $/ .2      ,     0.   ,       0.    ,      0.   ,
CC        x            a            b            c     
C     $  .4      ,    1.55  ,    -.155    ,    -.031  ,                         
CC        x            a            b            c     
C     $  .525    , -2.461538,    3.116923 ,  -.697923 ,                       
CC        x            a            b            c     
C     $  .75     ,  5.155555,    -5.017778,  1.473333 ,                       
CC        x            a            b            c     
C     $  .825    ,     0.   ,    2.866667 ,    -1.54  ,                         
CC        x            a            b            c     
C     $  .93     ,-9.6969697,   18.684848 ,    -7.99  ,
CC        x            a            b            c     
C     $  1.05    ,     0.   ,       0.    ,      1.   /
CC        x            a            b            c     
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 3
CC
C       DATA ((D_CPV(3,I02,L),L=1,4),I02=1,  5   )
CC                                NIP(3)
CC
CC
C     $/ .715    ,     0.   ,      0.     ,      0.   ,     
CC        x            a           b             c     
C     $  .8      , 9.344538 ,-12.604034   ,  4.234723 ,    
CC        x            a            b            c     
C     $  .875    , 35.73333 ,  -54.94666  ,    21.22  ,      
CC        x            a            b            c     
C     $  .96     ,-41.37255 ,   81.03627  , -38.73088 ,   
CC        x            a            b            c     
C     $  1.05    ,     0.   ,   .7222222  ,  .2416667 /    
CC        x            a            b            c     
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 4
CC
C       DATA ((D_CPV(4,I02,L),L=1,4),I02=1,  3   )
CC                                NIP(4)
CC
CC
CC
C     $/ .865    ,     0.   ,       0.    ,      0.   ,
CC        x            a            b            c     
C     $  .95     , 24.20168 ,  -41.57311  ,     17.8  ,
CC         x            a            b            c     
C     $  1.05    ,   57.6   ,   -105.48   ,     48.4  /
CC        x            a            b            c     
CC
C
CC                  CARICAMENTO VETTORE CPVF
CC
C                DATA ((D_CPVF(I02,L),L=1,4),I02=1, 1  )
CC                                        NIPF
CC
C     $/   1.05  ,     0.   ,       1.    ,       0.  /
CC          x          a            b             c     
CC
CC
C      TIPO=D_TIPO
CC
C      PSHNOM=D_PSHNOM
C      TSHNOM=D_TSHNOM
C      VUNOM =D_VUNOM
C      WNOM  =D_WNOM
C      RAGGIO=D_RAGGIO
C      CCR   =D_CCR
C      AETA  =D_AETA
C      BETA  =D_BETA
C      DPVE  =D_DPVE
C      PSHF  =D_PSHF
C      TSHF  =D_TSHF
C      XF    =D_XF
C      WF    =D_WF
C      NVALV =ID_NVALV
C      NIPF  =ID_NIPF
CC
C      DO I=1,16
C      CA(I)  =D_CA(I)
C      AUG(I) =D_AUG(I)
C      NIA(I) =ID_NIA(I)
C      NIP(I) =ID_NIP(I)
C      RCA(I) =D_RCA(I)
C      IAM(I) =ID_IAM(I)
C       DO J=1,3
C       CCF(I,J)=D_CCF(I,J)
C       ENDDO
C      ENDDO
CC
C      DO I=1,16
C       DO J=1,3
C        DO K=1,4
C        CAV(I,J,K)=D_CAV(I,J,K)
C        ENDDO
C       ENDDO
C      ENDDO
CC
C      DO I=1,16
C       DO J=1,10
C        DO K=1,4
C        CPV(I,J,K)=D_CPV(I,J,K)
C        ENDDO
C       ENDDO
C      ENDDO
C       DO J=1,10
C        DO K=1,4
C        CPVF(J,K)=D_CPVF(J,K)
C        ENDDO
C       ENDDO
CC
C       RETURN 
C       END
C******************** FINE ESEMPIO DATI TURBINA *****************************
C~FORAUS_STAZ~C
C
C~FORAUS_RSE0~C
C
C  FORTRAN AUSILIARIO DEL MODULO RSE0
CC ======================================================================
CC
        SUBROUTINE RSE0DAT (TIMP, DATIMP)
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
        DIMENSION DATCOE(3), DATSFO(2)
CC
CC     La subroutine RSE0DAT (RSE0 - DATI) deve assegnare i parametri
CC        caratteristici dell'impianto per il calcolo del coefficiente
CC        di scambio termico vapore / metallo ed i fattori di concen-
CC        trazione degli sforzi alla cava ed al foro.
CC
CC     DATO IN INGRESSO
CC        TIMP = Tipo di impianto non-standard (deve essere posto > 6)
CC
CC     DATI IN USCITA
CC        DATCOE = Vettore di dati utili per il calcolo del
CC                 coefficiente di scambio termico:
CC              DATCOE (1) = S07   (adimensionalizzazione Coeff.Scam.)
CC              DATCOE (2) = ...    a disposizione dell'utente
CC                         nella subroutine RSE0CC come DATI(IPD+ 5)
CC              DATCOE (3) = 1.0  se stadio di alta  pressione
CC              DATCOE (3) = 3.2  se stadio di media pressione
CC
CC        DATSFO = Vettore dei dati utili per il calcolo delle
CC                 sollecitazioni sul rotore:
CC              DATSFO (1) = fatt. di concentrazione sigma alla cava
CC              DATSFO (2) = sigma foro / omega^2  [in (kg/mm^2)/(rad/s)^2]
CC
        WRITE(6,*)' Attenzione nel file 14 del modulo RSE0 si richiede'
        WRITE(6,*)' sottoprogramma esterno RSE0DAT(TIMP,DATIMP)'
        RETURN
        END
CC
CC ======================================================================
CC
       REAL FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG, PVAP, DATI, IPD)
CC       DOUBLE PRECISION FUNCTION RSE0CC (TIMP, WVAP, TCAS, OMEG,        !DBLE
CC            PVAP, DATI, IPD)                                            !DBLE
CC       IMPLICIT DOUBLE PRECISION (A-H, O-Z)                             !DBLE
CC
CC---       Function per il calcolo coefficiente di scambio termico
CC          fra il metallo del rotore, assimilato a corpo cilin-
CC          drico (valore medio) e:
CC             - il vapore se passa vapore (WVAP > 0.1 kg/s)
CC             - la cassa se non passa vapore (irraggiamento)
CC
CC       Parametri d'ingresso:
CC        TIMP = Tipo di impianto non-standard (deve essere > 6)
CC        WVAP = Portata di vapore in camera ruota [in kg/s]
CC        TCAS = Temperatura della cassa del rotore [in K]
CC        OMEG = Velocita' di rotazione della macchina [in rad/s]
CC        PVAP = Pressione del vapore in camera ruota [in Pa]
CC        DATI ed IPD come da standard LEGO
CC
CC       Il valore di RSE0CC deve essere fornito in   W / (m^2 * K)
CC
        DIMENSION DATI(*)
        INTEGER   IPD
CC
C       RSE0CC = ....
        RSE0CC = 1.
C
        WRITE(6,*)' Attenzione nel file 14 del modulo RSE0 si richiede'
        WRITE(6,*)' sottoprogramma esterno RSE0CC'
CC
        RETURN
        END
CC
CC ======================================================================
C~FORAUS_RSE0~C
C
C~FORAUS_RSC1~C
C
      SUBROUTINE RSC1GAMUT(P,H,S,T,ROM,Y,TMI,EQD,VERT,
     $                     SUME,FCSA,TUBZSURF,LTUB,DETB,UEHC,
     $                     GAMMA,VWMASS,SHIVWT)
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO RSC1'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE IL FORTRAN AUSILIARIO'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' ***** RSC1GAMUT  ****'
      RETURN
      END
C
C     SUBROUTINE RSC1GAMUT(P,H,S,T,ROM,Y,TMI,EQD,VERT,
C    $                     SUME,FCSA,TUBZSURF,LTUB,DETB,UEHC,
C    $                     GAMMA,VWMASS,SHIVWT)
C
C      GAMMA = 5000.
C      RETURN
C      END
C
C~FORAUS_RSC1~C
C
C
C~FORAUS_LDCH~C 
        SUBROUTINE LDCH_UHTC(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,*) 'ATTENZIONE: fornire routine LDCH_UHTC!!'  
      RETURN
      END
C
C~FORAUS_LDCH~C 
C~FORAUS_LSGS~C 
        SUBROUTINE LSGS_UHTC(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,*) 'ATTENZIONE: fornire routine LSGS_UHTC!!'  
      RETURN
      END
C
C~FORAUS_LSGS~C 
C~FORAUS_HMCP~C
      SUBROUTINE HMCPDPU(TYP,QVN,OMN,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
      WRITE(6,*) 'ATTENZIONE: fornire routine HMCPDPU!!'
      STOP
      END
C
C~FORAUS_HMCP~C
C
C~FORAUS_WBCH~C
      SUBROUTINE WBCHGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C-------------------------------------------------------------------
C     COEFFICIENTE DI SCAMBIO METALLO/FLUIDO
C     FORNITO DALL'UTENTE
C-------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'**** DEVI FORNIRE LA SUBROUTINE UTENTE  "WBCHGAMUT"'
     $/10X,'      DAL MOMENTO CHE IL DATO  "CRIG"  SUL FILE F14 '
     $/10X,'      DEL MODULO "WBCH" LA RICHIEDE')
C
      STOP 'ESECUZIONE ARRESTATA DALLA SUBROUTINE "WBCHGAMUT" DI WBCH'
      END
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C CON MODELLO DI "DRIFT" OPPURE OMOGENEO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE WBCHGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]
C
C__________ SE VUOI CHE LA SUBROUTINE WBCHGAMUT SIA CHIAMATA DA WBCH
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   CRIG < 0.
C
C  La subroutine fornisce al modulo WBCH il coefficiente di scambio
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]
C   H     entalpia specifica del fluido           [J/kg]
C   S     entropia specifica del fluido           [J/kg/C]
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]
C   TITOL titolo della miscela                    [-]
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   CRIG  dato fornito dall'utente nel file F14   [-]
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato
C         come si vuole.
C         RICORDATI CHE CRIG E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]
C   Q     potenza totale scambiata                [W]
C   SUP   superficie di scambio                   [m**2]
C
C************ Esempio di subroutine GAMUTD *****************************
C
C       SUBROUTINE WBCHGAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C      IF (CRIG.EQ.-1.) THEN
CC
C       HTC=Q/(SUP*(TP-TF))
CC
C      ELSE
CC
C       CALL SATUR(P,2,HLS,HVS,1)
C       HLV=HVS-HLS
CC
C       HTCSOT=15000.
C       HTCBIF=50000.
C       HTCSUR=15000.
CC
C       IF (H.LE.0.9*HLS) HTC=HTCSOT
C       IF (H.GT.0.9*HLS.AND.H.LT.HLS)
C     $    HTC=HTCSOT+(HTCBIF-HTCSOT)*(H-0.9*HLS)/(0.1*HLS)
C       IF (H.GE.HLS.AND.H.LE.(HVS-0.1*HLV)) HTC=HTCBIF
C       IF (H.GT.(HVS-0.1*HLV).AND.H.LT.HVS)
C     $    HTC=HTCBIF+(HTCSUR-HTCBIF)*(H-HVS+0.1*HLV)/(0.1*HLV)
C       IF (H.GE.HVS) HTC=HTCSUR
CC
C      ENDIF
CC
C      RETURN
C      END
C
C~FORAUS_WBCH~C
C

