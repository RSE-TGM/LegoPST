# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fum0_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -118.0] [expr $y + 2.0] -image flue_e -anchor e]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + -118.0] -image flue_s -anchor s]}
s {set myportId [$c create image [expr $x + 118.0] [expr $y + -2.0] -image flue_w -anchor w]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + 118.0] -image flue_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WIF_ ____ TIF_ ____ ____ %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + 123.5] [expr $y + 7.5] -image flue_e -anchor w]}
e {set myportId [$c create image [expr $x + -7.5] [expr $y + 123.5] -image flue_s -anchor n]}
s {set myportId [$c create image [expr $x + -123.5] [expr $y + -7.5] -image flue_w -anchor e]}
w {set myportId [$c create image [expr $x + 7.5] [expr $y + -123.5] -image flue_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WIF_ ____ TUF_ ____ ____ %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + -76.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -76.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 76.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 76.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TM41 TF41 GF41 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -88.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -88.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 88.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 88.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TM31 TF31 GF31 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -68.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -68.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 68.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 68.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port16 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port16.$mymodId
set port16.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -60.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -60.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 60.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 60.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port17 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port17.$mymodId
set port17.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -96.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -96.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 96.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 96.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TM21 TF21 GF21 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -104.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -104.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 104.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 104.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TM11 TF11 GF11 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -8.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -8.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 8.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 8.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TM32 TF32 GF32 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -16.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 16.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TM22 TF22 GF22 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -24.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -24.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 24.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 24.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TM12 TF12 GF12 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 0.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 0.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TM42 TF42 GF42 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 8.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 8.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -8.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -8.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port18 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port18.$mymodId
set port18.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 16.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 16.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -16.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -16.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port19 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port19.$mymodId
set port19.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 72.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 72.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -72.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -72.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { TM33 TF33 GF33 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 64.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 64.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -64.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -64.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TM23 TF23 GF23 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 56.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 56.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -56.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -56.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TM13 TF13 GF13 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 80.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 80.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -80.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -80.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { TM43 TF43 GF43 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 88.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 88.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -88.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -88.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port20 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port20.$mymodId
set port20.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 96.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 96.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -96.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -96.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port21 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port21.$mymodId
set port21.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -64.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -64.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 64.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 64.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port22 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port22.$mymodId
set port22.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -56.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -56.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 56.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 56.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port23 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port23.$mymodId
set port23.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -48.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -48.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 48.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 48.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port24 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port24.$mymodId
set port24.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -40.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -40.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 40.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 40.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port25 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port25.$mymodId
set port25.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -32.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 32.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port26 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port26.$mymodId
set port26.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -24.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -24.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + 24.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 24.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port27 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port27.$mymodId
set port27.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 16.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 16.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -16.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -16.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port28 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port28.$mymodId
set port28.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 24.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 24.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -24.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -24.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port29 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port29.$mymodId
set port29.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 32.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -32.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port30 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port30.$mymodId
set port30.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 40.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 40.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -40.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -40.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port31 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port31.$mymodId
set port31.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 48.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 48.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -48.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -48.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port32 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port32.$mymodId
set port32.$mymodId { ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 56.0] [expr $y + -70.0] -image term_n -anchor s]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 56.0] -image term_e -anchor w]}
s {set myportId [$c create image [expr $x + -56.0] [expr $y + 70.0] -image term_s -anchor n]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -56.0] -image term_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port33 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port33.$mymodId
set port33.$mymodId { ____ ____ ____ ____ }
