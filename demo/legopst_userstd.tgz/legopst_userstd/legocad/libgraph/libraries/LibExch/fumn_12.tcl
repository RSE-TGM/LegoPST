# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fumn_12$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 30.0] [expr $y + 44.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -44.0] [expr $y + 30.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -30.0] [expr $y + -44.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 44.0] [expr $y + -30.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port31 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port31.$mymodId
set port31.$mymodId { TM61 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -36.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 36.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 36.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -36.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TM44 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -30.0] [expr $y + -12.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 12.0] [expr $y + -30.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 30.0] [expr $y + 12.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -12.0] [expr $y + 30.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port18 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port18.$mymodId
set port18.$mymodId { TM33 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -36.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 36.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 36.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -36.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port20 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port20.$mymodId
set port20.$mymodId { TM14 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -30.0] [expr $y + -44.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + -30.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 30.0] [expr $y + 44.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + 30.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port21 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port21.$mymodId
set port21.$mymodId { TM34 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -52.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 52.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 52.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -52.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TM54 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 30.0] [expr $y + -44.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + 30.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -30.0] [expr $y + 44.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + -30.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port22 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port22.$mymodId
set port22.$mymodId { TM64 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -20.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 20.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TM23 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -4.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 4.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port17 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port17.$mymodId
set port17.$mymodId { TM13 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -20.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 20.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port23 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port23.$mymodId
set port23.$mymodId { TM53 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -4.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 4.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port24 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port24.$mymodId
set port24.$mymodId { TM43 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 30.0] [expr $y + -12.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 12.0] [expr $y + 30.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -30.0] [expr $y + 12.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -12.0] [expr $y + -30.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port25 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port25.$mymodId
set port25.$mymodId { TM63 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 8.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -8.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TM22 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 24.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -24.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -24.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 24.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TM12 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -30.0] [expr $y + 16.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + -30.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 30.0] [expr $y + -16.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + 30.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { TM32 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 8.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -8.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port26 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port26.$mymodId
set port26.$mymodId { TM52 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 24.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -24.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -24.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 24.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port27 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port27.$mymodId
set port27.$mymodId { TM42 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 30.0] [expr $y + 16.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + 30.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -30.0] [expr $y + -16.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + -30.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port28 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port28.$mymodId
set port28.$mymodId { TM62 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 36.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -36.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -36.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 36.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TM21 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 52.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -52.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TM11 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -30.0] [expr $y + 44.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -44.0] [expr $y + -30.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 30.0] [expr $y + -44.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 44.0] [expr $y + 30.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port16 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port16.$mymodId
set port16.$mymodId { TM31 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 36.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -36.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -36.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 36.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port29 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port29.$mymodId
set port29.$mymodId { TM51 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 52.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -52.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port30 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port30.$mymodId
set port30.$mymodId { TM41 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -52.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 52.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 52.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -52.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port19 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port19.$mymodId
set port19.$mymodId { TM24 TF_4 GF_4 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 66.0] -image flue_n -anchor n]}
e {set myportId [$c create image [expr $x + -66.0] [expr $y + 0.0] -image flue_e -anchor e]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + -66.0] -image flue_s -anchor s]}
w {set myportId [$c create image [expr $x + 66.0] [expr $y + 0.0] -image flue_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WIF_ ____ TIF_ ____ {} %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -66.0] -image flue_n -anchor s]}
e {set myportId [$c create image [expr $x + 66.0] [expr $y + 0.0] -image flue_e -anchor w]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + 66.0] -image flue_s -anchor n]}
w {set myportId [$c create image [expr $x + -66.0] [expr $y + 0.0] -image flue_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WIF_ ____ TUF_ ____ {} %CO2 %PH2 %H2O }
