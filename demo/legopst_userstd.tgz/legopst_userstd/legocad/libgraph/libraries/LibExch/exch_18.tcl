# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image exch_18$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 192.0] [expr $y + 0.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + 192.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -192.0] [expr $y + -0.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + -192.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WUTU PUTU ____ ____ ____ HUTU ____ HVAL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 169.0] [expr $y + -13.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 13.0] [expr $y + 169.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -169.0] [expr $y + 13.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -13.0] [expr $y + -169.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WITU PITU ____ ____ ____ HITU ____ HM_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 171.0] [expr $y + -20.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + 171.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -171.0] [expr $y + 20.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + -171.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TF11 GE11 ____ ____ ____ ____ ____ ____ ____ TPE1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 192.0] [expr $y + 8.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + 192.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -192.0] [expr $y + -8.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + -192.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TF81 GE81 ____ ____ ____ ____ ____ ____ ____ TPE8 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -29.0] [expr $y + -187.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 187.0] [expr $y + -29.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 29.0] [expr $y + 187.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -187.0] [expr $y + 29.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TF31 GE31 ____ ____ ____ ____ ____ ____ ____ TPE3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -190.0] [expr $y + -20.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + -190.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 190.0] [expr $y + 20.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + 190.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TF41 GE41 ____ ____ ____ ____ ____ ____ ____ TPE4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -190.0] [expr $y + 11.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -11.0] [expr $y + -190.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 190.0] [expr $y + -11.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 11.0] [expr $y + 190.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TF51 GE51 ____ ____ ____ ____ ____ ____ ____ TPE5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -17.0] [expr $y + 187.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -187.0] [expr $y + -17.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 17.0] [expr $y + -187.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 187.0] [expr $y + 17.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TF61 GE61 ____ ____ ____ ____ ____ ____ ____ TPE6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 17.0] [expr $y + 187.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -187.0] [expr $y + 17.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -17.0] [expr $y + -187.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 187.0] [expr $y + -17.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TF71 GE71 ____ ____ ____ ____ ____ ____ ____ TPE7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 10.0] [expr $y + -187.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 187.0] [expr $y + 10.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -10.0] [expr $y + 187.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -187.0] [expr $y + -10.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TF21 GE21 ____ ____ ____ ____ ____ ____ ____ TPE2 }

set var1_anim HUTU
$c addtag $var1_anim.anim withtag $mymodId
