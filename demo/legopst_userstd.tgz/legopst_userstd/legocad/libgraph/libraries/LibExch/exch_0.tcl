# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image exch_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -22.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + 0.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + 22.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + -0.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WUTU PUTU ____ ____ ____ HUTU ____ HVAL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 22.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 0.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + -22.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -0.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WITU PITU ____ ____ ____ HITU ____ HM_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -3.0] [expr $y + -11.0] -image fltm_w -anchor e]}
e {set myportId [$c create image [expr $x + 11.0] [expr $y + -3.0] -image fltm_n -anchor s]}
s {set myportId [$c create image [expr $x + 3.0] [expr $y + 11.0] -image fltm_e -anchor w]}
w {set myportId [$c create image [expr $x + -11.0] [expr $y + 3.0] -image fltm_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { PUTU HM_2 WI_1 TPE2 }

set var1_anim PUTU
$c addtag $var1_anim.anim withtag $mymodId
