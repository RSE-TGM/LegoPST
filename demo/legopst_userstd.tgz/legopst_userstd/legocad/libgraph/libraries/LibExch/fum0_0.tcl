# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fum0_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -14.0] [expr $y + 0.0] -image flue_e -anchor e]}
e {set myportId [$c create image [expr $x + 0.0] [expr $y + -14.0] -image flue_s -anchor s]}
s {set myportId [$c create image [expr $x + 14.0] [expr $y + 0.0] -image flue_w -anchor w]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + 14.0] -image flue_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WIF_ ____ TIF_ ____ ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 13.5] [expr $y + -0.5] -image flue_e -anchor w]}
e {set myportId [$c create image [expr $x + 0.5] [expr $y + 13.5] -image flue_s -anchor n]}
s {set myportId [$c create image [expr $x + -13.5] [expr $y + 0.5] -image flue_w -anchor e]}
w {set myportId [$c create image [expr $x + -0.5] [expr $y + -13.5] -image flue_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WIF_ ____ TUF_ ____ ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -7.0] [expr $y + 2.0] -image httr_s -anchor n]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + -7.0] -image httr_w -anchor e]}
s {set myportId [$c create image [expr $x + 7.0] [expr $y + -2.0] -image httr_n -anchor s]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + 7.0] -image httr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag httr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { ____ ____ ____ ____ ____ ____ ____ ____ ____ TF21 GF21 TM21 TF11 GF11 TM11 }

set var1_anim TUF_
$c addtag $var1_anim.anim withtag $mymodId
