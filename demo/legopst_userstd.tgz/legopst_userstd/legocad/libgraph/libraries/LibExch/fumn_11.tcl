# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fumn_11$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -38.0] -image flue_n -anchor s]}
e {set myportId [$c create image [expr $x + 38.0] [expr $y + 0.0] -image flue_e -anchor w]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + 38.0] -image flue_s -anchor n]}
w {set myportId [$c create image [expr $x + -38.0] [expr $y + 0.0] -image flue_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WIF_ ____ TUF_ ____ ____ %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 34.0] -image flue_n -anchor n]}
e {set myportId [$c create image [expr $x + -34.0] [expr $y + 0.0] -image flue_e -anchor e]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + -34.0] -image flue_s -anchor s]}
w {set myportId [$c create image [expr $x + 34.0] [expr $y + 0.0] -image flue_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WIF_ ____ TIF_ ____ ____ %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -32.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 32.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 32.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -32.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TM43 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -32.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 32.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 32.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -32.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TM23 TF_3 GF_3 {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -20.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 20.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TM13 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -20.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 20.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TM33 TF_3 GF_3 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -8.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 8.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TM42 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 4.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -4.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TM32 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -8.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 8.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TM22 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 4.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -4.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TM12 TF_2 GF_2 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 16.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -16.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TM41 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 28.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + -18.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -28.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + 18.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TM31 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 16.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -16.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TM21 TF_1 GF_1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 28.0] -image term_e -anchor w]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + 18.0] -image term_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -28.0] -image term_w -anchor e]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + -18.0] -image term_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TM11 TF_1 GF_1 ____ }
