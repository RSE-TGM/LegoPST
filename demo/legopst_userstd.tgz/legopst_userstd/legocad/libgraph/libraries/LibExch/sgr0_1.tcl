# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image sgr0_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -31.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 31.0] [expr $y + -32.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 31.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -31.0] [expr $y + 32.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TL_3 G1_3 ____ ____ ____ ____ ____ ____ ____ T1_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -2.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + -32.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 2.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + 32.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TL_2 G1_2 ____ ____ ____ ____ ____ ____ ____ T1_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + 29.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -29.0] [expr $y + -32.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + -29.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 29.0] [expr $y + 32.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TL_1 G1_1 ____ ____ ____ ____ ____ ____ ____ T1_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 31.0] [expr $y + -32.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 32.0] [expr $y + 31.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -31.0] [expr $y + 32.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -32.0] [expr $y + -31.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { {} {} {} {} {} {} {} {} {} {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + 31.0] [expr $y + 28.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + 31.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -31.0] [expr $y + -28.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + -31.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { {} {} {} {} {} {} {} {} {} {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + -28.0] [expr $y + 81.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -81.0] [expr $y + -28.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + 28.0] [expr $y + -81.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 81.0] [expr $y + 28.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { {} {} {} {} {} {} {} {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + -80.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 80.0] [expr $y + 32.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + 80.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -80.0] [expr $y + -32.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { WU_3 PU_3 ____ ____ ____ HU_3 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 31.0] [expr $y + -2.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 31.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -31.0] [expr $y + 2.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -31.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { {} {} {} {} {} {} {} {} {} {} }

set var1_anim TL_3
$c addtag $var1_anim.anim withtag $mymodId
