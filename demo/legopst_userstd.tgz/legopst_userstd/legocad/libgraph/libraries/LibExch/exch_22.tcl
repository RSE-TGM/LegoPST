# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image exch_22$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 50.0] [expr $y + 24.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -24.0] [expr $y + 50.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -50.0] [expr $y + -24.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 24.0] [expr $y + -50.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WITU PITU ____ ____ ____ HITU ____ HM_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 50.0] [expr $y + -24.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 24.0] [expr $y + 50.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -50.0] [expr $y + 24.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -24.0] [expr $y + -50.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WUTU PUTU ____ ____ ____ HUTU ____ HVAL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -58.0] [expr $y + -4.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -58.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 58.0] [expr $y + 4.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 58.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TF61 GE61 TF51 GE51 TF41 GE41 TPE6 TPE5 TPE4 {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + -58.0] [expr $y + 4.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + -58.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 58.0] [expr $y + -4.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + 58.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TF31 GE31 TF21 GE21 TF11 GE11 TPE3 TPE2 TPE1 ____ }

set var1_anim 
$c addtag $var1_anim.anim withtag $mymodId
