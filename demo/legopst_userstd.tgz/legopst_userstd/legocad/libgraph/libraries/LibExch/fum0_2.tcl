# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fum0_2$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -64.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -64.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 64.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 64.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TM41 TF41 GF41 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -76.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -76.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 76.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 76.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TM31 TF31 GF31 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -92.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -92.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 92.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 92.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TM21 TF21 GF21 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -104.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -104.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 104.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 104.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TM11 TF11 GF11 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -28.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -28.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 28.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 28.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TM12 TF12 GF12 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -16.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 16.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TM22 TF22 GF22 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 4.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 4.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -4.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -4.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TM32 TF32 GF32 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 16.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 16.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -16.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -16.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TM42 TF42 GF42 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 56.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 56.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -56.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -56.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TM13 TF13 GF13 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 68.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 68.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -68.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -68.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TM23 TF23 GF23 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 84.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 84.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -84.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -84.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { TM33 TF33 GF33 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 96.0] [expr $y + 70.0] -image term_s -anchor n]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + 96.0] -image term_w -anchor e]}
s {set myportId [$c create image [expr $x + -96.0] [expr $y + -70.0] -image term_n -anchor s]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + -96.0] -image term_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { TM43 TF43 GF43 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -118.0] [expr $y + 2.0] -image flue_e -anchor e]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + -118.0] -image flue_s -anchor s]}
s {set myportId [$c create image [expr $x + 118.0] [expr $y + -2.0] -image flue_w -anchor w]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + 118.0] -image flue_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WIF_ ____ TIF_ ____ ____ %CO2 %PH2 %H2O }

switch $GIForient {
n {set myportId [$c create image [expr $x + 123.5] [expr $y + 7.5] -image flue_e -anchor w]}
e {set myportId [$c create image [expr $x + -7.5] [expr $y + 123.5] -image flue_s -anchor n]}
s {set myportId [$c create image [expr $x + -123.5] [expr $y + -7.5] -image flue_w -anchor e]}
w {set myportId [$c create image [expr $x + 7.5] [expr $y + -123.5] -image flue_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag flue_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WIF_ ____ TUF_ ____ ____ %CO2 %PH2 %H2O }
