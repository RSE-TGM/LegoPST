# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image exch_6$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 74.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -74.0] [expr $y + 0.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + -74.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 74.0] [expr $y + 0.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WITU PITU ____ ____ ____ HITU ____ HM_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -78.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 78.0] [expr $y + 0.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + 78.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -78.0] [expr $y + 0.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WUTU PUTU ____ ____ ____ HUTU ____ HVAL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -11.0] [expr $y + 80.0] -image httr_e -anchor e]}
e {set myportId [$c create image [expr $x + -80.0] [expr $y + -11.0] -image httr_s -anchor s]}
s {set myportId [$c create image [expr $x + 11.0] [expr $y + -80.0] -image httr_w -anchor w]}
w {set myportId [$c create image [expr $x + 80.0] [expr $y + 11.0] -image httr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag httr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { ____ ____ ____ ____ ____ ____ ____ ____ ____ TF21 GE21 TPE2 TF11 GE11 TPE1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -11.0] [expr $y + 32.0] -image httr_e -anchor e]}
e {set myportId [$c create image [expr $x + -32.0] [expr $y + -11.0] -image httr_s -anchor s]}
s {set myportId [$c create image [expr $x + 11.0] [expr $y + -32.0] -image httr_w -anchor w]}
w {set myportId [$c create image [expr $x + 32.0] [expr $y + 11.0] -image httr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag httr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { ____ ____ ____ ____ ____ ____ ____ ____ ____ TF41 GE41 TPE4 TF31 GE31 TPE3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -11.0] [expr $y + -20.0] -image httr_e -anchor e]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + -11.0] -image httr_s -anchor s]}
s {set myportId [$c create image [expr $x + 11.0] [expr $y + 20.0] -image httr_w -anchor w]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + 11.0] -image httr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag httr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { ____ ____ ____ ____ ____ ____ ____ ____ ____ TF61 GE61 TPE6 TF51 GE51 TPE5 }

set var1_anim HUTU
$c addtag $var1_anim.anim withtag $mymodId
