# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image cnd0_2$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -130.0] [expr $y + 62.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -62.0] [expr $y + -130.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 130.0] [expr $y + -62.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 62.0] [expr $y + 130.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WD_2 PFCN ____ ____ ____ HD_2 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + -130.0] [expr $y + 34.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -34.0] [expr $y + -130.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 130.0] [expr $y + -34.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 34.0] [expr $y + 130.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WD_1 PFCN ____ ____ ____ HD_1 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 69.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -69.0] [expr $y + 1.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -69.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 69.0] [expr $y + -1.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WC_1 PFCN ____ ____ ____ HLCN ____ HC_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + -69.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 69.0] [expr $y + 2.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + 69.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -69.0] [expr $y + -2.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { WTUR PCND ____ ____ ____ HTUR ____ HVCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 122.0] [expr $y + -31.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 31.0] [expr $y + 122.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -122.0] [expr $y + 31.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -31.0] [expr $y + -122.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { WD13 PFCN ____ ____ ____ HD13 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + -21.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 21.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + 21.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -21.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { WD12 PFCN ____ ____ ____ HD12 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + -11.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 11.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + 11.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -11.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WD11 PFCN ____ ____ ____ HD11 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 0.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -0.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WD10 PFCN ____ ____ ____ HD10 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 53.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -53.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -53.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 53.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { WD_5 PFCN ____ ____ ____ HD_5 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 63.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -63.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -63.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 63.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WD_4 PFCN ____ ____ ____ HD_4 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 73.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -73.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -73.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 73.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { WD_3 PFCN ____ ____ ____ HD_3 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 11.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -11.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -11.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 11.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { WD_9 PFCN ____ ____ ____ HD_9 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 21.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -21.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { WD_8 PFCN ____ ____ ____ HD_8 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 32.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -32.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -32.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 32.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { WD_7 PFCN ____ ____ ____ HD_7 ____ HLCN }

switch $GIForient {
n {set myportId [$c create image [expr $x + 131.0] [expr $y + 42.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -42.0] [expr $y + 131.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -131.0] [expr $y + -42.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 42.0] [expr $y + -131.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WD_6 PFCN ____ ____ ____ HD_6 ____ HLCN }

set var1_anim LCND
$c addtag $var1_anim.anim withtag $mymodId
