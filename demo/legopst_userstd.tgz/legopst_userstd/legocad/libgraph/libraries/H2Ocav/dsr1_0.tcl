# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image dsr1_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -15.0] [expr $y + 36.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -36.0] [expr $y + -15.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 15.0] [expr $y + -36.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 36.0] [expr $y + 15.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WS_1 PWSS ____ ____ ____ HS_1 ____ HV_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 16.0] [expr $y + -36.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 36.0] [expr $y + 16.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -16.0] [expr $y + 36.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -36.0] [expr $y + -16.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WSO1 PWSS ____ ____ ____ HV12 ____ HSO1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -63.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 63.0] [expr $y + 1.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 63.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -63.0] [expr $y + -1.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WFDW PFIN ____ ____ ____ HFIN ____ HF_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 64.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -64.0] [expr $y + 1.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -64.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 64.0] [expr $y + -1.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WFDW PFOU ____ ____ ____ HF12 ____ HFOU }

set var1_anim PWSS
$c addtag $var1_anim.anim withtag $mymodId
