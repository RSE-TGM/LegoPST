# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image rsor_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 38.0] [expr $y + -24.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 24.0] [expr $y + 38.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -38.0] [expr $y + 24.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -24.0] [expr $y + -38.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WTUR PRIS ____ ____ ____ HTUR ____ HLUR }

switch $GIForient {
n {set myportId [$c create image [expr $x + -19.0] [expr $y + -25.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 25.0] [expr $y + -19.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + 19.0] [expr $y + 25.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -25.0] [expr $y + 19.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WDIR PRIS ____ ____ ____ HDIR ____ HLUR }

switch $GIForient {
n {set myportId [$c create image [expr $x + 31.0] [expr $y + 26.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -26.0] [expr $y + 31.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -31.0] [expr $y + -26.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 26.0] [expr $y + -31.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WCUR PRIS ____ ____ ____ HLUR ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 63.0] [expr $y + 0.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + 63.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -63.0] [expr $y + -0.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + -63.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { WALR PALI ____ ____ ____ HALI ____ HALU }

switch $GIForient {
n {set myportId [$c create image [expr $x + -62.0] [expr $y + 0.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + -62.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 62.0] [expr $y + -0.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + 62.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WALR PALU ____ ____ ____ HALU ____ {} }

set var1_anim LIVR
$c addtag $var1_anim.anim withtag $mymodId
