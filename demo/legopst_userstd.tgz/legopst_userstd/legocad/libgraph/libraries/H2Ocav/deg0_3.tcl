# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image deg0_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -37.0] [expr $y + -76.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 76.0] [expr $y + -37.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 37.0] [expr $y + 76.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -76.0] [expr $y + 37.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { WM_2 PPVC ____ ____ ____ HM_2 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + -37.0] [expr $y + -59.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 59.0] [expr $y + -37.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 37.0] [expr $y + 59.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -59.0] [expr $y + 37.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { WM_1 PPVC ____ ____ ____ HM_1 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 39.0] [expr $y + -68.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 68.0] [expr $y + 39.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -39.0] [expr $y + 68.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -68.0] [expr $y + -39.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WS_1 PPVC ____ ____ ____ HVCA ____ HS_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 103.0] [expr $y + 21.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + 103.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -103.0] [expr $y + -21.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + -103.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port21 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port21.$mymodId
set port21.$mymodId { WL_5 PFCA ____ ____ ____ HL_5 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + -101.0] [expr $y + 21.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + -101.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 101.0] [expr $y + -21.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + 101.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { WL_2 PFCA ____ ____ ____ HL_2 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + -97.0] [expr $y + 56.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -56.0] [expr $y + -97.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 97.0] [expr $y + -56.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 56.0] [expr $y + 97.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { WL_1 PFCA ____ ____ ____ HL_1 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + -8.0] [expr $y + 82.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -82.0] [expr $y + -8.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 8.0] [expr $y + -82.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 82.0] [expr $y + 8.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WW_1 PFCA ____ ____ ____ HLCA ____ HW_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -97.0] [expr $y + -17.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 17.0] [expr $y + -97.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 97.0] [expr $y + 17.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -17.0] [expr $y + 97.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WL_3 PFCA ____ ____ ____ HL_3 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 99.0] [expr $y + -16.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 16.0] [expr $y + 99.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -99.0] [expr $y + 16.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -16.0] [expr $y + -99.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port22 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port22.$mymodId
set port22.$mymodId { WL_6 PFCA ____ ____ ____ HL_6 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 100.0] [expr $y + 54.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -54.0] [expr $y + 100.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -100.0] [expr $y + -54.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 54.0] [expr $y + -100.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port20 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port20.$mymodId
set port20.$mymodId { WL_4 PFCA ____ ____ ____ HL_4 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -88.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 88.0] [expr $y + 1.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 88.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -88.0] [expr $y + -1.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WG_1 PPVC ____ ____ ____ HG_1 ____ HVCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 69.0] [expr $y + 82.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -82.0] [expr $y + 69.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -69.0] [expr $y + -82.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 82.0] [expr $y + -69.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WW_2 PFCA ____ ____ ____ HLCA ____ HW_2 }

set var1_anim PCAV
$c addtag $var1_anim.anim withtag $mymodId
