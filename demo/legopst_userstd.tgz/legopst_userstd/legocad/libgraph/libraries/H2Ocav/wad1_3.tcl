# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image wad1_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -114.0] [expr $y + 28.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + -114.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 114.0] [expr $y + -28.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + 114.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { WM_1 PFCA ____ ____ ____ HM_1 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + -84.0] [expr $y + -50.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 50.0] [expr $y + -84.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 84.0] [expr $y + 50.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -50.0] [expr $y + 84.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WS_1 PPVC ____ ____ ____ HVCA ____ HS_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 44.0] [expr $y + -50.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 50.0] [expr $y + 44.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -44.0] [expr $y + 50.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -50.0] [expr $y + -44.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WS_2 PPVC ____ ____ ____ HVCA ____ HS_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 76.0] [expr $y + -50.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 50.0] [expr $y + 76.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -76.0] [expr $y + 50.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -50.0] [expr $y + -76.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WS_3 PPVC ____ ____ ____ HVCA ____ HS_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 110.0] [expr $y + -40.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 40.0] [expr $y + 110.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -110.0] [expr $y + 40.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -40.0] [expr $y + -110.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { WM_3 PFCA ____ ____ ____ HM_3 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 118.0] [expr $y + -28.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 28.0] [expr $y + 118.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -118.0] [expr $y + 28.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -28.0] [expr $y + -118.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { WM_2 PFCA ____ ____ ____ HM_2 ____ HLCA }

switch $GIForient {
n {set myportId [$c create image [expr $x + 80.0] [expr $y + 50.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -50.0] [expr $y + 80.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -80.0] [expr $y + -50.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 50.0] [expr $y + -80.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WW_2 PFCA ____ ____ ____ HLCA ____ HW_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 12.0] [expr $y + 50.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -50.0] [expr $y + 12.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -12.0] [expr $y + -50.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 50.0] [expr $y + -12.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WW_1 PFCA ____ ____ ____ HLCA ____ HW_1 }

set var1_anim PCAV
$c addtag $var1_anim.anim withtag $mymodId
