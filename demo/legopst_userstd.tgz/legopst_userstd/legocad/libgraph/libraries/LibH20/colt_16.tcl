# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image colt_16$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + -16.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + 16.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WU_4 PCOL ____ ____ ____ HCOL ____ HU_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 84.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 84.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -84.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -84.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WU_1 PCOL ____ ____ ____ HCOL ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 51.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 51.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -51.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -51.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WU_2 PCOL ____ ____ ____ HCOL ____ HU_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 17.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 17.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -17.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -17.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WU_3 PCOL ____ ____ ____ HCOL ____ HU_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -50.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + -50.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 50.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + 50.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { WU_5 PCOL ____ ____ ____ HCOL ____ HU_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -91.0] [expr $y + -2.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + -91.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 91.0] [expr $y + 2.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + 91.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WU_6 PCOL ____ ____ ____ HCOL ____ HU_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 89.0] [expr $y + 6.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -6.0] [expr $y + 89.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -89.0] [expr $y + -6.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 6.0] [expr $y + -89.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WE_1 PCOL ____ ____ ____ HE_1 ____ HCOL }

set var1_anim PCOL
$c addtag $var1_anim.anim withtag $mymodId
