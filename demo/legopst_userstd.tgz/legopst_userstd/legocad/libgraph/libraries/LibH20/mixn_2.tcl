# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image mixn_2$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 0.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + 18.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -0.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + -18.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WMIX XXXX ____ ____ ____ HMIX ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -22.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + 0.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + 22.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + -0.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { WE_5 ____ ____ ____ ____ HE_5 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -16.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 16.0] [expr $y + -18.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 16.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -16.0] [expr $y + 18.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WE_1 ____ ____ ____ ____ HE_1 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 0.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -0.0] [expr $y + -18.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -0.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 0.0] [expr $y + 18.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WE_2 ____ ____ ____ ____ HE_2 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 16.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + -18.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -16.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + 18.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WE_3 ____ ____ ____ ____ HE_3 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 22.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 0.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + -22.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -0.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WE_4 ____ ____ ____ ____ HE_4 ____ ____ }

set var1_anim WMIX
$c addtag $var1_anim.anim withtag $mymodId
