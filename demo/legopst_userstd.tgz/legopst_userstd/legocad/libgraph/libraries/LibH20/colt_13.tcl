# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image colt_13$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + -24.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + 24.0] [expr $y + -2.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + 24.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + -24.0] [expr $y + 2.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { WU_5 PCOL ____ ____ ____ HCOL ____ HU_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -4.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -18.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 4.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 18.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { WU_3 PCOL ____ ____ ____ HCOL ____ HU_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 8.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + -18.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -8.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + 18.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { WU_2 PCOL ____ ____ ____ HCOL ____ HU_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -10.0] [expr $y + 20.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + -20.0] [expr $y + -10.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 10.0] [expr $y + -20.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + 20.0] [expr $y + 10.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WU_1 PCOL ____ ____ ____ HCOL ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 14.0] [expr $y + -20.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + 14.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -14.0] [expr $y + 20.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + -14.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WE_4 PCOL ____ ____ ____ HE_4 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + -8.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + 18.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + 8.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + -18.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { WE_3 PCOL ____ ____ ____ HE_3 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 18.0] [expr $y + 8.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + 18.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -18.0] [expr $y + -8.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + -18.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { WE_2 PCOL ____ ____ ____ HE_2 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 10.0] [expr $y + 20.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + -20.0] [expr $y + 10.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -10.0] [expr $y + -20.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + 20.0] [expr $y + -10.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WE_1 PCOL ____ ____ ____ HE_1 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -14.0] [expr $y + -16.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + 16.0] [expr $y + -14.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 14.0] [expr $y + 16.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + -16.0] [expr $y + 14.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WU_4 PCOL ____ ____ ____ HCOL ____ HU_4 }
