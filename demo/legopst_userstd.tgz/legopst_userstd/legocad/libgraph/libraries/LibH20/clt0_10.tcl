# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image clt0_10$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -31.0] [expr $y + -22.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + -31.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + 31.0] [expr $y + 22.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + 31.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WE_1 PCOL ____ ____ ____ HE_1 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -46.0] [expr $y + 21.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + -46.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 46.0] [expr $y + -21.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + 46.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WU_1 PCOL ____ ____ ____ HCOL ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -15.0] [expr $y + 21.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + -15.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 15.0] [expr $y + -21.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + 15.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WU_2 PCOL ____ ____ ____ HCOL ____ HU_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 16.0] [expr $y + 21.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + 16.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -16.0] [expr $y + -21.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + -16.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WU_3 PCOL ____ ____ ____ HCOL ____ HU_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 47.0] [expr $y + 21.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -21.0] [expr $y + 47.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -47.0] [expr $y + -21.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 21.0] [expr $y + -47.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WU_4 PCOL ____ ____ ____ HCOL ____ HU_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 53.0] [expr $y + -2.0] -image fltm_n -anchor s]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 53.0] -image fltm_e -anchor w]}
s {set myportId [$c create image [expr $x + -53.0] [expr $y + 2.0] -image fltm_s -anchor n]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -53.0] -image fltm_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { PCOL HCOL WOUT TCOL }

set var1_anim PCOL
$c addtag $var1_anim.anim withtag $mymodId
