# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image clt0_19$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -78.0] [expr $y + -120.0] -image fltm_n -anchor s]}
e {set myportId [$c create image [expr $x + 120.0] [expr $y + -78.0] -image fltm_e -anchor w]}
s {set myportId [$c create image [expr $x + 78.0] [expr $y + 120.0] -image fltm_s -anchor n]}
w {set myportId [$c create image [expr $x + -120.0] [expr $y + 78.0] -image fltm_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { PCOL HCOL WOUT TCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 88.0] [expr $y + -5.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 5.0] [expr $y + 88.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -88.0] [expr $y + 5.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -5.0] [expr $y + -88.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WU_1 PCOL ____ ____ ____ HCOL ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -124.0] [expr $y + -115.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 115.0] [expr $y + -124.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 124.0] [expr $y + 115.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -115.0] [expr $y + 124.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { WE_1 PCOL ____ ____ ____ HE_1 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -90.0] [expr $y + -60.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 60.0] [expr $y + -90.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 90.0] [expr $y + 60.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -60.0] [expr $y + 90.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { WE_2 PCOL ____ ____ ____ HE_2 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -59.0] [expr $y + -4.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -59.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 59.0] [expr $y + 4.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 59.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port16 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port16.$mymodId
set port16.$mymodId { WE_3 PCOL ____ ____ ____ HE_3 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -26.0] [expr $y + 55.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -55.0] [expr $y + -26.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 26.0] [expr $y + -55.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 55.0] [expr $y + 26.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port17 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port17.$mymodId
set port17.$mymodId { WE_4 PCOL ____ ____ ____ HE_4 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + 117.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -117.0] [expr $y + 2.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + -117.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 117.0] [expr $y + -2.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { WE_5 PCOL ____ ____ ____ HE_5 ____ HCOL }

set var1_anim PCOL
$c addtag $var1_anim.anim withtag $mymodId
