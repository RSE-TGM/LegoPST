# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image clt0_20$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -95.0] [expr $y + -22.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + -95.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + 95.0] [expr $y + 22.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + 95.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { WE_1 PCOL ____ ____ ____ HE_1 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -22.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + -32.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 22.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + 32.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { WE_2 PCOL ____ ____ ____ HE_2 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + -21.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 21.0] [expr $y + 32.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + 21.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -21.0] [expr $y + -32.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { WE_3 PCOL ____ ____ ____ HE_3 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + -78.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -78.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 78.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 78.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port19 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port19.$mymodId
set port19.$mymodId { WU_4 PCOL ____ ____ ____ HCOL ____ HU_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -109.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -109.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 109.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 109.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { WU_3 PCOL ____ ____ ____ HCOL ____ HU_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -140.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -140.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 140.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 140.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { WU_2 PCOL ____ ____ ____ HCOL ____ HU_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -171.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -171.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 171.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 171.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { WU_1 PCOL ____ ____ ____ HCOL ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -45.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -45.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 45.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 45.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port18 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port18.$mymodId
set port18.$mymodId { WU_5 PCOL ____ ____ ____ HCOL ____ HU_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -14.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + -14.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 14.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + 14.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port17 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port17.$mymodId
set port17.$mymodId { WU_6 PCOL ____ ____ ____ HCOL ____ HU_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 17.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + 17.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -17.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + -17.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port16 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port16.$mymodId
set port16.$mymodId { WU_7 PCOL ____ ____ ____ HCOL ____ HU_7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 48.0] [expr $y + 23.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -23.0] [expr $y + 48.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -48.0] [expr $y + -23.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 23.0] [expr $y + -48.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { WU_8 PCOL ____ ____ ____ HCOL ____ HU_8 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 81.0] [expr $y + 22.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 81.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -81.0] [expr $y + -22.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -81.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port20 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port20.$mymodId
set port20.$mymodId { WU_9 PCOL ____ ____ ____ HCOL ____ HU_9 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 111.0] [expr $y + 22.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 111.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -111.0] [expr $y + -22.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -111.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port21 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port21.$mymodId
set port21.$mymodId { WU10 PCOL ____ ____ ____ HCOL ____ HU10 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 142.0] [expr $y + 22.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 142.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -142.0] [expr $y + -22.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -142.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port22 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port22.$mymodId
set port22.$mymodId { WU11 PCOL ____ ____ ____ HCOL ____ HU11 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 171.0] [expr $y + 22.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -22.0] [expr $y + 171.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -171.0] [expr $y + -22.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 22.0] [expr $y + -171.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port23 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port23.$mymodId
set port23.$mymodId { WU12 PCOL ____ ____ ____ HCOL ____ HU12 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 94.0] [expr $y + -21.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 21.0] [expr $y + 94.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + -94.0] [expr $y + 21.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -21.0] [expr $y + -94.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { WE_4 PCOL ____ ____ ____ HE_4 ____ HCOL }

switch $GIForient {
n {set myportId [$c create image [expr $x + 179.0] [expr $y + 1.0] -image fltm_e -anchor w]}
e {set myportId [$c create image [expr $x + -1.0] [expr $y + 179.0] -image fltm_s -anchor n]}
s {set myportId [$c create image [expr $x + -179.0] [expr $y + -1.0] -image fltm_w -anchor e]}
w {set myportId [$c create image [expr $x + 1.0] [expr $y + -179.0] -image fltm_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { PCOL HCOL WOUT TCOL }

set var1_anim PCOL
$c addtag $var1_anim.anim withtag $mymodId
