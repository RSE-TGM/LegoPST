# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image lsgs_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 66.0] [expr $y + -84.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 84.0] [expr $y + 66.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -66.0] [expr $y + 84.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -84.0] [expr $y + -66.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WITU PITU ____ ____ ____ HILD ____ HITI }

switch $GIForient {
n {set myportId [$c create image [expr $x + -8.0] [expr $y + 82.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -82.0] [expr $y + -8.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 8.0] [expr $y + -82.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 82.0] [expr $y + 8.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WUTU PUTU ____ ____ ____ HOLD ____ HDLC }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + -56.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 56.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + 56.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -56.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TL11 GL11 TL21 GL21 TL31 GL31 TW11 TW21 TW31 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + -48.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 48.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + 48.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -48.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TL41 GL41 TL51 GL51 TL61 GL61 TW41 TW51 TW61 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + -4.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + 4.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TL12 GL12 TL22 GL22 TL32 GL32 TW12 TW22 TW32 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + 4.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + -4.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TL42 GL42 TL52 GL52 TL62 GL62 TW42 TW52 TW62 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + 52.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + -52.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TL13 GL13 TL23 GL23 TL33 GL33 TW13 TW23 TW33 {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + 60.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -60.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + -60.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 60.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TL43 GL43 TL53 GL53 TL63 GL63 TW43 TW53 TW63 ____ }

set var1_anim HOLD
$c addtag $var1_anim.anim withtag $mymodId
