# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image meta_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + 52.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + 2.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + -52.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + -2.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TI_2 ____ ____ QI_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 52.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -52.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TE_2 ____ ____ QE_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 71.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -71.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -71.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 71.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TE_1 ____ ____ QE_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 72.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -72.0] [expr $y + 1.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -72.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 72.0] [expr $y + -1.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TI_1 ____ ____ QI_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + 35.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -35.0] [expr $y + 2.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + -35.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 35.0] [expr $y + -2.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TI_3 ____ ____ QI_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 15.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -15.0] [expr $y + 1.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -15.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 15.0] [expr $y + -1.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TI_4 ____ ____ QI_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -2.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + 1.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 2.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + -1.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TI_5 ____ ____ QI_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -24.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 24.0] [expr $y + 1.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 24.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -24.0] [expr $y + -1.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TI_6 ____ ____ QI_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -44.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + 1.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 44.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + -1.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TI_7 ____ ____ QI_7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -64.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 64.0] [expr $y + 0.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + 64.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -64.0] [expr $y + -0.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TI_8 ____ ____ QI_8 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 35.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -35.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -35.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 35.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TE_3 ____ ____ QE_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 15.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -15.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -15.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 15.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TE_4 ____ ____ QE_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -2.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 2.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 2.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -2.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TE_5 ____ ____ QE_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -24.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 24.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 24.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -24.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TE_6 ____ ____ QE_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -44.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 44.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { TE_7 ____ ____ QE_7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -64.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 64.0] [expr $y + -1.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 64.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -64.0] [expr $y + 1.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { TE_8 ____ ____ QE_8 }

set var1_anim TM_3
$c addtag $var1_anim.anim withtag $mymodId
