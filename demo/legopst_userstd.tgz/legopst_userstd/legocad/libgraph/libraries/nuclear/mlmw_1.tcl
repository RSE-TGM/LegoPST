# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image mlmw_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 110.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -110.0] [expr $y + 1.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -110.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 110.0] [expr $y + -1.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TFE1 GFE1 ____ ____ ____ ____ ____ ____ ____ TME1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 61.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -61.0] [expr $y + 1.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -61.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 61.0] [expr $y + -1.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TFE2 GFE2 ____ ____ ____ ____ ____ ____ ____ TME2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + 14.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -14.0] [expr $y + 1.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + -14.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 14.0] [expr $y + -1.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TFE3 GFE3 ____ ____ ____ ____ ____ ____ ____ TME3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -31.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 31.0] [expr $y + 1.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 31.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -31.0] [expr $y + -1.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TFE4 GFE4 ____ ____ ____ ____ ____ ____ ____ TME4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 1.0] [expr $y + -70.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 1.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -1.0] [expr $y + 70.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -1.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TFE5 GFE5 ____ ____ ____ ____ ____ ____ ____ TME5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -70.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -1.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 70.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 1.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TFI5 GFI5 {} {} {} {} {} {} {} TMI5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + -31.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 31.0] [expr $y + -1.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + 31.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -31.0] [expr $y + 1.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TFI4 GFI4 ____ ____ ____ ____ ____ ____ ____ TMI4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 14.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -14.0] [expr $y + -1.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -14.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 14.0] [expr $y + 1.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TFI3 GFI3 ____ ____ ____ ____ ____ ____ ____ TMI3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 61.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -61.0] [expr $y + -1.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -61.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 61.0] [expr $y + 1.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TFI2 GFI2 ____ ____ ____ ____ ____ ____ ____ TMI2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -1.0] [expr $y + 110.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -110.0] [expr $y + -1.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 1.0] [expr $y + -110.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 110.0] [expr $y + 1.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TFI1 GFI1 ____ ____ ____ ____ ____ ____ ____ TMI1 }

set var1_anim QE_5
$c addtag $var1_anim.anim withtag $mymodId
