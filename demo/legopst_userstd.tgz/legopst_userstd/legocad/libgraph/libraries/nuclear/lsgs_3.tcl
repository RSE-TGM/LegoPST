# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image lsgs_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 66.0] [expr $y + -84.0] -image hydr_w -anchor w]}
e {set myportId [$c create image [expr $x + 84.0] [expr $y + 66.0] -image hydr_n -anchor n]}
s {set myportId [$c create image [expr $x + -66.0] [expr $y + 84.0] -image hydr_e -anchor e]}
w {set myportId [$c create image [expr $x + -84.0] [expr $y + -66.0] -image hydr_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WITU PITU ____ ____ ____ HILD ____ HITI }

switch $GIForient {
n {set myportId [$c create image [expr $x + -8.0] [expr $y + 82.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -82.0] [expr $y + -8.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + 8.0] [expr $y + -82.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 82.0] [expr $y + 8.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WUTU PUTU ____ ____ ____ HOLD ____ HDLC }

switch $GIForient {
n {set myportId [$c create image [expr $x + -54.0] [expr $y + 52.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + -54.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 54.0] [expr $y + -52.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + 54.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TL11 GL11 TL12 GL12 {} {} {} {} TW11 TW12 }

set var1_anim HOLD
$c addtag $var1_anim.anim withtag $mymodId
