# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image cuo2_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -58.0] -image dump_s -anchor s]}
e {set myportId [$c create image [expr $x + 58.0] [expr $y + 0.0] -image dump_w -anchor w]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + 58.0] -image dump_n -anchor n]}
w {set myportId [$c create image [expr $x + -58.0] [expr $y + 0.0] -image dump_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { ____ ____ QNEU ____ ____ ____ ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + -12.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 12.0] [expr $y + -18.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + 12.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -12.0] [expr $y + 18.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { T_13 T_23 T_33 T_43 T_53 TG_1 TG_2 TG_3 TG_4 TG_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -18.0] [expr $y + 16.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -16.0] [expr $y + -18.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 18.0] [expr $y + -16.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 16.0] [expr $y + 18.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { T_63 T_73 T_83 T_93 T103 TG_6 TG_7 TG_8 TG_9 TG10 }

set var1_anim QNEU
$c addtag $var1_anim.anim withtag $mymodId
