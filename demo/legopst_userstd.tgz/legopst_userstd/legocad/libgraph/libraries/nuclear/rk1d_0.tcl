# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image rk1d_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + 66.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -66.0] [expr $y + 32.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + -66.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 66.0] [expr $y + -32.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TC11 TC12 TC13 QGC1 TC21 TC22 TC23 QGC2 {} {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + 55.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -55.0] [expr $y + 32.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + -55.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 55.0] [expr $y + -32.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TC31 TC32 TC33 QGC3 TC41 TC42 TC43 QGC4 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + 44.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -44.0] [expr $y + 32.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + -44.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 44.0] [expr $y + -32.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TC51 TC52 TC53 QGC5 TC61 TC62 TC63 QGC6 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 32.0] [expr $y + 33.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -33.0] [expr $y + 32.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -32.0] [expr $y + -33.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 33.0] [expr $y + -32.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TC71 TC72 TC73 QGC7 TC81 TC82 TC83 QGC8 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 55.0] [expr $y + -37.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 37.0] [expr $y + 55.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -55.0] [expr $y + 37.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -37.0] [expr $y + -55.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { HMN1 HMN2 HMN3 HMN4 HMN5 HMN6 HMN7 HMN8 ____ PMUN }

set var1_anim QTRC
$c addtag $var1_anim.anim withtag $mymodId
