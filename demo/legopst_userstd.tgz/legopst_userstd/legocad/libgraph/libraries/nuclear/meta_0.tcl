# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image meta_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + -8.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + 2.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + 8.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + -2.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TI_2 ____ ____ QI_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + -44.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + 2.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + 44.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + -2.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TI_3 ____ ____ QI_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 2.0] [expr $y + 28.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + 2.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -2.0] [expr $y + -28.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + -2.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TI_1 ____ ____ QI_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + 28.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -28.0] [expr $y + -2.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + -28.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 28.0] [expr $y + 2.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TE_1 ____ ____ QE_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + -8.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + -2.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + 8.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + 2.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TE_2 ____ ____ QE_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + -44.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 44.0] [expr $y + -2.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + 44.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -44.0] [expr $y + 2.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TE_3 ____ ____ QE_3 }

set var1_anim TM_3
$c addtag $var1_anim.anim withtag $mymodId
