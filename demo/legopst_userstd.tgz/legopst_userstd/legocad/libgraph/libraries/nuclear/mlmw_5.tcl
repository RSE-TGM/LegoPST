# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image mlmw_5$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 78.0] -image dump_n -anchor n]}
e {set myportId [$c create image [expr $x + -78.0] [expr $y + 0.0] -image dump_e -anchor e]}
s {set myportId [$c create image [expr $x + 0.0] [expr $y + -78.0] -image dump_s -anchor s]}
w {set myportId [$c create image [expr $x + 78.0] [expr $y + 0.0] -image dump_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TMI1 TMC1 TME1 ____ ____ ____ ____ TIGI TCGI TEGI }

switch $GIForient {
n {set myportId [$c create image [expr $x + 6.0] [expr $y + 4.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + 6.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -6.0] [expr $y + -4.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + -6.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TFI1 TFI2 TFI3 TFI4 TFI5 TMI1 TMI2 TMI3 TMI4 TMI5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + -8.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + -2.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + 8.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + 2.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { TFE1 GFE1 TFE2 GFE2 TFE3 GFE3 TFE4 GFE4 TFE5 GFE5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -2.0] [expr $y + 8.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + -2.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 2.0] [expr $y + -8.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + 2.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { TME1 TME2 TME3 TME4 TME5 ____ ____ ____ ____ ____ }

set var1_anim TMC1
$c addtag $var1_anim.anim withtag $mymodId
