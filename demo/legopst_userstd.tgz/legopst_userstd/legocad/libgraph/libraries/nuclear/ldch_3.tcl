# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image ldch_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -29.5] [expr $y + 86.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + -86.0] [expr $y + -29.5] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 29.5] [expr $y + -86.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + 86.0] [expr $y + 29.5] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WITU PITU ____ ____ ____ HILD ____ HITI }

switch $GIForient {
n {set myportId [$c create image [expr $x + 28.0] [expr $y + -86.5] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 86.5] [expr $y + 28.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -28.0] [expr $y + 86.5] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -86.5] [expr $y + -28.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WUTU PUTU ____ ____ ____ HOLD ____ HDLC }

switch $GIForient {
n {set myportId [$c create image [expr $x + 10.0] [expr $y + -8.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 8.0] [expr $y + 10.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -10.0] [expr $y + 8.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -8.0] [expr $y + -10.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TL11 GL11 TL12 GL12 TL13 GL13 TL14 GL14 {} {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + 10.0] [expr $y + 8.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -8.0] [expr $y + 10.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -10.0] [expr $y + -8.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 8.0] [expr $y + -10.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TW11 TW12 TW13 TW14 {} ____ ____ ____ ____ ____ }

set var1_anim HOLD
$c addtag $var1_anim.anim withtag $mymodId
