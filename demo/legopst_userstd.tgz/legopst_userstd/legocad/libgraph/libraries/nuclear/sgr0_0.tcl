# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image sgr0_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 5.0] [expr $y + -48.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 48.0] [expr $y + 5.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -5.0] [expr $y + 48.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -48.0] [expr $y + -5.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TL_6 G2_6 ____ ____ ____ ____ ____ ____ ____ T2_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 5.0] [expr $y + -22.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + 5.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -5.0] [expr $y + 22.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + -5.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TL_5 G2_5 ____ ____ ____ ____ ____ ____ ____ T2_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 6.0] [expr $y + 2.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + 6.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -6.0] [expr $y + -2.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + -6.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TL_4 G2_4 ____ ____ ____ ____ ____ ____ ____ T2_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 6.0] [expr $y + 27.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -27.0] [expr $y + 6.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -6.0] [expr $y + -27.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 27.0] [expr $y + -6.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TL_3 G2_3 ____ ____ ____ ____ ____ ____ ____ T2_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 6.0] [expr $y + 49.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -49.0] [expr $y + 6.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -6.0] [expr $y + -49.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 49.0] [expr $y + -6.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TL_2 G2_2 ____ ____ ____ ____ ____ ____ ____ T2_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 6.0] [expr $y + 69.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + -69.0] [expr $y + 6.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -6.0] [expr $y + -69.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + 69.0] [expr $y + -6.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TL_1 G2_1 ____ ____ ____ ____ ____ ____ ____ T2_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -5.0] [expr $y + -48.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 48.0] [expr $y + -5.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 5.0] [expr $y + 48.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -48.0] [expr $y + 5.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TL_6 G1_6 ____ ____ ____ ____ ____ ____ ____ T1_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + -20.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + 20.0] [expr $y + -4.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + 20.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + -20.0] [expr $y + 4.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { TL_5 G1_5 ____ ____ ____ ____ ____ ____ ____ T1_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 2.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + -4.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -2.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + 4.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TL_4 G1_4 ____ ____ ____ ____ ____ ____ ____ T1_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 27.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -27.0] [expr $y + -4.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -27.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 27.0] [expr $y + 4.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TL_3 G1_3 ____ ____ ____ ____ ____ ____ ____ T1_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 49.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -49.0] [expr $y + -4.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -49.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 49.0] [expr $y + 4.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TL_2 G1_2 ____ ____ ____ ____ ____ ____ ____ T1_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -5.0] [expr $y + 70.0] -image dump_e -anchor e]}
e {set myportId [$c create image [expr $x + -70.0] [expr $y + -5.0] -image dump_s -anchor s]}
s {set myportId [$c create image [expr $x + 5.0] [expr $y + -70.0] -image dump_w -anchor w]}
w {set myportId [$c create image [expr $x + 70.0] [expr $y + 5.0] -image dump_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TL_1 G1_1 ____ ____ ____ ____ ____ ____ ____ T1_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + 76.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -76.0] [expr $y + -32.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + -76.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 76.0] [expr $y + 32.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WIRI PIRI ____ ____ ____ HIRI ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -20.0] [expr $y + -79.0] -image hydr_w -anchor e]}
e {set myportId [$c create image [expr $x + 79.0] [expr $y + -20.0] -image hydr_n -anchor s]}
s {set myportId [$c create image [expr $x + 20.0] [expr $y + 79.0] -image hydr_e -anchor w]}
w {set myportId [$c create image [expr $x + -79.0] [expr $y + 20.0] -image hydr_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WU_6 PU_6 ____ ____ ____ HU_6 ____ ____ }

set var1_anim WU_6
$c addtag $var1_anim.anim withtag $mymodId
