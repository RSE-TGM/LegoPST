# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image cuo2_3$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + -70.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + 70.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { T_53 ____ ____ ____ ____ ____ ____ ____ ____ TG_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + -31.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + 31.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + 31.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + -31.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { T_43 ____ ____ ____ ____ ____ ____ ____ ____ TG_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + 14.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -14.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + -14.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 14.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { T_33 ____ ____ ____ ____ ____ ____ ____ ____ TG_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + 61.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -61.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + -61.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 61.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { T_23 ____ ____ ____ ____ ____ ____ ____ ____ TG_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + 110.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -110.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + -110.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 110.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { T_13 ____ ____ ____ ____ ____ ____ ____ ____ TG_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 34.0] -image dump_n -anchor n]}
e {set myportId [$c create image [expr $x + -34.0] [expr $y + 0.0] -image dump_e -anchor e]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + -34.0] -image dump_s -anchor s]}
w {set myportId [$c create image [expr $x + 34.0] [expr $y + -0.0] -image dump_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { ____ ____ QNEU ____ ____ ____ ____ ____ ____ ____ }

set var1_anim QG_5
$c addtag $var1_anim.anim withtag $mymodId
