# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image fuel_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 76.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -76.0] [expr $y + -4.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -76.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 76.0] [expr $y + 4.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { T_11 T_12 T_13 QN_1 T_21 T_22 T_23 QN_2 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 56.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -56.0] [expr $y + -4.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -56.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 56.0] [expr $y + 4.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { T_31 T_32 T_33 QN_3 T_41 T_42 T_43 QN_4 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 39.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -39.0] [expr $y + -4.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -39.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 39.0] [expr $y + 4.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { T_51 T_52 T_53 QN_5 T_61 T_62 T_63 QN_6 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -4.0] [expr $y + 19.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + -19.0] [expr $y + -4.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 4.0] [expr $y + -19.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + 19.0] [expr $y + 4.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { T_71 T_72 T_73 QN_7 T_81 T_82 T_83 QN_8 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + 109.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -109.0] [expr $y + -16.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + -109.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 109.0] [expr $y + 16.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { TG_1 ____ ____ QG_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -17.0] [expr $y + 81.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -81.0] [expr $y + -17.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 17.0] [expr $y + -81.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 81.0] [expr $y + 17.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { TG_2 ____ ____ QG_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -17.0] [expr $y + 55.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -55.0] [expr $y + -17.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 17.0] [expr $y + -55.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 55.0] [expr $y + 17.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { TG_3 ____ ____ QG_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -17.0] [expr $y + 29.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -29.0] [expr $y + -17.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 17.0] [expr $y + -29.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 29.0] [expr $y + 17.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { TG_4 ____ ____ QG_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + 4.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + -4.0] [expr $y + -16.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + -4.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + 4.0] [expr $y + 16.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { TG_5 ____ ____ QG_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + -21.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 21.0] [expr $y + -16.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + 21.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -21.0] [expr $y + 16.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { TG_6 ____ ____ QG_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + -45.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 45.0] [expr $y + -16.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + 45.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -45.0] [expr $y + 16.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TG_7 ____ ____ QG_7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -16.0] [expr $y + -70.0] -image term_w -anchor e]}
e {set myportId [$c create image [expr $x + 70.0] [expr $y + -16.0] -image term_n -anchor s]}
s {set myportId [$c create image [expr $x + 16.0] [expr $y + 70.0] -image term_e -anchor w]}
w {set myportId [$c create image [expr $x + -70.0] [expr $y + 16.0] -image term_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TG_8 ____ ____ QG_8 }

set var1_anim T_43
$c addtag $var1_anim.anim withtag $mymodId
