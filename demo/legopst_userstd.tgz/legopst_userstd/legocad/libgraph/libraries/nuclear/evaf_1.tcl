# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image evaf_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -10.0] [expr $y + -59.0] -image fltm_w -anchor e]}
e {set myportId [$c create image [expr $x + 59.0] [expr $y + -10.0] -image fltm_n -anchor s]}
s {set myportId [$c create image [expr $x + 10.0] [expr $y + 59.0] -image fltm_e -anchor w]}
w {set myportId [$c create image [expr $x + -59.0] [expr $y + 10.0] -image fltm_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { PUTU HU_3 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -11.0] [expr $y + 3.0] -image fltm_w -anchor e]}
e {set myportId [$c create image [expr $x + -3.0] [expr $y + -11.0] -image fltm_n -anchor s]}
s {set myportId [$c create image [expr $x + 11.0] [expr $y + -3.0] -image fltm_e -anchor w]}
w {set myportId [$c create image [expr $x + 3.0] [expr $y + 11.0] -image fltm_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { PUTU HU_2 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -11.0] [expr $y + 58.0] -image fltm_w -anchor e]}
e {set myportId [$c create image [expr $x + -58.0] [expr $y + -11.0] -image fltm_n -anchor s]}
s {set myportId [$c create image [expr $x + 11.0] [expr $y + -58.0] -image fltm_e -anchor w]}
w {set myportId [$c create image [expr $x + 58.0] [expr $y + 11.0] -image fltm_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag fltm_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { PUTU HU_1 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + 80.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -80.0] [expr $y + 0.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + -80.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 80.0] [expr $y + -0.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { WITU PITU ____ ____ ____ HITU ____ HU_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 0.0] [expr $y + -81.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 81.0] [expr $y + 0.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + -0.0] [expr $y + 81.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -81.0] [expr $y + -0.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { WUTU PUTU ____ ____ ____ HU_3 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + 33.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -33.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + -33.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 33.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { TM_3 ____ ____ QT_3 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + 52.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -52.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + -52.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 52.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { TM_2 ____ ____ QT_2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + 71.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -71.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + -71.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 71.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { TM_1 ____ ____ QT_1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + 15.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + -15.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + -15.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + 15.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { TM_4 ____ ____ QT_4 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + -7.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 7.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + 7.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -7.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { TM_5 ____ ____ QT_5 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + -51.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 51.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + 51.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -51.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { TM_7 ____ ____ QT_7 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + -28.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 28.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + 28.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -28.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { TM_6 ____ ____ QT_6 }

switch $GIForient {
n {set myportId [$c create image [expr $x + 15.0] [expr $y + -71.0] -image term_w -anchor w]}
e {set myportId [$c create image [expr $x + 71.0] [expr $y + 15.0] -image term_n -anchor n]}
s {set myportId [$c create image [expr $x + -15.0] [expr $y + 71.0] -image term_e -anchor e]}
w {set myportId [$c create image [expr $x + -71.0] [expr $y + -15.0] -image term_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port14 withtag $myportId
$c addtag port withtag $myportId
$c addtag term_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port14.$mymodId
set port14.$mymodId { TM_8 ____ ____ QT_8 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -19.0] [expr $y + -76.0] -image dump_w -anchor e]}
e {set myportId [$c create image [expr $x + 76.0] [expr $y + -19.0] -image dump_n -anchor s]}
s {set myportId [$c create image [expr $x + 19.0] [expr $y + 76.0] -image dump_e -anchor w]}
w {set myportId [$c create image [expr $x + -76.0] [expr $y + 19.0] -image dump_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port15 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port15.$mymodId
set port15.$mymodId { HU_1 HU_2 HU_3 HU_4 HU_5 HU_6 HU_7 HU_8 {} PUTU }

set var1_anim WITU
$c addtag $var1_anim.anim withtag $mymodId
