# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image crf0_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -7.0] [expr $y + 45.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -45.0] [expr $y + -7.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + 7.0] [expr $y + -45.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 45.0] [expr $y + 7.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WWIN PCHI ____ ____ ____ HWIE ____ HACH }

switch $GIForient {
n {set myportId [$c create image [expr $x + -7.0] [expr $y + -43.0] -image hydr_n -anchor s]}
e {set myportId [$c create image [expr $x + 43.0] [expr $y + -7.0] -image hydr_e -anchor w]}
s {set myportId [$c create image [expr $x + 7.0] [expr $y + 43.0] -image hydr_s -anchor n]}
w {set myportId [$c create image [expr $x + -43.0] [expr $y + 7.0] -image hydr_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WCHO PCHO ____ ____ ____ HACH ____ HSTI }

set var1_anim PCML
$c addtag $var1_anim.anim withtag $mymodId
