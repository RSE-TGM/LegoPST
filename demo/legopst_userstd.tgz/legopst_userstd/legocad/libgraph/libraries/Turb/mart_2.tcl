# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image mart_2$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 46.0] [expr $y + -22.0] -image dump_w -anchor w]}
e {set myportId [$c create image [expr $x + 22.0] [expr $y + 46.0] -image dump_n -anchor n]}
s {set myportId [$c create image [expr $x + -46.0] [expr $y + 22.0] -image dump_e -anchor e]}
w {set myportId [$c create image [expr $x + -22.0] [expr $y + -46.0] -image dump_s -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { ____ ____ ____ ____ ____ ____ ____ ____ ____ QTU1 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -43.0] [expr $y + -4.0] -image rome_w -anchor e]}
e {set myportId [$c create image [expr $x + 4.0] [expr $y + -43.0] -image rome_n -anchor s]}
s {set myportId [$c create image [expr $x + 43.0] [expr $y + 4.0] -image rome_e -anchor w]}
w {set myportId [$c create image [expr $x + -4.0] [expr $y + 43.0] -image rome_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -43.0] [expr $y + -9.0] -image rome_w -anchor e]}
e {set myportId [$c create image [expr $x + 9.0] [expr $y + -43.0] -image rome_n -anchor s]}
s {set myportId [$c create image [expr $x + 43.0] [expr $y + 9.0] -image rome_e -anchor w]}
w {set myportId [$c create image [expr $x + -9.0] [expr $y + 43.0] -image rome_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { RPM1 {} }

switch $GIForient {
n {set myportId [$c create image [expr $x + -43.0] [expr $y + -15.0] -image rome_w -anchor e]}
e {set myportId [$c create image [expr $x + 15.0] [expr $y + -43.0] -image rome_n -anchor s]}
s {set myportId [$c create image [expr $x + 43.0] [expr $y + 15.0] -image rome_e -anchor w]}
w {set myportId [$c create image [expr $x + -15.0] [expr $y + 43.0] -image rome_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -43.0] [expr $y + -21.0] -image rome_w -anchor e]}
e {set myportId [$c create image [expr $x + 21.0] [expr $y + -43.0] -image rome_n -anchor s]}
s {set myportId [$c create image [expr $x + 43.0] [expr $y + 21.0] -image rome_e -anchor w]}
w {set myportId [$c create image [expr $x + -21.0] [expr $y + 43.0] -image rome_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -43.0] [expr $y + -27.0] -image rome_w -anchor e]}
e {set myportId [$c create image [expr $x + 27.0] [expr $y + -43.0] -image rome_n -anchor s]}
s {set myportId [$c create image [expr $x + 43.0] [expr $y + 27.0] -image rome_e -anchor w]}
w {set myportId [$c create image [expr $x + -27.0] [expr $y + 43.0] -image rome_s -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port7 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port7.$mymodId
set port7.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -38.0] [expr $y + -30.0] -image rome_n -anchor s]}
e {set myportId [$c create image [expr $x + 30.0] [expr $y + -38.0] -image rome_e -anchor w]}
s {set myportId [$c create image [expr $x + 38.0] [expr $y + 30.0] -image rome_s -anchor n]}
w {set myportId [$c create image [expr $x + -30.0] [expr $y + 38.0] -image rome_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port8 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port8.$mymodId
set port8.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -30.0] -image rome_n -anchor s]}
e {set myportId [$c create image [expr $x + 30.0] [expr $y + -32.0] -image rome_e -anchor w]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 30.0] -image rome_s -anchor n]}
w {set myportId [$c create image [expr $x + -30.0] [expr $y + 32.0] -image rome_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -26.0] [expr $y + -30.0] -image rome_n -anchor s]}
e {set myportId [$c create image [expr $x + 30.0] [expr $y + -26.0] -image rome_e -anchor w]}
s {set myportId [$c create image [expr $x + 26.0] [expr $y + 30.0] -image rome_s -anchor n]}
w {set myportId [$c create image [expr $x + -30.0] [expr $y + 26.0] -image rome_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { RPM1 ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -21.0] [expr $y + -30.0] -image rome_n -anchor s]}
e {set myportId [$c create image [expr $x + 30.0] [expr $y + -21.0] -image rome_e -anchor w]}
s {set myportId [$c create image [expr $x + 21.0] [expr $y + 30.0] -image rome_s -anchor n]}
w {set myportId [$c create image [expr $x + -30.0] [expr $y + 21.0] -image rome_w -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { RPM1 ____ }

set var1_anim RPM1
$c addtag $var1_anim.anim withtag $mymodId
