# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image trn0_0$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + -24.0] [expr $y + -63.0] -image hydr_e -anchor e]}
e {set myportId [$c create image [expr $x + 63.0] [expr $y + -24.0] -image hydr_s -anchor s]}
s {set myportId [$c create image [expr $x + 24.0] [expr $y + 63.0] -image hydr_w -anchor w]}
w {set myportId [$c create image [expr $x + -63.0] [expr $y + 24.0] -image hydr_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WITZ PITZ ____ ____ ____ HITZ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 25.0] [expr $y + 2.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + 25.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -25.0] [expr $y + -2.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + -25.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { QMEC ____ ____ ____ ____ ____ ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 27.0] [expr $y + 15.0] -image rome_n -anchor n]}
e {set myportId [$c create image [expr $x + -15.0] [expr $y + 27.0] -image rome_e -anchor e]}
s {set myportId [$c create image [expr $x + -27.0] [expr $y + -15.0] -image rome_s -anchor s]}
w {set myportId [$c create image [expr $x + 15.0] [expr $y + -27.0] -image rome_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { RPMV QMEC }

switch $GIForient {
n {set myportId [$c create image [expr $x + -27.0] [expr $y + -69.0] -image comm_s -anchor s]}
e {set myportId [$c create image [expr $x + 69.0] [expr $y + -27.0] -image comm_w -anchor w]}
s {set myportId [$c create image [expr $x + 27.0] [expr $y + 69.0] -image comm_n -anchor n]}
w {set myportId [$c create image [expr $x + -69.0] [expr $y + 27.0] -image comm_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port5 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port5.$mymodId
set port5.$mymodId { SERC }

switch $GIForient {
n {set myportId [$c create image [expr $x + -17.0] [expr $y + -69.0] -image comm_s -anchor s]}
e {set myportId [$c create image [expr $x + 69.0] [expr $y + -17.0] -image comm_w -anchor w]}
s {set myportId [$c create image [expr $x + 17.0] [expr $y + 69.0] -image comm_n -anchor n]}
w {set myportId [$c create image [expr $x + -69.0] [expr $y + 17.0] -image comm_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port6 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port6.$mymodId
set port6.$mymodId { SEAV }

switch $GIForient {
n {set myportId [$c create image [expr $x + 5.0] [expr $y + -72.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 72.0] [expr $y + 5.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -5.0] [expr $y + 72.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -72.0] [expr $y + -5.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { WUTZ PUTZ ____ ____ ____ HUTZ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 28.0] [expr $y + 82.0] -image hydr_s -anchor n]}
e {set myportId [$c create image [expr $x + -82.0] [expr $y + 28.0] -image hydr_w -anchor e]}
s {set myportId [$c create image [expr $x + -28.0] [expr $y + -82.0] -image hydr_n -anchor s]}
w {set myportId [$c create image [expr $x + 82.0] [expr $y + -28.0] -image hydr_e -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { WSPZ PSES ____ ____ ____ HSES ____ ____ }

set var1_anim QMEC
$c addtag $var1_anim.anim withtag $mymodId
