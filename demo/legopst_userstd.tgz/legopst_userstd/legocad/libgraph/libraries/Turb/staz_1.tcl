# this file created with PREINST rel. 0.3 

set mymodId [$c create image $x $y -image staz_1$GIForient]
$c addtag id$mymodId withtag $mymodId
$c addtag module withtag $mymodId
$c addtag $idclass.cls withtag $mymodId
$c addtag $GIForient.ori withtag $mymodId
if {$fromfile == "yes"} {
	$c addtag $mlpath.lpath withtag $mymodId
} else {
	$c addtag $curLibPath.lpath withtag $mymodId
}
# let the user choose a name (Id)
if {$fromfile == "yes"} then {set progName $ff_progNumb} else {inputModName $c $x $y}
$c addtag $progName.name withtag $mymodId
incr progNumb

switch $GIForient {
n {set myportId [$c create image [expr $x + 39.0] [expr $y + -63.0] -image hydr_e -anchor w]}
e {set myportId [$c create image [expr $x + 63.0] [expr $y + 39.0] -image hydr_s -anchor n]}
s {set myportId [$c create image [expr $x + -39.0] [expr $y + 63.0] -image hydr_w -anchor e]}
w {set myportId [$c create image [expr $x + -63.0] [expr $y + -39.0] -image hydr_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port1 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port1.$mymodId
set port1.$mymodId { WAMM PCRT ____ ____ ____ HCRT ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -49.0] [expr $y + -71.0] -image hydr_s -anchor s]}
e {set myportId [$c create image [expr $x + 71.0] [expr $y + -49.0] -image hydr_w -anchor w]}
s {set myportId [$c create image [expr $x + 49.0] [expr $y + 71.0] -image hydr_n -anchor n]}
w {set myportId [$c create image [expr $x + -71.0] [expr $y + 49.0] -image hydr_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port0 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port0.$mymodId
set port0.$mymodId { WAM1 PAM1 ____ ____ ____ HAM1 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -49.0] [expr $y + 72.0] -image hydr_n -anchor n]}
e {set myportId [$c create image [expr $x + -72.0] [expr $y + -49.0] -image hydr_e -anchor e]}
s {set myportId [$c create image [expr $x + 49.0] [expr $y + -72.0] -image hydr_s -anchor s]}
w {set myportId [$c create image [expr $x + 72.0] [expr $y + 49.0] -image hydr_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port2 withtag $myportId
$c addtag port withtag $myportId
$c addtag hydr_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port2.$mymodId
set port2.$mymodId { WAM2 PAM2 ____ ____ ____ HAM2 ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -38.0] [expr $y + -66.0] -image comm_s -anchor s]}
e {set myportId [$c create image [expr $x + 66.0] [expr $y + -38.0] -image comm_w -anchor w]}
s {set myportId [$c create image [expr $x + 38.0] [expr $y + 66.0] -image comm_n -anchor n]}
w {set myportId [$c create image [expr $x + -66.0] [expr $y + 38.0] -image comm_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port3 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port3.$mymodId
set port3.$mymodId { ALZS }

switch $GIForient {
n {set myportId [$c create image [expr $x + -32.0] [expr $y + -89.0] -image comm_s -anchor s]}
e {set myportId [$c create image [expr $x + 89.0] [expr $y + -32.0] -image comm_w -anchor w]}
s {set myportId [$c create image [expr $x + 32.0] [expr $y + 89.0] -image comm_n -anchor n]}
w {set myportId [$c create image [expr $x + -89.0] [expr $y + 32.0] -image comm_e -anchor e]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port4 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port4.$mymodId
set port4.$mymodId { SEAV }

switch $GIForient {
n {set myportId [$c create image [expr $x + -33.0] [expr $y + 84.0] -image comm_n -anchor n]}
e {set myportId [$c create image [expr $x + -84.0] [expr $y + -33.0] -image comm_e -anchor e]}
s {set myportId [$c create image [expr $x + 33.0] [expr $y + -84.0] -image comm_s -anchor s]}
w {set myportId [$c create image [expr $x + 84.0] [expr $y + 33.0] -image comm_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port11 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port11.$mymodId
set port11.$mymodId { FARC }

switch $GIForient {
n {set myportId [$c create image [expr $x + 47.0] [expr $y + 2.0] -image dump_e -anchor w]}
e {set myportId [$c create image [expr $x + -2.0] [expr $y + 47.0] -image dump_s -anchor n]}
s {set myportId [$c create image [expr $x + -47.0] [expr $y + -2.0] -image dump_w -anchor e]}
w {set myportId [$c create image [expr $x + 2.0] [expr $y + -47.0] -image dump_n -anchor s]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port12 withtag $myportId
$c addtag port withtag $myportId
$c addtag dump_ptype withtag $myportId; #port type
$c addtag output withtag $myportId; #port direction
global port12.$mymodId
set port12.$mymodId { QMEC ____ ____ ____ ____ ____ ____ ____ ____ ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + 48.0] [expr $y + 26.0] -image rome_n -anchor n]}
e {set myportId [$c create image [expr $x + -26.0] [expr $y + 48.0] -image rome_e -anchor e]}
s {set myportId [$c create image [expr $x + -48.0] [expr $y + -26.0] -image rome_s -anchor s]}
w {set myportId [$c create image [expr $x + 26.0] [expr $y + -48.0] -image rome_w -anchor w]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port13 withtag $myportId
$c addtag port withtag $myportId
$c addtag rome_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port13.$mymodId
set port13.$mymodId { RPMT ____ }

switch $GIForient {
n {set myportId [$c create image [expr $x + -48.0] [expr $y + 64.0] -image comm_e -anchor e]}
e {set myportId [$c create image [expr $x + -64.0] [expr $y + -48.0] -image comm_s -anchor s]}
s {set myportId [$c create image [expr $x + 48.0] [expr $y + -64.0] -image comm_w -anchor w]}
w {set myportId [$c create image [expr $x + 64.0] [expr $y + 48.0] -image comm_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port10 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port10.$mymodId
set port10.$mymodId { ZVA2 }

switch $GIForient {
n {set myportId [$c create image [expr $x + -48.0] [expr $y + -62.0] -image comm_e -anchor e]}
e {set myportId [$c create image [expr $x + 62.0] [expr $y + -48.0] -image comm_s -anchor s]}
s {set myportId [$c create image [expr $x + 48.0] [expr $y + 62.0] -image comm_w -anchor w]}
w {set myportId [$c create image [expr $x + -62.0] [expr $y + 48.0] -image comm_n -anchor n]}
}
$c addtag id$myportId withtag $myportId
$c addtag id$mymodId withtag $myportId
$c addtag port9 withtag $myportId
$c addtag port withtag $myportId
$c addtag comm_ptype withtag $myportId; #port type
$c addtag input withtag $myportId; #port direction
global port9.$mymodId
set port9.$mymodId { ZVA1 }

set var1_anim QMEC
$c addtag $var1_anim.anim withtag $mymodId
