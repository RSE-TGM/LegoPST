#!/bin/bash
# Safe config launcher with automatic shared memory cleanup
# GUAG2025 con Claude - Helper script for robust config usage
set -x
cd /home/antonio/legocad/r_MDC0
source /home/antonio/LegoPST2010A_WSL_DARHE6_64/.profile_legoroot
export DISPLAY=:0

echo "=== Safe Config Launcher ==="
echo "This script automatically cleans shared memory when needed."
echo ""

# Function to clean shared memory
cleanup_shared_memory() {
    echo "Cleaning potentially corrupted shared memory segments..."
    # Get shared memory segments owned by antonio
    SEGMENTS=$(ipcs -m | grep antonio | awk '{print $2}')
    for seg in $SEGMENTS; do
        echo "Removing shared memory segment: $seg"
        ipcrm -m $seg 2>/dev/null
    done
    echo "Shared memory cleanup completed."
}

# Function to run config safely
run_config() {
    echo "Starting config..."
    /home/antonio/LegoPST2010A_WSL_DARHE6_64/Alg_mmi/bin/config "$@"
    EXIT_CODE=$?
    
    if [ $EXIT_CODE -ne 0 ]; then
        echo ""
        echo "Config exited with error code: $EXIT_CODE"
        if [ $EXIT_CODE -eq 134 ] || [ $EXIT_CODE -eq 139 ]; then
            echo "Detected crash (segfault or abort). Cleaning shared memory..."
            cleanup_shared_memory
        fi
    fi
    
    return $EXIT_CODE
}

# Show usage if no arguments
if [ $# -eq 0 ]; then
    echo "Usage: $0 [config arguments]"
    echo ""
    echo "Examples:"
    echo "  $0                    # Start config GUI"
    echo "  $0 -c compall         # Compile all pages"
    echo "  $0 -c compreg         # Compile regulation pages"
    echo ""
    echo "Additional commands:"
    echo "  $0 clean              # Just clean shared memory"
    echo "  $0 status             # Show shared memory status"
    exit 1
fi

# Handle special commands
case "$1" in
    "clean")
        cleanup_shared_memory
        exit 0
        ;;
    "status")
        echo "Current shared memory segments:"
        ipcs -m | grep antonio || echo "No shared memory segments found for antonio"
        exit 0
        ;;
    "exe")
        echo "starting config:"
        /home/antonio/LegoPST2010A_WSL_DARHE6_64/Alg_mmi/bin/config 
        exit 0
        ;;
    *)
        run_config "$@"
        ;;
esac
