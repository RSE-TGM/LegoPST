C***********************************************************************
C*                                                                     *
C*                   VERSIONE MODIFICATA DA S.D.I.                     *
C*                          IL 29/5/1992                               *
C*                                                                     *
C***********************************************************************
C
C~FORAUS_CGAS~C
      REAL FUNCTION GAMLF(W,S,D,T)                                      !SNGL
C      DOUBLE PRECISION FUNCTION GAMLF(W,S,D,T)                          !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C Calcola il coefficiente di scambio in long flow
C W = portata
C S = sezione
C D=  diametro equivalente
C T=  temperatura (kelvin)
C
      DATA A0,A1,B0,B1,T0/127.547,0.0633,156.27,0.0344,1060./
      DATA EPS/1./
      G=(ABS(W)+EPS)/S
C
      IF(T.LE.T0) THEN
      FPP=A0+A1*T
      ELSE
      FPP=B0+B1*T
      END IF
C
      UPCL=0.023*G**0.8/D**0.2
C
      GAMLF=UPCL*FPP
C
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO CONDOTTO ARIA GAS ADIABATICO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C     FUNCTION GAMLF(W,S,D,T)
C
C Calcola il coefficiente di scambio in long flow
C tra la parete e il gas e lo memorizza in GAMLF
C
C W = portata (kg/s)
C S = sezione (m**2)
C D=  diametro equivalente (m)
C T=  temperatura (kelvin)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
CC      REAL FUNCTION GAMLF(W,S,D,T)                                      !SNGL
CC      DOUBLE PRECISION FUNCTION GAMLF(W,S,D,T)                          !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C~FORAUS_CGAS~C
C~FORAUS_CNDN~C
      SUBROUTINE  CNDLIV(TYP,Y,VL,DVLDY,YPER)
C
C           SUBROUTINE DA COMPILARE A CURA DELL'UTENTE
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO CNDS'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE LA FUNZIONE '
      WRITE(6,*)' VOLUME=F(LIVELLO) PER IL CONDENSATORE'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' *****   CNDLIV   ****'
C
      IF(VL.LE.0.)STOP
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO CONDENSATORE DI VAPORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE CNDLIV(TYP,Y,VL,DVLDY,YPER)
C
C  La subroutine CNDLIV, in funzione dei valori TYP e Y
C  deve fornire  VL, DVLDY e YPER.
C
C  Parametri in ingresso:  TYP, Y
C  Parametri in uscita:    VL, DVLDY, YPER
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato TYPE_CAV nel file F14 (vedi scheda D1)  viene
C              utilizzato per distinguere le  diverse  geometrie  delle  cavita`
C              trattate dal modulo CNDN presenti contemporaneamente in un model-
C              lo matematico. Viene di solito usato all'interno della subroutine
C              come puntatore;
C
C  Y         = rappresenta la misura del livello totale nella cavita`in metri;
C
C  VL        = volume occupato dalla zona liquida in m**3;
C
C  DVLDY     = derivata del volume del liquido rispetto al livello;
C
C  YPER      = livello di liquido nel range di misura in %.
C
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  CNDLIV(TYP,Y,VL,DVLDY,YPER)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_CNDN~C
C~FORAUS_COND~C
      SUBROUTINE  CDLIV(TYP,Y,VL,DVLDY,YPER)
C
C      SUBROUTINE DA COMPILARE ACURA DELL'UTENTE
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO COND'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE LA FUNZIONE '
      WRITE(6,*)' VOLUME=F(LIVELLO) PER IL CONDENSATORE'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' *****   CDLIV   ****'
C
        IF(VL.LE.0.)STOP
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO CONDENSATORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE CDLIV(TYP,Y,VL,DVLDY,YPER)
C
C  La subroutine CDLIV, in funzione dei valori TYP e Y
C  deve fornire  VL, DVLDY e YPER.
C
C  Parametri in ingresso:  TYP, Y
C  Parametri in uscita:    VL, DVLDY, YPER
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato TYPE_CAV nel file F14 (vedi scheda D1)  viene
C              utilizzato per distinguere le  diverse  geometrie  delle  cavita`
C              trattate dal modulo COND presenti contemporaneamente in un model-
C              lo matematico. Viene di solito usato all'interno della subroutine
C              come puntatore;
C
C  Y         = rappresenta la misura del livello totale nella cavita`in metri;
C
C  VL        = volume occupato dalla zona liquida in m**3;
C
C  DVLDY     = derivata del volume del liquido rispetto al livello;
C
C  YPER      = livello di liquido nel range di misura in %.
C
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  CDLIV(TYP,Y,VL,DVLDY,YPER)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_COND~C
C~FORAUS_CPOM~C
      SUBROUTINE DPU(TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI DP E CRES IN
C      FUNZIONE DELLE ALTRE VARIABILI.
C      SIGNIFICATO DELLE VARIABILI DI INGRESSO-USCITA:
C
C       TYP = DATO A DISPOSIZIONE DELL'UTENTE PER DISTINGUERE
C             DIVERSE CARATTERISTICHE CONTENUTE IN QUESTA SUBROUTINE
C       QVNOM = PORTATA NOMINALE (M**3/S)
C       OMNOM = NUMERO DI GIRI NOMINALE (RAD/S)
C       DPNOM = PREVALENZA NOMINALE (PA)
C       CNOM = COPPIA NOMINALE (N*M)
C       ETANOM=RENDIMENTO NOMINALE
C       Q = PORTATA EFFETTIVA (M**3/S)
C       RO = DENSITA' EFFETTIVA (KG/M**3)
C       OM = VELOCITA' EFFETTIVA (RAD/S)
C       DP = PREVALENZA EFFETTIVA (PA)
C       CRES = COPPIA RESISTENTE EFFETTIVA (KG*M)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'*** FORNIRE LA CARATTERISTICA DELLA POMPA'
     $      ,' O TYP=0. NEL FILE 14 ***'/)
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO POMPA CENTRIFUGA
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C      SUBROUTINE DPU(TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
C
C  Parametri in ingresso: TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM
C  Parametri in uscita  : DP,CRES
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI DP E CRES IN
C      FUNZIONE DELLE ALTRE VARIABILI.
C      SIGNIFICATO DELLE VARIABILI DI INGRESSO-USCITA:
C
C       TYP = DATO A DISPOSIZIONE DELL'UTENTE PER DISTINGUERE
C             DIVERSE CARATTERISTICHE CONTENUTE IN QUESTA SUBROUTINE
C       QVNOM = PORTATA NOMINALE (M**3/S)
C       OMNOM = NUMERO DI GIRI NOMINALE (RAD/S)
C       DPNOM = PREVALENZA NOMINALE (PA)
C       CNOM = COPPIA NOMINALE (N*M)
C       ETANOM=RENDIMENTO NOMINALE
C       Q = PORTATA EFFETTIVA (M**3/S)
C       RO = DENSITA' EFFETTIVA (KG/M**3)
C       OM = VELOCITA' EFFETTIVA (RAD/S)
C       DP = PREVALENZA EFFETTIVA (PA)
C       CRES = COPPIA RESISTENTE EFFETTIVA (KG*M)
C
C       ESEMPIO DI SUBROUTINE:
C
C****************CARATTERISTICA POMPA*********************
CC        A=1.22
CC        OMS=OM/OMNOM
CC        QS=Q/QVNOM
CC        DP=DPNOM*(A*OMS**2-(A-1.)*QS*ABS(QS))
C
C       QUANDO LA POMPA FUNZIONA A BOCCA CHIUSA (Q=0) E A VELOCITA'
C       NOMINALE (OM=OMNOM), DP=DPNOM*A.
C       A DUNQUE DEFINISCE LA PREVALENZA A BOCCA CHIUSA
C
C****************FORMULA DEL RENDIMENTO*******************
CC        IF(OMS.LT.1.E-4)GO TO 125
CC        RID=QS/OMS
CC        ETA=ETANOM*(-RID**2+2.*RID)
C
C****************COPPIA RESISTENTE***********************
CC        IF(ETA.LT.1.E-4)GO TO 125
CC        OME=OM
CC        IF(OME.LE.1.E-3)OME=1.E-3
CC        CRES=Q*DP/OME/ETA
CC        GO TO 130
CC125     CRES=0.5*DP/DPNOM*CNOM
CC130     CONTINUE
CC        END
C
C       FINE ESEMPIO .
C
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C      SUBROUTINE DPU(TYP,QVNOM,OMNOM,DPNOM,CNOM,ETANOM,Q,RO,OM,DP,CRES)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      RETURN
C      END
C
C~FORAUS_CPOM~C
C~FORAUS_CUO2~C
      REAL FUNCTION FCUO21(T)                                           !SNGL
C      DOUBLE PRECISION FUNCTION FCUO21(T)                               !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C**CALCOLO DEL CALORE SPECIFICO UO2
C     RIF.: RAPPORTO  EDF (TB 71-9) ==>URANIUM DIOXIDE UO2 -USAEC
C        FCUO21(W/KG/K)  T(K)
C
      FCUO21=4186.8/270.*(18.45+.002431*T-2.272E5/(T*T))
      RETURN
      END
      REAL FUNCTION FCUO22(T)                                           !SNGL
C      DOUBLE PRECISION FUNCTION FCUO22(T)                               !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C**CALCOLO DELLA CONDUCIBILITA' UO2
C     RIF.: RAPPORTO  EDF (TB 71-9) ==>GENERAL ELECTRIC GEAP 5493
C        FCUO22(W/M/K)  T(K)
C
      FCUO22=1./(.0322+.0002497*T)+.641576E-10*T*T*T
      RETURN
      END
      REAL FUNCTION FCUO23(T)                                           !SNGL
C      DOUBLE PRECISION FUNCTION FCUO23(T)                               !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C**CALCOLO DEL COEFFICIENTE DI SCAMBIO INTERC.-GUAINA
      FCUO23=10000.
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO BARRE DI COMBUSTIBILE NUCLEARE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLE FUNCTIONS: ******************
C            FCUO21
C            FCUO22
C            FCUO23
C_______________________________________________________________________________
C_____________FUNCTION FCUO21(T)
C**calcolo del calore specifico uo2
C (puo` essere funzione della temperatura)
C       FCUO21  calore specifico del biossido di uranio (J/KG/K)
C       T       temperatura (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO21(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO21(T)                              !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       RETURN
C       END
C_______________________________________________________________________________
C_____________FUNCTION FCUO22(T)
C**calcolo della conducibilita' uo2
C (puo` essere funzione della temperatura)
C        FCUO22  conducibilita` uo2  (W/M/K)
C        T       temperatura  (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO22(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO22(T)                              !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       RETURN
C       END
C_______________________________________________________________________________
C_____________FUNCTION FCUO23(T)
C**calcolo del coefficiente di scambio intercapedine-guaina
C (puo` essere funzione della temperatura)
C        FCUO23  coefficiente di scambio (W/M**2)
C        T       temperatura  (K)
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
CC       REAL FUNCTION FCUO23(T)                                          !SNGL
CC       DOUBLE PRECISION FUNCTION FCUO23(T)                              !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       RETURN
C       END
C~FORAUS_CUO2~C
C~FORAUS_DAMP~C
      REAL FUNCTION ADNS10(ALZS,ALFA)                                   !SNGL
C      DOUBLE PRECISION FUNCTION ADNS10(ALZS,ALFA)                       !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'*** FORNIRE LA CARATTERISTICA DELLA SERRANDA'
     $/10X,'SCRIVENDO LA FUNCTION ADNS10(ALZAS,ALFA) (VEDI DOC. DAMP)'
     $/10X,' CHE DEFINISCE LA SEZIONE IN FUNZIONE DELLA POSIZIONE'
     $/10X,'POICHE` NEI DATI SU FILE 14 E` STATO POSTO ALFA > 10.'//)
      ADNS10=ALZAS
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO SERRANDA CIRCUITO ARIA_GAS
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C               FUNCTION ADNS10(ALZAS,ALFA)
C
C  Function per l'assegnazione della caratteristica della valvola
C
C  Parametri d'ingresso: ALZAS,ALFA
C  Parametri d'uscita  : ADNS10
C
C************* BREVE SPIEGAZIONE DEI PARAMETRI DELLA FUNCTION ************
C
C [p.u.]  ALZAS  -  grado di apertura della serranda.
C
C [ ]     ALFA   -  (>10) parametro,  proveniente  dai  dati  in input, che puo`
C                   essere utilizzato come indice  di  scelta nel caso in cui si
C                   vogliano introdurre diverse caratteristiche standard tramite
C                   un'unica FUNCTION ADNS10(ALZAS,ALFA).
C
C [p.u.]  ADNS10 -  valore calcolato della sezione di passaggio. Tale valore
C                   deve essere normalizzato rispetto alla sezione di passaggio
C                   a serranda completamente aperta.
C
C
C  Esempio di caratteristica assegnata per punti:
C
C
CC       REAL FUNCTION ADNS10(Z,ALFA)                                     !SNGL
CC       DOUBLE PRECISION FUNCTION ADNS10(Z,ALFA)                         !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       DIMENSION X1(11),Y1(11)
C       DATA X1/0.,.1,.2,.3,.4,.5,.6,.7,.8,.9,1./
C       DATA Y1/0.,.055,.085,.125,.17,.22,.28,.35,.43,.55,1./
CC
CC
C       CALL ADNSIN(Z,X1,Y1,11,A)
C       ADNS10=A
C       RETURN
C       END
C       SUBROUTINE ADNSIN(Z,X,Y,NP,A)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       DIMENSION X(*),Y(*)
CC
CC     INTERPOLAZIONE
CC
C       A=0.
C       IF(Z.LE.X(1))RETURN
C       A=1.
C       IF(Z.GE.X(NP))RETURN
C       DO I=1,NP-1
C       J=I
C       IF(Z.GE.X(J).AND.Z.LE.X(J+1))GO TO 15
C       END DO
C   15  A=Y(J)+(Z-X(J))*(Y(J+1)-Y(J))/(X(J+1)-X(J))
C       RETURN
C       END
C
C************** INIZIO DEL TESTO FORTRAN DA SCRIVERE ********************
C
CC      REAL FUNCTION ADNS10(ALZS,ALFA)                                   !SNGL
CC      DOUBLE PRECISION FUNCTION ADNS10(ALZS,ALFA)                       !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      RETURN
C      END
C
C~FORAUS_DAMP~C
C~FORAUS_EVAN~C
      SUBROUTINE GAMUTXE(P,HA,SA,TA,RA,TIT,TMCA,DIAI,
     $           CRIG,G,Q,SUPI,GAMIN)
C-------------------------------------------------------------------
C     COEFFICIENTE DI SCAMBIO METALLO/FLUIDO
C     FORNITO DALL'UTENTE
C-------------------------------------------------------------------
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'**** DEVI FORNIRE LA SUBROUINE UTENTE  "GAMUTXE"'
     $/10X,'      DAL MOMENTO CHE  IL DATO  "CRIG" DEL MODULO EVAN'
     $/10X,'      LA RICHIEDE')
C
      STOP 'ESECUZIONE ARRESTATA DALLA SUBROUTINE GAMUTXE DI EVAN'
      END
C
C
C FORTRAN AUSILIARIO DEL MODULO EVAN
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C      SUBROUTINE GAMUTXE(P,HA,SA,TA,RA,TIT,TMCA,DIAI,
C     &           CRIG,G,Q,SUPI,GAMIN)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C
C__________ SE VUOI CHE LA SUBROUTINE GAMUTXE SIA CHIAMATA DA EVAN
C           RICORDATI DI METTERE NEI DATI DEL MODULO
C
C                   CRIG < 0.
C
C  La subroutine fornisce al modulo EVAN il coefficiente di scambio
C  termico GAMIN fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C---  P      : PRESSIONE DI CELLA
C---  TA     : TEMPERATURA MEDIA DI CELLA DEL FLUIDO
C---  TMCA   : TEMPERATURA MEDIA DI CELLA DEL METALLO
C---  Q      : CALORE SCAMBIATO FRA METALLO E FUMI
C---  HA     : ENTALPIA SPECIFICA DI CELLA
C---  SA     : ENTROPIA SPECIFICA DI CELLA
C---  RA     : DENSITA' MEDIA DI CELLA
C---  DIAI   : DIAMETRO INTERNO DEL TUBO
C---  SUPI   : SUPERFICIE DI SCAMBIO DELLA CELLA
C---  G      : PORTATA SPECIFICA
C___  TIT    : TITOLO TERMODINAMICO DEL FLUIDO
C___  CRIG   : PARAMETRO-UTENTE IN INGRESSO ALLA SUBROUTINE
C------------------------------------------------------------
C          LA SUBROUTINE FORNISCE
C---  GAMIN  : COEFFICIENTI DI SCAMBIO METALLO/FLUIDO
C              (WATT/M**2/C)
C
C
C~FORAUS_EVAN~C
C~FORAUS_TURG~C
C
      FUNCTION TG_UT_FU10(QTGP,FTAMB)
C--   CALCOLO DELLA TEMPERATURA DI RIFERIMENTO
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI SET PER IL CONTROLLO
C                         DELLA TEMPERATURA DI USCITA GAS DAL TURBO_GAS
C                         IN GRADI KELVIN
C
C      IN FUNZIONE DI  QTGP = POTENZA IN % ,
C                      FTAMB = TEMPERATURA AMBIENTE IN GRADI FARENHEIT
C
C
C____ ESEMPIO PER TURBOGAS TIPO   NUOVO PIGNONE
C
CC      PARAMETER (LDT=13,LTC=5,LUR=65)
CC      DIMENSION TABQ(LDT),TABTAM(LTC),TABTRX(LUR)
CC      DATA TABQ  /0.,20.,40.,62.,71.,77.6,80.,88.6,
CC     &           97.,100.,110.6,121.7,130./
CC      DATA TABTAM/0.,30.,59.,90.,120./
CC      DATA TABTRX/1295.,1238.25,1181.5,1119.08,1093.54,
CC     &             1074.82,1068.01,1043.61,
CC     &             1019.77,1011.26,981.18,949.69,926.14,
CC     &           1277.,1221.44,1165.89,1104.78,1079.78,
CC     &             1061.44,1054.78,1030.89,1007.56,
CC     &             999.22,969.78,938.94,915.89,
CCC     &           1240.,1190.,1140.,1085.,1062.5,1046.,
CCC     &             1040.,1018.5,997.5,989.33,963.5,935.75,915.,
CC     &           1240.,1190.,1140.,1085.,1062.5,1060.,
CC     &             1060.,1060.,1060.,1060.,1060.,1060.,1060.,
CCC
CC     &           1225.,1175.68,1126.36,1072.11,
CC     &             1049.92,1033.65,1027.73,1006.52,
CC     &             985.81,978.41,952.27,924.9,904.43,
CC     &           1195.5,1151.45,1107.41,1058.95,1039.13,
CC     &             1024.6,1019.31,1000.37,981.87,
CC     &             975.26,951.92,927.47,909.19/
      PARAMETER (LDT=8,LTC=3,LUR=24)
      DIMENSION TABQ(LDT),TABTAM(LTC),TABTRX(LUR)
      DATA TABQ  /0.,50.,60.,70.,80.,90.,100.,110./
C
C temperature in Farenheit: 0,15,40 centigradi
C
      DATA TABTAM/32.,59.,104./
C
C temperature in centigradi
C
      DATA TABTRX/
C     &            490.,390.,427.,468.,515.,557.,543.,543.,
C     &            522.,422.,465.,510.,555.,552.,532.,532.,
C     &            588.,488.,535.,560.,560.,560.,560.,560/
     &            557.,557.,557.,557.,557.,557.,543.,543.,
     &            555.,555.,555.,555.,555.,552.,532.,532.,
     &            560.,560.,560.,560.,560.,560.,560.,560/
      XQTG=QTGP
C      IF(XQTG.LE.62.) THEN
C      XQTG=62.
C      ENDIF
C      CALL TGLINTAB(TABTAM,LTC,TABQ,LDT,TABTRX,XQTG,FTAMB,TR,Z1,Z2)
      TG_UT_FU10=TR+273.15
      RETURN
      END
C            
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI SET PER IL CONTROLLO
C                         DELLA TEMPERATURA DI USCITA GAS DAL TURBO_GAS
C                         IN GRADI KELVIN
C
C      IN FUNZIONE DI  POYX = POTENZA IN % ,
C                      FTAMB = TEMPERATURA AMBIENTE IN GRADI CENTIGRADI
C
C
C____ ESEMPIO PER TURBOGAS TIPO   F I A T
C
      FUNCTION TG_UT_FF14(POYX,FTAMB)
CC--  CALCOLO TEMPERATURA DI RIFERIMENTO
C     PARAMETER (LDT=14,LTC=7,LUR=98)
C     DIMENSION TABQ(LDT),TABTAM(LTC),TABTRX(LUR)
C     DATA TABQ/42.,46.,49.9,54.1,57.8,61.7,65.7,
C     &       77.7,85.,92.3,100.,106.9,114.2,121.5/
C     DATA TABTAM/0.,20.,40.,59.,80.,100.,120./
C     DATA TABTRX/534.,531.,528.,525.,523.,520.,517.,
C     &      508.,503.,497.,492.,487.,481.,476.,
C     &      536.,533.,530.,527.,524.,521.,518.,
C     &      508.,503.,497.,491.,486.,480.,474.,
C     &      541.,538.,534.,531.,528.,524.,521.,
C     &      511.,505.,499.,492.,486.,480.,474.,
C     &      550.,546.,542.,538.,535.,531.,527.,
C     &      516.,509.,502.,495.,488.,482.,475.,
C     &      555.,551.,547.,543.,539.,535.,531.,
C     &      519.,511.,504.,496.,489.,482.,474.,
C     &      560.,556.,551.,547.,542.,538.,534.,
C     &      520.,512.,504.,495.,487.,479.,471.,
C     &      572.,567.,562.,557.,552.,547.,542.,
C     &      527.,518.,508.,499.,490.,481.,472./
C     XQTG=POYX
C     CALL TGLINTAB(TABTAM,LTC,TABQ,LDT,TABTRX,XQTG,FTAMB,TR,Z1,Z2)
      TG_UT_FF14=TR+273.15
      RETURN
C
C
C       FINE ESEMPIO .
C
      END
C      
C~FORAUS_TURG~C
C~FORAUS_TANK~C
      SUBROUTINE TANKLIV(TYP,VLIV,Y,YTOT,AREA)
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        WRITE(6,1000)
 1000   FORMAT(/10X,'*** FORNIRE LA SUBROUTINE TANKLIV'
     $        ,' O SEZ_Y>0. NEL FILE 14 ***'/)
        STOP
        END
C
C
C FORTRAN AUSILIARIO DEL MODULO CAVITA` LIQUIDO-VAPORE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C  SUBROUTINE TANKLIV(TYP,VLIV,Y,YTOT,AREA)
C
C  La subroutine CNDLIV, in funzione dei valori TYP e VLIV
C  deve fornire  Y,YTOT,AREA
C
C  Parametri in ingresso:  TYP, VLIV
C  Parametri in uscita:    Y, YTOT, AREA
C
C  Significato dei parametri di chiamata:
C
C  TYP       = corrisponde al dato  TYPE_CAV richiesto in input (vedi scheda C1)
C              viene  utilizzato  per  distinguere  le  diverse  geometrie delle
C              cavita` trattate dal modulo  TANK  presenti contemporaneamente in
C              un modello matematico.  Viene  di  solito usato all'interno della
C              subroutine come puntatore;
C
C  VLIV      = volume occupato dal liquido in m**3;
C
C  Y         = rappresenta la misura del livello in percentuale rispetto alla
C              escursione massima misurabile dagli strumenti
C
C  YTOT      = rappresenta la misura del livello totale nella cavita`in metri;
C
C  AREA      = area della superficie di separazione fra la fase liquido e la
C              fase vapore
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C     SUBROUTINE  TANKLIV(TYP,VLIV,Y,YTOT,AREA)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_TANK~C
C~FORAUS_STAZ~C
C
C****** SUBROUTINE DI ACQUISIZIONE DATI PER LA TURBINA ANSALDO DA 320 MW *****
C
       SUBROUTINE   DXSTAZ (TIPO,
     $              R,AALAM,UDVU,CCR,AETA,BETA,CEME,NVALV,
     $              CA,CCF,AUG,NIA,CAV,CK,NIP,CPV,NIPF,CPVF,ALFA,HRIF,
     $              PSHNOM,TSHNOM,VUNOM,WNOM,RAGGIO,DPVE,PSHF,TSHF,
     $              RCA,XF,WF,IAM)
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
       DIMENSION
     $              CA(16),CCF(16,3),AUG(16),NIA(16),CAV(16,3,4),
     $              NIP(16),CPV(16,10,4),CPVF(10,4),RCA(16),IAM(16)
C
C
C      SUBROUTINE DA COMPILARE ACURA DELL'UTENTE
C
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14 DEL MODULO STAZ'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE I DATI DI UNA TURBINA '
      WRITE(6,*)' DIVERSA DA QUELLE INCLUSE NEL MODULO'
      WRITE(6,*)' OVVERO : TOSI_320,TOSI_660,ANS_320'
      WRITE(6,*)' MA NON HAI FORNITO LA SUBROUTINE'
      WRITE(6,*)' *****   DXSTAZ   ****'
C
      STOP
C
      END
C
C FORTRAN AUSILIARIO DEL MODULO TURBINA STADIO AD AZIONE
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C********************* ESEMPIO DI SUBROUTINE UTENTE **************************
C****** SUBROUTINE DI ACQUISIZIONE DATI PER LA TURBINA ANSALDO DA 320 MW *****
C
C       SUBROUTINE DXSTAZ(TIPO,
C     $              R,AALAM,UDVU,CCR,AETA,BETA,CEME,NVALV,
C     $              CA,CCF,AUG,NIA,CAV,CK,NIP,CPV,NIPF,CPVF,ALFA,HRIF,
C     $              PSHNOM,TSHNOM,VUNOM,WNOM,RAGGIO,DPVE,PSHF,TSHF,
C     $              RCA,XF,WF,IAM)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C       DIMENSION
C     $              CA(16),CCF(16,3),AUG(16),NIA(16),CAV(16,3,4),
C     $              NIP(16),CPV(16,10,4),CPVF(10,4),RCA(16),IAM(16)
C       DIMENSION
C     $             D_CA(16),D_CCF(16,3),D_AUG(16),ID_NIA(16),
C     $             D_CAV(16,3,4),ID_NIP(16),D_CPV(16,10,4),
C     $             D_CPVF(10,4),D_RCA(16),ID_IAM(16)
C      CHARACTER*36 TIPO
C      CHARACTER*36 D_TIPO
CC
C      DATA D_TIPO/'      TURBINA ANSALDO DA 320 MW      '/
CC
CC
C      DATA D_PSHNOM,D_TSHNOM,D_VUNOM,D_WNOM,D_RAGGIO,D_CCR,D_AETA,
C     $     D_BETA,D_DPVE,D_PSHF,D_TSHF,D_XF,D_WF,ID_NVALV,ID_NIPF
CC
C     $/ 16670000.,   811.15  ,  50.      , 299.145   , .4826     ,
CC        PSHNOM      TSHNOM     VUNOM       WNOM       RAGGIO
CC
C     $  .00002132,    -3.57  ,   3.228   ,  294000.  , 16670000. ,
CC          CCR         AETA      BETA        DPVE        PSHF
CC
C     $    811.15 ,      1.   ,  299.145  ,    4      ,    1      /
CC          TSHF         XF        WF        NVALV        NIPF
CC
C      DATA (ID_IAM(I),I=1,4)/1,2,1,2/
CC
CC                  CARICAMENTO VETTORE RCA
CC
C                     DATA (D_RCA(I),I=1,  4   )
CC                                     NVALV
CC
C     $/   1.    ,  .84037   , .84037  ,    1.     /
CC        (1)         (2)        (3)       (4)
CC
CC
CC                  CARICAMENTO VETTORE CCF
CC
C                DATA ((D_CCF(I,J),J=1,  3   ),I=1, 4 )
CC                                               NVALV
CC
C     $/   .14  ,  -.49   ,  .93    ,   .14   ,  -.49   ,  .93    ,
CC        (1,1)    (1,2)    (1,3)      (2,1)     (2,2)    (2,3)
C     $    .14  ,  -.49   ,  .93    ,   .14   ,  -.49   ,  .93    /
CC        (3,1)    (3,2)    (3,3)      (4,1)     (4,2)    (4,3)
CC
CC                  CARICAMENTO VETTORE AUG
CC
C                     DATA (D_AUG(I),I=1,  4   )
CC                                     NVALV
CC
C     $/.0063904,.0053541 , .0053541, .006394/
CC        (1)       (2)       (3)       (4)
CC
CC                  CARICAMENTO VETTORE NIA
CC
C                     DATA (ID_NIA(I),I=1,  4   )
CC                                     NVALV
CC
C     $/    2   ,    2    ,    2    ,   2    /
CC         (1)      (2)       (3)      (4)
CC
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 1
CC
C        DATA ((D_CAV(1,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(1)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/
CC         z         a            b            c
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 2
CC
C        DATA ((D_CAV(2,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(2)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/
CC         z         a            b            c
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 3
CC
C        DATA ((D_CAV(3,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(3)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/
CC         z         a            b            c
CC
CC
CC                  CARICAMENTO VETTORE CAV VALVOLA 4
CC
C        DATA ((D_CAV(4,I02,L),L=1,4),I02=1,  2   )
CC                                 NIA(4)
CC
C     $/  .55   ,    0.     ,   1.24      ,    0.   ,
CC         z         a            b            c
C     $   1.0   ,-1.1851852 , 2.5437037   , -.35851852/
CC         x         a            b            c
CC
CC
CC                  CARICAMENTO VETTORE NIP
CC
C                     DATA (ID_NIP(I),I=1,  4  )
CC                                     NVALV
CC
C     $/   9   ,     7    ,    5    ,    3    /
CC        (1)       (2)       (3)       (4)
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 1
CC
C       DATA ((D_CPV(1,I02,L),L=1,4),I02=1,  9   )
CC                                NIP(1)
CC
CC
C     $/  .15   ,  1.2444444,     0.      ,    0.     ,
CC          x         a            b            c
C     $  .275   ,  -.574359 ,  .7401026   , -.07009231,
CC         x          a            b            c
C     $  .35    ,  2.142857 , -.7392857   ,   .13125  ,
CC        x           a            b            c
C     $  .45     ,     0.   ,     .83     ,  -.1555   ,
CC        x            a            b            c
C     $  .575    , 2.246154 , -1.206308   , .3059923  ,
CC        x            a            b            c
C     $  .725    , -1.777778,  3.711111   ,  -1.191111,
CC        x            a            b            c
C     $  .8      , 19.285714, -26.210714  ,  9.430714 ,
CC        x            a            b            c
C     $  .865    ,    -30.  ,    52.95    ,  -22.355  ,
CC        x            a            b            c
C     $  1.05    ,     0.   ,       0.    ,      1.   /
CC         x           a            b            c
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 2
CC
C       DATA ((D_CPV(2,I02,L),L=1,4),I02=1,  7   )
CC                                NIP(2)
CC
CC
C     $/ .2      ,     0.   ,       0.    ,      0.   ,
CC        x            a            b            c
C     $  .4      ,    1.55  ,    -.155    ,    -.031  ,
CC        x            a            b            c
C     $  .525    , -2.461538,    3.116923 ,  -.697923 ,
CC        x            a            b            c
C     $  .75     ,  5.155555,    -5.017778,  1.473333 ,
CC        x            a            b            c
C     $  .825    ,     0.   ,    2.866667 ,    -1.54  ,
CC        x            a            b            c
C     $  .93     ,-9.6969697,   18.684848 ,    -7.99  ,
CC        x            a            b            c
C     $  1.05    ,     0.   ,       0.    ,      1.   /
CC        x            a            b            c
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 3
CC
C       DATA ((D_CPV(3,I02,L),L=1,4),I02=1,  5   )
CC                                NIP(3)
CC
CC
C     $/ .715    ,     0.   ,      0.     ,      0.   ,
CC        x            a           b             c
C     $  .8      , 9.344538 ,-12.604034   ,  4.234723 ,
CC        x            a            b            c
C     $  .875    , 35.73333 ,  -54.94666  ,    21.22  ,
CC        x            a            b            c
C     $  .96     ,-41.37255 ,   81.03627  , -38.73088 ,
CC        x            a            b            c
C     $  1.05    ,     0.   ,   .7222222  ,  .2416667 /
CC        x            a            b            c
CC
CC
CC
CC                  CARICAMENTO VETTORE CPV VALVOLA 4
CC
C       DATA ((D_CPV(4,I02,L),L=1,4),I02=1,  3   )
CC                                NIP(4)
CC
CC
CC
C     $/ .865    ,     0.   ,       0.    ,      0.   ,
CC        x            a            b            c
C     $  .95     , 24.20168 ,  -41.57311  ,     17.8  ,
CC         x            a            b            c
C     $  1.05    ,   57.6   ,   -105.48   ,     48.4  /
CC        x            a            b            c
CC
C
CC                  CARICAMENTO VETTORE CPVF
CC
C                DATA ((D_CPVF(I02,L),L=1,4),I02=1, 1  )
CC                                        NIPF
CC
C     $/   1.05  ,     0.   ,       1.    ,       0.  /
CC          x          a            b             c
CC
CC
C      TIPO=D_TIPO
CC
C      PSHNOM=D_PSHNOM
C      TSHNOM=D_TSHNOM
C      VUNOM =D_VUNOM
C      WNOM  =D_WNOM
C      RAGGIO=D_RAGGIO
C      CCR   =D_CCR
C      AETA  =D_AETA
C      BETA  =D_BETA
C      DPVE  =D_DPVE
C      PSHF  =D_PSHF
C      TSHF  =D_TSHF
C      XF    =D_XF
C      WF    =D_WF
C      NVALV =ID_NVALV
C      NIPF  =ID_NIPF
CC
C      DO I=1,16
C      CA(I)  =D_CA(I)
C      AUG(I) =D_AUG(I)
C      NIA(I) =ID_NIA(I)
C      NIP(I) =ID_NIP(I)
C      RCA(I) =D_RCA(I)
C      IAM(I) =ID_IAM(I)
C       DO J=1,3
C       CCF(I,J)=D_CCF(I,J)
C       ENDDO
C      ENDDO
CC
C      DO I=1,16
C       DO J=1,3
C        DO K=1,4
C        CAV(I,J,K)=D_CAV(I,J,K)
C        ENDDO
C       ENDDO
C      ENDDO
CC
C      DO I=1,16
C       DO J=1,10
C        DO K=1,4
C        CPV(I,J,K)=D_CPV(I,J,K)
C        ENDDO
C       ENDDO
C      ENDDO
C       DO J=1,10
C        DO K=1,4
C        CPVF(J,K)=D_CPVF(J,K)
C        ENDDO
C       ENDDO
CC
C       RETURN
C       END
C******************** FINE ESEMPIO DATI TURBINA *****************************
C~FORAUS_STAZ~C
C~FORAUS_TUBS~C
      SUBROUTINE GAMUT(P,H,S,T,RO,TIT,TW,D,CRIG,G,Q,SUP,COESCA)
C
C      SUBROUTINE UTENTE: DEVE FORNIRE IL VALORE DI COESCA IN
C      FUNZIONE DELLE ALTRE VARIABILI.
C
C
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,*)'***ATTENZIONE . DAI DATI DEL FILE 14'
      WRITE(6,*)' RISULTA CHE VUOI FORNIRE LA SUBROUTINE UTENTE '
      WRITE(6,*)' "GAMUT" PER IL CALCOLO DI COEFFICIENTI DI SCAMBIO'
C
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO CANALE BOLLENTE A PIU` PARETI DI SCAMBIO
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C*********** BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE ******************
C
C    SUBROUTINE GAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
C
C  Calcolo di HTC = coefficiente di scambio termico in [W/m**2/K]
C
C__________ SE VUOI CHE LA SUBROUTINE GAMUT SIA CHIAMATA DA TUBS
C           RICORDATI DI METTERE NEI DATI DEL MODULO SU FILE F14
C
C                   CRIG < 0.
C
C  La subroutine fornisce al modulo TUBS il coefficiente di scambio
C  termico HTC fra parete metallica e fluido ; quest'ultimo puo` essere
C  calcolato in funzione dei parametri di ingresso della subroutine il cui
C  significato e' il seguente:
C
C   P     pressione del fluido                    [Pa]
C   H     entalpia specifica del fluido           [J/kg]
C   S     entropia specifica del fluido           [J/kg/C]
C   TF    temperatura del fluido                  [K]
C   RO    densita' del fluido                     [kg/m**3]
C   TITOL titolo della miscela
C   TP    temperatura di parete                   [K]
C   DIA   diametro idraulico del condotto         [m]
C   CRIG  dato fornito dall'utente nel file F14
C         per ogni cella del canale.
C         In questa subroutine puo` essere usato
C         come si vuole.
C         RICORDATI CHE CRIG E` NEGATIVO !!!
C   G     portata specifica di fluido             [kg/m**2/s]
C   Q     potenza totale scambiata                [W]
C   SUP   superficie di scambio                   [m**2]
C
C************ INIZIO DEL TESTO FORTRAN DA SCRIVERE *****************************
C
C       SUBROUTINE GAMUT(P,H,S,TF,RO,TITOL,TP,DIA,CRIG,G,Q,SUP,HTC)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C     RETURN
C     END
C
C~FORAUS_TUBS~C
C~FORAUS_VALV~C
      REAL FUNCTION AVNS10(Z,ALFA)                                      !SNGL
C      DOUBLE PRECISION FUNCTION AVNS10(Z,ALFA)                          !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'*** FORNIRE LA CARATTERISTICA DELLA VALVOLA'
     $/10X,'SCRIVENDO LA FUNCTION AVNS10(Z,ALFA) (VEDI DOC. VALV)'
     $/10X,' CHE DEFINISCE IL CV IN FUNZIONE DELL''ALZATA'
     $/10X,'POICHE` NEI DATI SU FILE 14 E` STATO POSTO ALFA > 10.'//)
      AVNS10=Z
      RETURN
      END
      REAL FUNCTION CFNS10(Z,A,CFA)                                     !SNGL
C      DOUBLE PRECISION FUNCTION CFNS10(Z,A,CFA)                         !DBLE
C      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
      WRITE(6,1000)
 1000 FORMAT(/10X,'*** FORNIRE LA CARATTERISTICA DELLA VALVOLA'
     $/10X,'SCRIVENDO LA FUNCTION CFNS10(Z,A,CFA) (VEDI DOC. VALV)'
     $/10X,' CHE DEFINISCE IL CF IN FUNZIONE DELL''ALZATA Z  E'
     $/10X,' DELL''AREA DI PASSAGGIO  A '
     $/10X,'POICHE` NEI DATI SU FILE 14 E` STATO POSTO CFA > 10.'//)
      CFNS10=0.95
      RETURN
      END
C
C FORTRAN AUSILIARIO DEL MODULO VALVOLA
C PER LA SUA SCRITTURA VEDERE MANUALE D'USO O
C UTILIZZARE L'APPOSITO COMANDO DI LEGOCAD.
C
C
C                       FUNCTION AVNS10(ALZA, ALFA)
C
C  Function per l'assegnazione della caratteristica della valvola
C
C  Parametri d'ingresso: ALZA,ALFA
C  Parametri d'uscita  : AVNS10
C
C************* BREVE SPIEGAZIONE DEI PARAMETRI DELLA FUNCTION ************
C
C [p.u.]  ALZA   -  grado di apetura della valvola.
C
C [ ]     ALFA   -  (>10) parametro,  proveniente  dai  dati  in input, che puo`
C                   essere utilizzato come indice  di  scelta nel caso in cui si
C                   vogliano introdurre diverse caratteristiche standard tramite
C                   un'unica FUNCTION AVNS10(ALZA,ALFA).
C
C [p.u.]  AVNS10 -  valore dell'area  di  passaggio  calcolata. Tale valore deve
C                   essere normalizzato rispetto all'area di passaggio a valvola
C                   completamente aperta.
C
C
C  Esempio di caratteristica assegnata per punti:
C
C
CC      REAL FUNCTION AVNS10(Z,ALFA)                                      !SNGL
CC      DOUBLE PRECISION FUNCTION AVNS10(Z,ALFA)                          !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      DIMENSION X1(12),Y1(12)
C      DATA X1/0.,.1,.2,.3,.4,.5,.6,.7,.8,.9,1.,1.2/
C      DATA Y1/.055,.085,.125,.17,.22,.28,.35,.43,.55,.7,1.,1./
CC
CC     CARATTERISTICHE CV=FUNZIONE DI ALZATA VALVOLA
CC
C      IALF=ALFA-10.
C      GO TO (1,100),IALF
CC
CC     CARATTERISTICA DELLA FCV DEL RICIRCOLO
CC
C    1 CALL AVNSIN(Z,X1,Y1,12,A)
C      AVNS10=A
C      GO TO 500
CC
C 100  CONTINUE
C 500  RETURN
C      END
C      SUBROUTINE AVNSIN(Z,X,Y,NP,A)
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      DIMENSION X(*),Y(*)
CC
CC     INTERPOLAZIONE
CC
C      DO 10 I=1,NP-1
C      J=I
C      IF(Z.GE.X(J).AND.Z.LE.X(J+1))GO TO 15
C   10 CONTINUE
C      A=0.
C      GO TO 20
C   15 A=Y(J)+(Z-X(J))*(Y(J+1)-Y(J))/(X(J+1)-X(J))
C   20 RETURN
C      END
C
C************** INIZIO DEL TESTO FORTRAN DA SCRIVERE ********************
C
CC      REAL FUNCTION AVNS10(Z,ALFA)                                      !SNGL
CC      DOUBLE PRECISION FUNCTION AVNS10(Z,ALFA)                          !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      RETURN
C      END
C
C************** FINE FUNCTION AVNS10 ********************
C
C
C
C                FUNCTION CFNS10(ALZA,A,CFA)
C
C     Function per l'assegnazione della legge di variazione
C     del coefficiente di recupero della valvola
C
C  Parametri d'ingresso: ALZA, A, CFA
C  Parametri d'uscita  : CFNS10
C
C
C************* BREVE SPIEGAZIONE DEI PARAMETRI DELLA FUNCTION ************
C
C [p.u.]  ALZA   -  grado di apetura della valvola.
C
C [p.u.]  A      -  area di passaggio normalizzata.
C
C [ ]     CFA    -  (>10) parametro,  proveniente dai  dati  in input, che  puo`
C                   essere  utilizzato come indice di scelta qualora si vogliano
C                   assegnare  diverse  leggi  di variazione del coefficiente di
C                   recuperdetramite un'unica FUNCTION CFNS10(ALZA,A,CFA).
C
C [ ]     CFNS10 -  valore del coefficiente di recupero calcolato.
C
C
C
C   Esempio di coefficiente di recupero assegnato tramite function:
C
CC      REAL FUNCTION CFNS10(Z,A,CFA)                                     !SNGL
CC      DOUBLE PRECISION FUNCTION CFNS10(Z,A,CFA)                         !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      CFNS=0.95
C      RETURN
C      END
C
C
C************** INIZIO DEL TESTO FORTRAN DA SCRIVERE ********************
C
CC      REAL FUNCTION CFNS10(Z,A,CFA)                                     !SNGL
CC      DOUBLE PRECISION FUNCTION CFNS10(Z,A,CFA)                         !DBLE
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
C      RETURN
C      END
C
C~FORAUS_VALV~C
C~FORAUS_VENT~C
C
       SUBROUTINE CARVENUT(TYP,OMDEN,ORIF,WDEN,TETDEN,RO,DELTAP,CRDEN)
C******* BREVE SPIEGAZIONE DEI PARAMETRI DELLA SUBROUTINE **********
C
C
C
C            SUBROUTINE CARVENUT(TYP,OM,OM0,W,TET,RO,DELTAP,CR)
C
C Parametri d'ingresso :  TYP, OM, OM0, W, TET, RO
C Parametri d'uscita   :  DELTAP, CR
C
C [ ]       TYP     corrisponde  al  dato  TIPO  richiesto in input (vedi scheda
C                   C1);  puo` essere utilizzato come indice di selezione  delle
C                   curve caratteristiche, qualora si voglia utilizzare un unico
C                   sottoprogramma utente per piu` tipi di ventilatori
C
CC [rad/s]   OM      velocita' angolare del ventilatore
C
CC [rad/s]  OM0      velocita'angolare nominale (velocita' di riferimento  delle
C                    caratteristiche fornite dal costruttore)
C
C  [kg/s]    W       portata di fluido nel ventilatore
C
C  [p.u.]    TET     valore del parametro di comando del sistema di  regolazione
C                    della portata
C
C  [kg/m**3] RO      densita' del fluido che attraversa il ventilatore
C
C  [Pa]      DELTAP  prevalenza del ventilatore
C
C  [Nw*m]    CR      coppia resistente del ventilatore
C
CC      IMPLICIT DOUBLE PRECISION (A-H, O-Z)                              !DBLE
        ITY=-TYP
        GO TO (20,20,10),ITY
   10   CONTINUE
C
C
C  DATI PER I VENTILATORI DEI MULINI DI VADO LIGURE
C
        DELTAPNOM= 16900.                ! Pa, da 1740 mmH2O NOMINALE
        DELTAPMAX= 20000.                ! supposto 
        QVOLNOM  = 15.418                ! m3/s, da 121 ^C e 38000 Nm3/h
        POTNOM   = 3.67E5                ! 
        COPNOM   =POTNOM/OM0
        VELNOM   =1480.                  !  RPM
        ETANOM   = QVOLNOM*DELTAPNOM/POTNOM
        ALFA     = 1.5
        C =0.1*SQRT((ALFA-1.)/ALFA)
C
        QVR= W/RO/QVOLNOM
        OMR= OM/OM0
        ZETA   = 3.141592/2.*TET
        BETA   = SIN(ZETA)+ C*(1. - 2./3.141592*ZETA)
        DELTAP = DELTAPNOM*(-(ALFA-1.)*QVR**2/BETA/BETA +ALFA*OMR**2)
        IF(DELTAP.GT.DELTAPMAX) DELTAP=DELTAPMAX
C
        CR = COPNOM*(OMR * DELTAP/DELTAPNOM/(2.*OMR-QVR))
C
   20   CONTINUE
        RETURN
        END
C~FORAUS_VENT~C
