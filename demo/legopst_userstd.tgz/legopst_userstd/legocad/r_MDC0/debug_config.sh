#\!/bin/bash
source /home/antonio/LegoPST2010A_WSL_DARHE6_64/.profile_legoroot
export DISPLAY=:0
echo 'Starting config...'
/home/antonio/LegoPST2010A_WSL_DARHE6_64/Alg_mmi/bin/config &
sleep 5
echo 'Loading ACTR page manually...'

