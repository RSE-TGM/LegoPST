#\!/bin/bash
source /home/antonio/LegoPST2010A_WSL_DARHE6_64/.profile_legoroot
export DISPLAY=:0
ulimit -c unlimited
echo "Starting config under gdb..."
gdb -ex "set confirm off" -ex "run" -ex "bt" -ex "quit" /home/antonio/LegoPST2010A_WSL_DARHE6_64/Alg_mmi/bin/config

