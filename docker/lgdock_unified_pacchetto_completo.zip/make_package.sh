#!/bin/bash
#
# Crea un tarball del pacchetto lgdock completo
#

set -e

VERSION="1.1"
PACKAGE_NAME="lgdock-${VERSION}"
TARBALL="${PACKAGE_NAME}.tar.gz"

echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║              Creazione Pacchetto lgdock v${VERSION}                         ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""

# Crea directory temporanea per il pacchetto
TEMP_DIR=$(mktemp -d)
PACKAGE_DIR="${TEMP_DIR}/${PACKAGE_NAME}"

echo "→ Creazione directory pacchetto: $PACKAGE_DIR"
mkdir -p "$PACKAGE_DIR"

# Lista file da includere
FILES_TO_INCLUDE=(
    "lgdock_unified.sh:Script principale unificato"
    "test_lgdock.sh:Script di test e diagnostica"
    "setup_lgdock.sh:Script di setup automatico"
    "README_lgdock.md:Documentazione completa"
    "QUICKREF_lgdock.txt:Quick reference"
    "INSTALL.md:Guida installazione rapida"
    "PACKAGE_SUMMARY.txt:Riepilogo pacchetto"
)

echo ""
echo "File inclusi nel pacchetto:"
echo ""

INCLUDED=0
MISSING=0

for file_info in "${FILES_TO_INCLUDE[@]}"; do
    file="${file_info%%:*}"
    desc="${file_info##*:}"
    
    if [ -f "$file" ]; then
        cp "$file" "$PACKAGE_DIR/"
        # Rendi eseguibili gli script .sh
        if [[ "$file" == *.sh ]]; then
            chmod +x "$PACKAGE_DIR/$file"
        fi
        size=$(du -h "$file" | cut -f1)
        printf "  ✓ %-25s %s (%s)\n" "$file" "$desc" "$size"
        ((INCLUDED++))
    else
        printf "  ✗ %-25s MANCANTE\n" "$file"
        ((MISSING++))
    fi
done

echo ""
echo "Statistiche:"
echo "  File inclusi: $INCLUDED"
echo "  File mancanti: $MISSING"
echo ""

if [ $MISSING -gt 0 ]; then
    echo "ATTENZIONE: Alcuni file sono mancanti!"
    echo "Il pacchetto verrà creato comunque, ma potrebbe essere incompleto."
    echo ""
    read -p "Continuare? [s/N]: " CONTINUE
    if [[ ! "$CONTINUE" =~ ^[sS]$ ]]; then
        echo "Operazione annullata."
        rm -rf "$TEMP_DIR"
        exit 1
    fi
fi

# Crea README per il pacchetto
cat > "${PACKAGE_DIR}/README.txt" << 'EOF'
╔════════════════════════════════════════════════════════════════════════════╗
║                         PACCHETTO LGDOCK v1.1                              ║
╚════════════════════════════════════════════════════════════════════════════╝

Questo pacchetto contiene tutto il necessario per installare e usare lgdock,
uno script unificato per lanciare container LegoPST con Docker.

📦 CONTENUTO

  • lgdock_unified.sh     - Script principale
  • test_lgdock.sh        - Script di test sistema
  • setup_lgdock.sh       - Script installazione automatica
  • README_lgdock.md      - Documentazione completa
  • QUICKREF_lgdock.txt   - Quick reference
  • INSTALL.md            - Guida installazione
  • PACKAGE_SUMMARY.txt   - Riepilogo dettagliato

🚀 INSTALLAZIONE RAPIDA

  1. Estrai il pacchetto:
     tar xzf lgdock-1.1.tar.gz
     cd lgdock-1.1

  2. Esegui l'installazione guidata:
     chmod +x setup_lgdock.sh
     ./setup_lgdock.sh

  3. Usa lgdock:
     lgdock --help

📖 DOCUMENTAZIONE

  • INSTALL.md - Istruzioni installazione dettagliate
  • README_lgdock.md - Documentazione completa
  • QUICKREF_lgdock.txt - Comandi rapidi
  • PACKAGE_SUMMARY.txt - Descrizione pacchetto

✨ CARATTERISTICHE

  • Script unificato (standard + socat)
  • Setup automatico
  • Test diagnostico integrato
  • Documentazione completa
  • Supporto demo mode

🔗 USO VELOCE

  Locale:
    lgdock

  SSH/MobaXterm:
    lgdock --socat

  Con demo:
    lgdock --demo

Per maggiori informazioni, leggi INSTALL.md

Versione: 1.1
Data: Novembre 2024
EOF

echo "→ Creazione tarball..."
cd "$TEMP_DIR"
tar czf "$TARBALL" "$PACKAGE_NAME"
cd - > /dev/null

# Sposta il tarball nella directory corrente
mv "${TEMP_DIR}/${TARBALL}" .

# Cleanup
rm -rf "$TEMP_DIR"

# Informazioni sul pacchetto
TARBALL_SIZE=$(du -h "$TARBALL" | cut -f1)
FILE_COUNT=$(tar tzf "$TARBALL" | wc -l)

echo "✓ Tarball creato con successo!"
echo ""
echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║                      Pacchetto Creato!                                 ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "  File: $TARBALL"
echo "  Dimensione: $TARBALL_SIZE"
echo "  File inclusi: $FILE_COUNT"
echo ""
echo "Distribuzione:"
echo ""
echo "  1. Copia il tarball dove serve:"
echo "     scp $TARBALL user@server:/tmp/"
echo ""
echo "  2. Sul server, estrai:"
echo "     tar xzf $TARBALL"
echo "     cd $PACKAGE_NAME"
echo ""
echo "  3. Installa:"
echo "     ./setup_lgdock.sh"
echo ""
echo "Verifica contenuto:"
echo "  tar tzf $TARBALL"
echo ""
echo "Estrazione:"
echo "  tar xzf $TARBALL"
echo ""

# Crea anche un checksum
if command -v sha256sum >/dev/null 2>&1; then
    SHA256=$(sha256sum "$TARBALL" | cut -d' ' -f1)
    echo "$SHA256  $TARBALL" > "${TARBALL}.sha256"
    echo "Checksum SHA256:"
    echo "  File: ${TARBALL}.sha256"
    echo "  Hash: $SHA256"
    echo ""
    echo "Verifica integrità:"
    echo "  sha256sum -c ${TARBALL}.sha256"
    echo ""
fi

echo "Pacchetto pronto per la distribuzione! 🎉"
