#!/bin/bash
#
# Test script per lgdock
# Verifica che tutti i requisiti siano soddisfatti
#

echo "======================================================================="
echo "  Test Ambiente per lgdock"
echo "======================================================================="
echo ""

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funzioni di utilità
pass() {
    echo -e "${GREEN}✓${NC} $1"
}

fail() {
    echo -e "${RED}✗${NC} $1"
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Contatori
PASSED=0
FAILED=0
WARNINGS=0

# =============================================================================
# Test 1: Docker
# =============================================================================
echo "Test 1: Docker"
if command -v docker >/dev/null 2>&1; then
    DOCKER_VERSION=$(docker --version 2>&1)
    pass "Docker installato: $DOCKER_VERSION"
    ((PASSED++))
    
    # Verifica che docker sia eseguibile senza sudo
    if docker ps >/dev/null 2>&1; then
        pass "Docker accessibile senza sudo"
        ((PASSED++))
    else
        warn "Docker richiede sudo (normale su alcuni sistemi)"
        echo "   Suggerimento: aggiungi il tuo utente al gruppo docker"
        echo "   sudo usermod -aG docker $USER"
        ((WARNINGS++))
    fi
else
    fail "Docker non trovato"
    echo "   Installa Docker: https://docs.docker.com/engine/install/"
    ((FAILED++))
fi
echo ""

# =============================================================================
# Test 2: DISPLAY
# =============================================================================
echo "Test 2: Configurazione X11"
if [ -n "$DISPLAY" ]; then
    pass "DISPLAY impostato: $DISPLAY"
    ((PASSED++))
    
    # Estrai numero display
    DISPLAY_NUM=$(echo $DISPLAY | sed 's/.*:\([0-9]*\).*/\1/')
    echo "   Display number: $DISPLAY_NUM"
    
    # Verifica socket X11
    SOCKET_PATH="/tmp/.X11-unix/X${DISPLAY_NUM}"
    if [ -S "$SOCKET_PATH" ]; then
        pass "Socket X11 esiste: $SOCKET_PATH"
        ((PASSED++))
    else
        warn "Socket X11 non trovato: $SOCKET_PATH"
        echo "   Questo è normale se sei connesso via SSH"
        echo "   Usa: lgdock --socat"
        ((WARNINGS++))
    fi
else
    fail "DISPLAY non impostato"
    echo "   Sei connesso via SSH? Abilita X11 forwarding: ssh -X"
    ((FAILED++))
fi
echo ""

# =============================================================================
# Test 3: socat (opzionale)
# =============================================================================
echo "Test 3: socat (opzionale, per SSH X11 forwarding)"
if command -v socat >/dev/null 2>&1; then
    SOCAT_VERSION=$(socat -V 2>&1 | head -1)
    pass "socat installato: $SOCAT_VERSION"
    ((PASSED++))
else
    warn "socat non trovato (necessario solo per --socat mode)"
    echo "   Installa con: sudo dnf install socat"
    ((WARNINGS++))
fi
echo ""

# =============================================================================
# Test 4: xauth (opzionale)
# =============================================================================
echo "Test 4: xauth (opzionale, per SSH X11 forwarding)"
if command -v xauth >/dev/null 2>&1; then
    pass "xauth installato"
    ((PASSED++))
    
    # Verifica se ci sono cookies X11
    XAUTH_COUNT=$(xauth list 2>/dev/null | wc -l)
    if [ "$XAUTH_COUNT" -gt 0 ]; then
        pass "Cookie X11 disponibili: $XAUTH_COUNT"
        ((PASSED++))
    else
        warn "Nessun cookie X11 trovato"
        ((WARNINGS++))
    fi
else
    warn "xauth non trovato (necessario solo per --socat mode)"
    echo "   Installa con: sudo dnf install xorg-x11-xauth"
    ((WARNINGS++))
fi
echo ""

# =============================================================================
# Test 5: Immagine Docker
# =============================================================================
echo "Test 5: Immagine Docker LegoPST"
if docker images aguagliardi/legopst:2.0 --format "{{.Repository}}" 2>/dev/null | grep -q "aguagliardi/legopst"; then
    IMAGE_SIZE=$(docker images aguagliardi/legopst:2.0 --format "{{.Size}}")
    IMAGE_DATE=$(docker images aguagliardi/legopst:2.0 --format "{{.CreatedAt}}")
    pass "Immagine aguagliardi/legopst:2.0 presente"
    echo "   Size: $IMAGE_SIZE"
    echo "   Created: $IMAGE_DATE"
    ((PASSED++))
else
    warn "Immagine aguagliardi/legopst:2.0 non trovata"
    echo "   Verrà scaricata automaticamente al primo avvio"
    echo "   Oppure scarica ora: docker pull aguagliardi/legopst:2.0"
    ((WARNINGS++))
fi
echo ""

# =============================================================================
# Test 6: Directory defaults
# =============================================================================
echo "Test 6: Directory defaults"
DEFAULTS_DIR="$HOME/defaults"
if [ -d "$DEFAULTS_DIR" ]; then
    pass "Directory defaults esiste: $DEFAULTS_DIR"
    ((PASSED++))
else
    warn "Directory defaults non esiste"
    echo "   Verrà creata automaticamente da lgdock"
    ((WARNINGS++))
fi
echo ""

# =============================================================================
# Test 7: Configurazione SSH (se connesso via SSH)
# =============================================================================
echo "Test 7: Configurazione SSH X11 Forwarding"
if [ -n "$SSH_CONNECTION" ]; then
    echo "   Connesso via SSH da: $SSH_CLIENT"
    
    if echo "$DISPLAY" | grep -q "localhost:"; then
        pass "X11 forwarding abilitato via SSH"
        ((PASSED++))
    else
        warn "X11 forwarding potrebbe non essere abilitato"
        echo "   Connettiti con: ssh -X utente@host"
        ((WARNINGS++))
    fi
else
    pass "Non connesso via SSH (connessione locale)"
    ((PASSED++))
fi
echo ""

# =============================================================================
# Sommario
# =============================================================================
echo "======================================================================="
echo "  Sommario Test"
echo "======================================================================="
echo -e "${GREEN}Passati:${NC}   $PASSED"
echo -e "${YELLOW}Warning:${NC}   $WARNINGS"
echo -e "${RED}Falliti:${NC}   $FAILED"
echo ""

# Raccomandazioni
echo "Raccomandazioni:"
echo ""

if [ "$FAILED" -eq 0 ]; then
    if [ -n "$SSH_CONNECTION" ] || ! [ -S "/tmp/.X11-unix/X${DISPLAY_NUM}" ]; then
        echo "→ Sei connesso via SSH o il socket X11 non esiste"
        echo "  Usa: ./lgdock --socat"
        echo ""
    else
        echo "→ Sistema pronto per modalità standard"
        echo "  Usa: ./lgdock"
        echo ""
    fi
    
    if [ "$WARNINGS" -gt 0 ]; then
        echo "→ Ci sono alcuni warning (vedi sopra)"
        echo "  Alcuni tool opzionali mancano ma lo script dovrebbe funzionare"
        echo ""
    fi
else
    echo "→ Alcuni test critici sono falliti"
    echo "  Risolvi i problemi indicati sopra prima di usare lgdock"
    echo ""
fi

echo "Per testare lgdock:"
echo "  ./lgdock --help          # Mostra l'help"
echo "  ./lgdock                 # Avvia container (modalità standard)"
echo "  ./lgdock --socat         # Avvia container (modalità socat)"
echo "  ./lgdock --demo          # Installa demo e avvia container"
echo ""

# Exit code
if [ "$FAILED" -gt 0 ]; then
    exit 1
else
    exit 0
fi
