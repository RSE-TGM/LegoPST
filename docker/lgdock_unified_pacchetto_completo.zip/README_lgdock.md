# lgdock - Docker Container per LegoPST

Script unificato per lanciare il container LegoPST con supporto per due modalità di X11 forwarding.

## Installazione

```bash
# Rendi eseguibile lo script
chmod +x lgdock_unified.sh

# Opzionale: rinomina per comodità
mv lgdock_unified.sh lgdock

# Opzionale: copia in /usr/local/bin per averlo sempre disponibile
sudo cp lgdock /usr/local/bin/
```

## Uso

### Sintassi

```bash
lgdock [OPZIONI]
```

### Opzioni

- `-h, --help` - Mostra l'help
- `-v, --version` - Mostra la versione
- `-d, --demo` - Installa la demo di LegoPST (legocad e sked) nella home dell'utente
- `-s, --socat` - Usa socat per X11 forwarding (necessario per SSH con MobaXterm)

### Esempi

```bash
# Lancio standard (uso locale)
./lgdock

# Con demo
./lgdock --demo

# Con socat (per SSH/MobaXterm)
./lgdock --socat

# Demo + socat
./lgdock -d -s
```

## Modalità X11 Forwarding

### Modalità Standard (default)

**Quando usarla:**
- Esecuzione locale su Linux con server X nativo
- Fedora, Ubuntu, Debian desktop
- Non serve configurazione aggiuntiva

**Come funziona:**
- X11 forwarding diretto tramite socket `/tmp/.X11-unix`
- Usa il DISPLAY dell'host direttamente

```bash
./lgdock
```

### Modalità Socat (`--socat`)

**Quando usarla:**
- Connessione SSH con X11 forwarding (es. da Windows con MobaXterm)
- Il socket Unix X11 non esiste ma c'è un TCP X11 forwarding
- Hai bisogno di un bridge tra TCP e Unix socket

**Come funziona:**
- Crea un socket bridge con `socat`
- Gestisce l'autenticazione X11 con xauth
- Crea file temporanei per i cookie X11

**Requisiti:**
```bash
# Su Fedora/RHEL
sudo dnf install socat xorg-x11-xauth

# Su Ubuntu/Debian
sudo apt install socat xauth
```

```bash
./lgdock --socat
```

## Demo Mode

La modalità demo (`--demo`) installa automaticamente:

1. **legocad** - Modello CAD di esempio
2. **sked** - File di scheduling di esempio

I file vengono estratti da `/home/legoroot_fedora41/demo/legopst_userstd.tgz` dentro il container e copiati nella tua home:

```
$HOME/
├── legopst_userstd/
│   ├── legocad/    # Modelli demo
│   └── sked/       # Schedule demo
├── legocad -> legopst_userstd/legocad (symlink)
└── sked -> legopst_userstd/sked (symlink)
```

## Configurazione Utente

Lo script crea automaticamente:

1. **Utente dinamico** nel container con lo stesso UID/GID dell'host
2. **Gruppo** con lo stesso GID
3. **Permessi sudo** senza password
4. **Link simbolici** per accesso facile ai dati:
   - `~/host_data` → tutta la tua home
   - `~/legocad` → directory legocad
   - `~/sked` → directory sked
   - `~/defaults` → directory defaults

5. **`.bash_profile`** configurato con:
   - DISPLAY esportato correttamente
   - XAUTHORITY (in modalità socat)
   - Source del profilo LegoPST

## Directory Montate

| Container | Host | Descrizione |
|-----------|------|-------------|
| `/host_home` | `$HOME` | Tutta la home dell'utente |
| `/tmp/.X11-unix` | `/tmp/.X11-unix` | Socket X11 |
| `/tmp/.Xauthority` | File temporaneo | Cookie X11 (solo socat) |

## Troubleshooting

### X11 non funziona (modalità standard)

```bash
# Verifica che X sia in esecuzione
echo $DISPLAY

# Prova con socat
./lgdock --socat
```

### X11 non funziona (modalità socat)

```bash
# Verifica che socat sia installato
which socat

# Installa se mancante
sudo dnf install socat xorg-x11-xauth

# Verifica X11 forwarding SSH
echo $DISPLAY  # Deve mostrare qualcosa come localhost:10.0
```

### "xauth: command not found"

```bash
# Su Fedora/RHEL
sudo dnf install xorg-x11-xauth

# Su Ubuntu/Debian
sudo apt install xauth
```

### Demo non si installa

Verifica che il file demo esista nel container:
```bash
# All'interno del container
ls -la /home/legoroot_fedora41/demo/legopst_userstd.tgz
```

### Permessi file

I file creati nella home dell'host avranno automaticamente i permessi corretti (stesso UID/GID dell'utente host).

## Differenze rispetto agli script originali

### Vantaggi dello script unificato:

1. **Un solo script** invece di due da mantenere
2. **Help integrato** con `--help`
3. **Versioning** con `--version`
4. **Parsing parametri robusto** con gestione errori
5. **Output chiaro** con sezioni ben definite
6. **Cleanup automatico** delle risorse temporanee
7. **Controlli di sicurezza** (verifica tool mancanti)

### Compatibilità:

Lo script è **completamente compatibile** con i comandi precedenti:
- `lgdock` equivale a `lgdock.sh`
- `lgdock --socat` equivale a `lgdock_socat.sh`

## Variabili d'Ambiente

Lo script usa le seguenti variabili dell'host:

- `USER` / `whoami` - Nome utente
- `UID` / `id -u` - User ID
- `GID` / `id -g` - Group ID
- `HOME` - Directory home
- `DISPLAY` - Display X11

## Requisiti Sistema

- **Docker** - Installato e in PATH
- **Bash** - Version 4.0+
- **socat** (solo per modalità `--socat`)
- **xauth** (solo per modalità `--socat`)

## Container

- **Image**: `aguagliardi/legopst:2.0`
- **Platform**: `linux/amd64`
- **Network**: `host` mode
- **IPC**: `host` mode (solo socat)

## Autore

Script unificato basato su lgdock.sh e lgdock_socat.sh originali.

## Changelog

### v1.1
- Script unificato con supporto modalità standard e socat
- Aggiunto help e version
- Parsing parametri migliorato
- Output formattato con sezioni
- Gestione errori robusta
- Cleanup automatico risorse

### v1.0
- Script separati lgdock.sh e lgdock_socat.sh
