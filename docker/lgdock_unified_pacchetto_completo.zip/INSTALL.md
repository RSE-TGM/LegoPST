# Installazione Rapida lgdock

## Download dei file

Scarica tutti questi file nella stessa directory:
- `lgdock_unified.sh` - Script principale
- `test_lgdock.sh` - Script di test
- `setup_lgdock.sh` - Script di setup automatico
- `README_lgdock.md` - Documentazione completa
- `QUICKREF_lgdock.txt` - Quick reference

## Metodo 1: Installazione Automatica (Raccomandato)

```bash
# Rendi eseguibile lo script di setup
chmod +x setup_lgdock.sh

# Esegui l'installazione guidata
./setup_lgdock.sh
```

Lo script ti guiderà attraverso:
1. Verifica dei file necessari
2. Scelta del tipo di installazione (sistema/locale/corrente)
3. Installazione degli script
4. Test opzionale del sistema

## Metodo 2: Installazione Manuale

### Opzione A: Installazione Sistema (per tutti gli utenti)

```bash
# Rendi eseguibili gli script
chmod +x lgdock_unified.sh test_lgdock.sh

# Copia in /usr/local/bin
sudo cp lgdock_unified.sh /usr/local/bin/lgdock
sudo cp test_lgdock.sh /usr/local/bin/lgdock-test

# Verifica
which lgdock
lgdock --version
```

### Opzione B: Installazione Locale (solo per te)

```bash
# Crea directory se non esiste
mkdir -p ~/.local/bin

# Rendi eseguibili gli script
chmod +x lgdock_unified.sh test_lgdock.sh

# Copia in ~/.local/bin
cp lgdock_unified.sh ~/.local/bin/lgdock
cp test_lgdock.sh ~/.local/bin/lgdock-test

# Aggiungi a PATH se necessario (aggiungi a ~/.bashrc)
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Verifica
which lgdock
lgdock --version
```

### Opzione C: Uso dalla Directory Corrente

```bash
# Semplicemente rendi eseguibile
chmod +x lgdock_unified.sh test_lgdock.sh

# Usa con ./
./lgdock_unified.sh --help
```

## Test Installazione

```bash
# Con installazione sistema/locale
lgdock-test

# Dalla directory corrente
./test_lgdock.sh
```

## Primo Avvio

### Uso Locale (Linux Desktop)

```bash
# Test sistema
lgdock-test

# Avvia container
lgdock

# Con demo
lgdock --demo
```

### Uso Remoto (SSH da Windows/MobaXterm)

```bash
# Connettiti con X11 forwarding
ssh -X user@server

# Sul server
lgdock-test

# Avvia con socat
lgdock --socat

# Con demo
lgdock --demo --socat
```

## Requisiti

### Sempre Necessari

- Docker installato e funzionante
- Bash 4.0+

### Solo per Modalità --socat

```bash
# Su Fedora/RHEL
sudo dnf install socat xorg-x11-xauth

# Su Ubuntu/Debian
sudo apt install socat xauth
```

## Struttura File Installati

### Installazione Sistema
```
/usr/local/bin/
├── lgdock                    # Script principale
└── lgdock-test              # Script di test

/usr/share/doc/lgdock/       # Documentazione (opzionale)
├── README_lgdock.md
└── QUICKREF_lgdock.txt
```

### Installazione Locale
```
~/.local/bin/
├── lgdock                    # Script principale
└── lgdock-test              # Script di test
```

## Comandi Principali

```bash
lgdock                # Avvia container (standard)
lgdock --socat        # Avvia container (socat per SSH)
lgdock --demo         # Installa demo e avvia
lgdock --help         # Help completo
lgdock --version      # Mostra versione
lgdock-test           # Test sistema
```

## Quick Test

Dopo l'installazione, prova subito:

```bash
# Test installazione
lgdock --version

# Test sistema
lgdock-test

# Test X11 (se sei in locale)
lgdock
# Nel container:
xclock &
```

## Risoluzione Problemi

### lgdock: command not found (dopo installazione locale)

```bash
# Aggiungi ~/.local/bin al PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Permission denied

```bash
# Rendi eseguibile
chmod +x lgdock_unified.sh

# Oppure usa bash
bash lgdock_unified.sh --help
```

### Docker richiede sudo

```bash
# Aggiungi il tuo utente al gruppo docker
sudo usermod -aG docker $USER

# Riavvia la sessione o usa:
newgrp docker
```

### X11 non funziona

```bash
# Prova modalità socat
lgdock --socat

# Oppure verifica DISPLAY
echo $DISPLAY

# Su SSH, abilita X11 forwarding
ssh -X user@host
```

## Disinstallazione

### Installazione Sistema

```bash
sudo rm /usr/local/bin/lgdock
sudo rm /usr/local/bin/lgdock-test
sudo rm -rf /usr/share/doc/lgdock
```

### Installazione Locale

```bash
rm ~/.local/bin/lgdock
rm ~/.local/bin/lgdock-test
```

## Link Utili

- **Documentazione completa**: Leggi `README_lgdock.md`
- **Quick Reference**: Leggi `QUICKREF_lgdock.txt`
- **Help dello script**: `lgdock --help`

## Supporto

Per problemi o domande:
1. Esegui `lgdock-test` per diagnostica
2. Controlla `README_lgdock.md` per dettagli
3. Verifica `QUICKREF_lgdock.txt` per comandi comuni

---

**Versione**: 1.1  
**Data**: Novembre 2024  
**License**: Per uso con LegoPST
