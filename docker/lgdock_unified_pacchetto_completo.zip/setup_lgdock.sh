#!/bin/bash
#
# Setup script per lgdock
# Installa e configura lgdock per l'uso
#

set -e

echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║                    lgdock Setup & Installation                        ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""

# Colori
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Directory di installazione
INSTALL_DIR="/usr/local/bin"
USE_SUDO=""

# Determina se serve sudo
if [ -w "$INSTALL_DIR" ]; then
    echo "✓ Hai permessi di scrittura in $INSTALL_DIR"
else
    echo "→ Serve sudo per installare in $INSTALL_DIR"
    USE_SUDO="sudo"
fi

echo ""
echo -e "${BLUE}Configurazione:${NC}"
echo "  Directory installazione: $INSTALL_DIR"
echo "  Comando installazione: ${USE_SUDO:-nessuno}"
echo ""

# Funzione per copiare file
install_file() {
    local source="$1"
    local dest="$2"
    local name="$3"
    
    if [ -f "$source" ]; then
        echo -n "  → Installazione $name... "
        $USE_SUDO cp "$source" "$dest"
        $USE_SUDO chmod +x "$dest"
        echo -e "${GREEN}OK${NC}"
        return 0
    else
        echo -e "  → $name... ${YELLOW}NON TROVATO${NC}"
        return 1
    fi
}

# =============================================================================
# Fase 1: Verifica file necessari
# =============================================================================
echo -e "${BLUE}Fase 1: Verifica file${NC}"

REQUIRED_FILES=(
    "lgdock_unified.sh:Script principale"
    "test_lgdock.sh:Script di test"
)

OPTIONAL_FILES=(
    "README_lgdock.md:Documentazione"
    "QUICKREF_lgdock.txt:Quick reference"
)

MISSING_REQUIRED=0
for file_info in "${REQUIRED_FILES[@]}"; do
    file="${file_info%%:*}"
    desc="${file_info##*:}"
    
    if [ -f "$file" ]; then
        echo -e "  ✓ $desc: ${GREEN}trovato${NC}"
    else
        echo -e "  ✗ $desc: ${YELLOW}MANCANTE${NC}"
        ((MISSING_REQUIRED++))
    fi
done

if [ $MISSING_REQUIRED -gt 0 ]; then
    echo ""
    echo "ERRORE: Mancano file necessari!"
    echo "Assicurati di essere nella directory corretta con tutti i file."
    exit 1
fi

echo ""

# =============================================================================
# Fase 2: Scelta tipo di installazione
# =============================================================================
echo -e "${BLUE}Fase 2: Tipo di installazione${NC}"
echo ""
echo "Scegli il tipo di installazione:"
echo "  1) Sistema (/usr/local/bin) - disponibile per tutti gli utenti"
echo "  2) Locale (~/.local/bin) - solo per il tuo utente"
echo "  3) Directory corrente - nessuna installazione, solo rendi eseguibile"
echo ""
read -p "Scelta [1/2/3]: " CHOICE

case "$CHOICE" in
    1)
        INSTALL_DIR="/usr/local/bin"
        INSTALL_TYPE="sistema"
        ;;
    2)
        INSTALL_DIR="$HOME/.local/bin"
        USE_SUDO=""
        INSTALL_TYPE="locale"
        mkdir -p "$INSTALL_DIR"
        
        # Verifica se ~/.local/bin è nel PATH
        if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
            echo ""
            echo -e "${YELLOW}ATTENZIONE:${NC} $INSTALL_DIR non è nel tuo PATH"
            echo "Aggiungi questa riga a ~/.bashrc:"
            echo ""
            echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
            echo ""
        fi
        ;;
    3)
        INSTALL_DIR="$(pwd)"
        USE_SUDO=""
        INSTALL_TYPE="corrente"
        ;;
    *)
        echo "Scelta non valida!"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}✓${NC} Installazione $INSTALL_TYPE in: $INSTALL_DIR"
echo ""

# =============================================================================
# Fase 3: Installazione
# =============================================================================
echo -e "${BLUE}Fase 3: Installazione file${NC}"

# Script principale
if install_file "lgdock_unified.sh" "$INSTALL_DIR/lgdock" "lgdock"; then
    MAIN_INSTALLED=true
else
    MAIN_INSTALLED=false
fi

# Script di test
if [ "$INSTALL_TYPE" != "corrente" ]; then
    install_file "test_lgdock.sh" "$INSTALL_DIR/lgdock-test" "test lgdock"
else
    # In directory corrente, lascia il nome originale
    chmod +x test_lgdock.sh 2>/dev/null || true
    echo -e "  → test_lgdock.sh... ${GREEN}eseguibile${NC}"
fi

echo ""

# =============================================================================
# Fase 4: Documentazione
# =============================================================================
if [ "$INSTALL_TYPE" == "sistema" ]; then
    echo -e "${BLUE}Fase 4: Documentazione${NC}"
    
    DOC_DIR="/usr/share/doc/lgdock"
    if [ -w "/usr/share/doc" ] || [ -n "$USE_SUDO" ]; then
        echo "  → Installazione documentazione in $DOC_DIR"
        $USE_SUDO mkdir -p "$DOC_DIR"
        
        [ -f "README_lgdock.md" ] && $USE_SUDO cp README_lgdock.md "$DOC_DIR/"
        [ -f "QUICKREF_lgdock.txt" ] && $USE_SUDO cp QUICKREF_lgdock.txt "$DOC_DIR/"
        
        echo -e "  ${GREEN}✓${NC} Documentazione installata"
    fi
    echo ""
fi

# =============================================================================
# Fase 5: Verifica installazione
# =============================================================================
echo -e "${BLUE}Fase 5: Verifica installazione${NC}"

if [ "$INSTALL_TYPE" != "corrente" ]; then
    if command -v lgdock >/dev/null 2>&1; then
        LGDOCK_PATH=$(which lgdock)
        echo -e "  ${GREEN}✓${NC} lgdock trovato: $LGDOCK_PATH"
        
        # Test versione
        VERSION=$(lgdock --version 2>&1 | head -1)
        echo "  → Versione: $VERSION"
    else
        echo -e "  ${YELLOW}⚠${NC} lgdock non trovato nel PATH"
        echo "    Potresti dover riavviare il terminale"
    fi
else
    if [ -x "lgdock_unified.sh" ]; then
        echo -e "  ${GREEN}✓${NC} ./lgdock_unified.sh è eseguibile"
    fi
fi

echo ""

# =============================================================================
# Fase 6: Test opzionale
# =============================================================================
echo -e "${BLUE}Fase 6: Test sistema (opzionale)${NC}"
echo ""
read -p "Vuoi eseguire il test del sistema? [s/N]: " RUN_TEST

if [[ "$RUN_TEST" =~ ^[sS]$ ]]; then
    echo ""
    if [ "$INSTALL_TYPE" != "corrente" ] && command -v lgdock-test >/dev/null 2>&1; then
        lgdock-test
    elif [ -x "test_lgdock.sh" ]; then
        ./test_lgdock.sh
    else
        echo "Script di test non trovato"
    fi
else
    echo "  → Test saltato"
fi

echo ""

# =============================================================================
# Sommario finale
# =============================================================================
echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║                      Installazione Completata!                        ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""

case "$INSTALL_TYPE" in
    sistema|locale)
        echo -e "${GREEN}✓${NC} lgdock installato con successo!"
        echo ""
        echo "Comandi disponibili:"
        echo "  lgdock              Avvia container (modalità standard)"
        echo "  lgdock --socat      Avvia container (modalità socat)"
        echo "  lgdock --demo       Installa demo e avvia container"
        echo "  lgdock --help       Mostra help completo"
        echo "  lgdock-test         Test sistema (opzionale)"
        ;;
    corrente)
        echo -e "${GREEN}✓${NC} Script resi eseguibili!"
        echo ""
        echo "Comandi disponibili (da questa directory):"
        echo "  ./lgdock_unified.sh         Avvia container"
        echo "  ./lgdock_unified.sh --help  Mostra help"
        echo "  ./test_lgdock.sh            Test sistema"
        ;;
esac

echo ""

if [ -f "QUICKREF_lgdock.txt" ]; then
    echo "Quick Reference:"
    echo "  cat QUICKREF_lgdock.txt"
    echo ""
fi

if [ -f "README_lgdock.md" ]; then
    echo "Documentazione completa:"
    echo "  less README_lgdock.md"
    echo ""
fi

echo "Prossimi passi:"
echo "  1. (Opzionale) Esegui il test: lgdock-test"
echo "  2. Avvia il container: lgdock"
echo "  3. Per SSH/MobaXterm: lgdock --socat"
echo ""

echo "Buon lavoro con LegoPST! 🚀"
